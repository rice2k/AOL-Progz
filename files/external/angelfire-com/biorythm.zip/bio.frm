VERSION 5.00
Object = "{FE0065C0-1B7B-11CF-9D53-00AA003C9CB6}#2.0#0"; "MSCOMCT2.OCX"
Begin VB.Form bioR 
   Caption         =   "Ivy Technologies' Bio-Rythm Viewer"
   ClientHeight    =   7335
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   10485
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   9.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "bio.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   7335
   ScaleWidth      =   10485
   StartUpPosition =   3  'Windows Default
   WindowState     =   2  'Maximized
   Begin VB.PictureBox cont 
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1095
      Left            =   720
      ScaleHeight     =   1095
      ScaleWidth      =   7455
      TabIndex        =   3
      Top             =   120
      Width           =   7455
      Begin VB.CheckBox chkVert 
         Caption         =   "Vert"
         Height          =   255
         Left            =   6600
         TabIndex        =   15
         Top             =   420
         Width           =   735
      End
      Begin VB.CheckBox chkHorz 
         Caption         =   "Horz"
         Height          =   255
         Left            =   6600
         TabIndex        =   14
         Top             =   720
         Width           =   735
      End
      Begin VB.CheckBox chkAxes 
         Caption         =   "Axes"
         Height          =   255
         Left            =   6600
         TabIndex        =   13
         Top             =   120
         Value           =   1  'Checked
         Width           =   735
      End
      Begin VB.ComboBox cmb 
         Height          =   360
         Left            =   2520
         Style           =   2  'Dropdown List
         TabIndex        =   10
         Top             =   120
         Width           =   1455
      End
      Begin ComCtl2.DTPicker DTPick 
         Height          =   375
         Index           =   1
         Left            =   720
         TabIndex        =   8
         Top             =   120
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         _Version        =   393216
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   9
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Format          =   24510465
         CurrentDate     =   37650
      End
      Begin ComCtl2.DTPicker DTPick 
         Height          =   375
         Index           =   2
         Left            =   720
         TabIndex        =   5
         Top             =   600
         Width           =   1455
         _ExtentX        =   2566
         _ExtentY        =   661
         _Version        =   393216
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   9
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Format          =   24510465
         CurrentDate     =   37650
      End
      Begin VB.TextBox txt 
         Height          =   360
         Left            =   3120
         MaxLength       =   5
         TabIndex        =   4
         Text            =   "65432"
         Top             =   628
         Width           =   735
      End
      Begin VB.Label lblGrid 
         BackColor       =   &H80000010&
         Height          =   855
         Left            =   6360
         TabIndex        =   17
         ToolTipText     =   "Click to apply grid visibility."
         Top             =   120
         Width           =   60
      End
      Begin VB.Shape shKey 
         BorderColor     =   &H00000000&
         FillColor       =   &H00FF0000&
         FillStyle       =   0  'Solid
         Height          =   210
         Index           =   3
         Left            =   4245
         Shape           =   3  'Circle
         Top             =   735
         Width           =   135
      End
      Begin VB.Label lblKey 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Intelligence (33 days)"
         Height          =   240
         Index           =   3
         Left            =   4440
         TabIndex        =   16
         Top             =   720
         Width           =   1845
      End
      Begin VB.Label lblKey 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Physical (23 days)"
         Height          =   240
         Index           =   1
         Left            =   4440
         TabIndex        =   12
         Top             =   120
         Width           =   1545
      End
      Begin VB.Label lblKey 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Emotional (28 days)"
         Height          =   240
         Index           =   2
         Left            =   4440
         TabIndex        =   11
         Top             =   420
         Width           =   1710
      End
      Begin VB.Shape Shape1 
         Height          =   1095
         Left            =   0
         Shape           =   4  'Rounded Rectangle
         Top             =   0
         Width           =   7455
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "DOB:"
         Height          =   240
         Left            =   210
         TabIndex        =   9
         Top             =   195
         Width           =   435
      End
      Begin VB.Label Label3 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         Caption         =   "Days:"
         Height          =   240
         Left            =   2625
         TabIndex        =   7
         Top             =   675
         Width           =   495
      End
      Begin VB.Label Label2 
         AutoSize        =   -1  'True
         Caption         =   "Date:"
         Height          =   240
         Left            =   210
         TabIndex        =   6
         Top             =   675
         Width           =   465
      End
      Begin VB.Shape shKey 
         BorderColor     =   &H00000000&
         FillColor       =   &H000000FF&
         FillStyle       =   0  'Solid
         Height          =   210
         Index           =   1
         Left            =   4245
         Shape           =   3  'Circle
         Top             =   135
         Width           =   135
      End
      Begin VB.Shape shKey 
         BorderColor     =   &H00000000&
         FillColor       =   &H0000C000&
         FillStyle       =   0  'Solid
         Height          =   210
         Index           =   2
         Left            =   4245
         Shape           =   3  'Circle
         Top             =   435
         Width           =   135
      End
   End
   Begin VB.PictureBox PicDt 
      AutoRedraw      =   -1  'True
      BackColor       =   &H00808080&
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   240
      Left            =   120
      ScaleHeight     =   240
      ScaleWidth      =   9855
      TabIndex        =   1
      Top             =   1320
      Width           =   9855
      Begin VB.Label lbl 
         BackColor       =   &H00C0C0FF&
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   120
         Index           =   0
         Left            =   3000
         TabIndex        =   2
         Top             =   60
         Width           =   120
      End
   End
   Begin VB.PictureBox pic 
      AutoRedraw      =   -1  'True
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      FillColor       =   &H00C0C0C0&
      FillStyle       =   0  'Solid
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   4455
      Left            =   120
      ScaleHeight     =   4455
      ScaleWidth      =   9855
      TabIndex        =   0
      Top             =   1600
      Width           =   9855
   End
End
Attribute VB_Name = "bioR"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private twoPi As Double
Private strDOBs As String
Private Dys(3) As Byte
Dim rX As Integer, ry As Integer, Xy As Boolean


Private Sub Form_Load()
twoPi = 44 / 7
rX = -1: rX = -1

Dys(1) = 23 'Physical
Dys(2) = 28 'Emotional
Dys(3) = 33 'Intellectual

shKey(1).FillColor = vbRed
shKey(2).FillColor = vbGreen
shKey(3).FillColor = vbBlue


For i = 1 To 30
  Load lbl(i)
  lbl(i).Visible = True
Next

lbl(15).BackColor = Me.BackColor

DTPick(2).Value = Date

cmb.AddItem "..Clear.."

Dim strTmp() As String, strDOBs As String
strDOBs = GetSetting(App.CompanyName, App.ProductName, "DOB History")
strTmp = Split(strDOBs, ",")
For i = 0 To UBound(strTmp) - 1
  cmb.AddItem strTmp(i)
Next

'If cmb.ListCount > 1 Then cmb.ListIndex = 1 Else cmb.ListIndex = 0

End Sub

Private Sub cmb_Click()
If cmb.Text = "..Clear.." Then
  If cmb.ListCount = 1 Then Exit Sub ' = (1)
  m = MsgBox("Are you sure you want to purge recent birthdays?", vbYesNo)
  If m = vbYes Then
    cmb.Clear
    cmb.AddItem "..Clear.."
    strDOBs = ""
    cmb.ListIndex = 0 'this will cause this sub to be re-executed hence the NEED for (1)
  End If
  Exit Sub
End If

If IsDate(cmb.Text) = False Then Exit Sub

DTPick(1).Value = cmb.Text
DTPick_CloseUp (2)
End Sub

Private Sub DTPick_CloseUp(Index As Integer)
'first add dob to history
Me.MousePointer = 13

If Index = 1 Then
  If InStr(strDOBs, DTPick(1).Value) = 0 Then
    strDOBs = strDOBs & DTPick(1).Value & ","
    cmb.AddItem DTPick(1).Value
    cmb.ListIndex = cmb.ListCount - 1
  End If
End If

DTPick(Index).ToolTipText = Format(DTPick(Index).Value, "dddd")

txt = DateDiff("d", DTPick(1).Value, DTPick(2).Value)

If Val(txt) < 0 Then
  MsgBox "Cannot go back in time.", vbExclamation, App.Title & ":Improper Date Error"
  txt = "[none]"

Else

  'now cal & display offset
  'If Val(txt) = 0 Then Exit Sub
Dim offs As Byte, ht As Single
pic.Cls

'draw grid
  pic.ForeColor = vbWhite 'grid color
    
    'vertical gridlines
  If chkVert.Value = 1 Then
    For i = 0 To 30 '0.05 * pic.ScaleHeight To pic.ScaleHeight - 0.05 * pic.ScaleHeight Step 0.9 * pic.ScaleHeight / 18
      pic.Line (i * pic.ScaleWidth / 30, 0)-(i * pic.ScaleWidth / 30, pic.ScaleHeight)
    Next
  End If
  
  ht = pic.ScaleHeight / 2
    'horizontal gridlines
  If chkHorz.Value = 1 Then
    For i = 1 To 5
      y = i / 5 * 0.9 * ht
      pic.Line (0, ht + y)-(pic.Width, ht + y)
      pic.Line (0, ht - y)-(pic.Width, ht - y)
    Next
  End If
  
  'to draw axes
  If chkAxes.Value = 1 Then
    pic.ForeColor = vbWhite 'axes color
    pic.Line (0, ht)-(pic.ScaleWidth, ht)
    pic.Line (pic.ScaleWidth / 2, 0)-(pic.ScaleWidth / 2, pic.ScaleHeight)
  End If
  
'continue with sine waves

  For i = 1 To 3
    pic.ForeColor = shKey(i).FillColor: pic.FillColor = pic.ForeColor
    
    offs = Val(txt) Mod Dys(i)
    lblKey(i).ToolTipText = offs
    scl = twoPi / pic.ScaleWidth * 31 / Dys(i)
    xoff = pic.ScaleWidth / 2
    xoff = xoff - offs * (pic.Width / 30)
    
    
    For x = 0 To pic.ScaleWidth Step 20
      pic.Circle (x, ht - Sin((x - xoff) * scl) * 0.9 * ht), 30
    Next
  Next
  
'tooltips for placeholders
  'make day placeholders tooltips show their dates
  Dim cDat As Date
  cDat = DTPick(2).Value
  lbl(15).ToolTipText = Format(cDat, "dddd, mmmm dd yyyy")
  For i = -14 To 15
    cDat = DateAdd("d", i, DTPick(2).Value)
    lbl(15 + i).ToolTipText = Format(cDat, "dddd, mmmm dd yyyy")
    If Weekday(cDat) = 1 Then lbl(15 + i).BorderStyle = 1 Else lbl(15 + i).BorderStyle = 0
    
  'calculate PEI product and indicate local maxima/minima
    'pei = 50 + 50 / 3 * (Sin(twoPi * (Val(txt + i) Mod Dys(1)) / Dys(1)) + _
                            Sin(twoPi * (Val(txt + i) Mod Dys(1)) / Dys(1)) + _
                            Sin(twoPi * (Val(txt + i) Mod Dys(1)) / Dys(1)))
    'lbl(15 + i).ToolTipText = lbl(15 + i).ToolTipText & vbCrLf & Format(pei, "##.##")
  Next

  
End If

Me.MousePointer = 0
End Sub

Private Sub Form_Resize()
If Me.WindowState = 1 Then Exit Sub

pic.Visible = False

If Me.Width < cont.Width + 800 Then Me.Width = cont.Width + 800
cont.Left = (Me.Width - cont.Width) / 2
pic.Width = Me.ScaleWidth - 2 * pic.Left
PicDt.Width = pic.Width
pic.Height = Me.ScaleHeight - pic.Top - pic.Left
DTPick_CloseUp (2)

pic.Visible = True
End Sub

Private Sub Form_Unload(Cancel As Integer)
  SaveSetting App.CompanyName, App.ProductName, "DOB History", strDOBs
  End
  DeleteSetting App.CompanyName, App.ProductName  ', "DOB History"

For i = 1 To cmb.ListCount - 1
  SaveSetting App.CompanyName, App.ProductName, i, cmb.List(i)
Next
End Sub

Private Sub lblGrid_Click()
  DTPick_CloseUp (2)
End Sub

Private Sub PicDt_Resize()
For i = 0 To 30
  lbl(i).Left = i * PicDt.Width / 30 - lbl(i).Width / 2
Next
End Sub

Private Sub txt_KeyDown(KeyCode As Integer, Shift As Integer)
If KeyCode = vbKeyReturn Then _
  DTPick(2).Value = DateAdd("d", Val(txt), DTPick(1).Value): _
  DTPick_CloseUp (2)
End Sub
