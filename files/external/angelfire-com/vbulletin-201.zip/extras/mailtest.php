<html><head><title>PHP Mail Tester</title></head>
<body>
<?php

if ($address=="") {

  echo "<form action=\"mailtest.php\" method=get><p>Address to email: <input type=text name=address></p>";
  echo "<p><input type=submit value=\"Send email\"></p>";

} else {

  mail("$address","Testing mail() function","This is a test email");

  echo "<p>Mail sent. Were any errors shown? If there were, mail is probably not set up correctly.</p>";

}

?>
</body>
</html>