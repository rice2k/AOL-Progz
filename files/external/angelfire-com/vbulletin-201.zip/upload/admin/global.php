<?php
$incp=1;

// get rid of slashes in get / post / cookie data
function stripslashesarray (&$arr) {
  while (list($key,$val)=each($arr)) {
    if ((strtoupper($key)!=$key or "".intval($key)=="$key") and $key!="templatesused" and $key!="argc" and $key!="argv") {
			if (is_string($val)) {
				$arr[$key]=stripslashes($val);
			}
			if (is_array($val)) {
				$arr[$key]=stripslashesarray($val);
			}
	  }
  }
  return $arr;
}
if (get_magic_quotes_gpc() and is_array($GLOBALS)) {
  $GLOBALS=stripslashesarray($GLOBALS);
}
set_magic_quotes_runtime(0);

// version numbers:
$codeversionnumber="2.0.1";
$codeinfo="";

error_reporting(7);

if ($HTTP_GET_VARS['HTTP_POST_VARS']['action'] == $HTTP_POST_VARS['action']) {
  unset($HTTP_POST_VARS['action']);
}
$HTTP_POST_VARS['action'] = trim($HTTP_POST_VARS['action']);

if ($HTTP_GET_VARS['HTTP_COOKIE_VARS']['bbadminon'] == $HTTP_COOKIE_VARS['bbadminon']) {
  unset($HTTP_POST_VARS['action']);
}

// ###################### Start init #######################
//load config
require("./config.php");

// init db **********************
// load db class
$dbclassname="./db_$dbservertype.php";
require($dbclassname);

$DB_site=new DB_Sql_vb;

$DB_site->appname="vBulletin Control Panel";
$DB_site->appshortname="vBulletin (cp)";
$DB_site->database=$dbname;
$DB_site->server=$servername;
$DB_site->user=$dbusername;
$DB_site->password=$dbpassword;

$DB_site->connect();

$dbpassword="";
$DB_site->password="";
// end init db

// load options
$optionstemp=$DB_site->query_first("SELECT template FROM template WHERE title='options'");
eval($optionstemp[template]);
$versionnumber=$templateversion;

// ###################### Start headers #######################
/*
$noheader=1;
if ($addheaders and !$noheader) {
  // default headers
  header("HTTP/1.0 200 OK");
  header("HTTP/1.1 200 OK");
  header("Content-type: text/html");
}
*/

if ($nocacheheaders and !$noheader) {
  // no caching
  header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");             // Date in the past
  header("Last-Modified: " . gmdate("D, d M Y H:i:s") . "GMT"); // always modified
  header("Cache-Control: no-cache, must-revalidate");           // HTTP/1.1
  header("Pragma: no-cache");                                   // HTTP/1.0
}

// ###################### Start functions #######################
require("./functions.php");
require("./adminfunctions.php");


// ###################### Start sessions #######################
/*if (!isset($bbadminon) and !$bbadminon) {
  $sessionhash="";
  $bbuserinfo[userid]="";
  $bbuserinfo[password]="";
}*/

require("./sessions.php");

/*
if (isset($loginusername)) {
  if ($user=$DB_site->query_first("SELECT userid,password FROM user WHERE username='".addslashes($loginusername)."'")) {
    if ($user[password]==$password) {
      $userid=$user[userid];
      $bbuserinfo=getuserinfo($userid);
      $DB_site->query("UPDATE session SET userid='$userid' WHERE sessionhash='$session[dbsessionhash]'");
    }
  }
}
*/

$getperms=$DB_site->query_first("SELECT cancontrolpanel FROM user,usergroup WHERE user.usergroupid=usergroup.usergroupid AND user.userid='$bbuserinfo[userid]'");
if ($getperms[cancontrolpanel]!=1) {
  $bbuserinfo[userid]=0;
}

if ($bbuserinfo[userid]!=0 and $loginusername and !$createanonsession) {
  setcookie("bbadminon",1,0,'/');
  $HTTP_COOKIE_VARS['bbadminon']=1;
} else {
  if ($bbuserinfo[userid]==0) {
    $HTTP_COOKIE_VARS['bbadminon']=0;
  }
}

if ($debug!=1) {
  // check for files existance. Potential security risks!
	if (file_exists("install.php")==1) {
		echo "<html><body><p>Security alert! install.php still remains in the admin directory. This poses a security risk, so please delete that file immediately. You cannot access the control panel until you do.</p></body></html>";
		exit;
	}

	if (file_exists("upgrade.php")==1 and substr($PHP_SELF,-strlen("upgrade.php"))!="upgrade.php") {
		echo "<html><body><p><a href=\"upgrade.php?s=$session[sessionhash]\">upgrade.php</a> exists. If you have already upgraded fully, please delete it. Otherwise, run it now.</p></body></html>";
		exit;
	}
}

$checkpwd=1;
if ($HTTP_COOKIE_VARS['bbadminon']==0 and substr($PHP_SELF,-strlen("upgrade.php"))!="upgrade.php" and $checkpwd) {
  $bbuserinfo[userid]=0;
} else {
  /*
  if ($bbuserinfo['userid']!=0  and $loginusername and !$createanonsession) {
    setcookie("bbadminon",1,0,'/');
  }
  */
}

if ($bbuserinfo[userid]==0 and $checkpwd) {

  cpheader("<title>Forums admin</title>");
?><br><br><br>
<table cellpadding="1" cellspacing="0" border="0" class="tblborder" align="center" width="450"><tr><td>
<table cellpadding="4" cellspacing="0" border="0" width="100%">
<?php maketableheader("Please Log in:","login",0,1); ?>
<tr class="firstalt" id="submitrow"><td align="center" nowrap><p>You are either not a valid administrator or have not logged in.</p>
<form action="../admin/index.php" method="post" id="submitrow">
<input type="hidden" name="s" value="<?php echo $session[sessionhash]; ?>">
<input type="hidden" name="action" value="login">
<input type="hidden" name="redirect" value="<?php

if (GETENV("REQUEST_URI")!="") {
  $url = GETENV("REQUEST_URI");
} else {
  if ($PATH_INFO) {
    $url = $PATH_INFO;
  } else {
    $url = $PHP_SELF;
  }

  if ($QUERY_STRING) {
    $url .= "?$QUERY_STRING";
  }
}

  $url=ereg_replace("sessionhash=[a-z0-9]{32}&","",$url);
  $url=ereg_replace("\\?sessionhash=[a-z0-9]{32}","",$url);
  $url=ereg_replace("s=[a-z0-9]{32}&","",$url);
  $url=ereg_replace("\\?s=[a-z0-9]{32}","",$url);

echo htmlspecialchars($url);

?>">
<input type="text" name="loginusername">
<input type="password" name="loginpassword">
<input type="submit" value="   Log in   " accesskey="s">
</form>
</td></tr></table>
</td></tr></table>
<p align="center"><font size="1">vBulletin v<?php echo $templateversion ?> Administrator Control Panel</font></p>
<?php
  cpfooter();
  exit;
}

?>