<?php

$onvservers=0; // set this to 1 if you're on Vservers and get disconnected after running an ALTER TABLE command

error_reporting(7);

if (function_exists("set_time_limit")==1 and get_cfg_var("safe_mode")==0) {
  @set_time_limit(1200);
}
// ignore user abort??
set_magic_quotes_runtime(0);

if (!file_exists("./config.php")) {
  echo "<p>Please upload your config.php file</p>";
  exit;
}
require ("./config.php");

// init db **********************
// load db class
$dbclassname="./db_$dbservertype.php";
require($dbclassname);

  if ($onvservers) {
    $usepconnect = 0;
  }


$DB_site=new DB_Sql_vb;

$DB_site->appname="vBulletin Upgrade";
$DB_site->appshortname="vBulletin (upg)";
$DB_site->database=$dbname;
$DB_site->server=$servername;
$DB_site->user=$dbusername;
$DB_site->password=$dbpassword;

$DB_site->connect();
// end init db

// load options
$optionstemp=$DB_site->query_first("SELECT template FROM template WHERE title='options'");
eval($optionstemp[template]);
$versionnumber=$templateversion;

// ###################### Start cookies #######################
if (isset($username)!=0 and $username!="" and isset($password)!=0) {
  if (strpos($username,"%")>0) {
    $username=urldecode($username);
  }
  $bbuserid=0;
  $bbpassword="";
  if ($userinfo=$DB_site->query_first("SELECT userid,password FROM user WHERE username='".addslashes($username)."' AND password='".addslashes($password)."'")) {
    if ($userinfo[password]==$password) {
      setcookie("bbuserid",$userinfo[userid],mktime(0,0,0,0,0,2020),$cookiepath);
      setcookie("bbpassword",substr(md5($userinfo[password]),0,strlen($userinfo[password])),mktime(0,0,0,0,0,2020),$cookiepath);
      $bbuserid=$userinfo[userid];
      $bbpassword=substr(md5($userinfo[password]),0,strlen($userinfo[password]));

      setcookie("bbadminon",1,0,'/');
      $bbadminon=1;
    }
  }
}

$bbusergroupid=1;

if (isset($bbuserid)!=0 and $bbuserid!=0 and isset($bbpassword)!=0) {

  $bbuserid=$bbuserid;
  if ($userinfo=$DB_site->query_first("SELECT username,password,usergroupid FROM user WHERE userid=$bbuserid")) {
    if ($bbpassword==$userinfo[password] or $bbpassword==substr(md5($userinfo[password]),0,strlen($userinfo[password]))) {
      $bbusergroupid=$userinfo[usergroupid];

    } else {
      $bbuserid=0;
    }
  } else {
    $bbuserid=0;
  }
} else {
  $bbuserid=0;
}

$getperms=$DB_site->query_first("SELECT cancontrolpanel FROM user,usergroup WHERE user.usergroupid=usergroup.usergroupid AND user.userid=$bbuserid");
if ($getperms[cancontrolpanel]!=1 or !$bbadminon) {
  $bbuserid=0;
}

if ($bbuserid==0) {
?>
<html>
<head><title>Forums admin</title>
<body>
<p>You are either not a valid administrator or have not logged in. Please log in now:</p>
<form action="upgrade1.php" method=post>
<input type="hidden" name="redirect" value="upgrade1.php">
<input type="text" name="username">
<input type="password" name="password">
<input type="submit" value="Submit">
</form>
</body>
</html>
<?php
  exit;
}


if (!isset($dbservertype) or !isset($servername) or !isset($dbusername) or !isset($dbpassword) or !isset($dbname) or !isset($pwdincp) or !isset($technicalemail) or !isset($usepconnect)) {
  $filehandle=@fopen("./config.php","w");
  if ($filehandle) {
    $filedata="<"."?php

/////////////////////////////////////////////////////////////
// Please note that if you get any errors when connecting, //
// that you will need to email your host as we cannot tell //
// you what your specific values are supposed to be        //
/////////////////////////////////////////////////////////////

// type of database running
// (only mysql is supported at the moment)
\$dbservertype=\"$dbservertype\";

// hostname or ip of server
\$servername=\"$servername\";

// username and password to log onto db server
\$dbusername=\"$dbusername\";
\$dbpassword=\"$dbpassword\";

// name of database
\$dbname=\"$dbname\";

// allow password viewing / editing in control panel
// 0 = not visible or editable
// 1 = not visible, but can be edited
// 2 = visible and can be edited
\$pwdincp=$pwdincp;

// technical email address - any error messages will be emailed here
\$technicalemail = \"$technicalemail\";

// use persistant connections to the database
// 0 = don't use
// 1 = use
\$usepconnect = 1;

?".">";
    fwrite($filehandle,$filedata);
    fclose($filehandle);
  } else {
    echo "<p>Please be sure to upgrade your config.php to vBulletin 2.0 standard before continuing with the upgrade.</p>";
    exit;
  }
}

function iif($condition,$truevalue,$falsevalue) {
  if ($condition) {
    return $truevalue;
  } else {
    return $falsevalue;
  }
}

function doqueries () {
  global $DB_site,$query,$explain,$onvservers;

  while (list($key,$val)=each($query)) {
    echo "<p>$explain[$key]</p>\n";
    echo "<!-- ".htmlspecialchars($val)." -->\n\n";
    flush();
    if ($onvservers==1 and substr($val, 0, 5)=="ALTER") {
      $DB_site->reporterror=0;
    }
    $DB_site->query($val);
    if ($onvservers==1 and substr($val, 0, 5)=="ALTER") {
      $DB_site->link_id=0;
      @mysql_close();
      $DB_site->connect();
      $DB_site->reporterror=1;
    }
  }

  unset ($query);
  unset ($explain);
}

if (!isset($action)) {
?>
<HTML><HEAD>
<META content="text/html; charset=windows-1252" http-equiv=Content-Type>
<META content="MSHTML 5.00.3018.900" name=GENERATOR></HEAD>
<link rel="stylesheet" href="../cp.css">
<title>vBulletin 2.0.0 Upgrade script</title>
</HEAD>
<BODY>
<table width="100%" bgcolor="#3F3849" cellpadding="2" cellspacing="0" border="0"><tr><td>
<table width="100%" bgcolor="#524A5A" cellpadding="3" cellspacing="0" border="0"><tr>
<td><a href="http://vbulletin.com/forum" target="_blank"><img src="cp_logo.gif" width="160" height="49" border="0" alt="Click here to visit the vBulletin support forums"></a></td>
<td width="100%" align="center">
<p><font size="2" color="#F7DE00"><b>vBulletin 2.0.0 Upgrade Script</b></font></p>
<p><font size="1" color="#F7DE00"><b>(Note: Please be patient as some parts of this may take some time.)</b></font></p>
</td></tr></table></td></tr></table>
<br>
<?php
flush();
}

if ($step=="") {
  $step=1;
}
if ($step=="backup") {
  // data dump functions
  function sqldumptable($table) {
    global $DB_site;

    $tabledump = "DROP TABLE IF EXISTS $table;\n";
    $tabledump .= "CREATE TABLE $table (\n";

    $firstfield=1;

    // get columns and spec
    $fields = $DB_site->query("SHOW FIELDS FROM $table");
    while ($field = $DB_site->fetch_array($fields)) {
      if (!$firstfield) {
        $tabledump .= ",\n";
      } else {
        $firstfield=0;
      }
      $tabledump .= "   $field[Field] $field[Type]";
      if (!empty($field["Default"])) {
        // get default value
        $tabledump .= " DEFAULT '$field[Default]'";
      }
      if ($field[Null] != "YES") {
        // can field be null
        $tabledump .= " NOT NULL";
      }
      if ($field[Extra] != "") {
        // any extra info?
        $tabledump .= " $field[Extra]";
      }
    }

    // get keys list
    $keys = $DB_site->query("SHOW KEYS FROM $table");
    while ($key = $DB_site->fetch_array($keys)) {
      $kname=$key['Key_name'];
      if ($kname != "PRIMARY" and $key['Non_unique'] == 0) {
        $kname="UNIQUE|$kname";
      }
      if(!is_array($index[$kname])) {
        $index[$kname] = array();
      }
      $index[$kname][] = $key['Column_name'];
    }

    // get each key info
    while(list($kname, $columns) = @each($index)){
      $tabledump .= ",\n";
      $colnames=implode($columns,",");

      if($kname == "PRIMARY"){
        // do primary key
        $tabledump .= "   PRIMARY KEY ($colnames)";
      } else {
        // do standard key
        if (substr($kname,0,6) == "UNIQUE") {
          // key is unique
          $kname=substr($kname,7);
        }

        $tabledump .= "   KEY $kname ($colnames)";

      }
    }

    $tabledump .= "\n);\n\n";

    // get data
    $rows = $DB_site->query("SELECT * FROM $table");
    $numfields=mysql_num_fields($rows);
    while ($row = $DB_site->fetch_array($rows)) {
      $tabledump .= "INSERT INTO $table VALUES(";

      $fieldcounter=-1;
      $firstfield=1;
      // get each field's data
      while (++$fieldcounter<$numfields) {
        if (!$firstfield) {
          $tabledump.=",";
        } else {
          $firstfield=0;
        }

        if (!isset($row[$fieldcounter])) {
          $tabledump .= "NULL";
        } else {
          $tabledump .= "'".addslashes($row[$fieldcounter])."'";
        }
      }

      $tabledump .= ");\n";
    }
    return $tabledump;
  }

  function csvdumptable($table,$separator,$quotes,$showhead) {
    global $DB_site;

    $quotes=stripslashes($quotes);

    // get columns for header row
    if ($showhead) {
      $firstfield=1;
      $fields = $DB_site->query("SHOW FIELDS FROM $table");
      while ($field = $DB_site->fetch_array($fields)) {
        if (!$firstfield) {
          $contents.=$separator;
        } else {
          $firstfield=0;
        }
        $contents.=$quotes.$field[Field].$quotes;
      }
    }
    $contents.="\n";


    // get data
    $rows = $DB_site->query("SELECT * FROM $table");
    $numfields=mysql_num_fields($rows);
    while ($row = $DB_site->fetch_array($rows)) {

      $fieldcounter=-1;
      $firstfield=1;
      while (++$fieldcounter<$numfields) {
        if (!$firstfield) {
          $contents.=$separator;
        } else {
          $firstfield=0;
        }

        if (!isset($row[$fieldcounter])) {
          $contents .= "NULL";
        } else {
          $contents .= $quotes.addslashes($row[$fieldcounter]).$quotes;
        }
      }

      $contents .= "\n";
    }

    return $contents;
  }

  if ($action=="csvtable") {
    header("Content-disposition: $table.csv");
    header("Content-type: text/plain");

    echo csvdumptable($table,$separator,$quotes,$showhead);

    exit;

  }

  if ($action=="sqltable") {
      header("Content-type: text/plain");

    if (isset($table)) {
      header("Content-disposition: $table.sql");
      echo sqldumptable($table);
    } else {
      header("Content-disposition: vbulletin.sql");
      $result=$DB_site->query("SHOW tables");
      while ($currow=$DB_site->fetch_array($result)) {
        echo sqldumptable($currow[0])."\n\n\n";
      }
    }

    exit;

  }


  if (isset($action)==0) {
    $action="choose";
  }

  if ($action=="choose") {

    ?>
    <p>From here, you can back up your vBulletin database.</p>
    <p><font size=1>Please note that if you have a particularly large database,
	this script <i>may</i> not be able to fully back it up.
	For a foolproof backup, login to your server via Telnet or SSH and use the <i>mysqldump</i>
	command on the command line. For more details,
	<a href="http://vbulletin.com/forum/showthread.php?s=&postid=106506#post106506" target="_blank">read this</a>.
	</font></p>

    <P><b>SQL Dump of data:</b></p>

    <p><a href="upgrade1.php?step=backup&action=sqltable">Back up whole database!</a></p>

    <p><b>OR:</b></p>
    <form action="upgrade1.php" method="post">
    <input type="hidden" name="action" value="sqltable">
    <input type="hidden" name="step" value="backup">

    <?php

    echo "<p>Individual table: <select name=\"table\" size=\"1\">\n";

    $result=$DB_site->query("SHOW tables");
    while ($currow=$DB_site->fetch_array($result)) {
      echo "<option value=\"$currow[0]\">$currow[0]</option>\n";
    }

    echo "</select>\n</p>\n";

    echo "<input type=\"submit\" value=\"Submit!\"></form>";

    echo "<hr>\n";

    echo "<P><b>CSV Dump of data:</b></p>";
    ?>

    <form action="upgrade1.php" method="post">
    <input type="hidden" name="action" value="csvtable">
    <input type="hidden" name="step" value="backup">

    <?php

    echo "<p>Choose table: <select name=\"table\" size=\"1\">\n";

    $result=$DB_site->query("SHOW tables");
    while ($currow=$DB_site->fetch_array($result)) {
      echo "<option value=\"$currow[0]\">$currow[0]</option>\n";
    }

    echo "</select>\n</p>\n";

    ?>

    <p>Separator: <input type="text" name="separator" value=",">
    <BR>Quotes: <input type="text" name="quotes" value="'">
    <BR>Show column names: Yes<input type="radio" checked name="showhead" value="1"> No <input type="radio" name="showhead" value="0"></p>
    <input type="submit" value="Submit!"></form>

    <?php
  }
}

if ($step==1) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 1
------

+ Introduction
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/
?>
<p>Welcome to vBulletin version 2.0.0 . You are about to upgrade your forum, so it has been automatically shut down.</p>
<p>Clicking 'Next step -->' will begin the installation process.</p>
<p>It is recommended that you backup your entire database before proceeding. Click <a href="upgrade1.php?step=backup" target=_blank><b>here</b></a> to do that now.</p>
<?php

if (get_cfg_var("safe_mode")==1) {
  echo "<p><i>You are currently running PHP in safe mode. While running in safe mode we were unable to set your script timeout limit. It is even more important that you have made a backup on the chance that an error occurs.</i></p>";
}

$DB_site->query("UPDATE template SET template=CONCAT(template,'\n\$bbactive = 0;\n') WHERE title='options'");

echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
}  // end step 1

if ($step==2) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 2
------

+ Create all new tables
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/

$DB_site->reporterror=0;
  $DB_site->query("SELECT COUNT(*) AS count FROM privatemessage");
  $errno=$DB_site->errno;
  if (!$errno) {
    $errno = 0;
  }
$DB_site->reporterror=1;

if ($errno==0) {
  echo "We have detected that you have already tried to run the upgrade script. You will not be able to proceed unless you
  revert to a vB 1.1.x database.";
  exit;
}

$query[]="CREATE TABLE privatemessage (
   privatemessageid int(10) unsigned DEFAULT '0' NOT NULL auto_increment,
   folderid smallint(6) DEFAULT '0' NOT NULL,
   userid int(10) unsigned DEFAULT '0' NOT NULL,
   touserid int(10) unsigned DEFAULT '0' NOT NULL,
   fromuserid int(10) unsigned DEFAULT '0' NOT NULL,
   title varchar(250) NOT NULL,
   message mediumtext NOT NULL,
   dateline int(10) unsigned DEFAULT '0' NOT NULL,
   showsignature smallint(6) DEFAULT '0' NOT NULL,
   iconid smallint(5) unsigned DEFAULT '0' NOT NULL,
   messageread smallint(6) DEFAULT '0' NOT NULL,
   readtime INT (10) UNSIGNED DEFAULT '0' not null,
   receipt SMALLINT (6) UNSIGNED DEFAULT '0' not null,
   deleteprompt SMALLINT (6) UNSIGNED DEFAULT '0' not null,
   multiplerecipients SMALLINT (6) UNSIGNED DEFAULT '0' not null,
   PRIMARY KEY (privatemessageid),
   KEY userid (userid)
)";
$explain[]="Creating private message table";

$query[]="CREATE TABLE subscribeforum (
	subscribeforumid INT UNSIGNED NOT NULL AUTO_INCREMENT,
	userid INT UNSIGNED NOT NULL,
	forumid SMALLINT UNSIGNED NOT NULL,
	emailupdate SMALLINT UNSIGNED NOT NULL,
	PRIMARY KEY (subscribeforumid),
	KEY (userid)
)";
$explain[]="Creating subscribed forum table";

$query[]="CREATE TABLE subscribethread (
	subscribethreadid INT UNSIGNED NOT NULL AUTO_INCREMENT,
	userid INT UNSIGNED NOT NULL,
	threadid INT UNSIGNED NOT NULL,
	emailupdate SMALLINT UNSIGNED NOT NULL,
	PRIMARY KEY (subscribethreadid)
)";
$explain[]="Creating subscribed thread table";

$query[]="CREATE TABLE avatar (
	avatarid SMALLINT(5) UNSIGNED DEFAULT '0' NOT NULL AUTO_INCREMENT,
	title CHAR(100) NOT NULL,
	minimumposts SMALLINT NOT NULL,
	avatarpath CHAR(100) NOT NULL,
	PRIMARY KEY (avatarid)
)";
$explain[]="Creating avatar table";

$query[]="CREATE TABLE customavatar (
	userid INT UNSIGNED NOT NULL,
	avatardata MEDIUMTEXT NOT NULL,
	dateline INT UNSIGNED NOT NULL,
	filename VARCHAR(100),
	PRIMARY KEY(userid)
)";
$explain[]="Creating custom avatar table";

$query[]="CREATE TABLE attachment (
	attachmentid SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
	userid INT UNSIGNED NOT NULL,
	dateline INT UNSIGNED NOT NULL,
	filename CHAR(100) NOT NULL,
	filedata MEDIUMBLOB NOT NULL,
	visible SMALLINT UNSIGNED NOT NULL,
	counter SMALLINT UNSIGNED NOT NULL,
	PRIMARY KEY(attachmentid)
)";
$explain[]="Creating attachment table";

$DB_site->reporterror=0;
  $DB_site->query("SELECT COUNT(*) AS count FROM poll");
  $errno=$DB_site->errno;
  if (!$errno) {
    $errno = 0;
  }

  $DB_site->query("SELECT COUNT(*) AS count FROM events");
  $calerror=$DB_site->errno;
  if (!$calerror) {
    $calerror = 0;
  }
$DB_site->reporterror=1;

if ($calerror==0) {
  $query[]="ALTER TABLE events RENAME calendar_events";
  $explain[]="Renaming events table from hack to calendar events";

  $query[]="ALTER TABLE calendar_events
    CHANGE public public smallint(5) unsigned NOT NULL,
    CHANGE allowsmilies allowsmilies smallint(6) DEFAULT '1' NOT NULL";
  $explain[]="Altering calendar events table";
} else {
  $query[]="CREATE TABLE calendar_events (
  	eventid INT(10) UNSIGNED DEFAULT '0' NOT NULL AUTO_INCREMENT,
  	userid INT(10) UNSIGNED DEFAULT '0' NOT NULL,
  	event MEDIUMTEXT NOT NULL,
  	eventdate DATE DEFAULT '0000-00-00' NOT NULL,
  	public SMALLINT(5) UNSIGNED DEFAULT '0' NOT NULL,
  	subject VARCHAR(254) NOT NULL,
  	allowsmilies SMALLINT(6) DEFAULT '1' NOT NULL,
  	PRIMARY KEY (eventid),
  	KEY userid (userid)
  )";
  $explain[]="Creating calendar_events table";
}

$query[]="CREATE TABLE threadrate (
	threadrateid INT(10) UNSIGNED DEFAULT '0' NOT NULL AUTO_INCREMENT,
	threadid INT(10) UNSIGNED DEFAULT '0' NOT NULL,
	userid INT(10) UNSIGNED DEFAULT '0' NOT NULL,
	vote SMALLINT(6) DEFAULT '0' NOT NULL,
	ipaddress VARCHAR(20) NOT NULL,
	PRIMARY KEY (threadrateid),
	KEY threadid (threadid)
)";
$explain[]="Creating thread rate table";

if ($errno==0) {

  $query[]="ALTER TABLE poll
    CHANGE pollid pollid INT UNSIGNED NOT NULL AUTO_INCREMENT,
    ADD dateline INT UNSIGNED NOT NULL,
    ADD votes TEXT NOT NULL,
    ADD numberoptions SMALLINT UNSIGNED NOT NULL,
    ADD timeout SMALLINT UNSIGNED NOT NULL";
  $explain[]="Altering poll table from hack";

  $query[]="ALTER TABLE pollvote
    CHANGE pollvoteid pollvoteid INT UNSIGNED NOT NULL AUTO_INCREMENT,
    CHANGE pollid pollid INT UNSIGNED NOT NULL,
    CHANGE userid userid INT UNSIGNED NOT NULL";
  $explain[]="Altering poll vote table from hack";

  $query[]="ALTER TABLE pollvote ADD INDEX (userid,pollid)";
  $explain[]="Adding indexes to poll vote table from hack";

} else {

  $query[]="CREATE TABLE poll (
    pollid INT UNSIGNED NOT NULL AUTO_INCREMENT,
    question CHAR(100) NOT NULL,
    dateline INT UNSIGNED NOT NULL,
    options TEXT,
    votes TEXT NOT NULL,
    active SMALLINT DEFAULT '1',
    numberoptions SMALLINT UNSIGNED NOT NULL,
    timeout SMALLINT UNSIGNED NOT NULL,
    PRIMARY KEY (pollid)
  )";
  $explain[]="Creating poll table";

  $query[]="CREATE TABLE pollvote (
    pollvoteid INT UNSIGNED NOT NULL AUTO_INCREMENT,
    pollid INT UNSIGNED NOT NULL,
    userid INT UNSIGNED NOT NULL,
    votedate INT UNSIGNED,
    voteoption INT UNSIGNED NOT NULL,
    PRIMARY KEY (pollvoteid),
	KEY userid (userid, pollid)
  )";
  $explain[]="Creating poll vote table";

}

$query[]="CREATE TABLE word (
	wordid INT UNSIGNED NOT NULL AUTO_INCREMENT,
	title CHAR(50) NOT NULL,
	PRIMARY KEY (wordid)
)";
$explain[]="Creating word table";

$query[]="ALTER TABLE word ADD UNIQUE (title)";
$explain[]="Altering word table";

$query[]="CREATE TABLE searchindex (
	wordid INT UNSIGNED NOT NULL,
	postid INT UNSIGNED NOT NULL,
	intitle smallint(5) unsigned DEFAULT '0' NOT NULL
)";
$explain[]="Creating search index table";

$query[]="ALTER TABLE searchindex ADD UNIQUE (wordid,postid)";
$explain[]="Altering search index table";

$query[]="CREATE TABLE search (
	searchid INT UNSIGNED NOT NULL AUTO_INCREMENT,
	query MEDIUMTEXT NOT NULL,
	postids MEDIUMTEXT NOT NULL,
	dateline INT UNSIGNED NOT NULL,
	querystring CHAR(200) NOT NULL,
	showposts SMALLINT NOT NULL,
	userid INT UNSIGNED NOT NULL,
	ipaddress CHAR(20) NOT NULL,
	PRIMARY KEY (searchid),
	KEY (querystring),
   KEY (userid)
)";
$explain[]="Creating search table";

$query[]="DROP TABLE bbcode";
$explain[]="Dropping old bbcode table";
$query[]="CREATE TABLE bbcode (
	bbcodeid SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
	bbcodetag CHAR(200) NOT NULL,
	bbcodereplacement CHAR(200) NOT NULL,
	bbcodeexample CHAR(200) NOT NULL,
	bbcodeexplanation MEDIUMTEXT NOT NULL,
	twoparams SMALLINT NOT NULL,
	PRIMARY KEY (bbcodeid)
)";
$explain[]="Creating bbcode table";
//?? check slashes
$query[]="INSERT INTO bbcode VALUES (1,'b','<b>\\\\4</b>','[b]Bold[/b]','The [b] tag allows you to write text bold',0)";
$explain[]="Adding bbcode data";
$query[]="INSERT INTO bbcode VALUES (2,'i','<i>\\\\4</i>','[i]Italics[/i]','The [i] tag allows you to write text in italics',0)";
$explain[]="Adding bbcode data";
$query[]="INSERT INTO bbcode VALUES (3,'email','<a href=\"mailto:\\\\4\">\\\\4</a>','[email]support@vbulletin.com[/email]','The [email] tag allows you to include email addresses.',0)";
$explain[]="Adding bbcode data";
$query[]="INSERT INTO bbcode VALUES (4,'email','<a href=\"mailto:\\\\5\">\\\\7</a>','[email=support@vbulletin.com]vBulletin Support[/email]','This email tag allows you to include your own text in an email field.',1)";
$explain[]="Adding bbcode data";
$query[]="INSERT INTO bbcode VALUES (5,'size','<font size=\"\\\\5\">\\\\7</font>','[size=+1]Size 1[/size]','The [size] tag allows you to control the size of the font.',1)";
$explain[]="Adding bbcode data";
$query[]="INSERT INTO bbcode VALUES (6,'quote','<blockquote><smallfont>quote:</smallfont><hr>\\\\4<hr></blockquote>','[quote]This is a quote[/quote]','The quote tag is used to denote a quote from another post',0)";
$explain[]="Adding bbcode data";
$query[]="INSERT INTO bbcode VALUES (7,'u','<u>\\\\4</u>','[u]Underline[/u]','The [u] tag allows you to underline text.',0)";
$explain[]="Adding bbcode data";
$query[]="INSERT INTO bbcode VALUES (8,'color','<font color=\"\\\\5\">\\\\7</font>','[color=red]Red![/color]','The [color] tag allows you to specify the font color.',1)";
$explain[]="Adding bbcode data";
$query[]="INSERT INTO bbcode VALUES (9,'font','<font face=\"\\\\5\">\\\\7</font>','[font=courier]Test[/font]','The [font] tag allows you to specify the font face.',1)";
$explain[]="Adding bbcode data";

$query[]="CREATE TABLE access (
	userid INT (10) UNSIGNED DEFAULT '0' NOT NULL,
	forumid SMALLINT (5) UNSIGNED DEFAULT '0' NOT NULL,
	accessmask SMALLINT (5) UNSIGNED DEFAULT '0' NOT NULL
)";
$explain[]="Creating access table";

$query[]="ALTER TABLE access ADD UNIQUE (userid,forumid)";
$explain[]="Adding index";

$query[]="CREATE TABLE adminlog (
	adminlogid INT UNSIGNED AUTO_INCREMENT NOT NULL,
	userid INT UNSIGNED NOT NULL,
	dateline INT UNSIGNED NOT NULL,
	script CHAR(20) NOT NULL,
	action CHAR(20) NOT NULL,
	extrainfo CHAR(200) NOT NULL,
	PRIMARY KEY(adminlogid)
)";
$explain[]="Creating adminlog table";

$query[]="CREATE TABLE setting (
 settingid SMALLINT UNSIGNED AUTO_INCREMENT NOT NULL,
	settinggroupid SMALLINT UNSIGNED NOT NULL,
	title CHAR(100) NOT NULL,
	varname CHAR(100) NOT NULL,
	value MEDIUMTEXT NOT NULL,
	description MEDIUMTEXT NOT NULL,
	optioncode MEDIUMTEXT NOT NULL,
	displayorder SMALLINT UNSIGNED NOT NULL,
	PRIMARY KEY(settingid)
)";
$explain[]="Creating setting table";

$query[]="CREATE TABLE settinggroup (
	settinggroupid SMALLINT UNSIGNED AUTO_INCREMENT NOT NULL,
	title CHAR(100) NOT NULL,
	displayorder SMALLINT UNSIGNED NOT NULL,
	PRIMARY KEY(settinggroupid)
)";
$explain[]="Creating setting group table";

doqueries();

echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
} //end step 2

if ($step==3) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 3
------

+ Update templates, styles and replacements
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/

$query[]="ALTER TABLE template ADD templatesetid SMALLINT NOT NULL AFTER templateid, ADD INDEX title (title(30),templatesetid)";
$explain[]="Altering template table";
$query[]="UPDATE template SET templatesetid=2";
$explain[]="Updating template table - preserving old templates";
$query[]="UPDATE template SET templatesetid=-1 WHERE title='options'";
$explain[]="Moving 'options' template to global set";
$query[]="CREATE TABLE templateset (
	templatesetid SMALLINT UNSIGNED AUTO_INCREMENT NOT NULL,
	title CHAR(250) NOT NULL,
	PRIMARY KEY(templatesetid)
)";
$explain[]="Creating templateset table";
$query[]="INSERT INTO templateset VALUES (1,'Default')";
$explain[]="Inserting data into templateset table";
$query[]="INSERT INTO templateset VALUES (2,'Old templates')";
$explain[]="Inserting data into templateset table";

$query[]="ALTER TABLE replacement ADD replacementsetid SMALLINT NOT NULL AFTER replacementid, ADD INDEX (replacementsetid)";
$explain[]="Altering replacement table";
$query[]="UPDATE replacement SET replacementsetid=2";
$explain[]="Updating replacement table - preserving old replacements";
$query[]="CREATE TABLE replacementset (
	replacementsetid SMALLINT UNSIGNED AUTO_INCREMENT NOT NULL,
	title CHAR(250) NOT NULL,
	PRIMARY KEY(replacementsetid)
)";
$explain[]="Creating replacementset table";
$query[]="INSERT INTO replacementset VALUES (1,'Default')";
$explain[]="Inserting data into replacementset table";
$query[]="INSERT INTO replacementset VALUES (2,'Old replacements')";
$explain[]="Inserting data into replacementset table";

$query[]="INSERT INTO replacement VALUES (NULL, '-1', '<largefont', '<b><FONT face=\"verdana, arial, helvetica\" size=\"2\" ')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '<largefont', '<b><FONT face=\"verdana, arial, helvetica\" size=\"2\" ')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '</largefont>', '</b></font>')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '<body>', '<body bgcolor=\"#7d7092\" text=\"#000000\" id=all leftmargin=\"10\" topmargin=\"10\" marginwidth=\"10\" marginheight=\"10\" link=\"#000000\" vlink=\"#000000\" alink=\"#000000\">')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '<normalfont', '<FONT face=\"verdana, arial, helvetica\" size=\"2\" ')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '</normalfont>', '</font>')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{htmldoctype}', '<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\" \"http://www.w3.org/TR/REC-html40/loose.dtd\">')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '<smallfont', '<FONT face=\"verdana,arial,helvetica\" size=\"1\" ')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '</smallfont>', '</font>')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{secondaltcolor}', '#EFEFEF')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{firstaltcolor}', '#DEDEDE')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{tableheadtextcolor}', '#afa3c5')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{timecolor}', '#6c6081')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{categorybackcolor}', '#6c6081')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{categoryfontcolor}', '#f5d300')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{linkcolor}', '#000000')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{hovercolor}', '#f5d300')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{titleimage}', 'images/vBulletin_logo.gif')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{replyimage}', 'images/reply.gif')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{newthreadimage}', 'images/newthread.gif')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{closedthreadimage}', 'images/threadclosed.gif')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{contentareacolor}', '#FFFFFF')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{imagesfolder}', 'images')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{tablebordercolor}', '#000000')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '<highlight', '<font color=\"red\"')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{tablewidth}', '')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{calbgcolor}', 'white')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{caltodaycolor}', '#EEEEEE')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{caldaycolor}', 'blue')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{calbirthdaycolor}', 'purple')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{calpubliccolor}', 'green')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{calprivatecolor}', 'BLACK')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{pagebgcolor}', '#FFFFFF')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '{tableheadbgcolor}', '#6c6081')";
$explain[]="Inserting data into replacement table";
$query[]="INSERT INTO replacement VALUES (NULL, '-1', '</highlight>', '</font>')";
$explain[]="Inserting data into replacement table";

$query[]="CREATE TABLE style (
	styleid SMALLINT UNSIGNED AUTO_INCREMENT NOT NULL,
	replacementsetid SMALLINT UNSIGNED NOT NULL,
	templatesetid SMALLINT UNSIGNED NOT NULL,
	title CHAR(250) NOT NULL,
	userselect SMALLINT UNSIGNED NOT NULL,
	PRIMARY KEY(styleid)
)";
$explain[]="Creating style table";
$query[]="INSERT INTO style VALUES (1,1,1,'Default',1)";
$explain[]="Inserting data into style table";
$query[]="INSERT INTO style VALUES (2,2,2,'Old styles (may not work)',0)";
$explain[]="Inserting data into style table";

// Add special template that holds max logged in users information.
$query[]="INSERT INTO template (templatesetid, title) VALUES ('-2','maxloggedin')";
$explain[]="Add special template";
// Add special template that holds the birthday information.
$query[]="INSERT INTO template (templatesetid, title) VALUES ('-2','birthdays')";
$explain[]="Add special template";

doqueries();

echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
} //end step 3

if ($step==4) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 4
------

+ Update forums
+ Update categories
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/

$query[]="ALTER TABLE forum
	DROP headertemplate,
	DROP useadvheader,
	DROP forumbittemplate,
	DROP threadtemplate,
	DROP threadbittemplate,
	DROP replytemplate,
	DROP newthreadtemplate,
	DROP edittemplate,
	DROP rulestemplate,
	DROP titleimage,
	DROP replyimage,
	DROP newthreadimage,
	DROP closedthreadimage,
	DROP forumtemplate,
	DROP footertemplate,
	DROP useadvfooter";
$explain[]="Altering forum table";

$query[]="ALTER TABLE forum
	ADD allowicons SMALLINT NOT NULL,
	ADD parentid SMALLINT NOT NULL,
	ADD parentlist CHAR(250) NOT NULL";
$explain[]="Altering forum table";

$query[]="ALTER TABLE forum
	ADD styleid SMALLINT unsigned NOT NULL AFTER forumid,
	ADD allowratings SMALLINT (6) DEFAULT '0' NOT NULL,
	ADD countposts SMALLINT (6) DEFAULT '1' NOT NULL";
$explain[]="Altering forum table";

$query[]="ALTER TABLE forum
	ADD styleoverride SMALLINT (5) DEFAULT '0' NOT NULL,
	ADD moderateattach SMALLINT NOT NULL AFTER moderatenew,
	ADD cancontainthreads SMALLINT AFTER allowposting";
$explain[]="Altering forum table";

$query[]="UPDATE forum SET allowicons='".iif($showicons==1,1,0)."',allowratings=1,countposts=1,allowposting=1,cancontainthreads=1";
$explain[]="Updating data in forum table";

doqueries();

// convert categories to forums
$categorys=$DB_site->query("SELECT categoryid,title,displayorder FROM category");
while ($category=$DB_site->fetch_array($categorys)) {

  $DB_site->query("INSERT INTO forum (parentid,title,displayorder,cancontainthreads,allowposting,active) VALUES (-1,'".addslashes($category[title])."','$category[displayorder]',0,0,1)");
  $forumid=$DB_site->insert_id();
  $DB_site->query("UPDATE forum SET parentid=$forumid WHERE categoryid=$category[categoryid]");

}

$query[]="DROP TABLE category";
$explain[]="Dropping category table";

$query[]="ALTER TABLE forum DROP categoryid";
$explain[]="Altering forum table";

doqueries();

// update parent list:
// ###################### Start getforumarray #######################
function getforumarray($forumid) {
  global $DB_site;

  static $forumarraycache;

  if (isset($forumarraycache[$forumid])) {
    $forumarray=$forumarraycache[$forumid];
  } else {
    $foruminfo=$DB_site->query_first("SELECT parentid FROM forum WHERE forumid=$forumid");

    $forumarray=$forumid;

    if ($foruminfo[parentid]!=0) {
      $forumarray.=",".getforumarray($foruminfo[parentid]);
    }
    $forumarraycache[$forumid]=$forumarray;
  }
  return $forumarray;
}

$forums=$DB_site->query("SELECT forumid FROM forum");
while ($forum=$DB_site->fetch_array($forums)) {
  $DB_site->query("UPDATE forum SET parentlist='".getforumarray($forum[forumid])."' WHERE forumid=$forum[forumid]");
}

echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
} // end step 4

if ($step==5) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 5
------

+ Update announcements
+ Update and migrate moderators
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/

$query[]="ALTER TABLE announcement
	CHANGE title title CHAR(250) NOT NULL,
	CHANGE userid userid INT (10) UNSIGNED DEFAULT '0' NOT NULL,
	ADD INDEX (forumid)";
$explain[]="Altering announcement table";

$query[]="CREATE TABLE moderator (
	moderatorid SMALLINT UNSIGNED AUTO_INCREMENT NOT NULL,
	userid INT UNSIGNED NOT NULL,
	forumid SMALLINT NOT NULL,
	newthreademail SMALLINT NOT NULL,
	newpostemail SMALLINT NOT NULL,
	caneditposts SMALLINT NOT NULL,
	candeleteposts SMALLINT NOT NULL,
	canviewips SMALLINT NOT NULL,
	canmanagethreads SMALLINT NOT NULL,
	canopenclose SMALLINT NOT NULL,
	caneditthreads SMALLINT NOT NULL,
	caneditstyles SMALLINT NOT NULL,
	canbanusers SMALLINT NOT NULL,
	canviewprofile SMALLINT NOT NULL,
	canannounce SMALLINT NOT NULL,
	canmassmove SMALLINT NOT NULL,
	canmassprune SMALLINT NOT NULL,
	canmoderateposts SMALLINT NOT NULL,
	canmoderateattachments SMALLINT NOT NULL,
	PRIMARY KEY(moderatorid),
	KEY userid (userid,forumid)
)";
$explain[]="Creating moderator table";

$query[]="INSERT INTO moderator SELECT NULL,user.userid,forumpermission.forumid,0,0,1,1,1,1,1,1,0,0,0,1,0,0,1,1 FROM user,forumpermission WHERE user.usergroupid=forumpermission.usergroupid AND canadminedit=1";
$explain[]="Merging old moderators";

doqueries();

$usergroup=$DB_site->query_first("SELECT * FROM usergroup WHERE usergroupid=2");
$DB_site->query("INSERT INTO usergroup (usergroupid, title, usertitle, canview, cansearch, canemail, canpostnew, canreply, canadminedit, canedit, candelete, canopenclose, canmove, cancontrolpanel) VALUES (NULL, 'Moderators','Moderator', $usergroup[canview], $usergroup[cansearch], $usergroup[canemail], $usergroup[canpostnew], $usergroup[canreply], $usergroup[canadminedit], $usergroup[canedit], $usergroup[candelete], $usergroup[canopenclose], $usergroup[canmove], $usergroup[cancontrolpanel])");
$modgroupid=$DB_site->insert_id();

// delete old mods
$oldmods=$DB_site->query("SELECT user.userid,user.customtitle,user.usergroupid,usergroup.cancontrolpanel FROM user,usergroup WHERE user.usergroupid=usergroup.usergroupid AND LEFT(usergroup.title,15)='!Auto-generated'");
while ($oldmod=$DB_site->fetch_array($oldmods)) {
  if ($oldmod[cancontrolpanel]==1) {
    $newgroup = 6;
  } else {
    if ($modgroupid) {
      $newgroup = $modgroupid;
    } else {
      $newgroup = 2;
    }
  }
  $DB_site->query("UPDATE user SET usergroupid=$newgroup".iif(!$oldmod[customtitle],",usertitle='Moderator',customtitle=1","")." WHERE userid=$oldmod[userid]");

  $DB_site->query("DELETE FROM usergroup WHERE usergroupid=$oldmod[usergroupid]");
  $DB_site->query("DELETE FROM forumpermission WHERE usergroupid=$oldmod[usergroupid]");
}

echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
} // end step 5

if ($step==6) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 6
------

+ Update sessions
+ Update threads
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/

$query[]="DROP TABLE session";
$explain[]="Dropping old session table";

$query[]="CREATE TABLE session (
  sessionhash CHAR(32) NOT NULL,
  userid INT UNSIGNED NOT NULL,
  host CHAR(50) NOT NULL,
  useragent CHAR(50) NOT NULL,
  lastactivity INT UNSIGNED NOT NULL,
  styleid SMALLINT (5) UNSIGNED DEFAULT '0' NOT NULL,
  PRIMARY KEY (sessionhash)
)";
$explain[]="Creating new session table";

$query[]="ALTER TABLE thread
	DROP threadindex,
	DROP subjectindex,
	DROP userindex";
$explain[]="Altering thread table";

$query[]="ALTER TABLE thread
	ADD postuserid INT UNSIGNED NOT NULL AFTER postusername,
	ADD pollid INT UNSIGNED NOT NULL AFTER forumid";
$explain[]="Altering thread table";

$query[]="ALTER TABLE thread
	ADD sticky SMALLINT DEFAULT '0' NOT NULL,
	ADD votenum SMALLINT UNSIGNED NOT NULL";
$explain[]="Altering thread table";

$query[]="ALTER TABLE thread
	ADD votetotal SMALLINT UNSIGNED NOT NULL,
	ADD attach SMALLINT UNSIGNED NOT NULL";
$explain[]="Altering thread table";

$query[]="ALTER TABLE thread
	ADD INDEX (iconid),
	ADD INDEX (forumid, visible, sticky, lastpost)";
$explain[]="Altering thread table";

doqueries();

echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
} // end step 6

if ($step==7) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 7
------

+ Update usergroups and permissions
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/

$DB_site->reporterror=0;
$DB_site->query("ALTER TABLE session TYPE=HEAP");
$DB_site->reporterror=1;

$query[]="ALTER TABLE usergroup RENAME usergroup2";
$explain[]="Backing up old usergroup table";

$query[]="CREATE TABLE usergroup (
	usergroupid SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
	title CHAR(100) NOT NULL,
	usertitle CHAR(100) NOT NULL,
	cancontrolpanel SMALLINT NOT NULL,
	canmodifyprofile SMALLINT NOT NULL,
	canviewmembers SMALLINT NOT NULL,
	canview SMALLINT NOT NULL,
	cansearch SMALLINT NOT NULL,
	canemail SMALLINT NOT NULL,
	canpostnew SMALLINT NOT NULL,
	canmove SMALLINT NOT NULL,
	canopenclose SMALLINT NOT NULL,
	candeletethread SMALLINT NOT NULL,
	canreplyown SMALLINT NOT NULL,
	canreplyothers SMALLINT NOT NULL,
	canviewothers SMALLINT NOT NULL,
	caneditpost SMALLINT NOT NULL,
	candeletepost SMALLINT NOT NULL,
	maxbuddypm SMALLINT UNSIGNED DEFAULT '5' not null,
	maxforwardpm SMALLINT UNSIGNED DEFAULT '5' not null,
	cantrackpm SMALLINT DEFAULT '1' not null,
	candenypmreceipts SMALLINT DEFAULT '1' not null,
	PRIMARY KEY(usergroupid)
)";
$explain[]="Creating new usergroup table";

$query[]="INSERT INTO usergroup select usergroupid,title,usertitle,cancontrolpanel,1,1,canview,cansearch,canemail,canpostnew,canmove,canopenclose,candelete,canreply,canreply,canview,canedit,candelete,5,5,1,1 FROM usergroup2";
$explain[]="Merging old usergroup table information";

$query[]="DROP TABLE usergroup2";
$explain[]="Dropping old usergroup table";

$query[]="ALTER TABLE usergroup
	ADD canusepm SMALLINT NOT NULL,
	ADD canpostpoll SMALLINT NOT NULL,
	ADD canvote SMALLINT NOT NULL,
	ADD canpostattachment SMALLINT NOT NULL,
	ADD canpublicevent SMALLINT(6) DEFAULT '0' NOT NULL,
	ADD canpublicedit SMALLINT(6) DEFAULT '0' NOT NULL,
	ADD canthreadrate SMALLINT DEFAULT '1' NOT NULL,
	ADD ismoderator SMALLINT NOT NULL";
$explain[]="Altering new usergroup table";

$query[]="UPDATE usergroup set canvote=1,canusepm=1,canpostpoll=1,canpostattachment=1,canthreadrate=1 WHERE usergroupid<>1 AND usergroupid<>3 AND usergroupid<>4";
$explain[]="Updating usergroup table";
$query[]="UPDATE usergroup set canpublicevent=1,canpublicedit=1,ismoderator=1 WHERE usergroupid=5 OR usergroupid=6";
$explain[]="Updating usergroup table";


$query[]="ALTER TABLE forumpermission RENAME forumpermission2";
$explain[]="Backing up old forum permission table";

$query[]="CREATE TABLE forumpermission (
	forumpermissionid SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
	forumid SMALLINT UNSIGNED NOT NULL,
	usergroupid SMALLINT UNSIGNED NOT NULL,
	canview SMALLINT NOT NULL,
	cansearch SMALLINT NOT NULL,
	canemail SMALLINT NOT NULL,
	canpostnew SMALLINT NOT NULL,
	canmove SMALLINT NOT NULL,
	canopenclose SMALLINT NOT NULL,
	candeletethread SMALLINT NOT NULL,
	canreplyown SMALLINT NOT NULL,
	canreplyothers SMALLINT NOT NULL,
	canviewothers SMALLINT NOT NULL,
	caneditpost SMALLINT NOT NULL,
	candeletepost SMALLINT NOT NULL,
	PRIMARY KEY(forumpermissionid),
	KEY ugid_fid (usergroupid, forumid)
)";
$explain[]="Creating new forum permission table";

$query[]="INSERT INTO forumpermission select forumpermissionid,forumid,usergroupid,canview,cansearch,canemail,canpostnew,canmove,canopenclose,candelete,canreply,canreply,canview,canedit,candelete from forumpermission2";
$explain[]="Merging old forum permission information";

$query[]="DROP TABLE forumpermission2";
$explain[]="Dropping old forum permission information";

$query[]="ALTER TABLE forumpermission
	ADD canpostattachment SMALLINT NOT NULL,
	ADD canpostpoll SMALLINT (6) DEFAULT '0' NOT NULL,
	ADD canvote SMALLINT (6) DEFAULT '0' NOT NULL";
$explain[]="Altering new forum permission table";

$query[]="UPDATE forumpermission set canpostattachment=1,canpostpoll=1,canvote=1 WHERE canpostnew=1";
$explain[]="Updating forum permission table";

doqueries();

echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
} // end step 7

if ($step==8) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 8
------

+ Create custom profile fields
+ Update users
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/
$query[]="CREATE TABLE profilefield (
	profilefieldid SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
	title CHAR(50) NOT NULL,
	description CHAR(250) NOT NULL,
	required SMALLINT NOT NULL,
	hidden SMALLINT NOT NULL,
	maxlength SMALLINT DEFAULT '250' NOT NULL,
	size SMALLINT DEFAULT '25' NOT NULL,
	displayorder SMALLINT NOT NULL,
	PRIMARY KEY(profilefieldid)
)";
$explain[]="Creating profile field definitions table";

$query[]="CREATE TABLE userfield (
	userid INT UNSIGNED NOT NULL,
	field1 CHAR(250) NOT NULL,
	field2 CHAR(250) NOT NULL,
	field3 CHAR(250) NOT NULL,
	field4 CHAR(250) NOT NULL,
	PRIMARY KEY(userid)
)";
$explain[]="Creating user profile fields table";

$query[]="INSERT INTO userfield SELECT userid,biography,'','','' FROM user";
$explain[]="Getting biography custom profile field from user";

$query[]="INSERT INTO profilefield VALUES
	(1,'Biography','A few details about yourself',0,0,250,25,1),
	(2,'Location','Where you live',0,0,250,25,2),
	(3,'Interests','Your hobbies, etc',0,0,250,25,3),
	(4,'Occupation','Your job',0,0,250,25,4)";
$explain[]="Inserting definition for biography field";
doqueries();

$DB_site->reporterror=0;
  $DB_site->query("SELECT COUNT(*) AS count FROM privatercvd");
  $pmerrno=$DB_site->errno;
  if (!$pmerrno) {
    $pmerrno = 0;
  }

  $DB_site->query("SELECT COUNT(*) AS count FROM user WHERE buddylist<>''");
  $blerrno=$DB_site->errno;
  if (!$blerrno) {
    $blerrno = 0;
  }

  $DB_site->query("SELECT COUNT(*) AS count FROM user WHERE birthday<>''");
  $bdayerrno=$DB_site->errno;
  if (!$bdayerrno) {
    $bdayerrno = 0;
  }
$DB_site->reporterror=1;

// get keys list
$sql="";
$start=0;
$keys = $DB_site->query("SHOW KEYS FROM user");
while ($key = $DB_site->fetch_array($keys)) {
	$kname=$key['Key_name'];
	if (!$isdone[$kname]) {
     if ($kname!="PRIMARY") {
       if ($start==0) {
         $sql ="DROP INDEX $kname";
         $start=1;
       } else {
         $sql.=",DROP INDEX $kname";
       }
     }
	  $isdone[$kname]=1;
	}

}

if($bdayerrno==0) {
  $query[]="ALTER TABLE user DROP birthday";
  $explain[]="Dropping incompatible birthday field";
  doqueries();
}

$query[]="ALTER TABLE user
	DROP biography,
	DROP canpost,
	CHANGE timezoneoffset timezoneoffset CHAR(4) NOT NULL";
$explain[]="Altering user table";
doqueries();

if ($blerrno!=0) {
  $query[]="ALTER TABLE user ADD buddylist MEDIUMTEXT NOT NULL";
  $explain[]="Altering User Table";
  doqueries();
}

if ($pmerrno!=0) {
  $query[]="ALTER TABLE user ADD ignorelist MEDIUMTEXT NOT NULL";
  $explain[]="Altering User Table";
  doqueries();
}

$query[]="ALTER TABLE user
	ADD avatarid SMALLINT NOT NULL,
	ADD styleid SMALLINT UNSIGNED NOT NULL AFTER email";
$explain[]="Altering user table";
doqueries();

$query[]="ALTER TABLE user
	ADD options SMALLINT DEFAULT '1' NOT NULL,
	ADD birthday DATE DEFAULT '0000-00-00' NOT NULL";
$explain[]="Altering user table";
doqueries();

$query[]="ALTER TABLE user
	ADD maxposts SMALLINT DEFAULT '-1' NOT NULL,
	ADD startofweek SMALLINT DEFAULT '1' NOT NULL";
$explain[]="Altering user table";
doqueries();

$query[]="ALTER TABLE user
	ADD ipaddress CHAR(20) NOT NULL,
	ADD referrerid INT UNSIGNED NOT NULL";
$explain[]="Altering user table";
doqueries();

if ($pmerrno!=0) {
  $query[]="ALTER TABLE user
     ADD pmfolders MEDIUMTEXT NOT NULL,
     ADD receivepm SMALLINT DEFAULT '1' NOT NULL";
  $explain[]="Altering user table";
  doqueries();
}

$query[]="ALTER TABLE user
	".iif($pmerrno!=0,"ADD emailonpm SMALLINT NOT NULL,", "")."
	ADD pmpopup SMALLINT NOT NULL,
   ADD nosessionhash SMALLINT NOT NULL";
$explain[]="Altering user table";
doqueries();

if ($sql) {
  $query[]="ALTER TABLE user
    $sql";
  $explain[]="Removing Indexes from User";
  doqueries();
}

$query[]="ALTER TABLE user
     ADD INDEX (username),
     ADD INDEX (usergroupid)";
$explain[]="Adding username Index to User";
doqueries();

$query[]="UPDATE user SET options = options + 14,timezoneoffset=timezoneoffset+".intval(date("H",12*60*60)-gmdate("H",12*60*60));
$explain[]="Updating user timezones";
doqueries();

echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
} // end step 8

if ($step==9) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 9
------

+ nothing!
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/

$step=10;

//echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
} // end step 9

if ($step==10) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 10
-------

+ Update and insert settings
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/

// do settings
$DB_site->query("INSERT INTO settinggroup VALUES (1,'Turn Your vBulletin on and off',1)");
$DB_site->query("INSERT INTO settinggroup VALUES (2,'General Settings',2)");
$DB_site->query("INSERT INTO settinggroup VALUES (3,'Contact Details',3)");
$DB_site->query("INSERT INTO settinggroup VALUES (4,'Posting Code allowances (vB code / HTML / etc)',4)");
$DB_site->query("INSERT INTO settinggroup VALUES (5,'Forums Home Page Options',5)");
$DB_site->query("INSERT INTO settinggroup VALUES (6,'User and registration options',6)");
$DB_site->query("INSERT INTO settinggroup VALUES (7,'Memberlist options',7)");
$DB_site->query("INSERT INTO settinggroup VALUES (8,'Thread display options',8)");
$DB_site->query("INSERT INTO settinggroup VALUES (9,'Forum Display Options',9)");
$DB_site->query("INSERT INTO settinggroup VALUES (10,'Search Options',10)");
$DB_site->query("INSERT INTO settinggroup VALUES (11,'Email Options',11)");
$DB_site->query("INSERT INTO settinggroup VALUES (12,'Date / Time options',12)");
$DB_site->query("INSERT INTO settinggroup VALUES (14,'Edit Options',14)");
$DB_site->query("INSERT INTO settinggroup VALUES (15,'IP Logging Options',15)");
$DB_site->query("INSERT INTO settinggroup VALUES (16,'Floodcheck Options',16)");
$DB_site->query("INSERT INTO settinggroup VALUES (17,'Banning Options',17)");
$DB_site->query("INSERT INTO settinggroup VALUES (18,'Language Options',18)");
$DB_site->query("INSERT INTO settinggroup VALUES (19,'Private Messaging Options',19)");
$DB_site->query("INSERT INTO settinggroup VALUES (13,'Censorship Options',13)");
$DB_site->query("INSERT INTO settinggroup VALUES (20,'HTTP Headers and output',20)");
$DB_site->query("INSERT INTO settinggroup VALUES (21,'Version Info',0)");
$DB_site->query("INSERT INTO settinggroup VALUES (22,'Spell Check',21)");
$DB_site->query("INSERT INTO settinggroup VALUES (23,'Templates',22)");
$DB_site->query("INSERT INTO settinggroup VALUES (24,'Load limiting options',24)");
$DB_site->query("INSERT INTO settinggroup VALUES (25,'Polls',25)");
$DB_site->query("INSERT INTO settinggroup VALUES (26,'Avatars',26)");
$DB_site->query("INSERT INTO settinggroup VALUES (27,'Attachments',27)");
$DB_site->query("INSERT INTO settinggroup VALUES (28,'Custom User Titles',28)");
$DB_site->query("INSERT INTO settinggroup VALUES (29,'Calendar',29)");
$DB_site->query("INSERT INTO settinggroup VALUES (30,'Upload Options',30)");

echo "<p>Added settinggroup data</p>\n";

$DB_site->query("INSERT INTO setting VALUES (NULL,1,'Bulletin Board Active','bbactive','$bbactive','From time to time, you may want to turn your bulletin board off to the public while you perform maintenance, update versions, etc. When you turn your BB off, visitors will receive a message that states that the bulletin board is temporarily unavailable. <b>Administrators will still be able to see the board</b></p>\r\n<p>Use this as a master switch for your board. You can set options for individual user groups in the User Permissions area.','yesno',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,1,'Reason for turning board off','bbclosedreason','".addslashes($bbclosedreason)."','The text that is presented when the BB is closed.</p>\r\n<p>Note: you, as an administrator, will be able to see the forums as usual, even when you have turned them off to the public.','textarea',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,2,'URL','bburl','$bburl','URL (with no final \"/\") of the BB.','',3)");
$DB_site->query("INSERT INTO setting VALUES (NULL,2,'Board Title','bbtitle','".addslashes($bbtitle)."','Title of board. Appears in the title of every page','',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,2,'Homepage Name','hometitle','".addslashes($hometitle)."','Name of your homepage. Appears at the bottom of every page.','',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,2,'URL of homepage','homeurl','$homeurl','URL of your home page. Appears at the bottom of every page.','',4)");
$DB_site->query("INSERT INTO setting VALUES (NULL,2,'Copyright Text','copyrighttext','".addslashes($copyrighttext)."','Copyright text to insert the footer of the page.','',5)");
$DB_site->query("INSERT INTO setting VALUES (NULL,2,'URL of Privacy Statement','privacyurl','$privacyurl','Enter the URL of your privacy statement, if one exists.','',6)");
$DB_site->query("INSERT INTO setting VALUES (NULL,3,'Contact Us Link','contactuslink','".addslashes($contactuslink)."','Link for contacting the site. Can just be mailto:webmaster@whereever.com or your own form. Appears at the bottom of every page.','',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,3,'Webmaster\'s email','webmasteremail','$webmasteremail','Email address of the webmaster.','',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,3,'Company Name','companyname','".addslashes($companyname)."','The name of your company. Required for COPPA.','',6)");
$DB_site->query("INSERT INTO setting VALUES (NULL,3,'Address','address','".addslashes($address)."','Address of your company. This is required for COPPA forms to be posted to.','',5)");
$DB_site->query("INSERT INTO setting VALUES (NULL,3,'Fax Number','faxnumber','$faxnumber','Enter the fax number for your company here. COPPA forms will be faxed to it.\r\n</p>\r\n<p>You may wish to check out <a href=\"http://www.efax.com/\" target=_blank>http://www.efax.com/</a>','',4)");
$DB_site->query("INSERT INTO setting VALUES (NULL,4,'Allow vB IMG code in signatures?','allowbbimagecode','$allowbbimagecode','','yesno',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,4,'Allow vB code in signatures?','allowbbcode','$allowbbcode','','yesno',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,4,'Allow smilies in signatures?','allowsmilies','$allowsmilies','','yesno',3)");
$DB_site->query("INSERT INTO setting VALUES (NULL,4,'Allow HTML in signatures?','allowhtml','$allowhtml','','yesno',4)");
$DB_site->query("INSERT INTO setting VALUES (NULL,4,'Maximum images per post/signature','maximages','$maximages','Maximum number of images to allow in posts / signatures. Set this to 0 to have no effect.','',5)");
$DB_site->query("INSERT INTO setting VALUES (NULL,4,'Clickable Smilies per Row','smcolumns','3','When a user has enabled the clickable vbcode/smilies how many smilies do you want to show per row?','',6)");
$DB_site->query("INSERT INTO setting VALUES (NULL,4,'Clickable Smilies Total','smtotal','15','When a user has enabled the clickable vbcode/smilies how many smilies do you want to display on the screen before the user is prompted to \"click\" for more.','',7)");
$DB_site->query("INSERT INTO setting VALUES (NULL,4,'Allow Dynamic URL for [img] tags?','allowdynimg','0','If this is set to \'no\', the [img] tag will not be displayed if the path to the image contains dynamic characters such as ? and &. This can prevent malicious use of the tag.','yesno',8)");
$DB_site->query("INSERT INTO setting VALUES (NULL,5,'Show today\'s birthdays on the homepage?','showbirthdays',1,'','yesno',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,5,'Show Locked forums?','showlocks','0','Do you wish to have the new post indicators shown on the index page (on.gif and off.gif) be shown with locks to guests & other members who have no access to post?','yesno',6)");
$DB_site->query("INSERT INTO setting VALUES (NULL,5,'Depth of Forums','forumhomedepth','2','Depth to show forums on home page. Do not go too large on this value for performance reasons.','',7)");
$DB_site->query("INSERT INTO setting VALUES (NULL,5,'Hide private forum','hideprivateforums','$hideprivateforums','Select \'yes\' here to hide private forums from users who are not allowed to access them. Users who do have permission to access them will have to log in before they can see these forums too. This option applies to the forum home page, and the Jump To... box.','yesno',5)");
$DB_site->query("INSERT INTO setting VALUES (NULL,5,'Display logged in users on home page','displayloggedin','$displayloggedin','Display logged in and active members on the home page? This option displays those users that have been active in the last {your cookie timeout} seconds on the home page.','yesno',4)");
$DB_site->query("INSERT INTO setting VALUES (NULL,5,'Show forum descriptions on the homepage.','showforumdescription','$showforumdescriptions','','yesno',0)");
$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Display email addresses','displayemails','$displayemails','Allow public viewing of email addresses.','yesno',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Use email form?','secureemail','$secureemail','If \"display email addresses\" is set to yes, then how should then email address be displayed? If this is set to yes, then an online form must be filled in to send a user an email, thus hiding the destination email address. If secureemail is set to no, then the user is just given the email address.','yesno',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Allow signatures','allowsignatures','$allowsignatures','Allow registered users to have signatures. Don\'t forget to update these templates: newtopic newreply editpost modifyprofile register','yesno',3)");
$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Notify about new members','newuseremail','$newuseremail','Email address to receive email when a new user signs up. Leave blank for no email.','',4)");
$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Require unique email addresses','requireuniqueemail','$requireuniqueemail','The default option is to require unique email addresses for each registered user. This means that no two users can have the same email address. You can disable this requirement by checking the \"Unique Email Not Required\" box.','yesno',5)");
$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Illegal user names','illegalusernames','$illegalusernames','Enter names in here that you do not want people to register. If any of the names here are included within the username, the user will told that there is an error. Separate names by spaces.','',6)");
$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Allow new user registrations','allowregistration','$allowregistration','If you would like to temporarily (or permanently) prevent anyone new from registering, you can do so. The REGISTER button will still be seen throughout the BB, but anyone attempting to register will be told that you are not accepting new registrations at this time.','yesno',7)");
$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Allow multiple registrations per user','allowmultiregs','$allowmultiregs','Normally, vBulletin will stop users signing up for multiple names by checking for a cookie on the user\'s machine. If one exists, then the user may not sign up for additional names. If you wish to allow your users to sign up for multiple names, then select yes for this option, and they will not be blocked from registering additional usernames.','yesno',8)");
$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Verify Email address in registration','verifyemail','$verifyemail','The password is emailed to the new member after they submit their registration to confirm their identity and email address. If account is not activated, they will remain in the \"users awaiting activation\" usergroup.','yesno',9)");
$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Moderate New Members','moderatenewmembers','$moderatenewmembers','Allows you to validate new members before they are classified as registered members and are allowed to post.','yesno',10)");
$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Use COPPA Registration system','usecoppa','$usecoppa','Use the COPPA registration system. This complies with the COPPA laws and requires children under the age of 13 to get parental consent before they can post. For more info about this law, see here:<br>\r\n<a href=\"http://www.ftc.gov/opa/1999/9910/childfinal.htm\">http://www.ftc.gov/opa/1999/9910/childfinal.htm</a>','yesno',11)");
$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Timeout for Cookie','cookietimeout','$cookietimeout','This is the time in seconds that a user must remain inactive before the unread posts are reset to read.','',12)");
$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Allow Users To Change Styles','allowchangestyles','1','This allows users to set their preferred style set on registration or when editing their option. Setting this to \"no\" disables that option and will force them to use whatever style has been specified.','yesno',13)");
$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Enable Access Masks?','enableaccess','0','Access masks are a simple way to manage forum permissions, however they add additional queries on most pages. If you don\'t use it, it is recommended that you disable it.','yesno',14)");
$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Referrer', 'usereferrer', '0', 'Enable the referrer system? If yes than a user that visits your forum through a link that contains \"referrerid=XXX\" will give referral credit to the owner of the referrerid when they register (where XXX is the userid of the referrer).', 'yesno', 15)");
$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Minimum Username Length','minuserlength','3','Enter the minimum length a user can register with.','',15)");
$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Maximum Username Length','maxuserlength','15','Enter the maximum length a user can register with.','',16)");
$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Allow Ignore Moderators','ignoremods','0','Allow users to add Moderators and admins to their ignore list?','yesno',17)");
$DB_site->query("INSERT INTO setting VALUES (NULL,7,'Enable members list','enablememberlist','$enablememberlist','Enable the member list addon? This allows users to view a list of registered users and (optionally) search through it. ','yesno',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,7,'Allow advanced searches','usememberlistadvsearch','$usememberlistadvsearch','Allow the use of the advanced search tool for the member list.','yesno',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,7,'Members per page','memberlistperpage','$memberlistperpage','The number of records per page that will be shown by default in the members list.','',3)");
$DB_site->query("INSERT INTO setting VALUES (NULL,7,'Number of top posters to show','memberlisttopposters','$memberlisttopposters','On the \'Display top x posters\' , this option allows you to specify a value for x.','',4)");
$DB_site->query("INSERT INTO setting VALUES (NULL,8,'Order of posts within a thread','postorder','$postorder','The standard (recommended) way to display threads is chronologically from original topic to the latest reply. You can reverse this, if you prefer, to have threads displayed in reverse, from latest post to oldest post.','Newest first<input type=\\\\\"radio\\\\\" name=\\\\\"setting[\$setting[settingid]]\\\\\"  \".iif(\$setting[value]==1,\"checked\",\"\").\" value=\\\\\"1\\\\\"> Oldest first <input type=\\\\\"radio\\\\\" name=\\\\\"setting[\$setting[settingid]]\\\\\" \".iif(\$setting[value]==0,\"checked\",\"\").\" value=\\\\\"0\\\\\">',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,8,'Maximum number of posts to display on a thread page before splitting over multiple pages','maxposts','$maxposts','','',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,8,'User Settable Maximum Posts per Page','usermaxposts','5,10,20,30,40','If you would like to allow the user to set their own maximum posts per thread then give the options seperated by commas. Leave the field blank to force them to use the MAXPOSTS setting above this option.\r\n\r\nex. 10,20,30,40','',3)");
$DB_site->query("INSERT INTO setting VALUES (NULL,8,'Pages to show in nav bar','pagenavpages','3','In the list of links of pages in the current thread (or current forum), this option selects how many pages either side of the current page are shown. Set this to 0 to display all pages.','',4)");
$DB_site->query("INSERT INTO setting VALUES (NULL,8,'Number of characters before wrapping','wordwrap','$wordwrap','If you want posts to automatically insert spaces into long words to make them wrap after a certain number of characters, set the number of characters in the box above. If you do not want this to occur, enter 0.','',5)");
$DB_site->query("INSERT INTO setting VALUES (NULL,8,'Show Online Users?','showonline','0','Show images on posts that indicate whether or not a user is online? May add time to your query results so use with caution.','yesno',6)");
$DB_site->query("INSERT INTO setting VALUES (NULL,8,'Maximum Characters per post','postmaxchars','10000','The maximum number of characters that you want to allow per post. Set this to 0 to disable it.','',7)");
$DB_site->query("INSERT INTO setting VALUES (NULL,8,'Show default icon','showdeficon','0','Show a default icon if a user doesn\'t choose a message icon or is unable to choose one based on forum settings? {imagesfolder}/icons/icon1.gif will be used.','yesno',8)");
$DB_site->query("INSERT INTO setting VALUES (NULL,8,'Stop \'Shouting\' in titles','stopshouting','1','Prevent your users \'shouting\' in their thread titles by changing all-uppercase titles to capitalization only on the first letters of some words. Disable this for some international boards with different character sets, as this may cause problems.','yesno','9')");
$DB_site->query("INSERT INTO setting VALUES (NULL,9,'Threads per Page','maxthreads','$maxthreads','The number of threads to display on a forum page before splitting it over multiple pages.','',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,9,'Use \'hot\' icons','usehotthreads','$usehotthreads','Hot icons indicate topics with a lot of activity. The icons are animated to show a folder on fire. ','yesno',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,9,'Number of views to qualify as a hot thread','hotnumberviews','150','','',3)");
$DB_site->query("INSERT INTO setting VALUES (NULL,9,'Number of posts to qualify as a hot thread','hotnumberposts','$hotnumber','','',4)");
$DB_site->query("INSERT INTO setting VALUES (NULL,9,'Use \'dot\' icons?','showdots','0','When this feature is enabled, a logged in user will see a \"dot\" (or whatever graphic you choose) on the folder icons (hot folders, new folders, etc) next to the threads that they have participated in.','yesno',5)");
$DB_site->query("INSERT INTO setting VALUES (NULL,9,'Link to individual pages of a multipage thread on the forum listing?','linktopages','$linktopages','','yesno',6)");
$DB_site->query("INSERT INTO setting VALUES (NULL,9,'Maximum links to individual pages','maxmultipage','$maxmultipage','When linking to multiple pages in the forum display, this allows you to set the cut off point on which long posts stop adding more page numbers and are replaced by \'more...\'','',7)");
$DB_site->query("INSERT INTO setting VALUES (NULL,9,'Showing Votes','showvotes','2','How many votes will a thread need before the votes are displayed?','',8)");
$DB_site->query("INSERT INTO setting VALUES (NULL,9,'Change Votes?','votechange','0','Allow users to change their thread rating votes?','yesno',9)");
$DB_site->query("INSERT INTO setting VALUES (NULL,9,'Prefix for moved threads','movedthreadprefix','Moved: ','The text with which to prefix a thread that has been moved to another forum. (You may use HTML)','',10)");
$DB_site->query("INSERT INTO setting VALUES (NULL,9,'Prefix for Sticky threads','stickythreadprefix','Sticky: ','Prefix to append to the beginning of thread titles that have been set to \"Sticky\". These threads always appear at the top of the thread list. (You may use HTML)','',11)");
$DB_site->query("INSERT INTO setting VALUES (NULL,9,'Prefix for Polls','pollthreadprefix','Poll: ','Prefix to append to the beginning of Poll thread titles. (You may use HTML)','',12)");
$DB_site->query("INSERT INTO setting VALUES (NULL,9,'Use Forumjump?','useforumjump','1','Do you want to use the Forumjump drop-down menu on your pages?  If your mysql server is optimized and you still are having problems you can try disabling this option to save queries.','yesno',12)");
$DB_site->query("INSERT INTO setting VALUES (NULL,9,'Depth of Forums', 'forumdisplaydepth', '2', 'Depth of forums to show on forum display when displaying subforums. Do not go too large on this value for performance reasons.', '', '13')");
$DB_site->query("INSERT INTO setting VALUES (NULL,10,'Enable searches?','enablesearches','$allowsearches','Allow searching for posts within the BB. This is quite a server intensive process so you may want to disable it.</p>\r\n<p>To disable searching of all forums, delete the option from the searchintro template. ','yesno',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,10,'Number of posts per page','searchperpage','25','Number of successful search items to display per page.','',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,10,'Floodcheck - Minimum time between searches','searchfloodtime','0','The minimum time (in seconds) that must expire before the user can search again. Set this to 0 to disable it.','',3)");
$DB_site->query("INSERT INTO setting VALUES (NULL,10,'Minimum Word Length','minsearchlength','4','Enter the minimum word length that the search engine is to index.  The smaller this number is, the larger your search index, and conversely your database is going to be.','',4)");
$DB_site->query("INSERT INTO setting VALUES (NULL,10,'Maximum Word Length','maxsearchlength','20','Enter the maximum word length that the search engine is to index.  The larger this number is, the larger your search index, and conversely your database is going to be.','',5)");
$DB_site->query("INSERT INTO setting VALUES (NULL,10,'Allow Wild Cards?','allowwildcards','1','Allow users to use a star (*) in searches to match partial words?','yesno',6)");

$DB_site->query("INSERT INTO setting VALUES (NULL,11,'Enable Email features?','enableemail','$enableemail','Enable email sending features: send to friend and email notification for posters and moderators. Don\'t forget to remove those links from the <i>forumdisplay, newreply, newtopic</i>, &amp; <i>editpost</i> templates<br><br>You can turn off the \'Send to Friend\' feature for invidual user groups in the <a href=\"usergroup.php?s=$session[sessionhash]&action=modify\" target=\"_blank\">User Permissions area</a>.','yesno',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,12,'Time Zone Offset','timeoffset','".intval(date("H",12*60*60)-gmdate("H",12*60*60))."','Time (in hours) that the server is offset from GMT. Please select the most appropriate option.','<select name=\\\\\"setting[\$setting[settingid]]\\\\\">\r\n<option value=\\\\\"-12\\\\\" \".iif(\$setting[value]==-12,\"selected\",\"\").\">(GMT -12:00 hours) Eniwetok, Kwajalein</option>\r\n<option value=\\\\\"-11\\\\\" \".iif(\$setting[value]==-11,\"selected\",\"\").\">(GMT -11:00 hours) Midway Island, Samoa</option>\r\n<option value=\\\\\"-10\\\\\" \".iif(\$setting[value]==-10,\"selected\",\"\").\">(GMT -10:00 hours) Hawaii</option>\r\n<option value=\\\\\"-9\\\\\" \".iif(\$setting[value]==-9,\"selected\",\"\").\">(GMT -9:00 hours) Alaska</option>\r\n<option value=\\\\\"-8\\\\\" \".iif(\$setting[value]==-8,\"selected\",\"\").\">(GMT -8:00 hours) Pacific Time (US & Canada)</option>\r\n<option value=\\\\\"-7\\\\\" \".iif(\$setting[value]==-7,\"selected\",\"\").\">(GMT -7:00 hours) Mountain Time (US & Canada)</option>\r\n<option value=\\\\\"-6\\\\\" \".iif(\$setting[value]==-6,\"selected\",\"\").\">(GMT -6:00 hours) Central Time (US & Canada), Mexico City</option>\r\n<option value=\\\\\"-5\\\\\" \".iif(\$setting[value]==-5,\"selected\",\"\").\">(GMT -5:00 hours) Eastern Time (US & Canada), Bogota, Lima, Quito</option>\r\n<option value=\\\\\"-4\\\\\" \".iif(\$setting[value]==-4,\"selected\",\"\").\">(GMT -4:00 hours) Atlantic Time (Canada), Caracas, La Paz</option>\r\n<option value=\\\\\"-3.5\\\\\" \".iif(\$setting[value]==-3.5,\"selected\",\"\").\">(GMT -3:30 hours) Newfoundland</option>\r\n<option value=\\\\\"-3\\\\\" \".iif(\$setting[value]==-3,\"selected\",\"\").\">(GMT -3:00 hours) Brazil, Buenos Aires, Georgetown</option>\r\n<option value=\\\\\"-2\\\\\" \".iif(\$setting[value]==-2,\"selected\",\"\").\">(GMT -2:00 hours) Mid-Atlantic</option>\r\n<option value=\\\\\"-1\\\\\" \".iif(\$setting[value]==-1,\"selected\",\"\").\">(GMT -1:00 hours) Azores, Cape Verde Islands</option>\r\n<option value=\\\\\"0\\\\\" \".iif(\$setting[value]==0,\"selected\",\"\").\">(GMT) Western Europe Time, London, Lisbon, Casablanca, Monrovia</option>\r\n<option value=\\\\\"+1\\\\\" \".iif(\$setting[value]==+1,\"selected\",\"\").\">(GMT +1:00 hours) CET(Central Europe Time), Angola, Libya</option>\r\n<option value=\\\\\"+2\\\\\" \".iif(\$setting[value]==+2,\"selected\",\"\").\">(GMT +2:00 hours) EET(Eastern Europe Time), Kaliningrad, South Africa</option>\r\n<option value=\\\\\"+3\\\\\" \".iif(\$setting[value]==+3,\"selected\",\"\").\">(GMT +3:00 hours) Baghdad, Kuwait, Riyadh, Moscow, St. Petersburg, Volgograd, Nairobi</option>\r\n<option value=\\\\\"+3.5\\\\\" \".iif(\$setting[value]==+3.5,\"selected\",\"\").\">(GMT +3:30 hours) Tehran</option>\r\n<option value=\\\\\"+4\\\\\" \".iif(\$setting[value]==+4,\"selected\",\"\").\">(GMT +4:00 hours) Abu Dhabi, Muscat, Baku, Tbilisi</option>\r\n<option value=\\\\\"+4.5\\\\\" \".iif(\$setting[value]==+4.5,\"selected\",\"\").\">(GMT +4:30 hours) Kabul</option>\r\n<option value=\\\\\"+5\\\\\" \".iif(\$setting[value]==+5,\"selected\",\"\").\">(GMT +5:00 hours) Ekaterinburg, Islamabad, Karachi, Tashkent</option>\r\n<option value=\\\\\"+5.5\\\\\" \".iif(\$setting[value]==+5.5,\"selected\",\"\").\">(GMT +5:30 hours) Bombay, Calcutta, Madras, New Delhi</option>\r\n<option value=\\\\\"+6\\\\\" \".iif(\$setting[value]==+6,\"selected\",\"\").\">(GMT +6:00 hours) Almaty, Dhaka, Colombo</option>\r\n<option value=\\\\\"+7\\\\\" \".iif(\$setting[value]==+7,\"selected\",\"\").\">(GMT +7:00 hours) Bangkok, Hanoi, Jakarta</option>\r\n<option value=\\\\\"+8\\\\\" \".iif(\$setting[value]==+8,\"selected\",\"\").\">(GMT +8:00 hours) Beijing, Perth, Singapore, Hong Kong, Chongqing, Urumqi, Taipei</option>\r\n<option value=\\\\\"+9\\\\\" \".iif(\$setting[value]==+9,\"selected\",\"\").\">(GMT +9:00 hours) Tokyo, Seoul, Osaka, Sapporo, Yakutsk</option>\r\n<option value=\\\\\"+9.5\\\\\" \".iif(\$setting[value]==+9.5,\"selected\",\"\").\">(GMT +9:30 hours) Adelaide, Darwin</option>\r\n<option value=\\\\\"+10\\\\\" \".iif(\$setting[value]==+10,\"selected\",\"\").\">(GMT +10:00 hours) EAST(East Australian Standard), Guam, Papua New Guinea, Vladivostok</option>\r\n<option value=\\\\\"+11\\\\\" \".iif(\$setting[value]==+11,\"selected\",\"\").\">(GMT +11:00 hours) Magadan, Solomon Islands, New Caledonia</option>\r\n<option value=\\\\\"+12\\\\\" \".iif(\$setting[value]==+12,\"selected\",\"\").\">(GMT +12:00 hours) Auckland, Wellington, Fiji, Kamchatka, Marshall Island</option>\r\n</select>',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,12,'Format of dates','dateformat','$dateformat','Format that the date is presented in on the pages.</p>\r\n<p>See: <a href=\"http://www.php.net/manual/function.date.php3\" target=_blank>http://www.php.net/manual/function.date.php3</a></p>\r\n<p>Examples:<br>\r\nUS Format (e.g., 04-25-98) - m-d-y<br>\r\nExpanded US Format (e.g., April 25th, 1998) - F jS, Y<br>\r\nEuropean Format (e.g., 25-04-98) - d-m-Y<br>\r\nExpanded European Format (e.g., 25th April 1998) - jS F Y','',3)");
$DB_site->query("INSERT INTO setting VALUES (NULL,12,'Format of times','timeformat','$timeformat','Format that the time is presented in on the pages.</p>\r\n<p>See: <a href=\"http://www.php.net/manual/function.date.php3\" target=_blank>http://www.php.net/manual/function.date.php3</a></p>\r\n<p>Examples:<br>\r\nUse AM/PM Time Format (eg, 11:15 PM) - h:i A<br>\r\nUser 24-Hour Format Time (eg, 23:15) - H:i','',4)");
$DB_site->query("INSERT INTO setting VALUES (NULL,12,'Format for registration date','registereddateformat','$registereddateformat','This is used to format dates shown with users\' posts. In the left hand column of a thread display, under the username and title, there is some text showing when the user registered.</p>\r\n<p>See: <a href=\"http://www.php.net/manual/function.date.php3\" target=_blank>http://www.php.net/manual/function.date.php3</a>','',5)");
$DB_site->query("INSERT INTO setting VALUES (NULL,12,'Birthday Format','calformat1','F j, Y','Format of date shown in profile when user gives their birthyear.','',6)");
$DB_site->query("INSERT INTO setting VALUES (NULL,12,'Birthday Format #2','calformat2','F j','Format of user\'s birthday shown on profile when the user does specify their birth year. DO NOT put in a code for the year.','',7)");
$DB_site->query("INSERT INTO setting VALUES (NULL,13,'Enable censor?','enablecensor','$enablecensor','You may have certain words censored on your BB. Words you choose to censor will be replaced by asterisks. All subjects and messages will be affected. \r\n','yesno',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,13,'Words to censor','censorwords','$censorwords','Type all words you want censored in the field below. Do not use commas to separate words, just use spaces. For example, type \"dog cat boy\", rather than \"dog, cat, boy.\" If you type \"dog\", all words containing the string \"dog\" would be censored (dogma, for instance, would appear as \"***ma\"). To censor more accurately, you can require that censors occur only for exact words. You can do this by placing a censor word in curly braces, as in {dog}. Signifying \"dog\" in the curly braces would mean that dogma would appear as dogma, but dog would appear as \"***\". Thus your censor list may appear as: cat {dog} {barn} barn<br>Do not use quotation marks and make sure you use curly braces, not parentheses, when specifying exact words.<br>This field can contain a maximum 250 characters.','',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,13,'Character to use to replace censored words:','censorchar','$censorchar','','',3)");
$DB_site->query("INSERT INTO setting VALUES (NULL,14,'Show the \'Edited by xxx on yyy\' when a post is edited?','showeditedby','$showeditedby','','yesno',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,14,'Show \'edited by\' for admins?','showeditedbyadmin','$showeditedbyadmin','If you want the [edited by xxx] message to appear when an admin edits a message, select yes here. This message will appear automatically for all moderators and other users, but using this option you can optionally turn it off.','yesno',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,14,'Time to wait before starting to display \'edited by...\'','noeditedbytime','$noeditedbytime','Time limit (in minutes) to allow user to edit the post without the [edited by xxx] message appearing at the bottom of the post.','',3)");
$DB_site->query("INSERT INTO setting VALUES (NULL,14,'Time limit on editing of posts','edittimelimit','$edittimelimit','Time limit (in minutes) to impose on editing of messages. After this time limit only moderators will be able edit or delete the message. 1 day is 1440 minutes. Set this to 0 if you do not want it to be active.','',4)");
$DB_site->query("INSERT INTO setting VALUES (NULL,14,'Time limit on editing of thread title','editthreadtitlelimit','5','Specify the time-limit (in minutes) within which the thread-title may be edited by the thread starter.','','5')");
$DB_site->query("INSERT INTO setting VALUES (NULL,15,'Log IP addresses?','logip','$logip','For security reasons, you may wish to display the IP number of the person posting a message. The default is OFF. You may log the IP to file only- in which case the IP number is not viewable on the bulletin board, but is logged, or you may have the IP numbers logged and displayed publicly on the bulletin board.','Do not log IP<input type=\\\\\"radio\\\\\" name=\\\\\"setting[\$setting[settingid]]\\\\\"  \".iif(\$setting[value]==0,\"checked\",\"\").\" value=\\\\\"0\\\\\"> Display but require administrator or moderator <input type=\\\\\"radio\\\\\" name=\\\\\"setting[\$setting[settingid]]\\\\\" \".iif(\$setting[value]==1,\"checked\",\"\").\" value=\\\\\"1\\\\\"> Display publicly <input type=\\\\\"radio\\\\\" name=\\\\\"setting[\$setting[settingid]]\\\\\" \".iif(\$setting[value]==2,\"checked\",\"\").\" value=\\\\\"2\\\\\">',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,16,'Enable checking for post flooding?','enablefloodcheck','$enablefloodcheck','You may prevent your users from flooding your board with posts by activating this feature. By enabling floodcheck, you disallow users from posting within a given time span of their last post. In other words, if you set a floodcheck time span of 60 seconds, a user may not post a note within 60 seconds of his last post. Administrators and moderators are exempt from floodcheck.','yesno',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,16,'Minimum time between posts','floodchecktime','$floodchecktime','Set the amount of time in seconds used by FloodCheck to pevent post flooding. Recommended: 60. Type the number of seconds only.','',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,17,'Enable Banning Options?','enablebanning','$enablebanning','Banning allows you to stop certain IP addresses and email addresses from registering and posting to the board. ','yesno',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,17,'IPs to ban:','banip','$banip','IP Number Ban Lists: You may ban any IP numbers from registering and posting. Type in the complete IP number (as in 243.21.31.7), or use a partial IP number (as in 243.21.31). The BB will do matches from the beginning of each IP number that you enter. Thus, If you enter a partial IP of 243.21.31, someone attempting to register who has an IP number of 243.21.31.5 will not be able to register. Similarly, if you have an IP ban on 243.21, someone registering who has an IP of 243.21.3.44 will not be able to register. Thus, be careful when you add IPs to your ban list and be as specific as possible. As with the email ban list, put a space between each IP number. The IP Ban prevents anyone with matching IP number from registering and posting.','textarea',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,17,'Email addresses to ban','banemail','$banemail','Email Ban Lists: You may ban certain email addresses from registering on your forums. To ban a specific email, type the full email address (as in, waldo@whereiswaldo.com). To ban all email addresses from certain domains, such as hotmail, simply type the domain name (as in hotmail.com)- that will prevent anyone using a hotmail address from registering. Put a space between each banned email.','textarea',3)");
$DB_site->query("INSERT INTO setting VALUES (NULL,17,'Allow user to keep banned email','allowkeepbannedemail','1','If you ban an email address and a user already uses that address, a problem will occur. Using this option, you can specify whether the user will have to enter a new email address in their profile when they next modify their email address, or whether the user can just keep the email address which you have banned.','yesno',4)");
$DB_site->query("INSERT INTO setting VALUES (NULL,18,'Text for \'on\'','ontext','$ontext','Text that means on. This is used to keep the code language independent. It is used with the vB code / HTML code On / Off settings for postings.','',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,18,'Text for \'off\'','offtext','$offtext','Text that means off. This is used to keep the code language independent. It is used with the vB code / HTML code On / Off settings for postings.','',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,19,'Enable Private Messaging?','enablepms','1','Enabling this will add some performance overhead on the main index and it may not be a feature you wish to have at all.','yesno',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,19,'Allow vB IMG code in private messages?','privallowbbimagecode','1','','yesno',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,19,'Allow vB code in private messages?','privallowbbcode','1','','yesno',3)");
$DB_site->query("INSERT INTO setting VALUES (NULL,19,'Allow smilies in private messages?','privallowsmilies','1','','yesno',4)");
$DB_site->query("INSERT INTO setting VALUES (NULL,19,'Allow HTML in private messages?','privallowhtml','0','','yesno',5)");
$DB_site->query("INSERT INTO setting VALUES (NULL,19,'Allow message icons','privallowicons','1','Allow the use of the standard message icons for private messages.','yesno',6)");
$DB_site->query("INSERT INTO setting VALUES (NULL,19,'Maximum saved messages','pmquota','70','Maximum number of saved messages a user can have. 0 means unlimited','',7)");
$DB_site->query("INSERT INTO setting VALUES (NULL,19,'Inbox name','inboxname','Inbox','The name of the inbox folder.','',8)");
$DB_site->query("INSERT INTO setting VALUES (NULL,19,'Sent Items Name','sentitemsname','Sent Items','The name of the Sent Items folder.','',9)");
$DB_site->query("INSERT INTO setting VALUES (NULL,19,'IM Support - Check for new PMs','checknewpm','1','Selecting yes for this option will cause the system to check the PM database every time a user loads a page, and will display a visible prompt for it.','yesno',10)");
$DB_site->query("INSERT INTO setting VALUES (NULL,19,'Floodcheck - Minimum time between messages','pmfloodtime','60','Private Message Flood Checking. Select the minimum time that must pass before a user can send another private message. This is to prevent a single user \'spamming\' by sending lots of messages very quickly. Set this to 0 to disable the option.','',11)");
$DB_site->query("INSERT INTO setting VALUES (NULL,19,'Maximum characters per private message','pmmaxchars','1000','Maximum characters to allow in a private message. Set this to 0 for no limit.','',12)");
$DB_site->query("INSERT INTO setting VALUES (NULL,19,'Word to denote cancelled message','pmcancelledword','Cancelled:','This is the word that will prefix the title of \"cancelled\" messages in the <i>message tracking</i> section. (You may use HTML)','','15')");
$DB_site->query("INSERT INTO setting VALUES (NULL,19,'Delete \'cancelled\' messages?','pmcancelkill',0,'When users \'cancel\' messages in the message tracking area, would you like to remove the message completely? WARNING: Selecting \'yes\' could confuse users who have been notified by email about the message.','yesno',17)");
$DB_site->query("INSERT INTO setting VALUES (NULL,20,'Add Standard headers','addheaders','$addheaders','This option does not work with some combinations of web server, so is off by default. However, some IIS setups may need it turned on.</p>\r\n\r\n<p>It will send the 200 OK HTTP headers if turned on. Only turn it on if you\'re sure, as it may break your board!','yesno',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,20,'Add No-cache headers','nocacheheaders','$nocacheheaders','Selecting yes will cause vBulletin to add no-cache HTTP headers. These are very effective, so adding them may cause server load to increase due to increase page requests.','yesno',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,20,'GZIP Output','gzipoutput','0','Selecting yes will enable vBulletin to gzip the output of pages, thus reducing bandwidth requirements. This will be only used on clients that support it, and are HTTP 1.1 compliant. There will be a performance overhead. This feature requires PHP 4.0.1 or greater, and the ZLIB library.','yesno',3)");
$DB_site->query("INSERT INTO setting VALUES (NULL,20,'GZIP compression level','gziplevel','1','Set the level of GZIP compression that will take place on the output. 0=none; 9=max.','',4)");
$DB_site->query("INSERT INTO setting VALUES (NULL,20,'Cookie Domain','cookiedomain','','The domain on which you want the cookie to have effect. If you want this to affect all of yourhost.com rather than just forums.yourhost.com, enter .yourhost.com here (note the 2 dots!!!). Can be left blank.','',5)");
$DB_site->query("INSERT INTO setting VALUES (NULL,20,'Path to save cookies','cookiepath','$cookiepath','The path that the cookie is saved to. If you run more than one board on the same domain, it will be neccessary to set this to the inidividual directories of the forums. Otherwise, just leave it as / .','',6)");
$DB_site->query("INSERT INTO setting VALUES (NULL,21,'Template version number','templateversion','2.0.1','Don\'t touch!','',0)");
$DB_site->query("INSERT INTO setting VALUES (NULL,22,'Spell Check Language','spellchecklang','en','The language used for the spell checking features, provided by <a href=\"http://www.spellchecker.net/\" target=_blank>Spellchecker.net</a>. If you do not want to use these features, you should remove them from the template.','<select name=\\\\\"setting[\$setting[settingid]]\\\\\">\r\n<option value=\\\\\"en\\\\\" \".iif(\$setting[value]==\"en\",\"selected\",\"\").\">American English</option>\r\n<option value=\\\\\"uk\\\\\" \".iif(\$setting[value]==\"uk\",\"selected\",\"\").\">British English</option>\r\n<option value=\\\\\"fr\\\\\" \".iif(\$setting[value]==\"fr\",\"selected\",\"\").\">French</option>\r\n<option value=\\\\\"ge\\\\\" \".iif(\$setting[value]==\"ge\",\"selected\",\"\").\">German</option>\r\n<option value=\\\\\"it\\\\\" \".iif(\$setting[value]==\"it\",\"selected\",\"\").\">Italian</option>\r\n<option value=\\\\\"sp\\\\\" \".iif(\$setting[value]==\"sp\",\"selected\",\"\").\">Spanish</option>\r\n<option value=\\\\\"dk\\\\\" \".iif(\$setting[value]==\"dk\",\"selected\",\"\").\">Danish</option>\r\n<option value=\\\\\"br\\\\\" \".iif(\$setting[value]==\"br\",\"selected\",\"\").\">Brazilian Portuguese</option>\r\n<option value=\\\\\"nl\\\\\" \".iif(\$setting[value]==\"nl\",\"selected\",\"\").\">Dutch</option>\r\n<option value=\\\\\"no\\\\\" \".iif(\$setting[value]==\"no\",\"selected\",\"\").\">Norwegian</option>\r\n<option value=\\\\\"pt\\\\\" \".iif(\$setting[value]==\"pt\",\"selected\",\"\").\">Portuguese</option>\r\n<option value=\\\\\"se\\\\\" \".iif(\$setting[value]==\"se\",\"selected\",\"\").\">Swedish</option>\r\n<option value=\\\\\"fi\\\\\" \".iif(\$setting[value]==\"fi\",\"selected\",\"\").\">Finnish</option>\r\n</select>',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,23,'Add template name in comments','addtemplatename','0','Add the template name at the beginning and end of every template rendered. This is useful for debugging and analysing the HTML code, but turn it off to save bandwidth when running in a production environment.','yesno',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,24,'Simultaneous sessions limit','sessionlimit','0','Set this to the maximum number of simultaneous sessions that you want to be active at any one time. If this number is exceeded, new users are turned away until the server is less busy. Set this to 0 to disable this option.','',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,24,'*NIX Load Limit','loadlimit','0','vBulletin can read the overall load of the server on certain *nix setups (including Linux). This allows vBulletin to determine the load on the server and processor, and to turn away further users if the load becomes too high. If you do not want to use this option, set it to 0. A typical level would be 5.00 for a reasonable warning level.','',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,25,'Maximum Options','maxpolloptions','10','Maximum number of options a user can select for the poll. Set this to 0 to allow infintely many options.','',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,25,'Update last post time','updatelastpost','0','Update the last post time for the thread (thus returning it to the top of a forum) when a vote is placed.','yesno',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,26,'Enable Avatars','avatarenabled','1','Use this option to enable/disable the overall use of avatars.<br><br>Avatars are small images displayed under usernames in thread display and user info pages.','yesno',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,26,'Minimum custom posts','avatarcustomposts','0','Minimum number of posts that a user required before they can specify a custom avatar for use.','',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,26,'Allow uploads','avatarallowupload','1','Allow user to upload their own custom avatar if they have enough posts?','yesno',3)");
$DB_site->query("INSERT INTO setting VALUES (NULL,26,'Allow website uploads','avatarallowwebsite','1','Allow user to upload their own custom avatar from another website if they have enough posts?','yesno',4)");
$DB_site->query("INSERT INTO setting VALUES (NULL,26,'Maximum Dimensions','avatarmaxdimension','50','Maximum width and height (in pixels) that the custom avatar image can be.','',5)");
$DB_site->query("INSERT INTO setting VALUES (NULL,26,'Maximum File Size','avatarmaxsize','20000','The maximum file size (in bytes) that an avatar can be.\r\n\r\n1 KB = 1024 bytes\r\n1 MB = 1048576 bytes','',6)");
$DB_site->query("INSERT INTO setting VALUES (NULL,26,'Display Height','numavatarshigh','5','How many rows of avatars do you wish to display to the user when selecting an avatar?','',7)");
$DB_site->query("INSERT INTO setting VALUES (NULL,26,'Display Width','numavatarswide','5','How many columns of avatars do you wish to display to the user when selecting an avatar?','',8)");
$DB_site->query("INSERT INTO setting VALUES (NULL,27,'Maximum File Size','maxattachsize','102400','Specify the maximum size in bytes that an upload may be. Set this value to 0 to enable any sized uploads.\n\n1 KB = 1024 bytes\n1 MB = 1048576 bytes','',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,27,'Valid Extensions','attachextensions','gif jpg png txt zip bmp jpeg','Valid extensions that uploads may have. Separate each item with a space.\n\nFor each extension, you should have a file in the /images/attach/ folder called xxx.gif where xxx is the extension of the file. This allows you to have an icon for each file type.','',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,27,'View Images','viewattachedimages','0','Do you wish to display attached images in the threads? Select no to just generate a link to download the image.','yesno',3)");
$DB_site->query("INSERT INTO setting VALUES (NULL,27,'Maximum Image Width','maxattachwidth','0','Set this to the maximum width attached images (jpg and gif) may have. Set it to 0 to not limit the width.','',4)");
$DB_site->query("INSERT INTO setting VALUES (NULL,27,'Maximum Image Height','maxattachheight','0','Set this to the maximum height attached images (jpg and gif) may have. Set it to 0 to not limit the height.','',5)");
$DB_site->query("INSERT INTO setting VALUES (NULL,27,'Allow Duplicate Images','allowduplicates','1','Setting this to NO will cause the post to refer to the previous existence of the attachment instead of adding another copy of it to the database. It only checks for attachments posted by the user that is making the post.','yesno',6)");
$DB_site->query("INSERT INTO setting VALUES (NULL,28,'Enable Titles','ctEnable','1','Enable Custom User titles?','yesno',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,28,'Maximum Chars','ctMaxChars','25','Maximum length users will be allowed to set their custom title to.','',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,28,'Number of Posts','ctPosts','10','Number of posts a user must have before they can use custom titles.','',3)");
$DB_site->query("INSERT INTO setting VALUES (NULL,28,'Number of Days','ctDays','10','Number of days a user must be registered before they can use custom titles.','',4)");
$DB_site->query("INSERT INTO setting VALUES (NULL,28,'Allow Mods/Admins to Change titles','ctAdmin','1','Allow Admins/Mods to change titles whether or not they have enough posts or have been registered long enough? User titles must be enabled.','yesno',5)");
$DB_site->query("INSERT INTO setting VALUES (NULL,28,'Boolean','ctEitherOr','1','Do you want a user to have to have the number of posts you specified above AND be registered the number of days you specified above? If you select NO then if a user satisifies EITHER criteria than they can use custom titles. For Ex a User has been registered for 1 year but only has 20 posts. If you specified 100 posts and 1 year then they could use titles if you select NO.','yesno',6)");
$DB_site->query("INSERT INTO setting VALUES (NULL,28,'Censored Words','ctCensorWords','admin forum moderator vbulletin leader','Type all words you want censored in the field below. Do not use commas to separate words, just use spaces. For example, type \"dog cat boy\", rather than \"dog, cat, boy.\" If you type \"dog\", all words containing the string \"dog\" would be censored (dogma, for instance, would appear as \"***ma\"). To censor more accurately, you can require that censors occur only for exact words. You can do this by placing a censor word in curly braces, as in {dog}. Signifying \"dog\" in the curly braces would mean that dogma would appear as dogma, but dog would appear as \"***\". Thus your censor list may appear as: cat {dog} {barn} barn<br>\r\nDo not use quotation marks and make sure you use curly braces, not parentheses, when specifying exact words.','',7)");
$DB_site->query("INSERT INTO setting VALUES (NULL,28,'Exempt Mod from Censor','ctCensorMod','1','Do you want to exempt mods from the censor words? You will want to set this to yes if you censor anything that is part of a moderator\'s title like \"moderator\" as they have custom titles by default and will get censored.','yesno',8)");
$DB_site->query("INSERT INTO setting VALUES (NULL,29,'Enable Calendar','calendarenabled','1','Disable/enable the calendar','yesno',1)");
$DB_site->query("INSERT INTO setting VALUES (NULL,29,'Birthdays','calbirthday','1','Use birthdays?','yesno',2)");
$DB_site->query("INSERT INTO setting VALUES (NULL,29,'Individual Birthdays','calshowbirthdays','1','Show the individual birthdays for each user on the calendar? Set this to NO to just show a link if a particular day has birthdays on it.','yesno',3)");
$DB_site->query("INSERT INTO setting VALUES (NULL,29,'html','calallowhtml','0','Allow HTML to be used in the calendar events?','yesno',4)");
$DB_site->query("INSERT INTO setting VALUES (NULL,29,'bbimagecode','calbbimagecode','1','Allow [IMG] code to be used in calendar events?','yesno',5)");
$DB_site->query("INSERT INTO setting VALUES (NULL,29,'smilies','calallowsmilies','1','Allow smilies to be used in calendar events?','yesno',6)");
$DB_site->query("INSERT INTO setting VALUES (NULL,29,'bbcode','calallowbbcode','1','Allow VB code to be used in calendar events?','yesno',7)");
$DB_site->query("INSERT INTO setting VALUES (NULL,29,'title length','caltitlelength','50','Length to cut off titles when displayed on the main calendar. 0 disables cut-off.','',8)");
$DB_site->query("INSERT INTO setting VALUES (NULL,29,'Starting Day','calStart','1','Pick the day that you would like the weeks on your calendar to start with. Users can also change this in their profile to match their locale\'s customs.','<select name=\\\\\"setting[\$setting[settingid]]\\\\\">\r\n<option value=\\\\\"1\\\\\" \".iif(\$setting[value]==1,\"selected\",\"\").\">Sunday</option>\r\n<option value=\\\\\"2\\\\\" \".iif(\$setting[value]==2,\"selected\",\"\").\">Monday</option>\r\n<option value=\\\\\"3\\\\\" \".iif(\$setting[value]==3,\"selected\",\"\").\">Tuesday</option>\r\n<option value=\\\\\"4\\\\\" \".iif(\$setting[value]==4,\"selected\",\"\").\">Wednesday</option>\r\n<option value=\\\\\"5\\\\\" \".iif(\$setting[value]==5,\"selected\",\"\").\">Thursday</option>\r\n<option value=\\\\\"6\\\\\" \".iif(\$setting[value]==6,\"selected\",\"\").\">Friday</option>\r\n<option value=\\\\\"7\\\\\" \".iif(\$setting[value]==7,\"selected\",\"\").\">Saturday</option>\r\n</select>',9)");
$DB_site->query("INSERT INTO setting VALUES (NULL,'30','Upload In Safe Mode?','safeupload','0','If your server runs PHP with <b>SAFE MODE</b> Restrictions, set this to yes.','yesno','1')");
$DB_site->query("INSERT INTO setting VALUES (NULL,'30','Safe Mode Temp Directory','tmppath','/tmp','If your server is running in safe_mode, you\'ll need to specify a directory that is CHMOD to 777 that will act as a temporary directory for uploads.  All files are removed from this directory after database insertion. <br><b>Note:</b> Do NOT include the trailing slash (\"/\") after the directory name.','','2')");

echo "<p>Added setting data</p>\n";

$settings=$DB_site->query("SELECT varname,value FROM setting");
while ($setting=$DB_site->fetch_array($settings)) {
	$template.="\$$setting[varname] = \"".addslashes(str_replace("\"","\\\"",$setting[value]))."\";\n";
}

$DB_site->query("UPDATE template SET template='$template' WHERE title='options'");

echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
} // end step 10

if ($step==11) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 11
-------

+ Email notifications
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/

$query[]="INSERT INTO subscribethread (userid,threadid) SELECT DISTINCT userid,threadid FROM post WHERE email=1 AND userid<>0";
$explain[]="Adding subscribed threads";
$query[]="ALTER TABLE subscribethread ADD INDEX (threadid)";
$explain[]="Adding index to subscribethread";

doqueries();

echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
} // end step 11

if ($step==12) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 12
-------

+ Alter post table
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/

// get keys list
$sql="";
$start=0;
$keys = $DB_site->query("SHOW KEYS FROM post");
while ($key = $DB_site->fetch_array($keys)) {
	$kname=$key['Key_name'];
	if ($isdone[$kname]) {
	  continue;
	} else {
	  $isdone[$kname]=1;
   }

  if ($kname!="PRIMARY") {
    if ($start==0) {
	  $sql ="DROP INDEX $kname";
	  $start=1;
	} else {
	  $sql.=",DROP INDEX $kname";
    }
  }
}

if ($sql) {
  $query[]="ALTER TABLE post
	$sql";
  $explain[]="Altering post table";
  doqueries();
}

$query[]="ALTER TABLE post
	ADD edituserid INT UNSIGNED NOT NULL,
	ADD editdate INT UNSIGNED NOT NULL,
	ADD attachmentid SMALLINT UNSIGNED NOT NULL AFTER dateline,
	DROP email,
	CHANGE signature showsignature SMALLINT NOT NULL";
$explain[]="Altering post table";
doqueries();

$query[]="ALTER TABLE post
	ADD INDEX (userid),
	ADD INDEX (iconid),
	ADD INDEX (threadid,userid)";
$explain[]="Altering post table";
doqueries();

echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
} // end step 12

if ($step==13) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 13
-------

+ Do htmlspecialchars() on thread title
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/
if ($startat==0) {
  $startat=0;
}
$perpage=1000;

$threads=$DB_site->query("SELECT threadid,title FROM thread ORDER BY threadid DESC LIMIT $startat,$perpage");
while ($thread=$DB_site->fetch_array($threads)) {
  $done=1;
  if ($thread[title]!=htmlspecialchars($thread[title])) {
    $DB_site->query("UPDATE thread SET title='".addslashes(htmlspecialchars($thread[title]))."' WHERE threadid=$thread[threadid]");
		echo "<P>Thread $thread[threadid]</p>\n";
		flush();
  }
}

if ($done) {
  echo "<p><script language=\"javascript\">window.location=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\";</script><a name=\"end\"></a><a href=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\"><b>Batch completed. Click here to do next batch if you are not redirected --></b></a></p>\n";
} else {
  echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
}
} // end step 13

if ($step==14) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 14
-------

+ Update thread last poster id
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/
if ($startat==0) {
  $startat=0;
}
$perpage=1000;

$threads=$DB_site->query("SELECT thread.threadid,user.userid FROM thread LEFT JOIN user ON user.username=thread.postusername WHERE NOT ISNULL(user.userid) ORDER BY threadid DESC LIMIT $startat,$perpage");
while ($thread=$DB_site->fetch_array($threads)) {
  $done=1;

  $DB_site->query("UPDATE thread SET postuserid='$thread[userid]' WHERE threadid=$thread[threadid]");
  echo "<p>Thread $thread[threadid]</p>\n";
  flush();
}

if ($done) {
  echo "<p><script language=\"javascript\">window.location=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\";</script><a name=\"end\"></a><a href=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\"><b>Batch completed. Click here to do next batch if you are not redirected --></b></a></p>\n";
} else {
  echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
}
} // end step 14

if ($step==15) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 15
-------

+ Do htmlspecialchars() on post title
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/
if ($startat==0) {
  $startat=0;
}
$perpage=1000;

$posts=$DB_site->query("SELECT postid,title FROM post WHERE title<>'' ORDER BY postid DESC LIMIT $startat,$perpage");
while ($post=$DB_site->fetch_array($posts)) {
  $done=1;
  if ($post[title]!=htmlspecialchars($post[title])) {
    $DB_site->query("UPDATE post SET title='".addslashes(htmlspecialchars($post[title]))."' WHERE postid=$post[postid]");
    echo "<p>Post $post[postid]</p>\n";
    flush();
  }
}

if ($done) {
  echo "<p><script language=\"javascript\">window.location=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\";</script><a name=\"end\"></a><a href=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\"><b>Batch completed. Click here to do next batch if you are not redirected --></b></a></p>\n";
} else {
  echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
}
} // end step 15

if ($step==16) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 16
-------

+ Do htmlspecialchars() on various user fields
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/
if ($startat==0) {
  $startat=0;
}
$perpage=2000;

$users=$DB_site->query("SELECT userid,username,homepage,icq,aim,yahoo FROM user ORDER BY userid DESC LIMIT $startat,$perpage");
while ($user=$DB_site->fetch_array($users)) {
  $done=1;
  if ($user[username]!=htmlspecialchars($user[username]) or $user[homepage]!=htmlspecialchars($user[homepage]) or $user[icq]!=htmlspecialchars($user[icq]) or $user[aim]!=htmlspecialchars($user[aim]) or $user[yahoo]!=htmlspecialchars($user[yahoo])) {
    $DB_site->query("UPDATE user SET username='".addslashes(htmlspecialchars($user[username]))."',homepage='".addslashes(htmlspecialchars($user[homepage]))."',icq='".addslashes(htmlspecialchars($user[icq]))."',aim='".addslashes(htmlspecialchars($user[aim]))."',yahoo='".addslashes(htmlspecialchars($user[yahoo]))."' WHERE userid=$user[userid]");
    echo "<p>User $user[userid]</p>\n";
    flush();
  }
}

if ($done) {
  echo "<p><script language=\"javascript\">window.location=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\";</script><a name=\"end\"></a><a href=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\"><b>Batch completed. Click here to do next batch if you are not redirected --></b></a></p>\n";
} else {
  echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
}
} // end step 16

if ($step==17) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 17
-------

+ Get user's ip address
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/
if ($startat==0) {
  $startat=0;
}
$perpage=500;

// get users ip address
$users=$DB_site->query("SELECT userid FROM user WHERE user.userid<>0 AND user.posts>0 AND user.ipaddress='' ORDER BY userid DESC LIMIT $startat,$perpage");
while($user=$DB_site->fetch_array($users)) {
  $done=1;
  if ($userdone[$user[userid]]) {
    continue;
  } else {
    $userdone[$user[userid]]=1;
  }
  if ($ipadr=$DB_site->query_first("SELECT ipaddress FROM post WHERE userid='$user[userid]' AND ipaddress<>'' LIMIT 1")) {
    $DB_site->query("UPDATE user SET ipaddress='$ipadr[ipaddress]' WHERE userid=$user[userid] AND ipaddress=''");
  }
  echo "<p>User $user[userid]</p>\n";
  flush();
}

if ($done) {
  echo "<p><script language=\"javascript\">window.location=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\";</script><a name=\"end\"></a><a href=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\"><b>Batch completed. Click here to do next batch if you are not redirected --></b></a></p>\n";
} else {
  echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
}
}// end step 17

if ($step==18) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 18
-------

+ Parse location, etc for users
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/
if ($startat==0) {
  $startat=0;
}
$perpage=1000;

$userfields=$DB_site->query("SELECT * FROM userfield WHERE field1<>'' LIMIT $startat,$perpage");
while ($userfield=$DB_site->fetch_array($userfields)) {
  $done=1;

	$bio = explode("\n", trim($userfield[field1]));
	$location = "";
	$interests = "";
	$biography = "";
	while(list($key,$val)=each($bio)) {
		if (strlen(strpos($val, 'Location:'))) {
			$location = trim(eregi_replace("^Location:([^\\[]*)", "\\1", "$val"));
		} elseif (strlen(strpos($val, 'Interests:'))) {
			$interests = trim(eregi_replace("^Interests:([^\\[]*)", "\\1", "$val"));
		} elseif (strlen(strpos($val, 'Occupation:'))) {
			$interests = trim(eregi_replace("^Occupation:([^\\[]*)", "\\1", "$val"));
		} else {
		  $biography.="$val\n";
		}
	}
	if ($location!="" or $interests!="" or $occupation!="") {
  	  $biography=trim($biography);
      $DB_site->query("UPDATE userfield
                       SET field1='".addslashes(htmlspecialchars($biography))."',
                        field2='".addslashes(htmlspecialchars($location))."',
                        field3='".addslashes(htmlspecialchars($interests))."',
                        field4='".addslashes(htmlspecialchars($occupation))."'
                       WHERE userid=$userfield[userid]");

     echo "<p>User $userfield[userid]</p>\n";
     flush();
   }
}

if ($done) {
  echo "<p><script language=\"javascript\">window.location=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\";</script><a name=\"end\"></a><a href=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\"><b>Batch completed. Click here to do next batch if you are not redirected --></b></a></p>\n";
} else {
  echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
}
} // end step 18

if ($step==19) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 19
-------

+ Insert templates
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/

$path="./vbulletin.style";

if(file_exists($path)==0) {
	$styletext="";
} else {
	$filesize=filesize($path);

	$filenum=fopen($path,"r");

	$styletext=fread($filenum,$filesize);

	fclose($filenum);
}

if ($styletext=="") {
  echo "<p>Please ensure that the vbulletin.style file exists in the current directory and then reload this current page.</p>";
  exit;
}

$DB_site->query("DELETE FROM template WHERE templatesetid=-1 AND title<>'options'");
$DB_site->query("DELETE FROM replacement WHERE replacementsetid=-1");

$stylebits=explode("|||",$styletext);

list($devnul,$styleversion)=each($stylebits);

list($devnul,$style[title])=each($stylebits);
list($devnul,$replacementset[title])=each($stylebits);
list($devnul,$templateset[title])=each($stylebits);

// check to see if we are installing a master template set or just a custom style set

// installing a master!!
$style[styleid]=-1;
$style[userselect]=0;
$style[replacementsetid]=-1;
$style[templatesetid]=-1;

// get number of replacements and templates
list($devnull,$numreplacements)=each($stylebits);
list($devnull,$numtemplates)=each($stylebits);

$counter=0;
while ($counter++<$numreplacements) {
	list($devnull,$findword)=each($stylebits);
	list($devnull,$replaceword)=each($stylebits);
	if (trim($findword)!="") {
		$DB_site->query("INSERT INTO replacement (replacementsetid,findword,replaceword) VALUES ($style[replacementsetid],'".addslashes($findword)."','".addslashes($replaceword)."')");
	}
}

$counter=0;
while ($counter++<$numtemplates) {
	list($devnull,$title)=each($stylebits);
	list($devnull,$template)=each($stylebits);
	if (trim($title)!="") {
		$DB_site->query("INSERT INTO template (templatesetid,title,template) VALUES ($style[templatesetid],'".addslashes($title)."','".addslashes($template)."')");
	}
}

echo "<p>Style imported correctly!</p>";

echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
} // end step 19

if ($step==20) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 20
-------

+ PM Folder Upgrade
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/
if ($startat==0) {
  $startat=0;
}
$perpage=1000;

$DB_site->reporterror=0;
  $DB_site->query("SELECT COUNT(*) AS count FROM privatercvd");
  $errno=$DB_site->errno;
  if (!$errno) {
    $errno = 0;
  }
$DB_site->reporterror=1;

if ($errno==0) {

  $folders=$DB_site->query("SELECT userid,pmfolders FROM user WHERE pmfolders<>'' LIMIT $startat,$perpage");
  if ($DB_site->num_rows($folders)>0) {
    $done=1;
    while($folder=$DB_site->fetch_array($folders)) {
      $allfolders = split("\n", trim($folder[pmfolders]));
      $foldersql = '';
      while (list($key,$val)=each($allfolders)) {
        $foldersplit = split("\|\|\|", $val);
        if (!$foldersplit[1] or $foldersplit[2]) { //folders that bypassed security are bad
          continue;
        }
        $foldersplit[0]--;
        if (!$foldersql) {
          $foldersql = "$foldersplit[0]|||".addslashes($foldersplit[1]);
        } else {
          $foldersql .= "\n$foldersplit[0]|||".addslashes($foldersplit[1]);
        }
      }  //folders for this user

      echo "<p>Converted PM folders for $folder[userid]</p>\n";
      $DB_site->query("UPDATE user SET pmfolders='$foldersql' WHERE userid=$folder[userid]");
    } //users
  } //num rows

  if ($done) {
    echo "<p><script language=\"javascript\">window.location=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\";</script><a name=\"end\"></a><a href=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\"><b>Batch completed. Click here to do next batch if you are not redirected --></b></a></p>\n";
  } else {
    echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
  }
} else {
  $step = 23;
}
} // end step 20

if ($step==21) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 21
-------

+ PM Received Messages Upgrade
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/
if ($startat==0) {
  $startat=0;
}
$perpage=1000;

$pms=$DB_site->query("SELECT *,UNIX_TIMESTAMP(datetime) AS unixtime FROM privatercvd LIMIT $startat,$perpage");
while($pm=$DB_site->fetch_array($pms)) {
  $done = 1;
  $touserid = $pm[toid];
  $fromuserid = $pm[fromid];
  $title = addslashes(htmlspecialchars($pm[title]));
  $dateline = $pm[unixtime];
  $message = addslashes($pm[text]);
  $iconid = $pm[iconid];
  $showsignature = $pm[signature];
  $folderid = $pm[folder];
  if (!$folderid) {
    $folderid=0;
  }

  echo "<p>Converted received PM $pm[msgid]</p>\n";
  $DB_site->query("INSERT INTO privatemessage (privatemessageid,userid,touserid,fromuserid,title,message,dateline,showsignature,iconid,messageread,folderid) VALUES (NULL,$touserid,$touserid,$fromuserid,'$title','$message','$dateline','$showsignature','$iconid',1,$folderid)");
}

if ($done) {
  echo "<p><script language=\"javascript\">window.location=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\";</script><a name=\"end\"></a><a href=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\"><b>Batch completed. Click here to do next batch if you are not redirected --></b></a></p>\n";
} else {
  echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
}

} //end step 21

if ($step==22) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 22
-------

+ PM Sent Messages Upgrade
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/
if ($startat==0) {
  $startat=0;
}
$perpage=1000;

$pms=$DB_site->query("SELECT *,UNIX_TIMESTAMP(datetime) AS unixtime FROM privatesent LIMIT $startat,$perpage");
while($pm=$DB_site->fetch_array($pms)) {
  $done = 1;
  $touserid = $pm[toid];
  $fromuserid = $pm[fromid];
  $title = addslashes(htmlspecialchars($pm[title]));
  $dateline = $pm[unixtime];
  $message = addslashes($pm[text]);
  $iconid = $pm[iconid];
  $showsignature = $pm[signature];

  echo "<p>Converted sent PM $pm[msgid]</p>\n";
  $DB_site->query("INSERT INTO privatemessage (privatemessageid,userid,touserid,fromuserid,title,message,dateline,showsignature,iconid,messageread,folderid) VALUES (NULL,$fromuserid,$touserid,$fromuserid,'$title','$message','$dateline','$showsignature','$iconid',1,-1)");
}

if ($done) {
  echo "<p><script language=\"javascript\">window.location=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\";</script><a name=\"end\"></a><a href=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\"><b>Batch completed. Click here to do next batch if you are not redirected --></b></a></p>\n";
} else {
  $query[]="DROP TABLE IF EXISTS privatercvd";
  $explain[]="Dropping old received PMs";

  $query[]="DROP TABLE IF EXISTS privatesent";
  $explain[]="Dropping old sent PMs";

  doqueries();
  echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
}

} //end step 22

if ($step==23) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 23
-------

+ Buddylist Upgrade
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/
if ($startat==0) {
  $startat=0;
}
$perpage=1000;

$buddylists=$DB_site->query("SELECT userid,buddylist,ignorelist FROM user WHERE buddylist<>'' OR ignorelist<>'' LIMIT $startat,$perpage");
if ($DB_site->num_rows($buddylists) > 0) {
  while($buddy=$DB_site->fetch_array($buddylists)) {
    $done = 1;
    $buddy['buddylist'] = str_replace(',0', '', $buddy['buddylist']);
    $buddy['buddylist'] = str_replace(',1', '', $buddy['buddylist']);
    $buddy['buddylist'] = str_replace(';', ' ', $buddy['buddylist']);
    $buddy['buddylist'] = str_replace(',', '', $buddy['buddylist']); //any stray things
    $buddy['buddylist'] = trim($buddy['buddylist']);

    $buddy['ignorelist'] = str_replace("\n", " ", $buddy['ignorelist']);
    $buddy['ignorelist'] = str_replace("  ", " ", $buddy['ignorelist']);
    $buddy['ignorelist'] = trim($buddy['ignorelist']);

    echo "<p>Buddylist upgrade for $buddy[userid]<p>\n";
    $DB_site->query("UPDATE user SET buddylist='$buddy[buddylist]',ignorelist='$buddy[ignorelist]' WHERE userid=$buddy[userid]");
  }
}

if ($done) {
  echo "<p><script language=\"javascript\">window.location=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\";</script><a name=\"end\"></a><a href=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\"><b>Batch completed. Click here to do next batch if you are not redirected --></b></a></p>\n";
} else {
  echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
}

} // end step 23

if ($step==24) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 24
-------

+ Upgrade old polls
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/
if ($startat==0) {
  $startat=0;
}
$perpage=1000;

$polls=$DB_site->query("SELECT pollid,question,options FROM poll WHERE options<>'' LIMIT $startat,$perpage");
if ($DB_site->num_rows($polls) > 0) {
  while($poll=$DB_site->fetch_array($polls)) {
    $done = 1;
    $options=explode("#*#", $poll['options']);
    $optionsstring = "";
    $votesstring = "";
    $optionscount = 0;
    while(list($key,$val)=each($options)) {
      if ($key % 2 == 0) {
        if (!$val) {
          continue;
        }
        $val = str_replace("|||"," || | ", $val);
        if (!$optionsstring) {
          $optionsstring = "$val";
        } else {
          $optionsstring .= "|||".$val;
        }
        $optionscount++;
      } else {
        if (!$val) {
          $val = "0";
        }
        if ($votesstring=="") {
          $votesstring = "$val";
        } else {
          $votesstring .= "|||".$val;
        }
      }
    }

    echo "<p>Poll upgrade for poll $poll[pollid]<p>\n";
    $DB_site->query("UPDATE poll SET question='".addslashes($poll['question'])."', options='".addslashes($optionsstring)."', votes='".addslashes($votesstring)."', numberoptions=$optionscount WHERE pollid=$poll[pollid]");
  }
}

if ($done) {
  echo "<p><script language=\"javascript\">window.location=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\";</script><a name=\"end\"></a><a href=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\"><b>Batch completed. Click here to do next batch if you are not redirected --></b></a></p>\n";
} else {
  echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
}

} // end step 24

if ($step==25) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 25
-------

+ Upgrade old polls (most pollid to thread)
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/
if ($startat==0) {
  $startat=0;
}
$perpage=1000;

$DB_site->reporterror=0;
  $DB_site->query("SELECT COUNT(*) AS count FROM post WHERE pollid<>0");
  $errno=$DB_site->errno;
  if (!$errno) {
    $errno = 0;
  }
$DB_site->reporterror=1;

if ($errno==0) {
  $posts=$DB_site->query("SELECT postid,threadid,pollid FROM post WHERE pollid<>0 LIMIT $startat,$perpage");
  if ($DB_site->num_rows($posts) > 0) {
    $done = 1;
    while($post=$DB_site->fetch_array($posts)) {
      echo "<p>Poll upgrade for post $post[postid] with poll<p>\n";
      $DB_site->query("UPDATE thread SET pollid=$post[pollid] WHERE threadid=$post[threadid]");
    }
  }

  if ($done) {
    echo "<p><script language=\"javascript\">window.location=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\";</script><a name=\"end\"></a><a href=\"upgrade1.php?step=$step&startat=".($startat+$perpage)."#end\"><b>Batch completed. Click here to do next batch if you are not redirected --></b></a></p>\n";
  } else {
    echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
  }
} else {
  $step = 26;
}

} // end step 25

if ($step==26) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 26
-------

+ drop pollid from post table
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/

$DB_site->reporterror=0;
  $DB_site->query("SELECT COUNT(*) AS count FROM post WHERE pollid<>''");
  $pollerrno=$DB_site->errno;
  if (!$pollerrno) {
    $pollerrno = 0;
  }
$DB_site->reporterror=1;

  if($pollerrno==0) {
    $query[]="ALTER TABLE post DROP pollid";
    $explain[]="Dropping incompatible pollid field";

    doqueries();
  }

  echo "<p><a href=\"upgrade1.php?step=".($step+1)."\">Next step --></a></p>\n";
} //end step 26

if ($step==27) {
/*
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
STEP 27
-------

+ All done?
=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
*/
?>
<p>You have now successfully upgraded to vBulletin 2.0.0. Delete this file, and proceed to the <a href="index.php"><b>control panel</b></a>.</p>

<p>You will need to generate a new search index. Please head to the "Update Counters" section of the control panel to do this.</p>
<?php

} // end step 26

?></BODY></HTML>