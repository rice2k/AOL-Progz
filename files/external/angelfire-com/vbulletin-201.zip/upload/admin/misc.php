<?php
error_reporting(7);

if (function_exists("set_time_limit")==1 and get_cfg_var("safe_mode")==0) {
  @set_time_limit(1200);
}

//suppress gzipping
$nozip=1;

require("./global.php");

adminlog();

cpheader();

// ###################### Start user choices #######################
if (isset($action)==0 or $action=="") {

  doformheader("misc","updateuser");

  maketableheader("Update Users Info</b> - </b>updates user titles<b>","",0);
  makeinputcode("Number of users to do per cycle: ","perpage","1000");
  doformfooter("Update");

  doformheader("misc","updateforum");

  maketableheader("Update Forums Info</b> - </b>update forum post counts<b>","",0);
  makeinputcode("Number of forums to do per cycle: ","perpage","100");
  doformfooter("Update");

  doformheader("misc","updatethread");

  maketableheader("Update Thread Info</b> - </b>update thread post counts, original posters, last post date, attachment totals<b>","",0);
  makeinputcode("Number of threads to do per cycle: ","perpage","2000");
  doformfooter("Update");

  doformheader("misc","buildsearchindex");

  maketableheader("Rebuild search index</b> - </b>(very intensive, but rarely needed)<b>","",0);
  makeinputcode("Number of threads to do per cycle: ","perpage",100);
  makeinputcode("Thread number to start at: ","startat",0);
  makeinputcode("Total number of threads to process: <BR>(0 for unlimited)","doprocess",0);
  makeyesnocode("Include automatic JavaScript<BR>redirect to next page?","autoredirect",1);
  echo "<tr class='".iif($bgcounter++%2==0,"firstalt","secondalt")."'><td colspan=2><p><i>If you are reindexing, you may want to empty the indexes.</i> <a href=\"misc.php?action=emptyindex\"><b>Click Here to do so!</b></a></td></tr>";
  doformfooter("Re-index");

  doformheader("misc","removedupe");

  maketableheader("Remove dupe threads</b> - </b>(relatively intensive, but useful after importing posts)<b>","",0);
  makeinputcode("Number of threads to do per cycle: ","perpage","500");
  doformfooter("Remove");
}

// ###################### Start emptying the index #######################
if ($action=="emptyindex") {

	doformheader("misc","doemptyindex");
	maketableheader("Confirm action");
	makedescription("Are you sure you wish to empty the search index?");
	doformfooter("Yes","",2,"No");

}

// ###################### Start emptying the index #######################

if ($HTTP_POST_VARS['action']=="doemptyindex") {
  $DB_site->query("DELETE FROM searchindex");
  $DB_site->query("DELETE FROM word");

  echo "<p>Index successfully emptied</p>";
}

// ###################### Start build search index #######################
if ($action=="buildsearchindex") {
  if (isset($perpage)==0 or $perpage=="") {
    $perpage=100;
  }
  if (isset($startat)==0 or $startat=="") {
    $startat=0;
  }
  if (!isset($totalthreads)) {
    $totalthreads = 0;
  }

  $finishat=$startat+$perpage;

  echo "<p>Building index..</p>";

  $threads=$DB_site->query("SELECT DISTINCT thread.threadid,post.postid FROM thread,post WHERE thread.threadid=post.threadid AND thread.threadid>=$startat AND thread.threadid<$finishat AND thread.visible=1 ORDER BY thread.threadid");
  while ($thread=$DB_site->fetch_array($threads)) {
    $totalposts++;
    if ($thread['threadid']>$lastthreadid) {
      $totalthreads++;
    }
    $lastthreadid = $thread['threadid'];
    indexpost($thread['postid']);
    echo "Processing post <b>$thread[postid]</b> in thread <b>$thread[threadid]</b><BR>\n";
    flush();
  }

  if (($totalthreads<$doprocess or $doprocess==0) and $checkmore=$DB_site->query_first("SELECT threadid FROM thread WHERE threadid>=$finishat")) {
    if ($autoredirect==1) {
      echo "<script language=\"javascript\">window.location=\"misc.php?s=$session[sessionhash]&action=buildsearchindex&startat=$finishat&perpage=$perpage&autoredirect=$autoredirect&totalthreads=$totalthreads&doprocess=$doprocess\";</script>";
    }
    echo "<p><a href=\"misc.php?s=$session[sessionhash]&action=buildsearchindex&startat=$finishat&perpage=$perpage&autoredirect=$autoredirect&totalthreads=$totalthreads&doprocess=$doprocess\">Click here to continue building search engine</a></p>";
  } else {
    echo "<p>All done!</p>";
  }
}


// ###################### Start update user #######################
if ($action=="updateuser") {
  if (isset($perpage)==0 or $perpage=="") {
    $perpage=1000;
  }
  if (isset($startat)==0 or $startat=="") {
    $startat=0;
  }
  $finishat=$startat+$perpage;

  echo "<p>User ids:</p>";

  $users=$DB_site->query("SELECT userid,usertitle,usergroupid,customtitle,posts FROM user WHERE userid>=$startat AND userid<$finishat ORDER BY userid DESC");
  while ($user=$DB_site->fetch_array($users)) {
    unset($sql);
    $userid=$user[userid];

    // update user stuff
    if ($user[customtitle]==0)
    {
      $usergroup=$DB_site->query_first("SELECT usertitle FROM usergroup WHERE usergroupid=$user[usergroupid]");
      if ($usergroup[usertitle]=="")
      {
        $gettitle=$DB_site->query_first("SELECT title FROM usertitle WHERE minposts<=$user[posts] ORDER BY minposts DESC LIMIT 1");
        $usertitle=$gettitle[title];
      }
      else
      {
        $usertitle=$usergroup[usertitle];
      }

      $sql="usertitle='".addslashes($usertitle)."',";
    }

    if ($lastpost=$DB_site->query_first("SELECT dateline FROM post WHERE userid=$userid ORDER BY dateline DESC LIMIT 1")) {
      $lastpost[dateline]=intval($lastpost[dateline]);
      if (trim($lastpost[dateline])=="") {
        $lastpost[dateline]=0;
      }
    } else {
      $lastpost[dateline]=0;
    }

    $DB_site->query("UPDATE user SET $sql"."lastpost='$lastpost[dateline]' WHERE userid='$user[userid]'");

    echo "Processing user <b>$user[userid]</b><br>\n";
    flush();

  }
  if ($checkmore=$DB_site->query_first("SELECT userid FROM user WHERE userid>=$finishat")) {
    echo "<script language=\"javascript\">window.location=\"misc.php?s=$session[sessionhash]&action=updateuser&startat=$finishat&perpage=$perpage\";</script>";
    echo "<p><a href=\"misc.php?s=$session[sessionhash]&action=updateuser&startat=$finishat&perpage=$perpage\">Click here to continue updating users</a></p>";
  } else {
    echo "<p>All done!</p>";
  }

}

// ###################### Start update forum #######################
if ($action=="updateforum") {
  if (isset($perpage)==0 or $perpage=="") {
    $perpage=100;
  }
  if (isset($startat)==0 or $startat=="") {
    $startat=0;
  }
  $finishat=$startat+$perpage;

  echo "<p>Forum ids:</p>";

  $forums=$DB_site->query("SELECT forumid FROM forum WHERE forumid>=$startat AND forumid<$finishat ORDER BY forumid DESC");
  while ($forum=$DB_site->fetch_array($forums)) {

    $forumid=$forum[forumid];

    echo "Processing forum <b>$forumid</b><br>\n";
    flush();

    updateforumcount($forumid);

  }
  if ($checkmore=$DB_site->query_first("SELECT forumid FROM forum WHERE forumid>=$finishat")) {
    echo "<script language=\"javascript\">window.location=\"misc.php?s=$session[sessionhash]&action=updateforum&startat=$finishat&perpage=$perpage\";</script>";
    echo "<p><a href=\"misc.php?s=$session[sessionhash]&action=updateforum&startat=$finishat&perpage=$perpage\">Click here to continue updating forums</a></p>";
  } else {
    echo "<p>All done!</p>";
  }
}

// ###################### Start update threads #######################
if ($action=="updatethread") {

  if (isset($perpage)==0 or $perpage=="") {
    $perpage=2000;
  }
  if (isset($startat)==0 or $startat=="") {
    $startat=0;
  }
  $finishat=$startat+$perpage;
  echo "<p>Thread ids:</p>";

  $threads=$DB_site->query("SELECT MIN(post.postid) AS minpost, MAX(post.postid) AS maxpost, thread.threadid, MAX(post.dateline) AS dateline,
 							(COUNT(*)-1) AS posts,
 							  SUM(attachment.visible) AS attachsum
							FROM post,thread
							LEFT JOIN attachment ON attachment.attachmentid=post.attachmentid
							WHERE thread.threadid=post.threadid
							 AND thread.threadid>=$startat
							 AND thread.threadid<$finishat
							GROUP BY thread.threadid
							ORDER BY threadid DESC");
  while ($thread=$DB_site->fetch_array($threads)) {

    $threadid=$thread[threadid];

    echo "Processing thread <b>$threadid</b><br>\n";
    flush();
    $attachsum=$thread[attachsum];
    $numberposts=$thread[posts];
    $lastpost=$thread[dateline];
    $firstusername=$DB_site->query_first("SELECT username,userid FROM post WHERE postid=$thread[minpost]");
    $firstuserid=$firstusername['userid'];
    if ($firstusername[userid]==0) {
      $firstusername=$firstusername[username];
    } else {
      $users=$DB_site->query_first("SELECT username FROM user WHERE userid=$firstusername[userid]");
      $firstusername=$users[username];
    }

    $lastusername=$DB_site->query_first("SELECT username,userid FROM post WHERE postid=$thread[maxpost]");
    if ($lastusername[userid]==0) {
      $lastusername=$lastusername[username];
    } else {
      $users=$DB_site->query_first("SELECT username FROM user WHERE userid=$lastusername[userid]");
      $lastusername=$users[username];
    }


    $DB_site->query("UPDATE thread SET lastpost=$lastpost,replycount=$numberposts,postusername='".addslashes($firstusername)."', postuserid='$firstuserid', lastposter='".addslashes($lastusername)."',attach=$attachsum WHERE threadid=$threadid");
  }
  if ($checkmore=$DB_site->query_first("SELECT threadid FROM thread WHERE threadid>=$finishat")) {
    echo "<script language=\"javascript\">window.location=\"misc.php?s=$session[sessionhash]&action=updatethread&startat=$finishat&perpage=$perpage\";</script>";
    echo "<p><a href=\"misc.php?s=$session[sessionhash]&action=updatethread&startat=$finishat&perpage=$perpage\">Click here to continue updating threads</a></p>";
  } else {
    echo "<p>All done!</p>";
  }

}
// ###################### Start remove dupe #######################
if ($action=="removedupe") {

  if (isset($perpage)==0 or $perpage=="") {
    $perpage=500;
  }
  if (isset($startat)==0 or $startat=="") {
    $startat=0;
  }
  $finishat=$startat+$perpage;
  echo "<p>Thread ids:</p>";

  $threads=$DB_site->query("SELECT threadid,title,forumid,postusername,dateline FROM thread WHERE threadid>=$startat AND threadid<$finishat ORDER BY threadid");
  while ($thread=$DB_site->fetch_array($threads)) {

    $threadid=$thread[threadid];

    echo "Processing thread <b>$threadid</b><br>\n";
    flush();

    $deletethreads=$DB_site->query("SELECT threadid FROM thread WHERE title='".addslashes($thread[title])."' AND forumid=$thread[forumid] AND postusername='".addslashes($thread[postusername])."' AND dateline=$thread[dateline] AND threadid>$thread[threadid]");

    while ($deletethread=$DB_site->fetch_array($deletethreads)) {
      $DB_site->query("DELETE FROM post WHERE threadid=$deletethread[threadid]");
      $DB_site->query("DELETE FROM thread WHERE threadid=$deletethread[threadid]");
      echo " &nbsp;&nbsp;&nbsp; <p>Deleted thread <b>$deletethread[threadid]</b></p>";
    }

  }
  if ($checkmore=$DB_site->query_first("SELECT threadid FROM thread WHERE threadid>=$finishat")) {
    echo "<script language=\"javascript\">window.location=\"misc.php?s=$session[sessionhash]&action=removedupe&startat=$finishat&perpage=$perpage\";</script>";
    echo "<p><a href=\"misc.php?s=$session[sessionhash]&action=removedupe&startat=$finishat&perpage=$perpage\">Click here to continue removing duplicates</a></p>";
  } else {
    echo "<p>All done!</p>";
  }

}

cpfooter();
?>