<?php
error_reporting(7);

require("./global.php");

cpheader();

adminlog(iif($profilefieldid!=0,"profilefield id = $profilefieldid",""));

if (isset($action)==0) {
  $action="modify";
}

// ###################### Start add #######################
if ($action=="add") {

  doformheader("profilefield","insert");
  maketableheader("Add new user profile field");

  makeinputcode("Title<br> - maximum 50","title");
  makeinputcode("Description<br>- indicate here for the user whether field is required/hidden<br> - maximum 250","description");
  makeinputcode("Maximum Input<br>- how many characters may a user enter into this field?<br> - maximum 250","maxlength","100");
  makeinputcode("Field Length<br>- how many characters long shall the input field appear on the form?<br> - maximum 250","size","25");
  makeinputcode("Display Order<br>- Sets order of fields when displayed at registration or getinfo","displayorder");
  makeyesnocode("Field required?<br>- Require field to be filled during registration","required",0);
  makeyesnocode("Field hidden?<br>- Field only viewable by admins and mods<br>- User will still be able to change it","hidden",0);

  doformfooter("Save");
}

// ###################### Start insert #######################
if ($HTTP_POST_VARS['action']=="insert") {

  $DB_site->query("INSERT INTO profilefield (profilefieldid,title,description,required,hidden,maxlength,size,displayorder) VALUES (NULL,'".addslashes($title)."','".addslashes($description)."',$required,$hidden,'$maxlength','$size','$displayorder')");
  $profilefieldid=$DB_site->insert_id();

  $DB_site->query("ALTER TABLE userfield ADD field$profilefieldid CHAR(250) NOT NULL");
  // Uncomment this line and the one id "Do Update" to change the field size to match what the user specifies as "maxlength"
  //$DB_site->query("ALTER TABLE userfield ADD field$profilefieldid CHAR($maxlength) NOT NULL");
  $DB_site->query("OPTIMIZE TABLE userfield");

  $action="modify";

  echo "<p>Record added</p>";

}

// ###################### Start edit #######################
if ($action=="edit") {

  $profilefield=$DB_site->query_first("SELECT title,description,required,hidden,maxlength,size,displayorder
                                       FROM profilefield
                                       WHERE profilefieldid=$profilefieldid");

  doformheader("profilefield","doupdate");
  maketableheader("Edit user profile field:</b> <i>$profilefield[title]</i>","",0);
  makehiddencode("profilefieldid","$profilefieldid");

  makeinputcode("Title<br> - maximum 50","title",$profilefield[title]);
  makeinputcode("Description<br>- indicate here for the user whether field is required/hidden<br> - maximum 250","description",$profilefield[description]);
  makeinputcode("Maximum Input<br>- how many characters may a user enter into this field?<br> - maximum 250","maxlength",$profilefield[maxlength]);
  makeinputcode("Field Length<br>- how many characters long shall the input field appear on the form?<br> - maximum 250","size",$profilefield[size]);
  makeinputcode("Display Order<br>- Sets order of fields when displayed at registration or getinfo<br> - Starts at 1","displayorder",$profilefield[displayorder]);
  makeyesnocode("Field required?<br>Require field to be filled during registration","required",$profilefield[required]);
  makeyesnocode("Field hidden?<br>Field only viewable by admins and mods<br>- User will still be able to change it","hidden",$profilefield[hidden]);

  doformfooter("Save Changes");

}

// ###################### Start do update #######################
if ($HTTP_POST_VARS['action']=="doupdate") {
  $profilefield=$DB_site->query_first("SELECT title FROM profilefield WHERE profilefieldid=$profilefieldid");

  $DB_site->query("UPDATE profilefield SET title='".addslashes($title)."',description='".addslashes($description)."',required=$required,hidden=$hidden,maxlength='$maxlength',size='$size',displayorder='$displayorder' WHERE profilefieldid=$profilefieldid");
  //$DB_site->query("ALTER TABLE userfield CHANGE field$profilefieldid field$profilefieldid CHAR ($maxlength) NOT NULL");

  echo "<p>Record updated!</p>";

  $action="modify";

}
// ###################### Start Remove #######################

if ($action=="remove") {

	doformheader("profilefield","kill");
	makehiddencode("profilefieldid",$profilefieldid);
	maketableheader("Confirm deletion");
	makedescription("Are you sure you want to delete the selected record? This WILL lose data!");
	doformfooter("Yes","",2,"No");

}

// ###################### Start Kill #######################

if ($HTTP_POST_VARS['action']=="kill") {

  $DB_site->query("DELETE FROM profilefield WHERE profilefieldid=$profilefieldid");
  $DB_site->query("ALTER TABLE userfield DROP field$profilefieldid");
  $DB_site->query("OPTIMIZE TABLE userfield");

  $action="modify";
}

// ###################### Start modify #######################
if ($action=="modify") {

  $profilefields=$DB_site->query("SELECT profilefieldid,title FROM profilefield ORDER BY displayorder");

  echo "<ul>";

  while ($profilefield=$DB_site->fetch_array($profilefields)) {

    echo "<li>$profilefield[title] ".
			makelinkcode("edit","profilefield.php?s=$session[sessionhash]&action=edit&profilefieldid=$profilefield[profilefieldid]").
			makelinkcode("remove","profilefield.php?s=$session[sessionhash]&action=remove&profilefieldid=$profilefield[profilefieldid]").
			"</li>\n";

  }

  echo "</ul><p>That's all folks</p>";

}

cpfooter();
?>
