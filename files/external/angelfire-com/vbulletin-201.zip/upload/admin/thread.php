<?php
error_reporting(7);

//suppress gzipping
$nozip=1;

require("./global.php");

adminlog(iif($forumid!=0,"forum id = $forumid",""));

cpheader();

// ###################### Start Prune #######################
if ($action=="prune") {

  doformheader("thread","prunedate");
  maketableheader("Prune by date");
  makeinputcode("Delete threads with last post older than x days:<BR>(intensive if deleting a lot of threads)","daysdelete","0");
  makeforumchoosercode("Forum","forumid",-1,"All forums");
  makeyesnocode("Include sub forums","subforums");
  doformfooter("Prune");

  doformheader("thread","pruneuser");
  maketableheader("Prune by username");
  makeinputcode("Username","username");
  makeforumchoosercode("Forum","forumid",-1,"All forums");
  makeyesnocode("Include sub forums","subforums");
  doformfooter("Prune");

}

// ###################### Start Prune by date #######################
if ($action=="prunedate") {
  if ($daysdelete=="") {
    echo "<p>Please enter an age of post to delete</p>";
    exit;
  }

  if ($confirm!=1) {

    if ($forumid==-1) {
      $forumtitle="all forums";
    } else {
      $forum=$DB_site->query_first("SELECT title FROM forum WHERE forumid=$forumid");
      $forumtitle="the \"$forum[title]\" forum";
      if ($subforums) {
        $forumtitle.=" and sub forums";
      }
    }
    
    doformheader("thread","prunedate");
	 maketableheader("Prune All Threads Automatically");
	 makehiddencode("forumid", "$forumid");
	 makehiddencode("daysdelete", "$daysdelete");
	 makehiddencode("subforums", "$subforums");
	 makehiddencode("confirm", "1");
	 doformfooter("Click Here to Prune All Threads Automatically","",2);
	 
	 doformheader("thread","prunedatesel");
	 maketableheader("Prune Threads Selectively");
	 makehiddencode("forumid", "$forumid");
	 makehiddencode("daysdelete", "$daysdelete");
	 makehiddencode("subforums", "$subforums");
	 doformfooter("Click Here to Prune Threads Selectively","",2);
    
    //<a href=\"thread.php?s=$session[sessionhash]&action=prunedatesel&forumid=$forumid&daysdelete=$daysdelete&subforums=$subforums\"><b>here</b></a> to select those to delete.</p>";
    exit;
  }

  if ($forumid!=-1) {
    if ($subforums) {
      $forumcheck="(thread.forumid=$forumid OR INSTR(parentlist,',$forumid,')>0) AND ";
    } else {
      $forumcheck="thread.forumid=$forumid AND ";
    }
  }

  $datecut=time()-($daysdelete*86400);
  $threads=$DB_site->query("SELECT threadid FROM thread LEFT JOIN forum USING (forumid) WHERE $forumcheck thread.lastpost<=$datecut");
  while ($thread=$DB_site->fetch_array($threads)) {
    deletethread($thread[threadid],0);
  }

  echo "<p>Posts deleted successfully! It is recommend that you <a href=\"misc.php?s=$session[sessionhash]\">update counters</a> now.</p>";
}

// ###################### Start Prune by date selector #######################
if ($action=="prunedatesel") {

  doformheader("thread","doprunedate");

  if ($forumid!=-1) {
    if ($subforums) {
      $forumcheck="(thread.forumid=$forumid OR INSTR(parentlist,',$forumid,')>0) AND ";
    } else {
      $forumcheck="thread.forumid=$forumid AND ";
    }
  }

  echo "<tr class='tblhead'><td><font size='1'><b><span class='tblhead'>Thread Title</span></b></font></td><td><font size='1'><b><span class='tblhead'>Delete?</span></b></font></td></tr>\n";

  $datecut=time()-($daysdelete*86400);
  $threads=$DB_site->query("SELECT threadid,thread.title FROM thread LEFT JOIN forum USING (forumid) WHERE $forumcheck thread.lastpost<=$datecut ORDER BY thread.lastpost DESC");
  while ($thread=$DB_site->fetch_array($threads)) {
    makeyesnocode("<a href=\"../showthread.php?s=$session[sessionhash]&threadid=$thread[threadid]\" target=_blank>$thread[title]</a>","delete[$thread[threadid]]",1);
  }

  doformfooter("Submit - only click here if you are ABSOLUTELY certain");
}

// ###################### Start Prune by date selected #######################
if ($HTTP_POST_VARS['action']=="doprunedate") {

  echo "<p>Deleting...</p>";

  while (list($key,$val)=each($delete)) {
    if ($val==1) {
      deletethread($key,0);
    }
  }

  echo "<p>Threads deleted successfully! It is recommend that you <a href=\"misc.php?s=$session[sessionhash]\">update counters</a> now.</p>";
}

// ###################### Start Prune by user #######################
if ($action=="pruneuser") {
  if ($confirm!=1) {

    if (isset($username)==0 or $username=="") {
      echo "<p>Please enter a username to search for</p>";
      exit;
    }

    if ($forumid==-1) {
      $forumtitle="all forums";
    } else {
      $forum=$DB_site->query_first("SELECT title FROM forum WHERE forumid=$forumid");
      $forumtitle="the $forum[title] forum";
      if ($subforums) {
        $forumtitle.=" and sub forums";
      }
    }
    echo "<p>You are about to delete all posts and threads from $forumtitle by one of these users. Please select one:</p>";

    $users=$DB_site->query("SELECT userid,username FROM user WHERE INSTR(username,'".addslashes($username)."')>0 ORDER BY username");
    while ($user=$DB_site->fetch_array($users)) {
      
      doformheader("thread","pruneuser");
	   maketableheader("Prune All of \"$user[username]'s\" Posts Automatically");
	   makehiddencode("forumid", "$forumid");
	   makehiddencode("userid", "$user[userid]");
	   makehiddencode("subforums", "$subforums");
	   makehiddencode("confirm", "1");
	   doformfooter("Click Here to Prune All of &quot;$user[username]'s&quot; Posts Automatically","",2);
	   
	   doformheader("thread","pruneusersel");
	   maketableheader("Prune \"$user[username]'s\" Posts Selectively");
	   makehiddencode("forumid", "$forumid");
	   makehiddencode("userid", "$user[userid]");
	   makehiddencode("subforums", "$subforums");
	   makehiddencode("confirm", "1");
	   doformfooter("Click Here to Prune &quot;$user[username]'s&quot; Posts Selectively","",2);
	       
      echo "\n<hr>\n";
      
      //<a href=\"thread.php?s=$session[sessionhash]&action=pruneusersel&forumid=$forumid&userid=$user[userid]&confirm=1&subforums=$subforums\"><b>here</b></a> to select which posts to delete by <i>$user[username]</i>.</p>";
    }

    exit;
  }

  if ($forumid!=-1) {
    if ($subforums) {
      $forumcheck="(thread.forumid=$forumid OR INSTR(parentlist,',$forumid,')>0) AND ";
    } else {
      $forumcheck="thread.forumid=$forumid AND ";
    }
  }

  $usernames=$DB_site->query_first("SELECT username FROM user WHERE userid=$userid");
  $username=$usernames[username];

  $posts=$DB_site->query("SELECT postid FROM post,thread LEFT JOIN forum USING (forumid) WHERE $forumcheck post.threadid=thread.threadid AND post.userid=$userid");
  while ($post=$DB_site->fetch_array($posts)) {
    deletepost($post[postid]);
  }
  $threads=$DB_site->query("SELECT threadid FROM thread WHERE $forumcheck postusername='".addslashes($username)."'");
  while ($thread=$DB_site->fetch_array($threads)) {
    deletethread($thread[threadid],0);
  }

  echo "<p>Posts deleted successfully! It is recommend that you <a href=\"misc.php?s=$session[sessionhash]\">update counters</a> now.</p>";
}

// ###################### Start prune by user selector #######################
if ($action=="pruneusersel") {

  doformheader("thread","dopruneuser");
  $usernames=$DB_site->query_first("SELECT username FROM user WHERE userid=$userid");
  $username=$usernames[username];

  if ($forumid!=-1) {
    if ($subforums) {
      $forumcheck="(thread.forumid=$forumid OR INSTR(parentlist,',$forumid,')>0) AND ";
    } else {
      $forumcheck="thread.forumid=$forumid AND ";
    }
  }
  echo "<tr class='tblhead'><td><font size='1'><b><span class='tblhead'>Thread Title</span></b></font></td><td><font size='1'><b><span class='tblhead'>Delete?</span></b></font></td></tr>\n";

  $threads=$DB_site->query("SELECT threadid,thread.title FROM thread LEFT JOIN forum USING (forumid) WHERE $forumcheck postusername='".addslashes($username)."' ORDER BY thread.lastpost DESC");
  while ($thread=$DB_site->fetch_array($threads)) {
    makeyesnocode("<a href=\"../showthread.php?s=$session[sessionhash]&threadid=$thread[threadid]\" target=_blank>$thread[title]</a>","deletethread[$thread[threadid]]",1);
  }

  echo "
  <tr class='tblhead'><td colspan=\"2\"><hr></td></tr>\n";
  echo "<tr class='tblhead'><td><font size='1'><b><span class='tblhead'>Post</span></b></font></td><td><font size='1'><b><span class='tblhead'>Delete?</span></b></font></td></tr>\n";

  $threads=$DB_site->query("SELECT post.postid,thread.threadid,thread.title FROM post,thread LEFT JOIN forum USING (forumid) WHERE thread.threadid=post.threadid AND $forumcheck post.userid=$userid ORDER BY post.threadid DESC, post.dateline DESC");
  while ($thread=$DB_site->fetch_array($threads)) {
    makeyesnocode("<a href=\"../showthread.php?s=$session[sessionhash]&postid=$thread[postid]#post$thread[postid]\" target=_blank>$thread[title]</a> (postid $thread[postid])","deletepost[$thread[postid]]",1);
  }

  doformfooter("Submit - only click here if you are ABSOLUTELY certain");
}

// ###################### Start Prune by user selected #######################
if ($HTTP_POST_VARS['action']=="dopruneuser") {
  echo "<p>Deleting...</p>";

  while (list($key,$val)=each($deletethread)) {
    if ($val==1) {
      deletethread($key,0);
    }
  }

  while (list($key,$val)=each($deletepost)) {
    if ($val==1) {
      deletepost($key,0);
    }
  }

  echo "<p>Threads and posts deleted successfully! It is recommend that you <a href=\"misc.php?s=$session[sessionhash]\">update counters</a> now.</p>";
}

// ###################### Start Move #######################
if ($action=="move") {

  echo "<p>Note: This will only move the threads -- it will not copy them or leave a redirect!</p>";

  doformheader("thread","movedate");
  maketableheader("Move by date");
  makeinputcode("Move threads with last post older than x days:","daysmove","0");
  makeforumchoosercode("Source Forum","forumid",-1,"All forums");
  makeforumchoosercode("Destination Forum","destforumid");
  makelabelcode("Note: this will not move posts from sub forums!");

  doformfooter("Move");

  doformheader("thread","moveuser");
  maketableheader("Move by username");
  makeinputcode("Username","username");
  makeforumchoosercode("Source Forum","forumid",-1,"All forums");
  makeforumchoosercode("Destination Forum","destforumid");
  makelabelcode("Note: this will not move posts from sub forums!");

  doformfooter();

}

// ###################### Start by Move Date #######################
if ($HTTP_POST_VARS['action']=="movedate") {
  if ($daysmove=="") {
    echo "<p>Please enter an age of post to move</p>";
    exit;
  }

  if ($confirm!=1) {

    if ($forumid==-1) {
      $forumtitle="all";
    } else {
      $forum=$DB_site->query_first("SELECT title FROM forum WHERE forumid=$forumid");
      $forumtitle=$forum[title];
    }
    echo "<p>You are about to move all threads from the $forumtitle forum older than $daysmove day(s).";
    
    doformheader("thread","movedate");
	 maketableheader("Move All Threads Automatically");
	 makehiddencode("forumid", "$forumid");
	 makehiddencode("daysmove", "$daysmove");
	 makehiddencode("destforumid", "$destforumid");
	 makehiddencode("confirm", "1");
	 doformfooter("Click Here to Move All Threads Automatically","",2);
	 
	 doformheader("thread","movedatesel");
	 maketableheader("Move Threads Selectively");
	 makehiddencode("forumid", "$forumid");
	 makehiddencode("daysmove", "$daysmove");
	 makehiddencode("destforumid", "$destforumid");
	 doformfooter("Click Here to Move Threads Selectively","",2);
	 
    exit;
  }

  $forumcheck=iif($forumid!=-1,"forumid=$forumid AND ","");

  $datecut=time()-($daysmove*86400);
  $DB_site->query("UPDATE thread SET forumid=$destforumid WHERE $forumcheck thread.lastpost<=$datecut");

  echo "<p>Posts moved successfully! It is recommend that you <a href=\"misc.php?s=$session[sessionhash]\">update counters</a> now.</p>";
}

// ###################### Start Move by date selector #######################
if ($action=="movedatesel") {

  doformheader("thread","domovedate");
  makehiddencode("destforumid",$destforumid);
  maketableheader("Move Threads Selectively");

  $forumcheck=iif($forumid!=-1,"forumid=$forumid AND ","");

  $datecut=time()-($daysmove*86400);
  $threads=$DB_site->query("SELECT threadid,title FROM thread WHERE $forumcheck thread.lastpost<=$datecut ORDER BY lastpost DESC");
  while ($thread=$DB_site->fetch_array($threads)) {
    makeyesnocode("<a href=\"../showthread.php?s=$session[sessionhash]&threadid=$thread[threadid]\" target=\"_blank\"><i>$thread[title]</i></a>","move[$thread[threadid]]",1);
  }

  doformfooter("Submit - only click here if you are ABSOLUTELY certain");
}

// ###################### Start Move by date selected #######################
if ($HTTP_POST_VARS['action']=="domovedate") {

  echo "<p>Moving...</p>";

  while (list($key,$val)=each($move)) {
    if ($val==1) {
      $DB_site->query("UPDATE thread SET forumid=$destforumid WHERE threadid=$key");
    }
  }

  echo "<p>Posts moved successfully! It is recommend that you <a href=\"misc.php?s=$session[sessionhash]\">update counters</a> now.</p>";
}

// ###################### Start Move by user #######################
if ($HTTP_POST_VARS['action']=="moveuser") {
  if ($confirm!=1) {

    if (isset($username)==0 or $username=="") {
      echo "<p>Please enter a username to search for</p>";
      exit;
    }

    if ($forumid==-1) {
      $forumtitle="all forums";
    } else {
      $forum=$DB_site->query_first("SELECT title FROM forum WHERE forumid=$forumid");
      $forumtitle="the $forum[title] forum";
    }
    echo "<p>You are about to move all posts and threads from $forumtitle by one of these users. Please select one:</p>";

    $users=$DB_site->query("SELECT userid,username FROM user WHERE INSTR(username,'".addslashes($username)."')>0 ORDER BY username");
    while ($user=$DB_site->fetch_array($users)) {
      
      doformheader("thread","moveuser");
	   maketableheader("Move All of \"$user[username]'s\" Posts Automatically");
	   makehiddencode("forumid", "$forumid");
	   makehiddencode("userid", "$user[userid]");
	   makehiddencode("destforumid", "$destforumid");
	   makehiddencode("confirm", "1");
	   doformfooter("Click Here to Move All of &quot;$user[username]'s&quot; Posts Automatically","",2);
	   
	   doformheader("thread","moveusersel");
	   maketableheader("Move \"$user[username]'s\" Posts Selectively");
	   makehiddencode("forumid", "$forumid");
	   makehiddencode("userid", "$user[userid]");
	   makehiddencode("destforumid", "$destforumid");
	   makehiddencode("confirm", "1");
	   doformfooter("Click Here to Move &quot;$user[username]'s&quot; Posts Selectively","",2);
	       
      echo "\n<hr>\n";
    }

    exit;
  }

  $forumcheck=iif($forumid!=-1,"forumid=$forumid AND ","");

  $usernames=$DB_site->query_first("SELECT username FROM user WHERE userid=$userid");
  $username=$usernames[username];

  $DB_site->query("UPDATE thread SET forumid=$destforumid WHERE $forumcheck postusername='".addslashes($username)."'");

  echo "<p>Threads moved successfully! It is recommend that you <a href=\"misc.php?s=$session[sessionhash]\">update counters</a> now.</p>";
}

// ###################### Start move by user selector #######################
if ($action=="moveusersel") {

  doformheader("thread","domoveuser");
  makehiddencode("destforumid",$destforumid);
  $usernames=$DB_site->query_first("SELECT username FROM user WHERE userid=$userid");
  $username=$usernames[username];

  echo "<tr class='tblhead'><td><font size='1'><b><span class='tblhead'>Thread Title</span></b></font></td><td><font size='1'><b><span class='tblhead'>Move?</span></b></font></td></tr>\n";

  $forumcheck=iif($forumid!=-1,"thread.forumid=$forumid AND ","");

  $threads=$DB_site->query("SELECT threadid,title FROM thread WHERE $forumcheck postusername='".addslashes($username)."' ORDER BY thread.lastpost DESC");
  while ($thread=$DB_site->fetch_array($threads)) {
    makeyesnocode("<a href=\"../showthread.php?s=$session[sessionhash]&threadid=$thread[threadid]\" target=_blank>$thread[title]</a>","movethread[$thread[threadid]]",1);
  }

  doformfooter("Submit - only click here if you are ABSOLUTELY certain");
}

// ###################### Start move by user selected #######################
if ($HTTP_POST_VARS['action']=="domoveuser") {
  echo "<p>Moving...</p>";

  while (list($key,$val)=each($movethread)) {
    if ($val==1) {
      $DB_site->query("UPDATE thread SET forumid=$destforumid WHERE threadid=$key");
    }
  }

  echo "<p>Threads moved successfully! It is recommend that you <a href=\"misc.php?s=$session[sessionhash]\">update counters</a> now.</p>";
}


cpfooter();
?>
