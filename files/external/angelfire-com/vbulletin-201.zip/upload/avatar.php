<?php

$noheader=1;

//require("./global.php");

set_magic_quotes_runtime(0);

@error_reporting(7);

// ###################### Start init #######################
//load config
require('./admin/config.php');

// init db **********************
// load db class
$dbclassname="./admin/db_$dbservertype.php";
require($dbclassname);

$DB_site=new DB_Sql_vb;

$DB_site->appname='vBulletin';
$DB_site->appshortname='vBulletin (forum)';
$DB_site->database=$dbname;
$DB_site->server=$servername;
$DB_site->user=$dbusername;
$DB_site->password=$dbpassword;

$DB_site->connect();
// end init db

header("Content-type: image/gif");
if ($avatarinfo=$DB_site->query_first("SELECT avatardata,dateline,filename FROM customavatar WHERE userid='$userid'")) {
  header("Cache-control: max-age=31536000");
  header("Expires: " . gmdate("D, d M Y H:i:s",time()+31536000) . "GMT");
  header("Content-disposition: filename=$avatarinfo[filename]");
  header("Content-Length: ".strlen($avatarinfo[avatardata]));
  header("Last-Modified: " . gmdate("D, d M Y H:i:s",$avatarinfo[dateline]) . "GMT");
  echo $avatarinfo[avatardata];
} else {
  readfile("./images/clear.gif");
}

?>