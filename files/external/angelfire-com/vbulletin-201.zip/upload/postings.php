<?php
error_reporting(7);

require("./global.php");


// ############################### start do open / close thread ###############################
if ($action=="openclosethread" and $s==$session[dbsessionhash]) {

  $threadid=verifyid("thread",$threadid);

  $threadinfo=getthreadinfo($threadid);

  if (!ismoderator($threadinfo[forumid],"canopenclose")) {
    $permissions=getpermissions($threadinfo[forumid]);
    if (!$permissions[canview] or !$permissions[canopenclose]) {
      show_nopermission();
    } else {
      $firstpostinfo=$DB_site->query_first("SELECT userid FROM post WHERE threadid='$threadid' ORDER BY dateline LIMIT 1");
      if ($bbuserinfo[userid]!=$firstpostinfo[userid]) {
        show_nopermission();
      }
    }
  }

  if ($threadinfo[open]) {
    $threadinfo[open]=0;
    $action="closed";
  } else {
    $threadinfo[open]=1;
    $action="opened";
  }
  $threadinfo[notes] = "Thread $action by $bbuserinfo[username] on ".vbdate($dateformat." ".$timeformat,time()).". $threadinfo[notes]";
  $DB_site->query("UPDATE thread SET open=$threadinfo[open],notes='".addslashes($threadinfo[notes])."' WHERE threadid='$threadid'");

  eval("standardredirect(\"".gettemplate("redirect_openclose")."\",\"showthread.php?s=$session[sessionhash]&threadid=$threadid\");");

}

// ############################### start delete thread ###############################
if ($action=="deletethread") {

  $threadid = verifyid("thread",$threadid);
  $threadinfo=getthreadinfo($threadid);

  if (!$threadinfo[visible]) {
    $idname="thread";
    eval("standarderror(\"".gettemplate("error_invalidid")."\");");
  }

  if (!ismoderator($threadinfo[forumid],"candeleteposts")) {
    $permissions=getpermissions($threadinfo[forumid]);
    if (!$permissions[canview] or !$permissions[candelete]) {
      show_nopermission();
    } else {
      if (!$threadinfo[open]) {
        eval("standardredirect(\"".gettemplate("redirect_threadclosed")."\",\"showthread.php?s=$session[sessionhash]&threadid=$threadid\");");
        exit;
      }
      $firstpostinfo=$DB_site->query_first("SELECT userid FROM post WHERE threadid='$threadid' ORDER BY dateline LIMIT 1");
      if ($bbuserinfo[userid]!=$firstpostinfo[userid]) {
        show_nopermission();
      }
    }
  }

  // draw nav bar
  $navbar=makenavbar($threadid,"thread",1);

  eval("dooutput(\"".gettemplate("threads_deletethread")."\");");

}

// ############################### start do delete thread ###############################
if ($HTTP_POST_VARS['action']=="dodeletethread") {

  $threadid = verifyid("thread",$threadid);
  $threadinfo=getthreadinfo($threadid);
  $foruminfo=getforuminfo($threadinfo[forumid]);

  if (!$threadinfo[visible]) {
    $idname="thread";
    eval("standarderror(\"".gettemplate("error_invalidid")."\");");
  }

  if (!ismoderator($threadinfo[forumid],"candeleteposts")) {
    $permissions=getpermissions($threadinfo[forumid]);
    if (!$permissions[canview] or !$permissions[candelete]) {
      show_nopermission();
    } else {
      if (!$threadinfo[open]) {
        eval("standardredirect(\"".gettemplate("redirect_threadclosed")."\",\"showthread.php?s=$session[sessionhash]&threadid=$threadid\");");
        exit;
      }
      $firstpostinfo=$DB_site->query_first("SELECT userid FROM post WHERE threadid='$threadid' ORDER BY dateline LIMIT 1");
      if ($bbuserinfo[userid]!=$firstpostinfo[userid]) {
        show_nopermission();
      }
    }
  }

  deletethread($threadid,$foruminfo[countposts]);

  updateforumcount($threadinfo[forumid]);

  eval("standardredirect(\"".gettemplate("redirect_deletethread")."\",\"forumdisplay.php?s=$session[sessionhash]&forumid=$threadinfo[forumid]\");");

}

// ############################### start delete posts ###############################
if ($action=="deleteposts") {

  $threadid = verifyid("thread",$threadid);
  $threadinfo=getthreadinfo($threadid);

  if (!$threadinfo[visible]) {
    $idname="thread";
    eval("standarderror(\"".gettemplate("error_invalidid")."\");");
  }

  if (!ismoderator($threadinfo[forumid],"candeleteposts")) {
    show_nopermission();
  }

  // draw nav bar
  $navbar=makenavbar($threadid,"thread",1);

  $posts=$DB_site->query("SELECT post.*,user.* FROM post LEFT JOIN user ON user.userid=post.userid WHERE post.threadid='$threadid' ORDER BY dateline");
  $counter=0;
  while ($post=$DB_site->fetch_array($posts)) {
    if (++$counter%2==0) {
      $post[backcolor]="{firstaltcolor}";
    } else {
      $post[backcolor]="{secondaltcolor}";
    }
    $post[postdate]=vbdate($dateformat,$post[dateline]);
    $post[posttime]=vbdate($timeformat,$post[dateline]);

    // cut page text short if too long
    if (strlen($post[pagetext])>100) {
      $spacepos=strpos($post[pagetext]," ",100);
      if ($spacepos!=0) {
        $post[pagetext]=substr($post[pagetext],0,$spacepos)."...";
      }
    }
    $post[pagetext]=nl2br(htmlspecialchars($post[pagetext]));

    eval("\$postbits .= \"".gettemplate("threads_deletepostsbit")."\";");
  }

  eval("dooutput(\"".gettemplate("threads_deleteposts")."\");");

}

// ############################### start do delete posts ###############################
if ($HTTP_POST_VARS['action']=="dodeleteposts") {

  $threadid = verifyid("thread",$threadid);
  $threadinfo=getthreadinfo($threadid);
  $foruminfo=getforuminfo($threadinfo[forumid]);

  if (!$threadinfo[visible]) {
    $idname="thread";
    eval("standarderror(\"".gettemplate("error_invalidid")."\");");
  }

  if (!ismoderator($threadinfo[forumid],"candeleteposts")) {
    show_nopermission();
  }

  $deletethread=1;
  // decrement users post counts
  $posts=$DB_site->query("SELECT postid FROM post WHERE threadid='$threadid'");
  while ($post=$DB_site->fetch_array($posts)) {
    if ($deletepost[$post[postid]]=="yes") {
      deletepost($post[postid],$foruminfo[countposts]);
    } else {
      $deletethread=0;
    }
  }

  // update thread notes
  $threadinfo[notes] = "Thread had posts deleted by $bbuserinfo[username] on ".vbdate($dateformat." ".$timeformat,time()).". $threadinfo[notes]";
  $DB_site->query("UPDATE thread SET notes='".addslashes($threadinfo[notes])."' WHERE threadid=$threadinfo[threadid]");

  if ($deletethread) {
    deletethread($threadid,$foruminfo[countposts]);
  } else {
    updatethreadcount($threadid);
  }
  updateforumcount($threadinfo[forumid]);

  eval("standardredirect(\"".gettemplate("redirect_deleteposts")."\",\"showthread.php?s=$session[sessionhash]&threadid=$threadid\");");

}

// ############################### start retrieve ip ###############################
if ($action=="getip") {

  $postid=verifyid("post",$postid);
  $postinfo=getpostinfo($postid);
  $threadinfo=getthreadinfo($postinfo[threadid]);
  $foruminfo=getthreadinfo($threadinfo[forumid]);

  $postinfo[hostaddress]=gethostbyaddr($postinfo[ipaddress]);

  // check moderator permissions for getting ip
  if (!ismoderator($threadinfo[forumid],"canviewips")) {
    show_nopermission();
  }

  eval("standarderror(\"".gettemplate("threads_displayip")."\");");
}

// ###################### Start makeforumjumpbits #######################
function getmoveforums($parentid=-1,$addbox=1,$prependchars="") {
  // this generates the move to.. box for move/copy
  global $DB_site,$optionselected,$jumpforumid,$jumpforumtitle,$jumpforumbits;
  global $hideprivateforums,$bbuserinfo,$session, $useforumjump;

  $olduseforumjump=$useforumjump;
  $useforumjump=1;

  if ($addbox) {
    $jumpforumbits="";
  }

  $forums=$DB_site->query("SELECT forumid,title,displayorder,allowposting,parentid FROM forum WHERE displayorder<>0 AND parentid=$parentid ORDER BY displayorder");

  while ($forum=$DB_site->fetch_array($forums)) {

    $getperms=getpermissions($forum[forumid]);
    if ($getperms[canview]) {

      $jumpforumid=$forum[forumid];
      $jumpforumtitle=$prependchars." $forum[title]".iif($forum[allowposting],""," (no posting)");

      $optionselected="";
      eval("\$jumpforumbits .= \"".gettemplate("forumjumpbit")."\";");

      makeforumjump($forum[forumid],0,$prependchars."--");

    } // end if $getperms...
  } // end while

  $useforumjump=$olduseforumjump;

  return $jumpforumbits;
}

// ############################### start move thread ###############################
if ($action=="move") {

  $threadid = verifyid("thread",$threadid);
  $threadinfo=getthreadinfo($threadid);

  if (!$threadinfo[visible]) {
    $idname="thread";
    eval("standarderror(\"".gettemplate("error_invalidid")."\");");
  }

  // check forum permissions for this forum
  if (!ismoderator($threadinfo[forumid],"canmanagethreads")) {
    $permissions=getpermissions($forumid);
    if (!$permissions[canview] or !$permissions[canmove]) {
      show_nopermission();
    } else {
      if (!$threadinfo[open]) {
        eval("standardredirect(\"".gettemplate("redirect_threadclosed")."\",\"showthread.php?s=$session[sessionhash]&threadid=$threadid\");");
        exit;
      }
      $firstpostinfo=$DB_site->query_first("SELECT userid FROM post WHERE threadid='$threadid' ORDER BY dateline LIMIT 1");
      if ($bbuserinfo[userid]!=$firstpostinfo[userid]) {
        show_nopermission();
      }
    }
  }

  $moveforumbits=getmoveforums();

  // draw nav bar
  $navbar=makenavbar($threadid,"thread",1);

  eval("dooutput(\"".gettemplate("threads_move")."\");");

}

// ############################### start do move thread ###############################
if ($HTTP_POST_VARS['action']=="domove") {

  $threadid = verifyid("thread",$threadid);
  $threadinfo=getthreadinfo($threadid);

  if (!$threadinfo[visible]) {
    $idname="thread";
    eval("standarderror(\"".gettemplate("error_invalidid")."\");");
  }

  // check whether dest can contain posts
  $forumid=verifyid("forum",$forumid);
  $foruminfo=getforuminfo($forumid);
  if (!$foruminfo['cancontainthreads']) {
    eval("standarderror(\"".gettemplate("error_moveillegalforum")."\");");
    exit;
  }

  // check source forum permissions
  if (!ismoderator($threadinfo[forumid],"canmanagethreads")) {
    $permissions=getpermissions($threadinfo[forumid]);
    if (!$permissions[canview] or !$permissions[canmove]) {
      show_nopermission();
    } else {
      if (!$threadinfo[open]) {
        eval("standardredirect(\"".gettemplate("redirect_threadclosed")."\",\"showthread.php?s=$session[sessionhash]&threadid=$threadid\");");
        exit;
      }
      $firstpostinfo=$DB_site->query_first("SELECT userid FROM post WHERE threadid='$threadid' ORDER BY dateline LIMIT 1");
      if ($bbuserinfo[userid]!=$firstpostinfo[userid]) {
        show_nopermission();
      }
    }
  }

  // check destination forum permissions
  $permissions=getpermissions($forumid);
  if (!$permissions[canview]) {
    show_nopermission();
  }


	// check to see if this thread is being returned to a forum it's already been in
	// if a redirect exists already in the destination forum, remove it
	if ($checkprevious=$DB_site->query_first("SELECT threadid FROM thread WHERE forumid='$forumid' AND open='10' AND pollid='$threadid'")) {
		$DB_site->query("DELETE FROM thread WHERE threadid='$checkprevious[threadid]'");
	}

	if ($method=="move") { // straight move
		$threadinfo[notes]="Moved to '$foruminfo[title]' by $bbuserinfo[username] on ".vbdate($dateformat." ".$timeformat,time()).". $threadinfo[notes]";
		$DB_site->query("UPDATE thread SET forumid='".addslashes($forumid)."',notes='".addslashes($threadinfo[notes])."',sticky=0 WHERE threadid='$threadid'");

  } elseif ($method=="movered") { // move and leave redirect!

    $threadinfo[notes]="Moved (with redirect) to '$foruminfo[title]' by $bbuserinfo[username] on ".vbdate($dateformat." ".$timeformat,time()).". $threadinfo[notes]";
    $DB_site->query("INSERT INTO thread (threadid,title,lastpost,forumid,pollid,open,replycount,postusername,postuserid,lastposter,dateline,views,iconid,visible) VALUES (NULL,'".addslashes($threadinfo[title])."','".addslashes($threadinfo[lastpost])."','".addslashes($threadinfo[forumid])."','".addslashes($threadinfo[threadid])."',10,'".addslashes($threadinfo[replycount])."','".addslashes($threadinfo[postusername])."','".addslashes($threadinfo[postuserid])."','".addslashes($threadinfo[lastposter])."','".addslashes($threadinfo[dateline])."','".addslashes($threadinfo[views])."','".addslashes($threadinfo[iconid])."','".addslashes($threadinfo[visible])."')");

    $DB_site->query("UPDATE thread SET forumid='".addslashes($forumid)."', notes='".addslashes($threadinfo[notes])."' WHERE threadid='$threadid'");

  } else {

    //copy!!!
    $threadinfo[notes]="Copied to '$foruminfo[title]' by $bbuserinfo[username] on ".vbdate($dateformat." ".$timeformat,time()).". $threadinfo[notes]";

    if ($threadinfo['pollid'] and $threadinfo['open']!=10) {// We have a poll, need to duplicate it!
      if ($pollinfo=$DB_site->query_first("SELECT * FROM poll WHERE pollid='$threadinfo[pollid]'")) {
        $DB_site->query("INSERT INTO poll (question,dateline,options,votes,active,numberoptions,timeout)
                                           VALUES ('".addslashes($pollinfo[question])."','$pollinfo[dateline]','".addslashes($pollinfo[options])."','$pollinfo[votes]','$pollinfo[active]','$pollinfo[numberoptions]','$pollinfo[timeout]')");
        $oldpollid=$threadinfo['pollid'];
        $threadinfo['pollid'] = $DB_site->insert_id();
        $pollvotes=$DB_site->query("SELECT userid, votedate, voteoption FROM pollvote where pollid = '$oldpollid'");
        while ($pollvote=$DB_site->fetch_array($pollvotes)) {
          if ($insertsql) {
            $insertsql .= ",";
          }
          $insertsql .= "('$threadinfo[pollid]','$pollvote[userid]','$pollvote[votedate]','$pollvote[options]')";
        }
        if ($insertsql) {
          $DB_site->query("INSERT INTO pollvote (pollid,userid,votedate,voteoption) VALUES $insertsql");
        }
      }
    }

    $DB_site->query("INSERT INTO thread (threadid,title,lastpost,forumid,pollid,open,replycount,postusername,postuserid,lastposter,dateline,views,iconid,notes,visible) VALUES (NULL,'".addslashes($threadinfo[title])."','".addslashes($threadinfo[lastpost])."','".addslashes($threadinfo[forumid])."','".addslashes($threadinfo[pollid])."','".addslashes($threadinfo[open])."','".addslashes($threadinfo[replycount])."','".addslashes($threadinfo[postusername])."','".addslashes($threadinfo[postuserid])."','".addslashes($threadinfo[lastposter])."','".addslashes($threadinfo[dateline])."','".addslashes($threadinfo[views])."','".addslashes($threadinfo[iconid])."','".addslashes($threadinfo[notes])."','".addslashes($threadinfo[visible])."')");
    $newthreadid=$DB_site->insert_id();

    $DB_site->query("UPDATE thread SET notes='".addslashes($threadinfo[notes])."',forumid='".addslashes($forumid)."' WHERE threadid='$threadid'");

    $posts=$DB_site->query("SELECT * FROM post WHERE threadid='$threadid'");
    while ($post=$DB_site->fetch_array($posts)) {
      $DB_site->query("INSERT INTO post (postid,threadid,username,userid,title,dateline,attachmentid,pagetext,allowsmilie,showsignature,ipaddress,iconid,visible,edituserid,editdate) VALUES (NULL,'$newthreadid','".addslashes($post[username])."','".addslashes($post[userid])."','".addslashes($post[title])."','".addslashes($post[dateline])."','".addslashes($post[attachmentid])."','".addslashes($post[pagetext])."','".addslashes($post[allowsmilie])."','".addslashes($post[showsignature])."','".addslashes($post[ipaddress])."','".addslashes($post[iconid])."','".addslashes($post[visible])."','".addslashes($post[edituserid])."','".addslashes($post[editdate])."')");
      $newpostid=$DB_site->insert_id();
      indexpost($newpostid);
    }
  }

  updateforumcount($threadinfo[forumid]);
  updateforumcount($forumid);
  
  $users=$DB_site->query("SELECT user.userid,usergroupid FROM subscribethread,user WHERE subscribethread.userid=user.userid AND subscribethread.threadid='$threadid'");
  $deleteuser = '0';
  while($thisuser=$DB_site->fetch_array($users)) {
    $perms=getpermissions($forumid, $thisuser['userid'], $thisuser['usergroupid']);
    if (!$perms['canview']) {
      $deleteuser .= ",$thisuser[userid]";
    }
  }
  
  if ($deleteuser) {
    $DB_site->query("DELETE FROM subscribethread WHERE threadid='$threadid' AND userid IN ($deleteuser)");
  }

  eval("standardredirect(\"".gettemplate("redirect_movethread")."\",\"showthread.php?s=$session[sessionhash]&threadid=$threadid\");");
}

// ############################### start edit thread ###############################
if ($action=="editthread") {

  $threadid = verifyid("thread",$threadid);
  $threadinfo=getthreadinfo($threadid);
  $foruminfo=getforuminfo($threadinfo[forumid]);

  if (!$threadinfo[visible]) {
    $idname="thread";
    eval("standarderror(\"".gettemplate("error_invalidid")."\");");
  }

  // check forum permissions for this forum
  if (!ismoderator($threadinfo[forumid],"caneditthreads")) {
    $permissions=getpermissions($forumid);
    if (!$permissions[canview] or !$permissions[canmove]) {
      show_nopermission();
    } else {
      if (!$threadinfo[open]) {
        eval("standardredirect(\"".gettemplate("redirect_threadclosed")."\",\"showthread.php?s=$session[sessionhash]&threadid=$threadid\");");
        exit;
      }
      $firstpostinfo=$DB_site->query_first("SELECT userid FROM post WHERE threadid='$threadid' ORDER BY dateline LIMIT 1");
      if ($bbuserinfo[userid]!=$firstpostinfo[userid]) {
        show_nopermission();
      }
    }
  }

  // draw nav bar
  $navbar=makenavbar($threadid,"thread",1);

  $visiblechecked=iif($threadinfo[visible],"CHECKED","");
  $openchecked=iif($threadinfo[open],"CHECKED","");

  if ($foruminfo[allowicons]) {
    $posticons=chooseicons($threadinfo[iconid]);
  }  else {
    $posticons="";
  }

  eval("dooutput(\"".gettemplate("threads_editthread")."\");");

}

// ############################### start update thread ###############################
if ($HTTP_POST_VARS['action']=="updatethread") {

  $threadid = verifyid("thread",$threadid);
  $threadinfo=getthreadinfo($threadid);

  //if (!$threadinfo[visible]) {
  //  $idname="thread";
  //  eval("standarderror(\"".gettemplate("error_invalidid")."\");");
  //}

  // check forum permissions for this forum
  if (!ismoderator($threadinfo[forumid],"caneditthreads")) {
    $permissions=getpermissions($forumid);
    if (!$permissions[canview] or !$permissions[canmove]) {
      show_nopermission();
    } else {
      if (!$threadinfo[open]) {
        eval("standardredirect(\"".gettemplate("redirect_threadclosed")."\",\"showthread.php?s=$session[sessionhash]&threadid=$threadid\");");
        exit;
      }
      $firstpostinfo=$DB_site->query_first("SELECT userid FROM post WHERE threadid='$threadid' ORDER BY dateline LIMIT 1");
      if ($bbuserinfo[userid]!=$firstpostinfo[userid]) {
        show_nopermission();
      }
    }
  }

  $visible=iif($visible=="yes",1,0);
  $open=iif($open=="yes",1,0);

  if (!ismoderator($threadinfo[forumid],"canopenclose") and !$permissions[canopenclose]) {
    $open=$threadinfo[open];
  }

  if ($iconid=="") {
    $iconid=0;
  }

  $notes = "Thread edited by $bbuserinfo[username] on ".vbdate($dateformat." ".$timeformat,time()).". $notes";
  $DB_site->query("UPDATE thread SET visible='$visible',open='$open',title='".addslashes(htmlspecialchars($title))."',iconid='".addslashes($iconid)."',notes='".addslashes($notes)."' WHERE threadid='$threadid'");

  // Reindex first post to set up title properly.

  $getfirstpost=$DB_site->query_first("SELECT postid FROM post WHERE threadid=$threadid ORDER BY dateline LIMIT 1");
  $DB_site->query("DELETE FROM searchindex WHERE postid=$getfirstpost[postid]");
  indexpost($getfirstpost[postid]);

  updateforumcount($threadinfo[forumid]);


  eval("standardredirect(\"".gettemplate("redirect_editthread")."\",\"showthread.php?s=$session[sessionhash]&threadid=$threadid\");");
}

// ############################### start merge threads ###############################
if ($action=="merge") {

  $threadid = verifyid("thread",$threadid);
  $threadinfo=getthreadinfo($threadid);

  if (!$threadinfo[visible]) {
    $idname="thread";
    eval("standarderror(\"".gettemplate("error_invalidid")."\");");
  }

  // check forum permissions for this forum
  if (!ismoderator($threadinfo[forumid],"canmanagethreads")) {
    show_nopermission();
  }

  // draw nav bar
  $navbar=makenavbar($threadid,"thread",1);

  eval("dooutput(\"".gettemplate("threads_merge")."\");");

}

// ############################### start do merge threads ###############################
if ($HTTP_POST_VARS['action']=="domergethread") {

  $threadid = verifyid("thread",$threadid);
  $threadinfo=getthreadinfo($threadid);

  if (!$threadinfo[visible]) {
    $idname="thread";
    eval("standarderror(\"".gettemplate("error_invalidid")."\");");
  }

  // check forum permissions for this forum
  if (!ismoderator($threadinfo[forumid],"canmanagethreads")) {
    show_nopermission();
  }

  // get other threadid
  $getthreadid=intval(substr($mergethreadurl,strpos($mergethreadurl,"threadid=")+9));
  if ($getthreadid==0) {
    $getpostid=intval(substr($mergethreadurl,strpos($mergethreadurl,"postid=")+7));
    if ($getpostid==0) {
      // do invalid url
      eval("standarderror(\"".gettemplate("error_mergebadurl")."\");");
      exit;
    }
    $getpostid=verifyid("post",$getpostid,0);
    if ($getpostid==0) {
      // do invalid url
      eval("standarderror(\"".gettemplate("error_mergebadurl")."\");");
      exit;
    }

    $postinfo=getpostinfo($getpostid);
    $mergethreadid=$postinfo[threadid];
  } else {
    $getthreadid=verifyid("thread",$getthreadid,0);
    if ($getthreadid==0) {
      // do invalid url
      eval("standarderror(\"".gettemplate("error_mergebadurl")."\");");
      exit;
    }
    $mergethreadid=$getthreadid;
  }

  $mergethreadinfo=getthreadinfo($mergethreadid);

  if (!$mergethreadinfo[visible]) {
    $idname="thread";
    eval("standarderror(\"".gettemplate("error_invalidid")."\");");
  }

  // check forum permissions for this forum
  if (!ismoderator($mergethreadinfo[forumid],"canmanagethreads")) {
    show_nopermission();
  }

  // update notes
  $threadinfo[notes]="Thread merged by $bbuserinfo[username] on ".vbdate($dateformat." ".$timeformat,time()).". $threadinfo[notes]. $mergethreadinfo[notes]";

  // sort out polls
  $pollcode="";
  if ($mergethreadinfo[pollid]!=0) {
    if ($threadinfo[pollid]==0) {
      $pollcode=",pollid=$mergethreadinfo[pollid]";
    } else {
      if (!$poll=$DB_site->query_first("SELECT threadid FROM thread WHERE pollid=$mergethreadinfo[pollid] AND threadid<>$mergethreadinfo[threadid]")) {
        $DB_site->query("DELETE FROM poll WHERE pollid=$mergethreadinfo[pollid]");
        $DB_site->query("DELETE FROM pollvote WHERE pollid=$mergethreadinfo[pollid]");
      }
    }
  }

  // move posts
  $DB_site->query("UPDATE post SET threadid='$threadid' WHERE threadid='$mergethreadid'");
  $DB_site->query("UPDATE thread SET title='".addslashes(htmlspecialchars($title))."',notes='".addslashes($threadinfo[notes])."'$pollcode WHERE threadid='$threadid'");
  $DB_site->query("DELETE FROM thread WHERE threadid='$mergethreadid'");
  $DB_site->query("UPDATE thread SET pollid='$threadid' WHERE open=10 AND pollid='$mergethreadid'"); // update redirects
  $DB_site->query("DELETE FROM threadrate WHERE threadid='$mergethreadid'");
  $DB_site->query("DELETE FROM subscribethread WHERE threadid='$mergethreadid'");
  // Update searchindex properly, especially the new title and remove what may have been in the old title of either thread
  $posts=$DB_site->query("SELECT userid,attachmentid,postid FROM post WHERE threadid='$threadid'");
  while ($post=$DB_site->fetch_array($posts)) {
    $DB_site->query("DELETE FROM searchindex WHERE postid=$post[postid]");
    indexpost($post[postid]);
  }

  updatethreadcount($threadid);
  updateforumcount($threadinfo['forumid']);
  if ($mergethreadinfo['forumid']!=$threadinfo['forumid']) {
    updateforumcount($mergethreadinfo['forumid']);
  }

  eval("standardredirect(\"".gettemplate("redirect_mergethread")."\",\"showthread.php?s=$session[sessionhash]&threadid=$threadid\");");

}

// ############################### start split thread ###############################
if ($action=="split") {

  $threadid = verifyid("thread",$threadid);
  $threadinfo=getthreadinfo($threadid);

  if (!$threadinfo[visible]) {
    $idname="thread";
    eval("standarderror(\"".gettemplate("error_invalidid")."\");");
  }

  if (!ismoderator($threadinfo[forumid],"canmanagethreads")) {
    show_nopermission();
  }

  // draw nav bar
  $navbar=makenavbar($threadid,"thread",1);

  $posts=$DB_site->query("SELECT post.*,user.* FROM post LEFT JOIN user ON user.userid=post.userid WHERE post.threadid='$threadid' ORDER BY dateline");
  if ($DB_site->num_rows($posts) <= 1) {
     eval("standarderror(\"".gettemplate("error_cantsplitone")."\");");
  }
  $counter=0;
  while ($post=$DB_site->fetch_array($posts)) {
    if (++$counter%2!=0) {
      $post[backcolor]="{firstaltcolor}";
    } else {
      $post[backcolor]="{secondaltcolor}";
    }
    $post[postdate]=vbdate($dateformat,$post[dateline]);
    $post[posttime]=vbdate($timeformat,$post[dateline]);

    // cut page text short if too long
    if (strlen($post[pagetext])>100) {
      $spacepos=strpos($post[pagetext]," ",100);
      if ($spacepos!=0) {
        $post[pagetext]=substr($post[pagetext],0,$spacepos)."...";
      }
    }
    $post[pagetext]=nl2br(htmlspecialchars($post[pagetext]));

    eval("\$postbits .= \"".gettemplate("threads_splitthreadbit")."\";");
  }

  eval("dooutput(\"".gettemplate("threads_splitthread")."\");");

}

// ############################### start do split thread ###############################
if ($HTTP_POST_VARS['action']=="dosplitthread") {

  $threadid = verifyid("thread",$threadid);
  $threadinfo=getthreadinfo($threadid);

  if (!$threadinfo[visible]) {
    $idname="thread";
    eval("standarderror(\"".gettemplate("error_invalidid")."\");");
  }

  if (!ismoderator($threadinfo[forumid],"canmanagethreads")) {
    show_nopermission();
  }

  $doyes = 0;
  $dono = 0;
  while ( list($key,$val)=each($splitpost) ) {
    if ($val=="yes") {
      $doyes = 1;
    } else {
      $dono = 1;
    }
  }
  if ($doyes==0 and $dono==1) { // Selected no posts to split
    eval("standarderror(\"".gettemplate("error_nosplitposts")."\");");
  } elseif ($doyes==1 and $dono==0) { // Selected all posts to split
    eval("standarderror(\"".gettemplate("error_cantsplitall")."\");");
  }


  $DB_site->query("INSERT INTO thread (threadid,title,lastpost,forumid,open,replycount,postusername,postuserid,lastposter,dateline,views,iconid,notes,visible) VALUES (NULL,'".addslashes($title)."','".addslashes($threadinfo[lastpost])."','".addslashes($threadinfo[forumid])."','".addslashes($threadinfo[open])."','".addslashes($threadinfo[replycount])."','".addslashes($threadinfo[postusername])."','".addslashes($threadinfo[postuserid])."','".addslashes($threadinfo[lastposter])."','".addslashes($threadinfo[dateline])."','".addslashes($threadinfo[views])."','".addslashes($threadinfo[iconid])."','Thread split from threadid $threadid by $bbuserinfo[username] on ".vbdate($dateformat." ".$timeformat,time()).". ".addslashes($threadinfo[notes])."','".addslashes($threadinfo[visible])."')");
  $newthreadid=$DB_site->insert_id();

  // Move post info to new thread...
  $posts=$DB_site->query("SELECT postid,attachmentid,userid FROM post WHERE threadid='$threadid'");
  while ($post=$DB_site->fetch_array($posts)) {
    if ($splitpost[$post[postid]]=="yes") {
      $DB_site->query("UPDATE post SET threadid=$newthreadid WHERE postid=$post[postid]");
    }
  }

  // update thread notes
  $threadinfo[notes]="Thread split to threadid $newthreadid by $bbuserinfo[username] on ".vbdate($dateformat." ".$timeformat,time()).". $threadinfo[notes]";
  $DB_site->query("UPDATE thread SET notes='".addslashes($notes)."' WHERE threadid='$threadid'");

  // Update first post in each thread as title information in relation to the sames words being in the first post may have changed now.
  $getfirstpost=$DB_site->query_first("SELECT postid FROM post WHERE threadid=$threadid ORDER BY dateline LIMIT 1");
  $DB_site->query("DELETE FROM searchindex WHERE postid=$getfirstpost[postid]");
  indexpost($getfirstpost[postid]);

  $getfirstpost=$DB_site->query_first("SELECT postid FROM post WHERE threadid=$newthreadid ORDER BY dateline LIMIT 1");
  $DB_site->query("DELETE FROM searchindex WHERE postid=$getfirstpost[postid]");
  indexpost($getfirstpost[postid]);

  updatethreadcount($threadid);
  updatethreadcount($newthreadid);
  updateforumcount($threadinfo[forumid]);

  eval("standardredirect(\"".gettemplate("redirect_splitthread")."\",\"showthread.php?s=$session[sessionhash]&threadid=$newthreadid\");");
}

// ############################### start stick / unstick thread ###############################
if ($action=="stick" and $s==$session[dbsessionhash]) {

  $threadid=verifyid("thread",$threadid);
  $threadinfo=getthreadinfo($threadid);

  if (!$threadinfo[visible]) {
    $idname="thread";
    eval("standarderror(\"".gettemplate("error_invalidid")."\");");
  }

  if (!ismoderator($threadinfo[forumid],"canmanagethreads")) {
      show_nopermission();
  }

  if ($threadinfo[sticky]) {
    $threadinfo[sticky]=0;
    $action="unstuck";
  } else {
    $threadinfo[sticky]=1;
    $action="stuck";
  }
  $threadinfo[notes]= "Thread $action by $bbuserinfo[username] on ".vbdate($dateformat." ".$timeformat,time()).". $threadinfo[notes]";
  $DB_site->query("UPDATE thread SET sticky=$threadinfo[sticky],notes='".addslashes($threadinfo[notes])."' WHERE threadid='$threadid'");

  eval("standardredirect(\"".gettemplate("redirect_sticky")."\",\"showthread.php?s=$session[sessionhash]&threadid=$threadid\");");

}


?>