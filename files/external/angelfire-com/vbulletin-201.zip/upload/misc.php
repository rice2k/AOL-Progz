<?php
error_reporting(7);


// ############################### start show smilies ###############################
if ($action=="showsmilies") {
  $templatesused = ""; // Only one template used so load it when called
  include("./global.php");
  $smiliebits="";

  $smilies=$DB_site->query("SELECT smilietext,title,smiliepath FROM smilie ORDER BY title");
  while ($smilie=$DB_site->fetch_array($smilies)) {
    eval("\$smiliebits .= \"".gettemplate("smiliebit")."\";");
  }

  eval("dooutput(\"".gettemplate("smilies")."\");");
}

// ############################### start show avatars ###############################
if ($action=="showavatars") {
  $templatesused = "avatarbit,avatar,avatars";
  include("./global.php");

  $minposts=0;
  $avatarbits="";

  $avatars=$DB_site->query("SELECT title,minimumposts,avatarpath FROM avatar ORDER BY minimumposts,title");
  if ($DB_site->num_rows($avatars)!=0) {
    while ($avatar=$DB_site->fetch_array($avatars)) {
      if ($avatar[minimumposts]!=$minposts) {
        eval("\$avatarbits .= \"".gettemplate("avatarbit")."\";");
        $avatarlist="";
      }
      $minposts=$avatar[minimumposts];
      eval("\$avatarlist .= \"".gettemplate("avatar")."\";");
    }
    eval("\$avatarbits .= \"".gettemplate("avatarbit")."\";");
  }

  eval("dooutput(\"".gettemplate("avatars")."\");");
}

// ############################### start bbcode ###############################
if ($action=="bbcode") {
  $templatesused = ""; // Only one template used so load it when called
  include("./global.php");
  eval("dooutput(\"".gettemplate("bbcode")."\");");

}

// ############################### start faq ###############################
if ($action=="faq") {
  $templatesused = ""; // Only one template used so load it when called
  include("./global.php");
  $page = intval($page);
  if (!$page)
    $page = '';
  eval("dooutput(\"".gettemplate("faq$page")."\");");

}

// ############################### Popup Smilies for vbCode ################
if ($action=="getsmilies") {
  $templatesused = "vbcode_popup_smiliesbits,vbcode_popup_smilies";
  include("./global.php");

  $smilies = $DB_site->query("SELECT smilietext AS text, smiliepath AS path, title FROM smilie");

  $rightorleft = 'left';
  while ($smilie = $DB_site->fetch_array($smilies))
  {
	if ($rightorleft == 'left') {
	  if (($i++ % 2) != 0)
	    $backcolor='{firstaltcolor}';
	  else $backcolor='{secondaltcolor}';
	    $popup_smiliesbits .= "";
	  eval ("\$popup_smiliesbits .= \"<tr>".gettemplate("vbcode_popup_smiliesbits")."\";");
	  $rightorleft = 'right';
	} else {
	  eval ("\$popup_smiliesbits .= \"".gettemplate("vbcode_popup_smiliesbits")."</tr>\";");
	  $rightorleft = 'left';
	}
  }
  if ($rightorleft=='right') {
    $popup_smiliesbits .= "<td bgcolor=\"$backcolor\">&nbsp;</td><td bgcolor=\"$backcolor\">&nbsp;</td></tr>";
  }
  eval("dooutput(\"".gettemplate("vbcode_popup_smilies")."\");");
}

?>