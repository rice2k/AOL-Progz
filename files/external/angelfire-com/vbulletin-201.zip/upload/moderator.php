<?php
error_reporting(7);

if ($action=="move" or $action=="prune" or $action=="useroptions") {
  $noheader=1;
}

require("./global.php");

if ($action=="useroptions") {

  $userid = verifyid("user",$userid);

  $permissions=getpermissions();
  if ($permissions[cancontrolpanel]) {
    header("Location: admin/index.php?s=$session[sessionhash]&loc=user.php?s=$session[sessionhash]%26action=edit%26userid=$userid");
  } elseif ($permissions[ismoderator] or $ismod=$DB_site->query_first("SELECT * FROM moderator WHERE userid=$bbuserinfo[userid] AND canviewprofile=1")) {
    header("Location: mod/index.php?s=$session[sessionhash]&loc=user.php?s=$session[sessionhash]%26action=view%26userid=$userid");
  } else {
    show_nopermission();
  }

  exit;
}

if ($action=="move") {

  $forumid = verifyid("forum",$forumid);

  $permissions=getpermissions();
  if (!$permissions[canview] or !$permissions[cancontrolpanel]) {
    show_nopermission();
    exit;
  }

  header("Location: admin/index.php?s=$session[sessionhash]&loc=thread.php?s=$session[sessionhash]%26action=move");
  exit;
}

if ($action=="prune") {

  $forumid = verifyid("forum",$forumid);

  $permissions=getpermissions();
  if (!$permissions[canview] or !$permissions[cancontrolpanel]) {
    show_nopermission();
    exit;
  }

  header("Location: admin/index.php?s=$session[sessionhash]&loc=thread.php?s=$session[sessionhash]%26action=prune");
  exit;
}

if ($action=="modposts") {

  $permissions=getpermissions();
  if ($permissions[ismoderator] or $ismod=$DB_site->query_first("SELECT * FROM moderator WHERE userid=$bbuserinfo[userid] AND canmoderateposts=1")) {
    header("Location: mod/index.php?s=$session[sessionhash]&loc=moderate.php?s=$session[sessionhash]%26action=posts");
  } else {
    show_nopermission();
  }

}

if ($action=="modattach") {

  $permissions=getpermissions();
  if ($permissions[ismoderator] or $ismod=$DB_site->query_first("SELECT * FROM moderator WHERE userid=$bbuserinfo[userid] AND canmoderateattachments=1")) {
    header("Location: mod/index.php?s=$session[sessionhash]&loc=moderate.php?s=$session[sessionhash]%26action=attachments");
  } else {
    show_nopermission();
  }

}

//setup redirects for other options in moderators cp

?>