<?php
error_reporting(7);

if ($HTTP_GET_VARS['HTTP_POST_VARS']['action'] == $HTTP_POST_VARS['action']) {
  unset($HTTP_POST_VARS['action']);
}
$HTTP_POST_VARS['action'] = trim($HTTP_POST_VARS['action']);

if ( isset($action) and $action=="login") {
  $noheader=1;
}

if (!isset($action) or $action=="") {
  $action="lostpw";
}

// ############################### start logout ###############################
if ($action=="logout") {
  include("./global.php");
  vbsetcookie("bbuserid","",1);
  vbsetcookie("bbpassword","",1);

  if ($bbuserinfo[userid]!=0 and $bbuserinfo[userid]!=-1) {
    $DB_site->query("UPDATE user SET lastactivity='".(time()-$cookietimeout)."',lastvisit='".time()."' WHERE userid='$bbuserinfo[userid]'");
  }

  //$DB_site->query("UPDATE session SET userid=0 WHERE sessionhash='".addslashes($session[sessionhash])."'");
  $DB_site->query("DELETE FROM session WHERE sessionhash='".addslashes($session[dbsessionhash])."'");
  // make sure any other of this user's sessions are deleted (incase they ended up with more than one)
  $DB_site->query("DELETE FROM session WHERE userid='$bbuserinfo[userid]'");

  $session['sessionhash']=md5(uniqid(microtime()));
  $session['dbsessionhash']=$session['sessionhash'];
  $DB_site->query("INSERT INTO session (sessionhash,userid,host,useragent,lastactivity,styleid) VALUES ('".addslashes($session['sessionhash'])."','0','".addslashes($session['host'])."','".addslashes($session['useragent'])."','".time()."','$session[styleid]')");
  vbsetcookie("sessionhash",$session['sessionhash'],0);

  eval("standarderror(\"".gettemplate("error_cookieclear")."\");");

}

// ############################### start login ###############################
if ($action=="login") {
  include("./global.php");
  if (isset($username)) {
    // get userid for given username
    if ($user=$DB_site->query_first("SELECT userid,username,password,cookieuser FROM user WHERE username='".addslashes(htmlspecialchars($username))."'")) {
      if ($user[password]!=$password) {  // check password
        eval("standarderror(\"".gettemplate("error_wrongpassword")."\");");
        exit;
      }
      $userid=$user[userid];
    } else { // invalid username entered
       eval("standarderror(\"".gettemplate("error_wrongusername")."\");");
       exit;
    }

    if ($user['cookieuser']==1) {
      vbsetcookie("bbuserid",$user['userid']);
      vbsetcookie("bbpassword",md5($user['password']));
    }

    $DB_site->query("DELETE FROM session WHERE sessionhash='".addslashes($session[dbsessionhash])."'");

    $session['sessionhash']=md5(uniqid(microtime()));
    $session['dbsessionhash']=$session['sessionhash'];
    $DB_site->query("INSERT INTO session (sessionhash,userid,host,useragent,lastactivity,styleid) VALUES ('".addslashes($session['sessionhash'])."','$userid','".addslashes($session['host'])."','".addslashes($session['useragent'])."','".time()."','$session[styleid]')");
    vbsetcookie("sessionhash",$session['sessionhash'],0);
    $username = $user['username'];
  }

  $url=ereg_replace("sessionhash=[a-z0-9]{32}&","",$url);
  $url=ereg_replace("\\?sessionhash=[a-z0-9]{32}","",$url);
  $url=ereg_replace("s=[a-z0-9]{32}&","",$url);
  $url=ereg_replace("\\?s=[a-z0-9]{32}","",$url);

  if ($url!="" and $url!="index.php" and $url!=$HTTP_REFERER) {

    if (strpos($url,"?")>0) {
      $url.="&s=$session[dbsessionhash]";
    } else {
      $url.="?s=$session[dbsessionhash]";
    }
    //header("Location: $url");

    $url = str_replace("\"", "", $url);
    eval("standardredirect(\"".gettemplate("redirect_login")."\",\"$url\");");
  } else {
    $bbuserinfo=getuserinfo($userid);
    eval("standardredirect(\"".gettemplate("redirect_login")."\",\"index.php?s=$session[dbsessionhash]\");");
  }

}


// ############################### start mark all forums read ###############################
if ($action=="markread") {
  include("./global.php");
  if ($bbuserinfo[userid]!=0 and $bbuserinfo[userid]!=-1) {
    $DB_site->query("UPDATE user SET lastactivity='".time()."',lastvisit='".time()."' WHERE userid='$bbuserinfo[userid]'");
  } else {
    vbsetcookie("bblastvisit",time());
  }
  eval("standardredirect(\"".gettemplate("redirect_markread")."\",\"index.php?s=$session[sessionhash]\");");
}

// ############################### start lost password ###############################
if ($action=="lostpw") {
  include("./global.php");
  eval("dooutput(\"".gettemplate("lostpw")."\");");
}

// ############################### start email password ###############################
if ($HTTP_POST_VARS['action']=="emailpassword") {
  include("./global.php");

  $users=$DB_site->query("SELECT username,email,password FROM user WHERE email='".addslashes(htmlspecialchars($email))."'");

  if ($DB_site->num_rows($users)) {

    while ($user=$DB_site->fetch_array($users)) {

      $username=unhtmlspecialchars($user[username]);
      $password=$user[password];

      eval("\$message = \"".gettemplate("email_lostpw",1,0)."\";");
      eval("\$subject = \"".gettemplate("emailsubject_lostpw",1,0)."\";");

      mail ($user[email],$subject,$message,"From: \"$bbtitle Mailer\" <$webmasteremail>");

    }
		if ($url=="") {
			$url="index.php?s=$session[sessionhash]";
		}

    $url = str_replace("\"", "", $url);
    eval("standardredirect(\"".gettemplate("redirect_lostpw")."\",\"$url\");");
  } else {
    eval("standarderror(\"".gettemplate("error_invalidemail")."\");");
  }
}

// ############################### start modify profile ###############################
if ($action=="editprofile") {
  $templatesused .= "register_birthday,modifyprofile_customtext,register_customfields,usercpnav,modifyprofile";
  include("./global.php");
  // do modify profile form

  if ($bbuserinfo[userid]==0 or $permissions['canmodifyprofile']==0) {
    show_nopermission();
  }

  if ($bbuserinfo[coppauser]!=0) {
    $parentemail=$bbuserinfo[parentemail];

    eval("\$coppatext = \"".gettemplate("modifycoppa")."\";");
    eval("\$parentemail = \"".gettemplate("modifyparentemail")."\";");
  }
  if ($calbirthday == 1)  {
     if ($bgcolor=="{firstaltcolor}") {
        $bgcolor="{secondaltcolor}";
     } else {
        $bgcolor="{firstaltcolor}";  }
     // Set birthday fields right here!
     if ($bbuserinfo[birthday] == '0000-00-00') {
        $daydefaultselected = "selected";
        $monthdefaultselected = "selected";
     } else {
        $birthday = explode("-",$bbuserinfo[birthday]);
        $dayname = "day".$birthday[2]."selected";
        $$dayname = "selected";
        $monthname = "month".$birthday[1]."selected";
        $$monthname = "selected";
        if (date("Y")>$birthday[0] && $birthday[0]!='0000')
           $year = $birthday[0];
     }
     eval("\$birthday = \"".gettemplate("register_birthday")."\";");
  }
  if ($ctEnable == 1) { // Custom Titles are ON
    $ctShowTitle = 0;
    if (ismoderator() and $ctAdmin == 1) { // Allow mods to use titles no matter what
       $ctShowTitle = 1;
    } else {
       if ($ctEitherOr==0)  {  // Allow titles if Posts are ok OR JoinDate is ok
          if ( ($bbuserinfo[posts] >= $ctPosts) or ( ($bbuserinfo[joindate] <= (time()-($ctDays*86400))) or ($ctDays==0)) ) {
             $ctShowTitle = 1;
          }
       } else { // Allow titles if Posts AND Joindate is ok
          if ( ($bbuserinfo[posts] >= $ctPosts) and ( ($bbuserinfo[joindate] <= (time()-($ctDays*86400))) or ($ctDays==0)) )  {
             $ctShowTitle = 1;
          }
       }
    }
    if ($ctShowTitle == 1) {
        if ($bgcolor=="{firstaltcolor}") {
        $bgcolor="{secondaltcolor}";
      } else {
        $bgcolor="{firstaltcolor}";
      }
      if ($bbuserinfo[customtitle]==2)
        $bbuserinfo[usertitle] = htmlspecialchars($bbuserinfo[usertitle]);
      eval("\$customtext.= \"".gettemplate("modifyprofile_customtext")."\";");
    }
  }
  // get extra profile fields
  $profilefields=$DB_site->query("SELECT * FROM profilefield ORDER BY displayorder");
  while ($profilefield=$DB_site->fetch_array($profilefields)) {
    $profilefieldname="field$profilefield[profilefieldid]";
    if ($bgcolor=="{firstaltcolor}") {
      $bgcolor="{secondaltcolor}";
    } else {
      $bgcolor="{firstaltcolor}";
    }
    eval("\$customfields .= \"".gettemplate("register_customfields")."\";");
  }

  if ($allowhtml) {
    $htmlonoff=$ontext;
  } else {
    $htmlonoff=$offtext;
  }
  if ($allowbbcode) {
    $bbcodeonoff=$ontext;
  } else {
    $bbcodeonoff=$offtext;
  }
  if ($allowbbimagecode) {
    $imgcodeonoff=$ontext;
  } else {
    $imgcodeonoff=$offtext;
  }
  if ($allowsmilies) {
    $smiliesonoff=$ontext;
  } else {
    $smiliesonoff=$offtext;
  }

  $signature=htmlspecialchars($bbuserinfo[signature]);

  // draw cp nav bar
  $cpnav[1]="{secondaltcolor}";
  $cpnav[2]="{firstaltcolor}";
  $cpnav[3]="{secondaltcolor}";
  $cpnav[4]="{secondaltcolor}";
  $cpnav[5]="{secondaltcolor}";
  $cpnav[6]="{secondaltcolor}";
  $cpnav[7]="{secondaltcolor}";
  eval("\$cpnav = \"".gettemplate("usercpnav")."\";");

  eval("dooutput(\"".gettemplate("modifyprofile")."\");");
}

// ############################### start update profile ###############################
if ($HTTP_POST_VARS['action']=="updateprofile") {
  $templatesused = "redirect_updatethanks,error_fieldmissing,error_emailmismatch,error_emailtaken,error_fieldmissing,error_requiredfieldmissing,error_birthdayfield";
  include("./global.php");

  if ($bbuserinfo[userid]==0 or $permissions['canmodifyprofile']==0) {
    show_nopermission();
  }

  if ($enablebanning and $banemail!="") {
  	$banemail = preg_replace("/[[:space:]]+/"," ",$banemail);

   if (!$allowkeepbannedemail or $bbuserinfo[email]!=$email) {
     if (stristr(" ".$banemail." "," ".$email." ")!="") {
        eval("standarderror(\"".gettemplate("error_banemail")."\");");
        exit;
      }
      if ($emaildomain=substr(strstr($email,"@"),1)) {
        if (stristr(" ".$banemail." "," ".$emaildomain." ")!="") {
          eval("standarderror(\"".gettemplate("error_banemail")."\");");
          exit;
        }
      }
    }
  }

  if ($requireuniqueemail and $checkuser=$DB_site->query_first("SELECT userid,username,email FROM user WHERE email='".addslashes($email)."' AND userid<>'$bbuserinfo[userid]'")) {
    if ($checkuser[userid]!=$bbuserinfo[userid]) {
      eval("standarderror(\"".gettemplate("error_emailtaken")."\");");
      exit;
    }
  }

  if ($email=="" or $emailconfirm=="") { //  or $password=="" or $passwordconfirm==""
    eval("standarderror(\"".gettemplate("error_fieldmissing")."\");");
    exit;
  }

  if ($email!=$emailconfirm) {
    eval("standarderror(\"".gettemplate("error_emailmismatch")."\");");
    exit;
  }

  $icq=intval($icq);
  if ($icq==0) {
    $icq="";
  }

  // check coppa things
  $coppauser = intval($coppauser);
  if ($coppauser) {
    if ($parentemail=="") {
      eval("standarderror(\"".gettemplate("error_fieldmissing")."\");");
      exit;
    }

    if ($enableemail) {
      eval("\$message = \"".gettemplate("email_parentcoppa",1,0)."\";");
      eval("\$subject = \"".gettemplate("emailsubject_parentcoppa",1,0)."\";");

      mail($parentemail,$subject,$message,"From: \"$bbtitle Mailer\" <$webmasteremail>");
    }
  } else {
    $parentemail="";
    $coppauser=0;
  }

  // check max images
  if ($maximages!=0) {
    $parsedsig=bbcodeparse($signature,0,$allowsmilies);
    if (countchar($parsedsig,"<img")>$maximages) {
      eval("standarderror(\"".gettemplate("error_toomanyimages")."\");");
      exit;
    }
  }
  // check that nothing illegal is in the signature
  $signature=censortext($signature);

  // check extra profile fields
  $userfields="";
  $profilefields=$DB_site->query("SELECT profilefieldid,required,title,size,maxlength FROM profilefield");
  while ($profilefield=$DB_site->fetch_array($profilefields))
  {
    $varname="field$profilefield[profilefieldid]";
    if ($profilefield[required] and $$varname=="")
    {
      eval("standarderror(\"".gettemplate("error_requiredfieldmissing")."\");");
      exit;
    }
    $$varname=censortext($$varname);
    // ENTER ANY CUSTOM FIELD VALIDATION HERE!
    //Make sure user didn't try to bypass the maxchars for the fields
    $$varname=substr($$varname,0,$profilefield[maxlength]);
    $userfields.=",$varname='".addslashes(htmlspecialchars($$varname))."'";
  }

  if ($customtext) {
    $customtext = trim($customtext);
  }
  // Custom User Title Code!

  if ($resettitle) {
    $group=$DB_site->query_first("SELECT usertitle FROM usergroup WHERE usergroupid=$bbuserinfo[usergroupid]");
    if ($group[usertitle]=="") {
      $gettitle=$DB_site->query_first("SELECT title FROM usertitle WHERE minposts<=$bbuserinfo[posts] ORDER BY minposts DESC LIMIT 1");
      $usertitle=$gettitle[title];
    } else {
      $usertitle=$group[usertitle];
    }
    $bbuserinfo[usertitle] = $usertitle;
    $bbuserinfo[customtitle] = 0;
    unset($customtext);
  }

  if ($ctEnable == 1 and $customtext) {// Custom Titles are ON, Make sure user can actually use them and isn't trying to manipulate them through forms
     $ctShowTitle = 0;
     if (ismoderator() and $ctAdmin == 1) {// Allow mods to use titles no matter what
        $ctShowTitle = 1;
     } else {
        if ($ctEitherOr==0)  {// Allow titles if Posts are ok OR JoinDate is ok
           if ( ($bbuserinfo[posts] >= $ctPosts) or ( ($bbuserinfo[joindate] <= (time()-($ctDays*86400))) or ($ctDays==0)) ) {
              $ctShowTitle = 1;
           }
        } else {// Allow titles if Posts AND Joindate is ok
           if ( ($bbuserinfo[posts] >= $ctPosts) and ( ($bbuserinfo[joindate] <= (time()-($ctDays*86400))) or ($ctDays==0)) ) {
              $ctShowTitle = 1;
           }
        }
     }
     if ($ctShowTitle == 1) {
        if ($bbuserinfo[usergroupid]!=6) {
          $customtitle = 2;  // 2 signifies that the user set the title and we need to htmlspecialchars when ever displaying the title.
        } else {
          $customtitle = 1;
        }
        $customtext = censortext($customtext);
        if (!ismoderator() or (ismoderator() and $ctCensorMod==0)) {
          $customtext = customcensortext($customtext);
        }
      } else {
         $customtitle = $bbuserinfo[customtitle];
         $customtext = $bbuserinfo[usertitle];
      }
  } else {
     $customtitle = $bbuserinfo[customtitle];
     $customtext = $bbuserinfo[usertitle];
  }
  // Birthday Stuff...
  if ($calbirthday == 1) {
     if ( ($day == -1 and $month != -1) or ($day !=-1 and $month == -1) ) {
        eval("standarderror(\"".gettemplate("error_birthdayfield")."\");");
        exit;
     }
     if (($day == -1) and ($month==-1)) {
        $birthday = 0;
     } else {
        if (($year>1901) and ($year<date("Y")))
           $birthday = $year . "-" . $month . "-" . $day;
        else
           $birthday = "0000" . "-" . $month . "-" . $day;
     }
  } else {
     $birthday = 0;
  }
  if ($verifyemail and $email!=$bbuserinfo['email'] and $bbuserinfo['usergroupid']==2) {
    $newemailaddress=1;
    $activateid=$bbuserinfo['joindate'];
    $username=unhtmlspecialchars($bbuserinfo['username']);
    $userid=$bbuserinfo['userid'];

    eval("\$message = \"".gettemplate("email_activateaccount_change",1,0)."\";");
    eval("\$subject = \"".gettemplate("emailsubject_activateaccount_change",1,0)."\";");

    mail ($email,$subject,$message,"From: \"$bbtitle Mailer\" <$webmasteremail>");

    $bbuserinfo['usergroupid'] = 3;
  } else {
    $newemailaddress=0;
  }

  $DB_site->query("UPDATE user SET birthday='".addslashes($birthday)."',signature='".addslashes($signature)."',customtitle='$customtitle',usertitle='".addslashes($customtext)."',email='".addslashes(htmlspecialchars($email))."',parentemail='".addslashes(htmlspecialchars($parentemail))."',coppauser='$coppauser',homepage='".addslashes(htmlspecialchars($homepage))."',icq='".addslashes(htmlspecialchars($icq))."',aim='".addslashes(htmlspecialchars($aim))."',yahoo='".addslashes(htmlspecialchars($yahoo))."',usergroupid='$bbuserinfo[usergroupid]' WHERE userid='$bbuserinfo[userid]'");
  if ($showbirthdays)
    getbirthdays();
  // insert custom user fields
  $DB_site->query("UPDATE userfield SET userid=$bbuserinfo[userid]$userfields WHERE userid=$bbuserinfo[userid]");

  if ($newemailaddress) {
    eval("standardredirect(\"".gettemplate("redirect_updatethanks_newemail")."\",\"usercp.php?s=$session[sessionhash]\");");
  } else {
    eval("standardredirect(\"".gettemplate("redirect_updatethanks")."\",\"usercp.php?s=$session[sessionhash]\");");
  }

}

// ############################### start modify options ###############################
if ($action=="editoptions") {
  $templatesused = "modifyoptions_maxposts,modifyoptions_styleset,modifyoptions_stylecell,usercpnav,modifyoptions";
  include("./global.php");
  // do modify profile form

  if ($bbuserinfo[userid]==0 or $permissions['canmodifyprofile']==0) {
    show_nopermission();
  }

  if ($bbuserinfo[adminemail]) {
    $allowmailchecked="checked";
    $allowmailnotchecked="";
  } else {
    $allowmailchecked="";
    $allowmailnotchecked="checked";
  }

  if ($bbuserinfo[emailnotification]) {
    $emailnotificationchecked="checked";
    $emailnotificationnotchecked="";
  } else {
    $emailnotificationchecked="";
    $emailnotificationnotchecked="checked";
  }

  if ($bbuserinfo[showsignatures]) {
    $showsignatureschecked="checked";
    $showsignaturesnotchecked="";
  } else {
    $showsignatureschecked="";
    $showsignaturesnotchecked="checked";
  }

  if ($bbuserinfo[showavatars]) {
      $showavatarschecked="checked";
      $showavatarsnotchecked="";
    } else {
      $showavatarschecked="";
      $showavatarsnotchecked="checked";
  }

  if ($bbuserinfo[showimages]) {
      $showimageschecked="checked";
      $showimagesnotchecked="";
    } else {
      $showimageschecked="";
      $showimagesnotchecked="checked";
  }

  if ($bbuserinfo[showvbcode]) {
      $vbcodechecked="checked";
      $vbcodenotchecked="";
    } else {
      $vbcodechecked="";
      $vbcodenotchecked="checked";
  }

  if ($bbuserinfo[showemail]) {
    $showemailchecked="checked";
    $showemailnotchecked="";
  } else {
    $showemailchecked="";
    $showemailnotchecked="checked";
  }

  if ($bbuserinfo[invisible]) {
    $invisiblechecked="checked";
    $invisiblenotchecked="";
  } else {
    $invisiblechecked="";
    $invisiblenotchecked="checked";
  }

  if ($bbuserinfo[cookieuser]) {
    $cookieuserchecked="checked";
    $cookieusernotchecked="";
  } else {
    $cookieuserchecked="";
    $cookieusernotchecked="checked";
  }

  if ($bbuserinfo[nosessionhash]) {
    $nosessionhashchecked="checked";
    $nosessionhashnotchecked="";
  } else {
    $nosessionhashchecked="";
    $nosessionhashnotchecked="checked";
  }

  if ($bbuserinfo[receivepm]) {
    $receivepmchecked="checked";
    $receivepmnotchecked="";
  } else {
    $receivepmchecked="";
    $receivepmnotchecked="checked";
  }

  if ($bbuserinfo[emailonpm]) {
    $emailonpmchecked="checked";
    $emailonpmnotchecked="";
  } else {
    $emailonpmchecked="";
    $emailonpmnotchecked="checked";
  }

  if ($bbuserinfo[pmpopup]) {
    $pmpopupchecked="checked";
    $pmpopupnotchecked="";
  } else {
    $pmpopupchecked="";
    $pmpopupnotchecked="checked";
  }

  if ($bbuserinfo[daysprune]==-1) {
    $daysdefaultselected="selected";
  } else {
    $dname="days".$bbuserinfo[daysprune]."selected";
    $$dname="selected";
  }

  if ($bbuserinfo[timezoneoffset]<0) {
    $timezonesel["n".(-$bbuserinfo[timezoneoffset]*10)]="selected";
  } else {
    $timezonesel[$bbuserinfo[timezoneoffset]*10]="selected";
  }

  if ($bbuserinfo[startofweek]>0) {
     $dname="day".$bbuserinfo[startofweek]."selected";
     $$dname = "selected";
  } else {
     $day1selected = "selected";
  }

  $bbuserinfo[avatarurl]=getavatarurl($bbuserinfo[userid]);
  if ($bbuserinfo[avatarurl]=="") {
    $bbuserinfo[avatarurl]="{imagesfolder}/clear.gif";
  }

  //MaxPosts by User
  $optionArray = explode(",", $usermaxposts);
  $foundmatch = 0;
  while (list($key, $val) = each($optionArray))
  {
     if ($val == $bbuserinfo[maxposts])
     {   $selected = "selected";
         $foundmatch = 1;
     }
     else
     {   $selected = "";   }
     eval ("\$maxpostsoptions .= \"".gettemplate("modifyoptions_maxposts")."\";");
  }
  if ($foundmatch == 0)
  {
     $postsdefaultselected = "selected";
  }

  $stylesetlist = "";
  if ($allowchangestyles==1) {
    $stylesets=$DB_site->query("SELECT * FROM style WHERE userselect=1 ORDER BY title");
    if ( !isset($bbuserinfo['realstyleid']) ) {
      $bbuserinfo['realstyleid'] = $bbuserinfo['styleid'];
    }
    while($thisset=$DB_site->fetch_array($stylesets)) {
      if ($bbuserinfo['realstyleid']==$thisset['styleid']) {
        $selected = "selected";
      } else {
        $selected = "";
      }
      $thisid = $thisset['styleid'];
      $thisstylename = $thisset['title'];
      eval ("\$stylesetlist .= \"".gettemplate("modifyoptions_styleset")."\";");
      eval ("\$stylecell = \"".gettemplate("modifyoptions_stylecell")."\";");
    }
  } else {
    $stylecell = "";
  }

  // draw cp nav bar
  $cpnav[1]="{secondaltcolor}";
  $cpnav[2]="{secondaltcolor}";
  $cpnav[3]="{firstaltcolor}";
  $cpnav[4]="{secondaltcolor}";
  $cpnav[5]="{secondaltcolor}";
  $cpnav[6]="{secondaltcolor}";
  $cpnav[7]="{secondaltcolor}";
  eval("\$cpnav = \"".gettemplate("usercpnav")."\";");

  eval("dooutput(\"".gettemplate("modifyoptions")."\");");
}

// ############################### start update options ###############################
if ($action=="updateoptions") {
  include("./global.php");

  if ($s!=$session[dbsessionhash]) {
  	eval("standarderror(\"ADMINISTRATOR: You MUST revert your <b>modifyoptions</b> template.\");");
	exit;
  }

  if ($bbuserinfo[userid]==0 or $permissions['canmodifyprofile']==0) {
    show_nopermission();
  }

  $adminemail=iif($allowmail=="yes",1,0);
  $emailnotification=iif($emailnotification=="yes",1,0);
  $options=iif($showsignatures=="yes",1,0);
  $options+=iif($showavatars=="yes",2,0);
  $options+=iif($showimages=="yes",4,0);
  $options+=iif($vbcode=="yes",8,0);
  $showemail=iif($showemail=="yes",1,0);
  $invisible=iif($invisible=="yes",1,0);
  $cookieuser=iif($cookieuser=="yes",1,0);
  $nosessionhash=iif($nosessionhash=="yes",1,0);
  $receivepm=iif($receivepm=="yes",1,0);
  $emailonpm=iif($emailonpm=="yes",1,0);
  $pmpopup=iif($pmpopup=="yes",1,0);

  if ($allowchangestyles==1) {
    $updatestyles = "styleid='$newstyleset',";
    if ($newstyleset!=$bbuserinfo['styleid']) {
      $DB_site->query("UPDATE session SET styleid=".intval($newstyleset)." WHERE sessionhash='".addslashes($session['dbsessionhash'])."'");
      vbsetcookie("bbstyleid", intval($newstyleset));
    }
  } else {
    $updatestyles = "";
  }

  //delete cookies if cookie user is off
  if ($cookieuser==0) {
    vbsetcookie("bbuserid","");
    vbsetcookie("bbpassword","");
  }

  $DB_site->query("UPDATE user
                   SET ".$updatestyles."adminemail='$adminemail',
                      showemail='$showemail',invisible='$invisible',cookieuser='$cookieuser',
                      maxposts='".addslashes($umaxposts)."',daysprune='".addslashes($prunedays)."',
                      timezoneoffset='".addslashes($timezoneoffset)."',emailnotification='$emailnotification',
                      startofweek='".addslashes($startofweek)."',options='$options',receivepm='$receivepm',
                      emailonpm='$emailonpm',pmpopup='$pmpopup',usergroupid='$bbuserinfo[usergroupid]',
                      nosessionhash='$nosessionhash'
                   WHERE userid='$bbuserinfo[userid]'");

  if ($modifyavatar!="") {
    $goto="member.php?s=$session[sessionhash]&action=editavatar";
  } else {
    $goto="usercp.php?s=$session[sessionhash]";
  }
  eval("standardredirect(\"".gettemplate("redirect_updatethanks")."\",\"$goto\");");

}

// ############################### start modify password ###############################
if ($action=="editpassword") {
  $templatesused = "usercpnav,modifypassword";
  include("./global.php");
  // do modify profile form

  if ($bbuserinfo[userid]==0) {
    show_nopermission();
  }

  // draw cp nav bar
  $cpnav[1]="{secondaltcolor}";
  $cpnav[2]="{secondaltcolor}";
  $cpnav[3]="{secondaltcolor}";
  $cpnav[4]="{firstaltcolor}";
  $cpnav[5]="{secondaltcolor}";
  $cpnav[6]="{secondaltcolor}";
  $cpnav[7]="{secondaltcolor}";
  eval("\$cpnav = \"".gettemplate("usercpnav")."\";");

  eval("dooutput(\"".gettemplate("modifypassword")."\");");
}

// ############################### start update password ###############################
if ($HTTP_POST_VARS['action']=="updatepassword") {
  include("./global.php");

  if ($bbuserinfo[userid]==0) {
    show_nopermission();
  }

  // validate old password
  if ($currentpassword!=$bbuserinfo[password]) {
    eval("standarderror(\"".gettemplate("error_wrongpassword")."\");");
    exit;
  }

  if ($newpassword!=$newpasswordconfirm) {
    eval("standarderror(\"".gettemplate("error_passwordmismatch")."\");");
    exit;
  }

  $DB_site->query("UPDATE user SET password='".addslashes($newpassword)."',usergroupid='$bbuserinfo[usergroupid]' WHERE userid='$bbuserinfo[userid]'");

  eval("standardredirect(\"".gettemplate("redirect_updatethanks")."\",\"usercp.php?s=$session[sessionhash]\");");

}

// ############################### start modify avatar ###############################
if ($action=="editavatar") {
  $templatesused = "numbernav_pages,numbernav,modifyavatarbit,modifyavatar_customwebsite,modifyavatar_customupload,modifyavatar_custom,usercpnav,modifyavatar";
  include("./global.php");
  // do modify profile form
  if (!$avatarenabled) {
    eval("standarderror(\"".gettemplate("error_avatardisabled")."\");");
    exit;
  }

  if ($bbuserinfo[userid]==0) {
    show_nopermission();
  }

  $avatarchecked[$bbuserinfo[avatarid]]="checked";

  $avatarlist="";
  $nouseavatarchecked="";
  if (!$avatarinfo=$DB_site->query_first("SELECT * FROM customavatar WHERE userid=$bbuserinfo[userid]")) {
    // no custom avatar exists
    if ($bbuserinfo[avatarid]==0) {
      // must have no avatar selected
      $nouseavatarchecked="checked";
      $avatarchecked[0]="";
    }
  }

  if (intval($numavatarshigh)==0)
    $numavatarshigh=5;
  if (intval($numavatarswide)==0)
    $numavatarswide=5;
  $perpage = $numavatarshigh * $numavatarswide;
  if (!isset($pagenumber) or $pagenumber==0) {
    $pagenumber=1;
  }
  $limitlower=($pagenumber-1)*$perpage+1;
  $limitupper=($pagenumber)*$perpage;
  $avatarcount = $DB_site->query_first("SELECT COUNT(*) AS count
                                  FROM avatar
                                  WHERE minimumposts<='$bbuserinfo[posts]'");
  $totalavatars = $avatarcount[count];
  if ($limitupper>$totalavatars) {
    $limitupper=$totalavatars;
    if ($limitlower>$totalavatars) {
      $limitlower=$totalavatars-$perpage;
    }
  }
  if ($limitlower<=0) {
    $limitlower=1;
  }


  $avatars=$DB_site->query("SELECT *
                            FROM avatar
                            WHERE minimumposts<='$bbuserinfo[posts]'
                            ORDER BY title
                            LIMIT ".($limitlower-1).",$perpage");

  $avatarcount = 0;
  while ($avatar=$DB_site->fetch_array($avatars)) {
    $avatarid=$avatar[avatarid];
    if ($avatarcount==0)
      $avatarlist .= '<tr>';
    eval("\$avatarlist .= \"".gettemplate("modifyavatarbit")."\";");
    $avatarcount++;
    if ($avatarcount==$numavatarswide) {
      $avatarlist .= '</tr>';
      $avatarcount = 0;
    }
  }
  if ($avatarcount!=0) {
    while ($avatarcount < $numavatarswide) {
      $avatarlist .= '<td bgcolor="{firstaltcolor}">&nbsp;</td>';
      $avatarcount++;
    }
    $avatarlist .= '</tr>';
  }

  if ($totalavatars>$perpage) {

      $totalpages=$totalavatars/$perpage;
      if ($totalpages!=intval($totalpages)) {
        $totalpages=intval($totalpages)+1;
      }

      $shorturl="member.php?s=$session[sessionhash]&action=editavatar&perpage=$perpage";

      if ($pagenumber==1) {
        $firstpage_atag='';
        $prevpage_atag='';
      } else {
        $endfirstprevtag = '</a>';
        $firstpage_atag="<a href=\"$shorturl&pagenumber=1\">";
        $prevpage_atag="<a href=\"$shorturl&pagenumber=".($pagenumber-1)."\">";
      }
      if ($pagenumber==$totalpages) {
        $lastpage_atag='';
        $nextpage_atag='';
      } else {
        $endlastnexttag = '</a>';
        $lastpage_atag="<a href=\"$shorturl&pagenumber=$totalpages\">";
        $nextpage_atag="<a href=\"$shorturl&pagenumber=".($pagenumber+1)."\">";
      }

      $curpage=0;
      $pagenumbers="";
      while ($curpage++<$totalpages) {
        if (($curpage>$pagenumber-$pagenavpages and $curpage<$pagenumber+$pagenavpages) or $pagenavpages==0) {
          if ($curpage==$pagenumber) {
            $numbernav_atag="";
            $endpagetag = '';
            eval("\$pagenumbers .= \"".gettemplate('numbernav_pages')."\";");
          } else {
            $numbernav_atag="<a href=\"$shorturl&pagenumber=$curpage\">";
            $endpagetag = '</a>';
            eval("\$pagenumbers .= \"".gettemplate('numbernav_pages')."\";");
          }
        }
      }
      eval("\$pagenav = \"".gettemplate('numbernav')."\";");

    } else {
      $pagenav="";
  }

  if (($avatarallowupload or $avatarallowwebsite) and $bbuserinfo[posts] >= $avatarcustomposts)
  {
    $bbuserinfo[avatarurl]=getavatarurl($bbuserinfo[userid]);
    if ($bbuserinfo[avatarurl]=="" or $bbuserinfo[avatarid]!=0) {
      $bbuserinfo[avatarurl]="{imagesfolder}/clear.gif";
    }
    $backcolor = "{secondaltcolor}";
    if ($avatarallowwebsite) {
      eval("\$customwebsite = \"".gettemplate("modifyavatar_customwebsite")."\";");
      $backcolor = "{firstaltcolor}";
    }

    if ($avatarallowupload and (!$safeupload or function_exists("is_uploaded_file"))) {
      eval("\$customupload = \"".gettemplate("modifyavatar_customupload")."\";");
    }

    eval("\$customavatar = \"".gettemplate("modifyavatar_custom")."\";");
  }

  // draw cp nav bar
  $cpnav[1]="{secondaltcolor}";
  $cpnav[2]="{secondaltcolor}";
  $cpnav[3]="{firstaltcolor}";
  $cpnav[4]="{secondaltcolor}";
  $cpnav[5]="{secondaltcolor}";
  $cpnav[6]="{secondaltcolor}";
  $cpnav[7]="{secondaltcolor}";
  eval("\$cpnav = \"".gettemplate("usercpnav")."\";");

  eval("dooutput(\"".gettemplate("modifyavatar")."\");");
}

// ############################### start update avatar ###############################
if ($HTTP_POST_VARS['action']=="updateavatar") {
  $templatesused = "error_avatarmoreposts,error_avatarbadurl,error_avataruploaderror,error_avatarbaddimensions,error_avatarnotimage,error_avatartoobig,error_avatarmoreposts,redirect_updatethanks";
  include("./global.php");

  if ($bbuserinfo[userid]==0) {
    show_nopermission();
  }

  $useavatar=iif($avatarid==-1,0,1);

  if ($useavatar) {
    if ($avatarid==0) {
      // using custom avatar
      $filename="";

      if ($bbuserinfo['posts']<$avatarcustomposts) {
        eval("standarderror(\"".gettemplate("error_avatarmoreposts")."\");");
        // not enough posts error
        exit;
      }

      // check for new uploaded file or for new url
      $avatarurl=trim($avatarurl);
      if ($avatarurl!="" and $avatarurl!="http://www.") {
        // get file from url

        $filenum=@fopen($avatarurl,"rb");
        if ($filenum!=0) {
          $contents="";
          while (!@feof($filenum)) {
            $contents.=@fread($filenum,1024); //filesize($filename));
          }
          @fclose($filenum);

          $avatarfile_name = "vba".substr(time(),-4);
          if ($safeupload) {
            $filename="$tmppath/$avatarfile_name";
            $filenum=@fopen($filename,"wb");
            @fwrite($filenum,$contents);
            @fclose($filenum);
          } else {
            // write in temp dir
            $filename=tempnam(get_cfg_var("upload_tmp_dir"),"vbavatar");
            $filenum=@fopen($filename,"wb");
            @fwrite($filenum,$contents);
            @fclose($filenum);
          }
        } else {
          // invalid address error
          eval("standarderror(\"".gettemplate("error_avatarbadurl")."\");");
          exit;
        }
      } else {
        // check file exists on server
        if ($safeupload) {
          $filename="";
	       $path = "$tmppath/$avatarfile_name";
          if (function_exists("is_uploaded_file") and is_uploaded_file($avatarfile) and move_uploaded_file($avatarfile, "$path")) {
            if (file_exists($path)) {
              if (filesize($path)!=$avatarfile_size) {
                // security error
                eval("standarderror(\"".gettemplate("error_avataruploaderror")."\");");
              } ####### END if (filesize($path)!=$avatarfile_size) {

              $filename=$path;
            } else {
              // bad upload
              $avatarid=0;
              $filename="";
            } ####### END if (file_exists($path)) {
          } ####### END if (function_exists("is_uploaded_file") and is_uploaded_file($avatarfile) [...]
        } else {
          if (file_exists($avatarfile)) {
            if (filesize($avatarfile)!=$avatarfile_size) {
              eval("standarderror(\"".gettemplate("error_avataruploaderror")."\");");
              // security error
              exit;
            }
            $filename=$avatarfile;
          } else {
            // bad upload
            $avatarid=0;
            $filename="";
          }
        } ####### END if ($safeupload) {
      } ####### END if ($avatarurl!="" and $avatarurl!="http://www.") {

      if ($filename!="") {
        // check valid image
        if ($imginfo=@getimagesize($filename)) {
          if ($imginfo[0]>$avatarmaxdimension or $imginfo[1]>$avatarmaxdimension) {
            eval("standarderror(\"".gettemplate("error_avatarbaddimensions")."\");");
            // wrong dimensions
            exit;
          }
          if ($imginfo[2]!=1 and $imginfo[2]!=2) {
            eval("standarderror(\"".gettemplate("error_avatarnotimage")."\");");
            // not gif or jpg
            exit;
          }
        }

        // read file
        $filesize=@filesize($filename);
        if ($filesize>$avatarmaxsize) {
          eval("standarderror(\"".gettemplate("error_avatartoobig")."\");");
          // file size too big
          exit;
        }

        $filenum=@fopen($filename,"rb");
        $filestuff=@fread($filenum,$filesize);
        @fclose($filenum);

        @unlink($filename);

        if ($avexists=$DB_site->query_first("SELECT userid FROM customavatar WHERE userid=$bbuserinfo[userid]")) {
          $DB_site->query("UPDATE customavatar SET filename='".addslashes($avatarfile_name)."',dateline='".time()."',avatardata='".addslashes($filestuff)."' WHERE userid=$bbuserinfo[userid]");
        } else {
          $DB_site->query("INSERT INTO customavatar (userid,avatardata,dateline,filename) VALUES ($bbuserinfo[userid],'".addslashes($filestuff)."','".time()."','".addslashes($avatarfile_name)."')");
        }
      }
    } else {
      $avatarid=verifyid("avatar",$avatarid);
      $avatarinfo=$DB_site->query_first("SELECT minimumposts FROM avatar WHERE avatarid=$avatarid");
      if ($avatarinfo[minimumposts]>$bbuserinfo[posts]) {
        eval("standarderror(\"".gettemplate("error_avatarmoreposts")."\");");
        // not enough posts error
        exit;
      }
      $DB_site->query("DELETE FROM customavatar WHERE userid=$bbuserinfo[userid]");
    }
  } else {
    $avatarid=0;
    $DB_site->query("DELETE FROM customavatar WHERE userid=$bbuserinfo[userid]");
  }

  $DB_site->query("UPDATE user SET avatarid='".addslashes($avatarid)."',usergroupid='$bbuserinfo[usergroupid]' WHERE userid='$bbuserinfo[userid]'");

  eval("standardredirect(\"".gettemplate("redirect_updatethanks")."\",\"usercp.php?s=$session[sessionhash]\");");

}

// ############################### start get info ###############################
if ($action=="getinfo") {
  $templatesused = "getinfo_sendpm,aol,icq,yahoo,getinfo_birthday,getinfo_customfields,getinfo";
  include("./global.php");

  $permissions=getpermissions();
  if (!$permissions[canview] or !$permissions[canviewmembers]) {
		show_nopermission();
  }

  if ($find=="firstposter" and isset($threadid)) {
    $threadid=verifyid("thread",$threadid);
    $getuserid=$DB_site->query_first("SELECT postuserid FROM thread WHERE threadid='$threadid'");
    $userid=$getuserid[postuserid];
  }
  if ($find=="lastposter" and isset($threadid)) {
    $threadid=verifyid("thread",$threadid);
    $getuserid=$DB_site->query_first("SELECT userid FROM post WHERE threadid='$threadid' AND visible=1 ORDER BY dateline DESC");
    $userid=$getuserid[userid];
  }
  if ($find=="lastposter" and isset($forumid)) {
    $foruminfo=verifyid("forum",$forumid,1,1);
    $forumid = $foruminfo['forumid'];

    // prevent a small backdoor where anyone could see who the last poster in ANY forum was
    $forumperms=getpermissions($forumid);
    if (!$forumperms['canview']) {
		show_nopermission();
    }

    $getchildforums=$DB_site->query("SELECT forumid,parentlist FROM forum WHERE INSTR(CONCAT(',',parentlist,','),',$forumid,')>0");
    while ($getchildforum=$DB_site->fetch_array($getchildforums)) {
      $forumslist.=",$getchildforum[forumid]";
    }

    $thread=$DB_site->query_first("SELECT threadid FROM thread WHERE forumid IN (0$forumslist) AND visible=1 AND (sticky=1 OR sticky=0) AND lastpost>='".($foruminfo[lastpost]-30)."' AND open<>10 ORDER BY lastpost DESC LIMIT 1");
    $getuserid=$DB_site->query_first("SELECT userid FROM post WHERE threadid='$thread[threadid]' AND visible=1 ORDER BY dateline DESC LIMIT 1");
    $userid=$getuserid[userid];
  }
  if ($find=="moderator" and isset($moderatorid)) {
    $moderatorid=verifyid("moderator",$moderatorid);
    $getuserid=$DB_site->query_first("SELECT userid FROM moderator WHERE moderatorid='$moderatorid'");
    $userid=$getuserid[userid];
  }

  if ($userid=="" and $username!="") {
    $username=urldecode($username);
    $user=$DB_site->query_first("SELECT userid FROM user WHERE username='".addslashes(htmlspecialchars($username))."'");
    $userid=$user[userid];
  }

  if ($userid==0) {
    eval("standarderror(\"".gettemplate("error_unregistereduser")."\");");
  }

  $userid = verifyid("user",$userid);

  // display user info

  $userinfo=getuserinfo($userid);
  if ($userinfo[customtitle]==2)
    $userinfo[usertitle] = htmlspecialchars($userinfo[usertitle]);
  $userinfo[datejoined]=vbdate($dateformat,$userinfo[joindate]);

  $jointime = (time() - $userinfo[joindate]) / 86400; // Days Joined
  if ($jointime < 1) { // User has been a member for less than one day.
    $postsperday = "$userinfo[posts]";
  } else {
    $postsperday = sprintf("%.2f",($userinfo[posts] / $jointime));
  }

  if ($userinfo[homepage]!="http://" and $userinfo[homepage]!="") {
    $userinfo[homepage]=$userinfo[homepage];
  } else {
    $userinfo[homepage]="";
  }

  if ($userinfo[receivepm]) {
    eval("\$userinfo[sendpm] = \"".gettemplate("getinfo_sendpm")."\";");
  } else {
    $userinfo[sendpm] = "";
  }

  if ($userinfo[icq]!="") {
    eval("\$userinfo[icqicon] = \"".gettemplate("icq")."\";");
  } else {
    $userinfo[icq]="&nbsp;";
  }
  if ($userinfo[aim]!="") {
    eval("\$userinfo[aimicon] = \"".gettemplate("aim")."\";");
  } else {
    $userinfo[aim]="&nbsp;";
  }
  if ($userinfo[yahoo]!="") {
    eval("\$userinfo[yahooicon] = \"".gettemplate("yahoo")."\";");
  } else {
    $userinfo[yahoo]="&nbsp;";
  }

  $userinfo[avatarurl]=getavatarurl($userinfo[userid]);
  if ($userinfo[avatarurl]=="") {
    $userinfo[avatarurl]="{imagesfolder}/clear.gif";
  }

  // get last post
  $totalposts=$userinfo[posts];
  if ($userinfo[posts]!=0 and $userinfo[lastpost]!=0) {
    $lastpostdate=vbdate($dateformat,$userinfo[lastpost]);
    $lastposttime=vbdate($timeformat,$userinfo[lastpost]);

    $getlastposts=$DB_site->query("SELECT thread.title,thread.threadid,thread.forumid,postid,post.dateline FROM post,thread WHERE thread.threadid=post.threadid AND thread.visible = 1 AND post.userid='$userid' ORDER BY post.dateline DESC LIMIT 20");

    while ($getlastpost=$DB_site->fetch_array($getlastposts)) {

      $getperms=getpermissions($getlastpost[forumid]);
      if ($getperms[canview]) {
        $lastposttitle=$getlastpost[title];
        $lastposturl="showthread.php?s=$session[sessionhash]&postid=$getlastpost[postid]#post$getlastpost[postid]";
        break;
      }
    }
  } else {
    $lastpostdate="Never";
  }
  if ($calbirthday == 1) {
     if ($backcolor=="{firstaltcolor}") {
        $backcolor="{secondaltcolor}";
     } else {
        $backcolor="{firstaltcolor}";  }
     // Set birthday fields right here!
     if ($userinfo[birthday] == '0000-00-00') {
        $birthday = "N/A";
     } else {
        $bday = explode("-",$userinfo[birthday]);
        if (date("Y")>$bday[0] and $bday[0]>1901 && $bday[0]!='0000') {
          $birthday = @date($calformat1,mktime(0,0,0,$bday[1],$bday[2],$bday[0]));
        } else {
          // lets send a valid year as some PHP3 don't like year to be 0
          // $calformat2 should not contania year identifier so the year doesn't matter
          $birthday = @date($calformat2,mktime(0,0,0,$bday[1],$bday[2],1993));
        }
        if ($birthday=="") {
          $birthday="$bday[1]-$bday[2]-$bday[0]";
        }
     }
     eval("\$birthday = \"".gettemplate("getinfo_birthday")."\";");
  }

  // Get referrals
  if ($usereferrer) {
    if ($backcolor=="{firstaltcolor}") {
	  $backcolor="{secondaltcolor}";
	} else {
      $backcolor="{firstaltcolor}";  }
    $refcount = $DB_site->query_first("SELECT count(*) AS count
                                       FROM user
                                       WHERE referrerid = '$userinfo[userid]'");
    $referrals = $refcount[count];
    eval("\$referrals = \"".gettemplate("getinfo_referrals")."\";");
  }

  // get extra profile fields
  $profilefields=$DB_site->query("SELECT profilefieldid,required,title FROM profilefield WHERE hidden=0 ORDER BY displayorder");
  while ($profilefield=$DB_site->fetch_array($profilefields)) {
    if ($backcolor=="{firstaltcolor}") {
      $backcolor="{secondaltcolor}";
    } else {
      $backcolor="{firstaltcolor}";
    }

    $profilefieldname="field$profilefield[profilefieldid]";
    $profilefield[value]=$userinfo[$profilefieldname];
    eval("\$customfields .= \"".gettemplate("getinfo_customfields")."\";");

  }

  eval("dooutput(\"".gettemplate("getinfo")."\");");

}

// ############################### start aim message ###############################
if ($action=="aimmessage") {
  include("./global.php");
  eval("dooutput(\"".gettemplate("aimmessage")."\");");

}

// ############################### start mail member ###############################
if ($action=="mailform") {
  include("./global.php");
  $userid=verifyid("user",$userid);

  if (!$bbuserinfo['userid'] or $bbuserinfo['usergroupid']==3) {
    //don't let people awaiting email confirmation use it either as their email may be fake
    show_nopermission();
  }

  $userinfo=$DB_site->query_first("SELECT username,email,showemail FROM user WHERE userid='$userid'");
  if ($userinfo[showemail]) {
    $destusername=$userinfo[username];
    if ($secureemail) {
			if (!$enableemail) {
				eval("standarderror(\"".gettemplate("error_emaildisabled")."\");");
				exit;
			}

      eval("dooutput(\"".gettemplate("mailform")."\");");
    } else {
      $destusername=$userinfo[username];
      $email=$userinfo[email];

      eval("standarderror(\"".gettemplate("error_showemail")."\");");

    }
  } else {
    eval("standarderror(\"".gettemplate("error_usernoemail")."\");");
    exit;
  }
}

// ############################### start mail member ###############################
if ($HTTP_POST_VARS['action']=="emailmessage") {
  include("./global.php");

  if (!$bbuserinfo['userid'] or $bbuserinfo['usergroupid']==3) {
    show_nopermission();
  }

  if (!$enableemail) {
    eval("standarderror(\"".gettemplate("error_emaildisabled")."\");");
    exit;
  }

  $destuserid=verifyid("user",$userid);
  $destuserinfo=$DB_site->query_first("SELECT username,email,showemail FROM user WHERE userid='$destuserid'");

  if (!$destuserinfo[showemail]) {
    eval("standarderror(\"".gettemplate("error_usernoemail")."\");");
    exit;
  }

  $message = trim($message);
  if (!$message) {
    eval("standarderror(\"".gettemplate("error_nomessage")."\");");
  }

  eval("\$sendmessage = \"".gettemplate("email_usermessage",1,0)."\";");

  mail($destuserinfo[email],$subject,$sendmessage,"From: \"$bbuserinfo[username]\" <$bbuserinfo[email]>");

  // parse this next line with eval:
  $sendtoname=$destuserinfo[username];
  eval("standardredirect(\"".gettemplate("redirect_sentemail")."\",\"usercp.php?s=$session[sessionhash]\");");
}

?>