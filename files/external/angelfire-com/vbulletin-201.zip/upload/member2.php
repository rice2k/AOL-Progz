<?php
error_reporting(7);

if ($HTTP_GET_VARS['HTTP_POST_VARS']['action'] == $HTTP_POST_VARS['action']) {
  unset($HTTP_POST_VARS['action']);
}
$HTTP_POST_VARS['action'] = trim($HTTP_POST_VARS['action']);

// buddy list
// ignore list
// ############################### start add to list ###############################
if ($action=="addlist") {
  $templatesused = ""; // Only one used so just load it when called...
  include("./global.php");
  //check usergroup of user to see if they can use Profile
  if ($bbuserinfo[userid]==0) {
    show_nopermission();
  }

  if ($userlist!="buddy") {
    $userlist="ignore";
  }
  $var=$userlist."list";

  $userid=verifyid("user",$userid);
  $userinfo=getuserinfo($userid);

  $splitlist=explode(" ",$bbuserinfo[$var]);

  $found=0;
  while (list($key,$val)=each($splitlist)) {
    if ($val==$userid) {
      $found=1;
    }
  }
  if (!$found) {
    $bbuserinfo[$var].=" $userid";
  }
  $bbuserinfo[$var]=trim($bbuserinfo[$var]);

  $DB_site->query("UPDATE user SET $var='".addslashes($bbuserinfo[$var])."' WHERE userid=$bbuserinfo[userid]");
  $url = str_replace("\"", "", $url);
  eval("standardredirect(\"".gettemplate("redirect_addlist")."\",\"$url\");");

}

// ############################### start remove from ###############################
if ($action=="removelist") {
  $templatesused = ""; // Only one used so just load it when called...
  include("./global.php");
  //check usergroup of user to see if they can use Profile
  if ($bbuserinfo[userid]==0) {
    show_nopermission();
  }

  if ($userlist!="buddy") {
    $userlist="ignore";
  }
  $var=$userlist."list";

  $userid=verifyid("user",$userid);
  $userinfo=getuserinfo($userid);

  $splitlist=explode(" ",$bbuserinfo[$var]);

  while (list($key,$val)=each($splitlist)) {
    if ($val==$userid) {
      unset($splitlist[$key]);
    }
  }

  $bbuserinfo[$var]=implode(" ",$splitlist);
  $bbuserinfo[$var]=trim($bbuserinfo[$var]);

  $DB_site->query("UPDATE user SET $var='".addslashes($bbuserinfo[$var])."' WHERE userid=$bbuserinfo[userid]");
  $url = str_replace("\"", "", $url);
  eval("standardredirect(\"".gettemplate("redirect_removelist")."\",\"$url\");");

}

// ############################### start view list ###############################
if ($action=="viewlist") {

  $templatesused = "listbit,usercpnav,listedit";

  include("./global.php");
  //check usergroup of user to see if they can use Profile
  if ($bbuserinfo[userid]==0) {
    show_nopermission();
  }

  if ($userlist!="buddy") {
    $userlist="ignore";
    $listtype = "Ignore";
  } else {
    $listtype = "Buddy";
  }
  //HAPPY?
  $var=$userlist."list";

  $splitlist=explode(" ",$bbuserinfo[$var]);

  while (list($key,$val)=each($splitlist)) {
    if ($val!="") {
      if ($userinfo=getuserinfo($val)) {
        eval("\$listbits .= \"".gettemplate("listbit")."\";");
      }
    }
  }

  // draw cp nav bar
  $cpnav[1]="{secondaltcolor}";
  $cpnav[2]="{secondaltcolor}";
  $cpnav[3]="{secondaltcolor}";
  $cpnav[4]="{secondaltcolor}";
  if ($userlist!="buddy") {
    $cpnav[5]="{secondaltcolor}";
    $cpnav[6]="{firstaltcolor}";
  } else {
    $cpnav[5]="{firstaltcolor}";
    $cpnav[6]="{secondaltcolor}";
  }
  $cpnav[7]="{secondaltcolor}";
  eval("\$cpnav = \"".gettemplate("usercpnav")."\";");

  eval("dooutput(\"".gettemplate("listedit")."\");");

}

// ############################### start update list ###############################
if ($HTTP_POST_VARS['action']=="updatelist") {
  $templatesused = ""; // Only one used so just load it when called...
  include("./global.php");
  //check usergroup of user to see if they can use Profile
  if ($bbuserinfo[userid]==0) {
    show_nopermission();
  }

  if ($userlist!="buddy") {
    $userlist="ignore";
  }
  $var=$userlist."list";

  $listids="";
  while (list($key,$val)=each($listbits)) {
    if ($userid=$DB_site->query_first("SELECT usergroupid, user.userid, moderator.userid as moduserid
                                       FROM user
                                       LEFT JOIN moderator ON (user.userid = moderator.userid)
                                       WHERE username='".addslashes(htmlspecialchars($val))."'")) {
      if ($var=='ignorelist' and !$ignoremods and ($userid[usergroupid]==6 or $userid[usergroupid]==5 or $userid[moduserid])) {
        $username=$val;
        eval("standarderror(\"".gettemplate("error_listignoreuser")."\");");
        exit;
      } else {
        $listids.=" $userid[userid]";
      }
    } else {
      if (trim($val)!="") {
        $username=$val;
        eval("standarderror(\"".gettemplate("error_listbaduser")."\");");
        exit;
      }
    }
  }

  $listids=trim($listids);

  $DB_site->query("UPDATE user SET $var='".addslashes($listids)."' WHERE userid=$bbuserinfo[userid]");

  eval("standardredirect(\"".gettemplate("redirect_updatelist")."\",\"usercp.php?s=$session[sessionhash]\");");

}

// ############################### start add subscription ###############################
if ($action=="addsubscription") {
  $templatesused = ""; // Only one used so just load it when called...
  include("./global.php");
  //check usergroup of user to see if they can use Profile
  if ($bbuserinfo[userid]==0) {
    show_nopermission();
  }

  if (isset($threadid)) {
    $type="thread";
    $id=$threadid;
    $id=verifyid($type,$id);
    $threadinfo=getthreadinfo($id);

    $permissions=getpermissions($threadinfo[forumid]);
    if (!$permissions[canview]) {
      show_nopermission();
    }

  } else {
    $type="forum";
    $id=$forumid;

    $permissions=getpermissions($forumid);
    if (!$permissions[canview]) {
      show_nopermission();
    }

  }

  $table="subscribe$type";
  $tableid=$table."id";
  $typeid=$type."id";

  if (!$checkid=$DB_site->query_first("SELECT $tableid FROM $table WHERE userid=$bbuserinfo[userid] AND $typeid=$id")) {
    $id=verifyid($type,$id);
    $DB_site->query("INSERT INTO $table ($tableid,userid,$typeid) VALUES (NULL,$bbuserinfo[userid],$id)");
  }

  $url = str_replace("\"", "", $url);
  eval("standardredirect(\"".gettemplate("redirect_subsadd")."\",\"$url\");");
}

// ############################### start remove subscription ###############################
if ($action=="removesubscription" or $action=="usub") {
  $templatesused = ""; // Only one used so just load it when called...
  include("./global.php");
  //check usergroup of user to see if they can use Profile
  if ($bbuserinfo[userid]==0) {
    show_nopermission();
  }

  if (!$url) {
    $url = "usercp.php?s=$session[sessionhash]";
  }

  if ($type=="allthread") {
    $DB_site->query("DELETE FROM subscribethread WHERE userid=$bbuserinfo[userid]");

    $type="threads";
    $url = str_replace("\"", "", $url);
    eval("standardredirect(\"".gettemplate("redirect_subsremoveall")."\",\"$url\");");
  } elseif ($type=="allforum") {
    $DB_site->query("DELETE FROM subscribeforum WHERE userid=$bbuserinfo[userid]");

    $type="forums";
    $url = str_replace("\"", "", $url);
    eval("standardredirect(\"".gettemplate("redirect_subsremoveall")."\",\"$url\");");
  } else {
    if (isset($threadid)) {
      $type="thread";
      $id=$threadid;
    } else {
      $type="forum";
      $id=$forumid;
    }

    $table="subscribe$type";
    $tableid=$table."id";
    $typeid=$type."id";
    $id=verifyid($type,$id);

    $DB_site->query("DELETE FROM $table WHERE userid=$bbuserinfo[userid] AND $typeid='$id'");

    $url = str_replace("\"", "", $url);
    eval("standardredirect(\"".gettemplate("redirect_subsremove")."\",\"$url\");");
  }
}


// ############################### start view threads ###############################
if ($action=="viewsubscription") {

  $templatesused = "forumdisplay_multipagenav_more,forumdisplay_multipagenav_pagenumber,forumdisplay_multipagenav,forumdisplay_gotonew,subscribe_threadbit,subscribe_threads,subscribe_nothreads,usercpnav,subscribe";

  include("./global.php");
  //check usergroup of user to see if they can use Profile
  if ($bbuserinfo[userid]==0) {
    show_nopermission();
  }

  makeforumjump();
  // set defaults
  if (!isset($perpage) or $perpage>200) { //max of 200, per several users requests
    $perpage=$maxthreads;
  }

  if (!isset($pagenumber) or $pagenumber==0) {
      $pagenumber=1;
  }

  // display threads
  $limitlower=($pagenumber-1)*$perpage+1;
  $limitupper=($pagenumber)*$perpage;

  if (!isset($daysprune) or $daysprune==0 or $daysprune==-1) {
    $daysprune=30;
  }

  // look at thread limiting options
  if ($daysprune!=1000) {
    $datecut="AND lastpost >= ".(time() - ($daysprune*86400));
  }
  $daysprunesel[$daysprune]="selected";

  if (trim($bbuserinfo[ignorelist])!="") {
    $ignoreusers="AND thread.postuserid<>".implode(" AND thread.postuserid<>",explode(" ",$bbuserinfo[ignorelist]));
  } else {
    $ignoreusers="";
  }

  $threadscount=$DB_site->query_first("SELECT COUNT(*) AS threads
                                       FROM thread,subscribethread
                                       WHERE subscribethread.threadid=thread.threadid
									     AND subscribethread.userid='$bbuserinfo[userid]'
		                                 AND thread.visible=1 $datecut $ignoreusers");
  $totalallthreads=$threadscount[threads];

  if ($limitupper>$totalallthreads) {
    $limitupper=$totalallthreads;
    if ($limitlower>$totalallthreads) {
      $limitlower=$totalallthreads-$perpage;
    }
  }
  if ($limitlower<=0) {
    $limitlower=1;
  }

  if ($showdots and $bbuserinfo[userid] >= 1) {
    $dotuserid = "DISTINCT post.userid,";
    $dotjoin = "LEFT JOIN post ON (thread.threadid = post.threadid AND post.userid = '$bbuserinfo[userid]')";
  }

  $getthreadids=$DB_site->query("SELECT thread.threadid
		FROM thread,subscribethread
		WHERE subscribethread.threadid=thread.threadid
		  AND subscribethread.userid='$bbuserinfo[userid]'
	 	  AND thread.visible=1 $datecut $ignoreusers
	 	ORDER BY lastpost DESC
        LIMIT ".($limitlower-1).",$perpage
	");
  $totalthreads=$DB_site->num_rows($getthreadids);

  if ($totalthreads>0) {
   // check to see if there are any threads to display. If there are, do so, otherwise, show message

	$threadids="thread.threadid IN (0";
	while ($thread=$DB_site->fetch_array($getthreadids)) {
		$threadids.=",".$thread[threadid];
	}
	$threadids.=")";

    $threads=$DB_site->query("SELECT $dotuserid icon.title as icontitle,icon.iconpath,thread.threadid,thread.title,
		lastpost,forumid,pollid,open,replycount,postusername,postuserid,lastposter,thread.dateline,views,
		thread.iconid,notes,thread.visible
		FROM thread
		LEFT JOIN icon ON (icon.iconid = thread.iconid)
		$dotjoin
		WHERE $threadids
		ORDER BY lastpost DESC");

    while ($thread=$DB_site->fetch_array($threads)) {
      if (($bbuserinfo[maxposts] != -1) and ($bbuserinfo[maxposts] != 0))
      {   $maxposts = $bbuserinfo[maxposts];  }
      if (($thread[replycount]+1)>$maxposts and $linktopages) {

        $totalpages=($thread[replycount]+1)/$maxposts;
        if ($totalpages!=intval($totalpages)) {
          $totalpages=intval($totalpages)+1;
        }

        $acurpage=0;
        $pagenumbers="";
        while ($acurpage++<$totalpages) {
          if ($acurpage==$maxmultipage) {
            eval("\$pagenumbers .= \"".gettemplate("forumdisplay_multipagenav_more")."\";");
            break;
          } else {
            eval("\$pagenumbers .= \"".gettemplate("forumdisplay_multipagenav_pagenumber")."\";");
          }
        }
        eval("\$thread[pagenav] = \"".gettemplate("forumdisplay_multipagenav")."\";");
      } else {
        $thread[pagenav]="";
      }

      $threadicon="&nbsp;";
      if ($thread[iconid]!=0)
      {
        $thread[icon]="<img src=\"$thread[iconpath]\" alt=\"$thread[icontitle]\" width=\"15\" height=\"15\" border=\"0\">";
      }
      if ($thread[pollid]!=0) {
        $thread[icon]="<img src=\"{imagesfolder}/poll.gif\" alt=\"Poll\" width=\"15\" height=\"15\" border=\"0\">";
      }

      if ($wordwrap!=0) {
        $thread[title]=dowordwrap($thread[title]);
      }

      $replies=$thread[replycount];
      $views=$thread[views];
      $thread[lastreplydate]=vbdate($dateformat,$thread[lastpost]);
      $thread[lastreplytime]=vbdate($timeformat,$thread[lastpost]);

      $thread[gotonew]="";

      $thread[newoldhot]="folder";
      if (!$thread[open]) {
        $thread[newoldhot]="lock".$thread[newoldhot];
      }
      if ($thread[replycount]>=$hotnumberposts or $thread[views]>=$hotnumberviews and $usehotthreads) {
        $thread[newoldhot]="hot".$thread[newoldhot];
      }
      if ($bbuserinfo[lastvisitdate]=="Never") {
        $thread[newoldhot]="new".$thread[newoldhot];
      } elseif ($thread[lastpost]>$bbuserinfo[lastvisit]) {
          if (!isset($bbthreadview) or $bbthreadview[$thread[threadid]]<$thread[lastpost]) {
         $thread[newoldhot]="new".$thread[newoldhot];
          }
          eval("\$thread[gotonew] = \"".gettemplate("forumdisplay_gotonew")."\";");
      }
      if ($showdots and $bbuserinfo[userid] >= 1 and $bbuserinfo[userid] == $thread[userid]) {
         $thread[newoldhot] = "dot_" . $thread[newoldhot];
      }

      eval("\$threadbits .= \"".gettemplate("subscribe_threadbit")."\";");

    }

    $DB_site->free_result($threads);

	if ($totalallthreads>$perpage) {

	  $totalpages=$totalallthreads/$perpage;
	  if ($totalpages!=intval($totalpages)) {
	     $totalpages=intval($totalpages)+1;
	  }

	  $shorturl="member2.php?s=$session[sessionhash]&action=viewsubscription&daysprune=$daysprune&perpage=$perpage";

	    if ($pagenumber==1) {
	      $firstpage_atag='';
	      $prevpage_atag='';
	    } else {
	      $endfirstprevtag = '</a>';
	      $firstpage_atag="<a href=\"$shorturl&pagenumber=1\">";
	      $prevpage_atag="<a href=\"$shorturl&pagenumber=".($pagenumber-1)."\">";
	    }
	    if ($pagenumber==$totalpages) {
	      $lastpage_atag='';
	      $nextpage_atag='';
	    } else {
	      $endlastnexttag = '</a>';
	      $lastpage_atag="<a href=\"$shorturl&pagenumber=$totalpages\">";
	      $nextpage_atag="<a href=\"$shorturl&pagenumber=".($pagenumber+1)."\">";
	    }

	    $curpage=0;
	    $pagenumbers="";
	    while ($curpage++<$totalpages) {
	      if (($curpage>$pagenumber-$pagenavpages and $curpage<$pagenumber+$pagenavpages) or $pagenavpages==0) {
	        if ($curpage==$pagenumber) {
	          $numbernav_atag="";
	          $endpagetag = '';
	          eval("\$pagenumbers .= \"".gettemplate('numbernav_pages')."\";");
	        } else {
	          $numbernav_atag="<a href=\"$shorturl&pagenumber=$curpage\">";
	          $endpagetag = '</a>';
	          eval("\$pagenumbers .= \"".gettemplate('numbernav_pages')."\";");
	        }
	      }
	    }
	    eval("\$pagenav = \"".gettemplate('numbernav')."\";");

	  } else {
	    $pagenav="";
  }

    eval("\$threadslist = \"".gettemplate("subscribe_threads")."\";");
  } else {
    eval("\$threadslist = \"".gettemplate("subscribe_nothreads")."\";");
  }

  // draw cp nav bar
  $cpnav[1]="{secondaltcolor}";
  $cpnav[2]="{secondaltcolor}";
  $cpnav[3]="{secondaltcolor}";
  $cpnav[4]="{secondaltcolor}";
  $cpnav[5]="{secondaltcolor}";
  $cpnav[6]="{secondaltcolor}";
  $cpnav[7]="{secondaltcolor}";

  eval("\$cpnav = \"".gettemplate("usercpnav")."\";");

  eval("dooutput(\"".gettemplate("subscribe")."\");");
}

if ($bbuserinfo[userid]==0) {
   show_nopermission();
}

?>