<?php
error_reporting(7);

$templatesused="postbit_useremail,icq,aim,yahoo,postbit_homepage,announcebit,announcement";

require("./global.php");

$foruminfo = verifyid("forum",$forumid,1,1);

makeforumjump();

$getperms=getpermissions($foruminfo[forumid]);
if (!$getperms[canview]) {
  eval("standarderror(\"".gettemplate("error_nopermission")."\");");
  exit;
}

$counter=0;

$datenow=time();
$datecut = $datenow - $cookietimeout;

$forumlist=getforumlist($forumid,"announcement.forumid");
$announcements=$DB_site->query("
SELECT DISTINCT
".iif ($showonline,"session.userid AS sessionuserid,","")."
announcementid,startdate,enddate,announcement.title,pagetext,user.*,userfield.*
".iif($avatarenabled,",avatar.avatarpath,NOT ISNULL(customavatar.avatardata) AS hascustomavatar,customavatar.dateline AS avatardateline","")."
FROM announcement
LEFT JOIN user ON user.userid=announcement.userid
LEFT JOIN userfield ON userfield.userid=announcement.userid
".iif ($avatarenabled,"LEFT JOIN avatar ON avatar.avatarid=user.avatarid LEFT JOIN customavatar ON customavatar.userid=announcement.userid","")."
".iif( $showonline,"LEFT JOIN session ON (session.userid = announcement.userid
                                            AND session.userid <> 0
                                            AND user.invisible = 0
                                            AND session.lastactivity>$datecut)","")."
WHERE startdate<='$datenow' AND enddate>='$datenow' AND $forumlist ORDER BY startdate DESC");
while ($post=$DB_site->fetch_array($announcements)) {

  $counter++;

  if ($counter%2==0) {
    $backcolor="{firstaltcolor}";
  } else {
    $backcolor="{secondaltcolor}";
  }

  $post[startdate]=vbdate($dateformat,$post[startdate]);
  $post[enddate]=vbdate($dateformat,$post[enddate]);

  if ($post[startdate]>$bbuserinfo[lastvisit]) {
    $post[posticon]="<img src=\"{imagesfolder}/posticonnew.gif\" border=\"0\" alt=\"\">";
  } else {
    $post[posticon]="<img src=\"{imagesfolder}/posticon.gif\" border=\"0\" alt=\"\">";
  }

  if ($showonline) {
    unset($onlinestatus);
    if ($post[sessionuserid]>0) {
	   eval("\$onlinestatus = \"".gettemplate("postbit_online")."\";");
	 } else {
      eval("\$onlinestatus = \"".gettemplate("postbit_offline")."\";");
    }
  }

  if ($post[avatarid]!=0) {
  	 $avatarurl=$post[avatarpath];
  } else {
    if ($post[hascustomavatar] and $avatarenabled) {
      $avatarurl="avatar.php?userid=$post[userid]&dateline=$post[avatardateline]";
    } else {
  		$avatarurl="";
  	 }
  }
  if ($avatarurl=="") {
  	 $post[avatar]="";
  } else {
  	 eval("\$post[avatar] = \"".gettemplate("postbit_avatar")."\";");
  }

  if ($post[customtitle]==2)
    $post[usertitle] = htmlspecialchars($post[usertitle]);
  $post[joindate]=vbdate($registereddateformat,$post[joindate]);

  if ($post[showemail] and $displayemails) {
  	 eval("\$post[useremail] = \"".gettemplate("postbit_useremail")."\";");
  } else {
  	 $post[useremail]="";
  }

  if ($post[icq]!="") {
     $userinfo[icq] = $post[icq];
  	 eval("\$post[icqicon] = \"".gettemplate("icq")."\";");
  } else {
  	 $post[icq]="";
  }
  if ($post[aim]!="") {
     $userinfo[aim] = $post[aim];
  	 eval("\$post[aimicon] = \"".gettemplate("aim")."\";");
  } else {
  	 $post[aim]="";
  }
  if ($post[yahoo]!="") {
     $userinfo[yahoo] = $post[yahoo];
  	 eval("\$post[yahooicon] = \"".gettemplate("yahoo")."\";");
  } else {
  	 $post[yahoo]="";
  }

  if ($post[homepage]!="" and $post[homepage]!="http://") {
  	 eval("\$post[homepage] = \"".gettemplate("postbit_homepage")."\";");
  } else {
  	 $post[homepage]="";
  }

  if ($post[receivepm]) {
  	 eval("\$post[pmlink] = \"".gettemplate("postbit_sendpm")."\";");
  } else {
  	 $post[pmlink] = "";
  }

  eval("\$post[profile] = \"".gettemplate("postbit_profile")."\";");

  $message = $post[pagetext];

  eval("\$announcebits .= \"".gettemplate("announcebit")."\";");

}

$announcecount=$counter;

eval("dooutput(\"".gettemplate("announcement")."\");");

?>