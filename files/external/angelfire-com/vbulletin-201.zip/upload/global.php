<?php
if (isset($explain)) {
  $showqueries=1;
}
if (isset($showqueries)) {
  $pagestarttime=microtime();
}

// get rid of slashes in get / post / cookie data
function stripslashesarray (&$arr) {
  while (list($key,$val)=each($arr)) {
    if ((strtoupper($key)!=$key or "".intval($key)=="$key") and $key!="templatesused" and $key!="argc" and $key!="argv") {
			if (is_string($val)) {
				$arr[$key]=stripslashes($val);
			}
			if (is_array($val)) {
				$arr[$key]=stripslashesarray($val);
			}
	  }
  }
  return $arr;
}
if (get_magic_quotes_gpc() and is_array($GLOBALS)) {
  $GLOBALS=stripslashesarray($GLOBALS);
}

set_magic_quotes_runtime(0);

@error_reporting(7);

// get useful vars
$ipaddress=$REMOTE_ADDR;
$scriptpath=$REQUEST_URI;
if ($scriptpath=='') {
  if ($PATH_INFO) {
    $scriptpath = $PATH_INFO;
  } else {
    $scriptpath = $PHP_SELF;
  }
  
  if ($QUERY_STRING) {
    $scriptpath .= '?'.addslashes($QUERY_STRING);
  }
}

if ( !isset($url) ) {
  $url=getenv('HTTP_REFERER');
} else {
  if ($url==getenv('HTTP_REFERER')) {
    $url='index.php';
  }
}
if ($url==$scriptpath or $url=='') {
  $url='index.php';
}
$url = addslashes($url);

if ($HTTP_GET_VARS['HTTP_POST_VARS']['action'] == $HTTP_POST_VARS['action']) {
  unset($HTTP_POST_VARS['action']);
}
$HTTP_POST_VARS['action'] = trim($HTTP_POST_VARS['action']);


// ###################### Start init #######################
//load config
require('./admin/config.php');

// init db **********************
// load db class
$dbclassname="./admin/db_$dbservertype.php";
require($dbclassname);

$DB_site=new DB_Sql_vb;

$DB_site->appname='vBulletin';
$DB_site->appshortname='vBulletin (forum)';
$DB_site->database=$dbname;
$DB_site->server=$servername;
$DB_site->user=$dbusername;
$DB_site->password=$dbpassword;

$DB_site->connect();

$dbpassword="";
$DB_site->password="";
// end init db

if ( isset($showqueries) ) {
  echo "<pre>";
}

// ###################### Start functions #######################
require('./admin/functions.php');

// ###################### Start load options #######################
$optionstemp=$DB_site->query_first("SELECT template FROM template WHERE title='options'");
eval($optionstemp['template']);
$versionnumber=$templateversion;

// ###################### Start headers #######################
if ($addheaders and !$noheader) {
  // default headers
  @header("HTTP/1.0 200 OK");
  @header("HTTP/1.1 200 OK");
  @header("Content-type: text/html");
}

if ($nocacheheaders and !$noheader) {
  // no caching
  @header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");             // Date in the past
  @header("Last-Modified: " . gmdate("D, d M Y H:i:s") . "GMT"); // always modified
  @header("Cache-Control: no-cache, must-revalidate");           // HTTP/1.1
  @header("Pragma: no-cache");                                   // HTTP/1.0
}


// ###################### Start sessions #######################
$servertoobusy=0;
if ($loadlimit>0) {
  $path='/proc/loadavg';

  if(file_exists($path)) {
    $filesize=filesize($path);
    $filenum=fopen($path,'r');
    $filestuff=@fread($filenum,6);
    fclose($filenum);
  }

  $loadavg=explode(' ',$filestuff);
  if (trim($loadavg[0])>$loadlimit) {
    $servertoobusy=1;
  }
}

if (!$servertoobusy) {
  require('./admin/sessions.php');
}

// figure out the chosen style settings

//get some ids!
if (isset($postid)) {
  $postid=verifyid('post',$postid,0);
  if ($postid!=0) {
    $getthread=$DB_site->query_first("SELECT threadid FROM post WHERE postid='$postid'");
    $threadid=$getthread[threadid];
  }
}
if (isset($threadid) and $thread=verifyid("thread",$threadid,0,1)) {
  $threadid = $thread['threadid'];
  if ($threadid!=0) {
    $getforum=$DB_site->query_first("SELECT forum.forumid,styleid,styleoverride FROM forum,thread WHERE forum.forumid=thread.forumid AND threadid='$threadid'");
    if ($getforum[styleoverride]==1 or $bbuserinfo[styleid]==1) {
      $codestyleid=$getforum[styleid];
    }
  }
}
if (isset($forumid) and !isset($codestyleid)) {
  $getforum=verifyid('forum',$forumid,0,1);
  if ($getforum[styleoverride]==1 or $bbuserinfo[styleid]==1) {
    $codestyleid=$getforum[styleid];
  }
}
if (isset($pollid) and !isset($codestyleid)) {
  $getforum=$DB_site->query_first("SELECT forum.forumid,styleid,styleoverride FROM forum,thread WHERE forum.forumid=thread.forumid AND pollid='$pollid'");
  if ($getforum[styleoverride]==1 or $bbuserinfo[styleid]==1) {
    $codestyleid=$getforum[styleid];
  }
}

// is style in the forum/thread set?
if (isset($codestyleid) and $codestyleid!=0) {
  $styleid=$codestyleid;
} else {

  // Will look in the user info for a style
  if ($bbuserinfo['styleid']!=0) { //style specified
    $styleid=$bbuserinfo['styleid'];
  } else { //no style
    $styleid=1;
  }

  if ($style=$DB_site->query_first("SELECT templatesetid,replacementsetid,userselect FROM style WHERE styleid='$styleid'")) {
    if (!$style['userselect']) {
      unset($style);
      $styleid=1;
    }
  } else {
    unset($style);
    $styleid=1;
  }
}

if (!isset($style)) {
  $style=$DB_site->query_first("SELECT templatesetid,replacementsetid,userselect FROM style WHERE styleid='$styleid' or styleid=1 ORDER BY styleid DESC");
}
//get template set and replacement set details
$templatesetid=$style['templatesetid'];
$replacementsetid=$style['replacementsetid'];

// ###################### Referrer Stuff #########################

// Referer stuff
if ($bbuserinfo['userid']==0 and $usereferrer and !$bbreferrerid and $referrerid) {
  if ($r_id = $DB_site->query_first("SELECT userid FROM user WHERE userid = '".addslashes($referrerid)."'")) {
    vbsetcookie("bbreferrerid",$r_id[userid]);
  }
}

// ###################### Start templates #######################
//prepare default templates **********************
if ($templatesused!='') {
  $templatesused.=',';
}
$templatesused.='timezone,username_loggedout,username_loggedin,phpinclude,headinclude,header,footer,forumjumpbit,forumjump,nav_linkoff,nav_linkon,navbar,nav_joiner';
unset($templatecache);
cachetemplates($templatesused);

$newpmmsg=0;
$headnewpm='';
if ($checknewpm and $bbuserinfo['userid']!=0 and $bbuserinfo['pmpopup']==2) {
  if ($noshutdownfunc) {
    $DB_site->query("UPDATE user SET pmpopup=1 WHERE userid=$bbuserinfo[userid]");
  } else {
    $shutdownqueries[]="UPDATE LOW_PRIORITY user SET pmpopup=1 WHERE userid=$bbuserinfo[userid]";
  }
  $newpmmsg=1;
  eval("\$headnewpm = \"".gettemplate('head_newpm')."\";");
}

$header='';
$footer='';

// parse header ##################
eval(gettemplate('phpinclude',0,0));

// parse css ################## not really needed!
eval("\$headinclude = \"".gettemplate('headinclude')."\";");

if (!$header) {
  eval("\$header = \"".gettemplate('header')."\";");
} else {
  eval("\$header .= \"".gettemplate('header')."\";");
}

if (!$footer) {
  eval("\$footer = \"".gettemplate('footer')."\";");
} else {
  eval("\$footer .= \"".gettemplate('footer')."\";");
}

if ($url=="") {
  $url=getenv('HTTP_REFERER');
}

$timediff='';
if ($bbuserinfo['timezoneoffset']!=0) {
  $timediff=" $bbuserinfo[timezoneoffset] hours";
}

$timenow=vbdate($timeformat,time());

eval("\$timezone = \"".gettemplate('timezone')."\";");

// end prepare default templates ********************

// check to see if server is too busy. this is checked at the end of session.php
if ($servertoobusy) {
  eval("standarderror(\"".gettemplate('error_toobusy')."\");");
  exit;
}

// check that board is active - if not admin, then display error
if (!$bbactive) {
  $permissions=getpermissions();
  if (!$permissions[cancontrolpanel]) {
    eval("standarderror(\"".str_replace("\'", "'", addslashes($bbclosedreason))."\");");
    exit;
  }

}

$PHP_SELF = strtolower($PHP_SELF);
if (substr($PHP_SELF,-strlen('register.php'))!='register.php' and substr($PHP_SELF,-strlen('member.php'))!='member.php') {
  $permissions=getpermissions();
  if (!$permissions['canview']) {
    show_nopermission();
  }
} else {
  if ($action!="register" and $action!="signup" and $action!="activate" and $action!="login" and $action!="logout" and $action!="lostpw" and $action!="emailpassword" and $action!="addmember" and $action!="coppaform" and $a!="act" and $a!="ver") {
    $permissions=getpermissions();
    if (!$permissions['canview']) {
  		show_nopermission();
    }
  }
}

checkipban();
$logincode=makelogincode();

?>