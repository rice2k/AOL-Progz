<?php
error_reporting(7);
if ( isset($goto) and ($goto=='lastpost' or $goto=='newpost')) {
  $noheader=1;
}

$templatesused='showthread_adminoptions,showthread_threadrate,postbit_search,postbit_buddy,postbit_useremail,icq,aim,yahoo,postbit_homepage,postbit_profile,postbit_ip_show,postbit_ip_hidden,postbit,numbernav_pages,numbernav,showthread_firstunread,showthread_nextnewestthread,showthread_nextoldestthread,forumrules,showthread,postbit_sendpm,postbit_avatar,postbit_offline,postbit_online,postbit_editedby,postbit_signature,showthread_pollresults_voted,showthread_pollresults_closed,postbit_attachment,postbit_attachmentimage';
// REMOVED FROM PRECACHING: error_invalidid,error_nopermission,

require('./global.php');

// oldest first or newest first
if ($postorder==0) {
  $postorder="";
} else {
  $postorder="DESC";
}

// goto last post
if ($goto=="lastpost") {
  if (isset($threadid) and $threadid!=0) {
    $threadid = verifyid("thread",$threadid);

    if ($getlastpost=$DB_site->query_first("SELECT postid,post.dateline FROM post,thread WHERE post.threadid=thread.threadid AND thread.threadid='$threadid' AND post.visible=1 AND thread.visible=1 ORDER BY post.dateline DESC LIMIT 1")) {
      header("Location: showthread.php?s=$session[sessionhash]&postid=$getlastpost[postid]#post$getlastpost[postid]");
      exit;
    }
  }
  if (isset($forumid) and $forumid!=0) {
    $foruminfo=verifyid("forum",$forumid,1,1);
    $forumid=$foruminfo['forumid'];

		$getchildforums=$DB_site->query("SELECT forumid,parentlist FROM forum WHERE INSTR(CONCAT(',',parentlist,','),',$forumid,')>0");
		while ($getchildforum=$DB_site->fetch_array($getchildforums)) {
			if ($getchildforum[forumid]==$forumid) {
				$parentlist=$getchildforum[parentlist];
			}
			$forumslist.=",$getchildforum[forumid]";
		}

    $thread=$DB_site->query_first("SELECT threadid FROM thread WHERE forumid IN (0$forumslist) AND visible=1 AND (sticky=1 OR sticky=0) AND lastpost>='".($foruminfo[lastpost]-30)."' AND open<>10 ORDER BY lastpost DESC LIMIT 1");

    if ($getlastpost=$DB_site->query_first("SELECT postid FROM post WHERE threadid='$thread[threadid]' AND visible=1 ORDER BY postid DESC LIMIT 1")) {
      header("Location: showthread.php?s=$session[sessionhash]&postid=$getlastpost[postid]#post$getlastpost[postid]");
      exit;
    }
  }
}

// goto newest post
if ($goto=="newpost") {
  $threadid = verifyid("thread",$threadid);

  if ($posts=$DB_site->query_first("SELECT postid,dateline FROM post WHERE post.threadid=$threadid AND post.visible=1 AND post.dateline>'$bbuserinfo[lastvisit]' ORDER BY dateline LIMIT 1")) {
    header("Location: showthread.php?s=$session[sessionhash]&postid=$posts[postid]#post$posts[postid]");
    exit;
  } else {
    header("Location: showthread.php?s=$session[sessionhash]&threadid=$threadid&goto=lastpost");
    exit;
  }
}

if ($goto=="nextnewest") {
  $thread = verifyid("thread",$threadid,1,1);
  if ($getnextnewest=$DB_site->query_first("SELECT threadid
                                          FROM thread
                                          WHERE forumid='$thread[forumid]'
                                            AND lastpost>'$thread[lastpost]'
                                            AND visible=1
                                            AND open<>10
                                          ORDER BY lastpost LIMIT 1")) {
    $threadid=$getnextnewest[threadid];
    unset ($thread);
  } else {
    eval("standarderror(\"".gettemplate("error_nonextnewest")."\");");
  }
}

if ($goto=="nextoldest") {
  $thread = verifyid("thread",$threadid,1,1);
	if ($getnextoldest=$DB_site->query_first("SELECT threadid
																						FROM thread
																						WHERE forumid='$thread[forumid]'
																							AND lastpost<'$thread[lastpost]'
																							AND visible=1
																							AND open<>10
																						ORDER BY lastpost DESC LIMIT 1")) {
		$threadid=$getnextoldest[threadid];
		unset($thread);
	} else {
    eval("standarderror(\"".gettemplate("error_nonextoldest")."\");");
	}
}

if (!isset($perpage)) {
	if ($bbuserinfo[maxposts]!=-1 and $bbuserinfo[maxposts]!=0)
	{
		$perpage = $bbuserinfo[maxposts];
	} else {
		$perpage=$maxposts;
	}
}

if (isset($postid) and $postid!=0 and $postid!="") {
  $postid = verifyid("post",$postid);

  $getthread=$DB_site->query_first("SELECT threadid FROM post WHERE postid='$postid'");
  $threadid=$getthread[threadid];

  if (!$postorder) {
    $getpagenum=$DB_site->query_first("SELECT COUNT(*) AS posts FROM post WHERE threadid='$threadid' AND postid<='$postid'");
    if ($getpagenum[posts]%$perpage==0) {
      $pagenumber=$getpagenum[posts]/$perpage;
    } else {
      $pagenumber=intval($getpagenum[posts]/$perpage)+1;
    }
  } else {
    $getpagenum=$DB_site->query_first("SELECT COUNT(*) AS posts FROM post WHERE threadid='$threadid' AND postid>='$postid'");
    if ($getpagenum[posts]%$perpage==0) {
      $pagenumber=$getpagenum[posts]/$perpage;
    } else {
      $pagenumber=intval($getpagenum[posts]/$perpage)+1;
    }
  }
}

$threadid = intval($threadid);
$thread = verifyid("thread",$threadid,1,1);

if ($wordwrap!=0) {
  $thread['title']=dowordwrap($thread['title']);
}

if (!$thread['visible']) {
  $idname="thread";
  eval("standarderror(\"".gettemplate("error_invalidid")."\");");
  exit;
}

$forum=getforuminfo($thread['forumid']);

$getperms=getpermissions($thread['forumid'],-1,-1,$foruminfo['parentlist']);
if (!$getperms['canview']) {
  show_nopermission();
}
if (!$getperms['canviewothers'] and $thread['postuserid']!=$bbuserinfo['userid']) {
  show_nopermission();
}

if ((!isset($pagenumber) or $pagenumber==0) and $pagenumber!="lastpage") {
  $pagenumber=1;
}

if ($noshutdownfunc) {
  $DB_site->query("UPDATE thread SET views=views+1 WHERE threadid='$threadid'");
} else {
  $shutdownqueries[]="UPDATE LOW_PRIORITY thread SET views=views+1 WHERE threadid='$threadid'";
}

if ($bbuserinfo[cookieuser]) {
  vbsetcookie("bbthreadview[$threadid]",time(),0);
}

// words to highlight from the search engine
if (isset($highlight)) {
  $highlight=urldecode($highlight);
  $highlightwords=explode(" ",str_replace("/","\/",quotemeta($highlight)));
  while (list($key,$val)=each($highlightwords)) {
    $val = strtolower($val);
    if ($val=='or' OR $val=='and' OR $val=='not') {
      continue;
    }
    if ($allowwildcards) {
      $val = str_replace("\*", "[a-zA-z]+", $val);
    }
    $replacewords[$key]="$val";
  }
}
// draw nav bar
$navbar=makenavbar($threadid,"thread",0);

$curforumid = $thread['forumid'];

makeforumjump();

if ($thread[pollid]) {
  $pollid=$thread[pollid];
  $pollinfo=$DB_site->query_first("SELECT * FROM poll WHERE pollid='$pollid'");

  $pollinfo[question]=bbcodeparse($pollinfo[question],$forum[forumid],1);

  $splitoptions=explode("|||", $pollinfo[options]);
  $splitvotes=explode("|||",$pollinfo[votes]);

  $showresults=0;

  if (!$pollinfo[active] or !$thread[open] or ($pollinfo[dateline]+($pollinfo[timeout]*86400)<time() and $pollinfo[timeout]!=0)){
    //thread/poll is closed, ie show results no matter what
    $showresults=1;
  } else {
    //get userid, check if user already voted
    if ($uservote=$DB_site->query_first("SELECT pollvoteid FROM pollvote WHERE userid='$bbuserinfo[userid]' AND pollid=$pollid")) {
      $uservoted=1;
    }
  }

  $counter=0;
  while ($counter++<$pollinfo[numberoptions]) {
    $pollinfo[numbervotes]+=$splitvotes[$counter-1];
  }

  $counter=0;
  $pollbits="";

  while ($counter++<$pollinfo[numberoptions]) {
    $option[question] = bbcodeparse($splitoptions[$counter-1],$forum[forumid],1);
    $option[votes] = $splitvotes[$counter-1];  //get the vote count for the option
    $option[number] = $counter;  //number of the option

    //Now we check if the user has voted or not
    if ($showresults or $uservoted) { // user did vote or poll is closed

      if ($option[votes] == 0){
        $option[percent]=0;
      } else{
        $option[percent] = number_format($option[votes]/$pollinfo[numbervotes]*100,2);
      }

      $option[graphicnumber]=$option[number]%6 + 1;
      $option[barnumber] = round($option[percent])*2;
      if ($showresults) {
         eval("\$pollstatus = \"".gettemplate("showthread_pollresults_closed")."\";");
      } elseif ($uservoted) {
         eval("\$pollstatus = \"".gettemplate("showthread_pollresults_voted")."\";");
      }
      eval("\$pollbits .= \"".gettemplate("pollresult")."\";");
    } else {
      eval("\$pollbits .= \"".gettemplate("polloption")."\";");
    }
  }

  if ($showresults or $uservoted) {
    eval("\$poll = \"".gettemplate("showthread_pollresults")."\";");
  } else {
    eval("\$poll .= \"".gettemplate("showthread_polloptions")."\";");
  }
} else {
  $poll="";
}

$bbcodeon=iif($forum[allowbbcode],$ontext,$offtext);
$imgcodeon=iif($forum[allowimages],$ontext,$offtext);
$htmlcodeon=iif($forum[allowhtml],$ontext,$offtext);
$smilieson=iif($forum[allowsmilies],$ontext,$offtext);

$limitlower=($pagenumber-1)*$perpage+1;
$limitupper=($pagenumber)*$perpage;

$counter=0;

if (trim($bbuserinfo[ignorelist])!="") {
  $ignoreusers='AND post.userid<>'.implode(' AND post.userid<>',explode(' ',$bbuserinfo[ignorelist]));
} else {
  $ignoreusers="";
}

$datecut = time() - $cookietimeout;
$postscount=$DB_site->query_first("SELECT COUNT(*) AS posts FROM post WHERE post.threadid='$threadid' AND post.visible=1 $ignoreusers");

$totalposts=$postscount[posts];

$getpostids=$DB_site->query("
SELECT
post.postid
FROM
post
WHERE
post.threadid='$threadid' AND post.visible=1 $ignoreusers
ORDER BY dateline $postorder
LIMIT ".($limitlower-1).",$perpage
");

if ($limitupper>$totalposts) {
  $limitupper=$totalposts;
  if ($limitlower>$totalposts) {
    $limitlower=$totalposts-$perpage;
  }
}
if ($limitlower<=0) {
  $limitlower=1;
}
$postids="post.postid IN (0";
while ($post=$DB_site->fetch_array($getpostids)) {
  $postids.=",".$post[postid];
}
$postids.=")";

$posts=$DB_site->query("
SELECT
".iif ($showonline,"session.userid AS sessionuserid,","")."
post.*,post.username AS postusername,post.ipaddress AS ip,user.*,userfield.*,".iif($forum[allowicons],'icon.title as icontitle,icon.iconpath,','')."
attachment.attachmentid,attachment.filename,attachment.visible AS attachmentvisible,attachment.counter
".iif($avatarenabled,",avatar.avatarpath,NOT ISNULL(customavatar.avatardata) AS hascustomavatar,customavatar.dateline AS avatardateline","")."
FROM
post
".iif($forum[allowicons],'LEFT JOIN icon ON icon.iconid=post.iconid','')."
LEFT JOIN user ON user.userid=post.userid
LEFT JOIN userfield ON userfield.userid=user.userid
".iif ($avatarenabled,"LEFT JOIN avatar ON avatar.avatarid=user.avatarid
                       LEFT JOIN customavatar ON customavatar.userid=user.userid","")."
LEFT JOIN attachment ON attachment.attachmentid=post.attachmentid
".iif( $showonline,"LEFT JOIN session ON (session.userid = user.userid
                                            AND session.userid > 0
                                            ".iif($bbuserinfo['usergroupid']!=6,"AND user.invisible = 0","")."
                                            AND session.lastactivity>$datecut)","")."
WHERE
$postids
ORDER BY dateline $postorder
");


$counter=0;
while ($post=$DB_site->fetch_array($posts) and $counter++<$perpage) {

  if ($postdone[$post[postid]]) {
    $counter--;
    continue;
  } else {
    $postdone[$post[postid]]=1;
  }

  if ($counter%2==0) {
    $post[backcolor]="{firstaltcolor}";
  } else {
    $post[backcolor]="{secondaltcolor}";
  }

  // find first new post
  if (isset($bbuserinfo[lastvisit])) {
    if ($post[dateline]>$bbuserinfo[lastvisit] and $firstnew==0) {
      $firstnew=1;
      $post[firstnewinsert]="<a name=\"newpost\"></a>";
    } else {
      $post[firstnewinsert]="";
    }
  }

  $post[postdate]=vbdate($dateformat,$post[dateline]);
  $post[posttime]=vbdate($timeformat,$post[dateline]);

  if ($wordwrap!=0) {
    $post[title]=dowordwrap($post[title]);
  }

  if ($post[attachmentid]!=0 and $post[attachmentvisible])
  {
    $post[attachmentextension]=strtolower(getextension($post[filename]));
    if ($post[attachmentextension]=="gif" or $post[attachmentextension]=="jpg" or $post[attachmentextension]=="jpeg" or $post[attachmentextension]=="jpe" or $post[attachmentextension]=="png") {
      if (($viewattachedimages) and ($bbuserinfo[userid]==0 or $bbuserinfo[showimages])) {
        eval("\$post[attachment] = \"".gettemplate("postbit_attachmentimage")."\";");
      } else {
        eval("\$post[attachment] = \"".gettemplate("postbit_attachment")."\";");
      }
    } else {
      eval("\$post[attachment] = \"".gettemplate("postbit_attachment")."\";");
    }
  } else {
    $post[attachment]="";
  }

  if ($post[edituserid]!=0) {
    if ($post['edituserid']!=$post['userid']) {
      $edituser=getuserinfo($post[edituserid]);
    } else {
      $edituser = $post;
    }
    $post[edittime]=vbdate($timeformat,$post[editdate]);
    $post[editdate]=vbdate($dateformat,$post[editdate]);
    eval("\$post[editedby] = \"".gettemplate("postbit_editedby")."\";");
  } else {
    $post[editedby]="";
  }

  if ($post[dateline]>$bbuserinfo[lastvisit]) {
    $post[foldericon]="<img src=\"{imagesfolder}/posticonnew.gif\" border=\"0\" alt=\"New Post\">";
  } else {
    $post[foldericon]="<img src=\"{imagesfolder}/posticon.gif\" border=\"0\" alt=\"Old Post\">";
  }
  if (!$forum[allowicons] or $post[iconid]==0) {
    if ($showdeficon) {
      $post[icon]='<img src="{imagesfolder}/icons/icon1.gif" border="0" alt="">';
    }
  } else {
  	/*
    unset ($iconwidth);
    unset($iconheight);
    $imginfo=@getimagesize($post[iconpath]);
    if ($imginfo[2]==1 or $imginfo[2]==2) { // We have a .gif or .jpg
       $iconwidth = "width=\"$imginfo[0]\"";
       $iconheight = "height=\"$imginfo[1]\"";
    }
	*/
    $post[icon]="<img src=\"$post[iconpath]\" alt=\"$post[icontitle]\" border=\"0\">";
  }

  if ($post[userid]!=0) {
    if ($showonline) {
       unset($onlinestatus);
       if ($post[sessionuserid]>0) {
          eval("\$onlinestatus = \"".gettemplate("postbit_online")."\";");
       } else {
          eval("\$onlinestatus = \"".gettemplate("postbit_offline")."\";");
       }
    }
    if ($post[avatarid]!=0) {
      $avatarurl=$post[avatarpath];
    } else {
      if ($post[hascustomavatar] and $avatarenabled) {
        $avatarurl="avatar.php?userid=$post[userid]&dateline=$post[avatardateline]";
      } else {
        $avatarurl="";
      }
    }
    if ($avatarurl=="" or ($bbuserinfo[userid]>0 and !($bbuserinfo[showavatars]))) {
      $post[avatar]="";
    } else {
      eval("\$post[avatar] = \"".gettemplate("postbit_avatar")."\";");
    }
    if ($post[customtitle]==2)
      $post[usertitle] = htmlspecialchars($post[usertitle]);
    $jointime = (time() - $post[joindate]) / 86400; // Days Joined
    if ($jointime < 1) { // User has been a member for less than one day.
      $postsperday = "$post[posts]";
    } else {
      $postsperday = sprintf("%.2f",($post[posts] / $jointime));
    }

    $post[joindate]=vbdate($registereddateformat,$post[joindate]);

    if ($post[showemail] and $displayemails) {
      eval("\$post[useremail] = \"".gettemplate("postbit_useremail")."\";");
    } else {
      $post[useremail]="";
    }
    $userinfo=$post;
    if ($post[icq]!="") {
      eval("\$post[icqicon] = \"".gettemplate("icq")."\";");
    } else {
      $post[icq]="";
    }
    if ($post[aim]!="") {
      eval("\$post[aimicon] = \"".gettemplate("aim")."\";");
    } else {
      $post[aim]="";
    }
    if ($post[yahoo]!="") {
      eval("\$post[yahooicon] = \"".gettemplate("yahoo")."\";");
    } else {
      $post[yahoo]="";
    }

    if ($post[homepage]!="" and $post[homepage]!="http://") {
      eval("\$post[homepage] = \"".gettemplate("postbit_homepage")."\";");
    } else {
      $post[homepage]="";
    }

    if ($post['receivepm'] and $enablepms==1) {
      eval("\$post[pmlink] = \"".gettemplate("postbit_sendpm")."\";");
    } else {
      $post[pmlink] = "";
    }

    eval("\$post[profile] = \"".gettemplate("postbit_profile")."\";");
    eval("\$post[search] = \"".gettemplate("postbit_search")."\";");
    eval("\$post[buddy] = \"".gettemplate("postbit_buddy")."\";");

    if ($post[showsignature] and $allowsignatures and trim($post[signature])!="" and ($bbuserinfo[userid]==0 or $bbuserinfo[showsignatures])) {
      if (!isset($sigcache["$post[userid]"])) {
        $post[signature]=bbcodeparse($post[signature],0,$allowsmilies);
        eval("\$post[signature] = \"".gettemplate("postbit_signature")."\";");
        $sigcache["$post[userid]"] = $post[signature];
      } else {
        $post[signature] = $sigcache["$post[userid]"];
      }
    } else {
      $post[signature] = "";
    }
  } else {
    $postsperday=0;
    $post[username]=$post[postusername];
    $post[usertitle]="Guest";
    $post[joindate]="Not Yet";
    $post[posts]="N/A";

    $post[avatar]="";
    $post[profile]="";
    $post[email]="";
    $post[useremail]="";
    $post[icqicon]="";
    $post[aimicon]="";
    $post[yahooicon]="";
    $post[homepage]="";
    $post[findposts]="";
    $post[signature]="";
    $onlinestatus="";
  }

  if ($post[ip]!="") {
    if ($logip==2) {
      eval("\$post[iplogged] .= \"".gettemplate("postbit_ip_show")."\";");
    }
    if ($logip==1) {
      eval("\$post[iplogged] .= \"".gettemplate("postbit_ip_hidden")."\";");
    }
    if ($logip==0) {
      $post[iplogged]="";
    }
  } else {
    $post[iplogged]="";
  }

  $post[message]=bbcodeparse($post[pagetext],$forum[forumid],$post[allowsmilie]);

  //highlight words for search engine
  if (isset($highlight)) {
    if ((isset($postid) and $postid==$post[postid]) or !isset($postid)) {
      reset($replacewords);
		while (list($key,$val)=each($replacewords)) {
		  $post['message']=preg_replace("/(^| |\n|\r|\t|\]|>|\")(".$val.")(([\.,]+[ $\n\r\t])|$|\"|<|\[| |\n|\r|\t)/si", "\\1<highlight>\\2</highlight>\\3", $post['message']);
		}
    }
  }

  //$post[message].=$post[signature];

  eval("\$postbits .= \"".gettemplate("postbit")."\";");

}

if ($totalposts>$perpage) {

  $totalpages=$totalposts/$perpage;
  if ($totalpages!=intval($totalpages)) {
    $totalpages=intval($totalpages)+1;
  }
  if ($pagenumber=="lastpage") {
    $pagenumber=$totalpages;
  }

  $shorturl="showthread.php?s=$session[sessionhash]&threadid=$threadid&perpage=$perpage";

  if ($pagenumber==1) {
    $firstpage_atag="";
    $prevpage_atag="";
  } else {
    $endfirstprevtag = '</smallfont></a>';
    $firstpage_atag="<a href=\"$shorturl&pagenumber=1\" class=\"thtcolor\"><smallfont color=\"{tableheadtextcolor}\">";
    $prevpage_atag="<a href=\"$shorturl&pagenumber=".($pagenumber-1)."\" class=\"thtcolor\"><smallfont color=\"{tableheadtextcolor}\">";
  }
  if ($pagenumber==$totalpages) {
    $lastpage_atag="";
    $nextpage_atag="";
  } else {
    $endlastnexttag = '</smallfont></a>';
    $lastpage_atag="<a href=\"$shorturl&pagenumber=$totalpages\" class=\"thtcolor\"><smallfont color=\"{tableheadtextcolor}\">";
    $nextpage_atag="<a href=\"$shorturl&pagenumber=".($pagenumber+1)."\" class=\"thtcolor\"><smallfont color=\"{tableheadtextcolor}\">";
  }

  $curpage=0;
  $pagenumbers="";
  while ($curpage++<$totalpages) {
    if (($curpage>$pagenumber-$pagenavpages and $curpage<$pagenumber+$pagenavpages) or $pagenavpages==0) {
      if ($curpage==$pagenumber) {
        $numbernav_atag="";
        $endpagetag = '';
        eval("\$pagenumbers .= \"".gettemplate("numbernav_pages")."\";");
      } else {
        $numbernav_atag="<a href=\"$shorturl&pagenumber=$curpage\" class=\"thtcolor\"><smallfont color=\"{tableheadtextcolor}\">";
        $endpagetag = '</smallfont></a>';
        eval("\$pagenumbers .= \"".gettemplate("numbernav_pages")."\";");
      }
    }
  }
  eval("\$pagenav = \"".gettemplate("numbernav")."\";");

} else {

  $pagenav="";
  if ($pagenumber=="lastpage") {
    $pagenumber=1;
  }

}

if ($thread[lastpost]>$bbuserinfo[lastvisit]) {
  // do blue arrow link

	if ($firstnew) {
		$newpostlink="#newpost";
	} else {
		$newpostlink="showthread.php?s=$session[sessionhash]&threadid=$threadid&goto=newpost";
	}

  eval("\$firstunread = \"".gettemplate("showthread_firstunread")."\";");

} else {
  $firstunread="";
}
$DB_site->free_result($posts);
unset($post);
unset($sigcache); //don't need the signature cache anymore

if ($thread[open]) {
  $replyclose="{replyimage}";
} else {
  $replyclose="{closedthreadimage}";
}

if ($forum[allowratings]) {
  eval("\$threadrateselect = \"".gettemplate("showthread_threadrate")."\";");
} else {
  $threadrateselect = "&nbsp;";
}

if (ismoderator($forumid) or $getperms['canopenclose'] or $getperms['candeletethread'] or $getperms['canmove']) {
	eval("\$adminoptions = \"".gettemplate("showthread_adminoptions")."\";");
} else {
	$adminoptions = "&nbsp;";
}

getforumrules($forum,$getperms);
eval("dooutput(\"".gettemplate("showthread")."\");");

?>