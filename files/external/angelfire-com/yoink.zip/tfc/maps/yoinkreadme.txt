**********************************************************
Map: yoink
Bsp name: yoink.bsp
Map Author: Noodlehammer
e-mail: thecrippler65@yahoo.com :e-mail me if you would like foxbot watpoints
**********************************************************
Installation: Extract the zip files to your Halflife directory.

**********************************************************
Description:  Pure chaos. This is a 2 team map where you get the ball 
from the basement and bring it back to the ramp room. Then you must 
go through the hole in the wall in the elevator or jump over the edge 
of the rampway. Then go through the teleporter to the capture area. 
Its best to crouch+walk under the laser on the far side.
There are two traps, one is gas near the elevator triggered in the
glass pit. The other is a trap door near the ball. It can be triggered
 from the room above and will suck anyone in the area in.
**********************************************************
Tools used: Wc 3.3
                       Merls build of Zoners tools
                       Wally
                       Gensurf
**********************************************************
Thanks to 2ezekill,mimicmaster and Mr.Yuk for testing. Big thanks to
 the DoE (www.gamedesign.net)for beta testing. Also to
 Mr. Yuk for help.
**********************************************************
More maps for tfc and HLDM at: http://www.angelfire.com/realm/noodlehammer