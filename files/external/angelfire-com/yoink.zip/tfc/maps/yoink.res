sprites/XBeam.spr
sound/yoink_beta2
maps/yoink.bsp
maps/yoink.txt
maps/yoink.res
maps/yoinkreadme.txt