VERSION 5.00
Begin VB.UserControl klotski 
   BackColor       =   &H00FFFFFF&
   ClientHeight    =   1125
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   1125
   ScaleHeight     =   1125
   ScaleWidth      =   1125
   Begin VB.Label lblShow 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "Webdings"
         Size            =   12
         Charset         =   2
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   285
      Index           =   4
      Left            =   10
      TabIndex        =   4
      Top             =   420
      Visible         =   0   'False
      Width           =   240
   End
   Begin VB.Label lblShow 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "Webdings"
         Size            =   12
         Charset         =   2
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   285
      Index           =   1
      Left            =   442
      TabIndex        =   3
      Top             =   10
      Visible         =   0   'False
      Width           =   240
   End
   Begin VB.Label lblShow 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "6"
      BeginProperty Font 
         Name            =   "Webdings"
         Size            =   12
         Charset         =   2
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   285
      Index           =   3
      Left            =   442
      TabIndex        =   2
      Top             =   775
      Visible         =   0   'False
      Width           =   240
   End
   Begin VB.Label lblShow 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "4"
      BeginProperty Font 
         Name            =   "Webdings"
         Size            =   12
         Charset         =   2
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   285
      Index           =   2
      Left            =   820
      TabIndex        =   1
      Top             =   420
      Visible         =   0   'False
      Width           =   240
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "1"
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   21.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   525
      Left            =   405
      TabIndex        =   0
      Top             =   300
      Width           =   315
   End
End
Attribute VB_Name = "klotski"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
'Default Property Values:
Const m_def_ShowArrows = 1
Const m_def_Show = 0
'Property Variables:
Dim m_ShowArrows As Boolean
Dim m_Show As Byte
'Event Declarations:
Event MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single) 'MappingInfo=UserControl,UserControl,-1,MouseDown
Attribute MouseDown.VB_Description = "Occurs when the user presses the mouse button while an object has the focus."
Event MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single) 'MappingInfo=UserControl,UserControl,-1,MouseUp
Attribute MouseUp.VB_Description = "Occurs when the user releases the mouse button while an object has the focus."
Event MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single) 'MappingInfo=UserControl,UserControl,-1,MouseMove
Attribute MouseMove.VB_Description = "Occurs when the user moves the mouse."
Event MoveDirection(Direction As Integer)

Private Sub lbl_Change()
lbl.Top = (UserControl.ScaleHeight - lbl.Height) / 2
lbl.Left = (UserControl.ScaleWidth - lbl.Width) / 2
End Sub

Private Sub lbl_Click()
If m_Show <> 0 Then RaiseEvent MoveDirection(CInt(m_Show))
End Sub

Private Sub lblShow_Click(Index As Integer)
  RaiseEvent MoveDirection(Index)
End Sub

Private Sub UserControl_Click()
If m_Show <> 0 Then RaiseEvent MoveDirection(CInt(m_Show))
End Sub

'Initialize Properties for User Control
Private Sub UserControl_InitProperties()
  m_Show = m_def_Show
  m_ShowArrows = m_def_ShowArrows
End Sub

'Load property values from storage
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
  UserControl.BackColor = PropBag.ReadProperty("BackColor", &HFFFFFF)
  lbl.ForeColor = PropBag.ReadProperty("ForeColor", &H80000012)
  Set lbl.Font = PropBag.ReadProperty("Font", Ambient.Font)
  lbl.Caption = PropBag.ReadProperty("Value", "1")
  m_Show = PropBag.ReadProperty("Show", m_def_Show)
  m_ShowArrows = PropBag.ReadProperty("ShowArrows", m_def_ShowArrows)
End Sub

Private Sub UserControl_Resize()
  With UserControl
lbl.Top = (.Height - lbl.Height) / 2
lbl.Left = (.Width - lbl.Width) / 2

lblShow(1).Left = (.Width - lblShow(1).Width) / 2: lblShow(3).Left = lblShow(1).Left
lblShow(2).Top = (.Height - lblShow(1).Height) / 2: lblShow(4).Top = lblShow(2).Top

lblShow(2).Left = .Width - 10 - lblShow(2).Width
lblShow(3).Top = .Height - 10 - lblShow(3).Height
'lblShow(4).Top = .ScaleHeight - 60 - lblShow(4).Height
'lblShow(3).Left = lblShow(2).Left: lblShow(3).Top = lblShow(4).Top
  End With
End Sub

'Write property values to storage
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)
  Call PropBag.WriteProperty("BackColor", UserControl.BackColor, &HFFFFFF)
  Call PropBag.WriteProperty("ForeColor", lbl.ForeColor, &H80000012)
  Call PropBag.WriteProperty("Font", lbl.Font, Ambient.Font)
  Call PropBag.WriteProperty("Value", lbl.Caption, "1")
  Call PropBag.WriteProperty("Show", m_Show, m_def_Show)
  Call PropBag.WriteProperty("ShowArrows", m_ShowArrows, m_def_ShowArrows)
End Sub

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,BackColor
Public Property Get BackColor() As OLE_COLOR
Attribute BackColor.VB_Description = "Returns/sets the background color used to display text and graphics in an object."
  BackColor = UserControl.BackColor
End Property

Public Property Let BackColor(ByVal New_BackColor As OLE_COLOR)
  UserControl.BackColor() = New_BackColor
  PropertyChanged "BackColor"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=lbl,lbl,-1,ForeColor
Public Property Get ForeColor() As OLE_COLOR
Attribute ForeColor.VB_Description = "Returns/sets the foreground color used to display text and graphics in an object."
  ForeColor = lbl.ForeColor
End Property

Public Property Let ForeColor(ByVal New_ForeColor As OLE_COLOR)
  lbl.ForeColor() = New_ForeColor
  lblShow(1).ForeColor = New_ForeColor
  lblShow(2).ForeColor = New_ForeColor
  lblShow(3).ForeColor = New_ForeColor
  lblShow(4).ForeColor = New_ForeColor
  PropertyChanged "ForeColor"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=lbl,lbl,-1,Font
Public Property Get Font() As Font
Attribute Font.VB_Description = "Returns a Font object."
Attribute Font.VB_UserMemId = -512
  Set Font = lbl.Font
End Property

Public Property Set Font(ByVal New_Font As Font)
  Set lbl.Font = New_Font
  UserControl_Resize
  PropertyChanged "Font"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=lbl,lbl,-1,Caption
Public Property Get Value() As String
Attribute Value.VB_Description = "Returns/sets the text displayed in an object's title bar or below an object's icon."
  Value = lbl.Caption
End Property

Public Property Let Value(ByVal New_Value As String)
  lbl.Caption() = New_Value
  PropertyChanged "Value"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=1,0,0,0
Public Property Get Show() As Byte
Attribute Show.VB_Description = "Which of the four directions to show (0=none)"
  Show = m_Show
End Property

Public Property Let Show(ByVal New_Show As Byte)
  m_Show = New_Show

  Dim i As Byte
  For i = 1 To 4
    If i = m_Show Then lblShow(i).Visible = ShowArrows Else lblShow(i).Visible = False
  Next
  
  PropertyChanged "Show"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=0,0,0,1
Public Property Get ShowArrows() As Boolean
Attribute ShowArrows.VB_Description = "Whether Arrows are shown or not"
  ShowArrows = m_ShowArrows
End Property

Public Property Let ShowArrows(ByVal New_ShowArrows As Boolean)
  m_ShowArrows = New_ShowArrows
  If m_Show <> 0 Then lblShow(m_Show).Visible = ShowArrows
  PropertyChanged "ShowArrows"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=5
Public Sub Refresh()
Attribute Refresh.VB_Description = "Forces a complete resize of a object."
  UserControl_Resize
End Sub

Private Sub UserControl_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
  RaiseEvent MouseDown(Button, Shift, X, Y)
End Sub

Private Sub UserControl_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
  RaiseEvent MouseUp(Button, Shift, X, Y)
End Sub

Private Sub UserControl_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
  RaiseEvent MouseMove(Button, Shift, X, Y)
End Sub

