VERSION 5.00
Begin VB.Form frmKlotski 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "KLOTSKI - the fun game"
   ClientHeight    =   5505
   ClientLeft      =   150
   ClientTop       =   435
   ClientWidth     =   11145
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "klotski.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5505
   ScaleWidth      =   11145
   StartUpPosition =   2  'CenterScreen
   Tag             =   "loading"
   Begin VB.PictureBox pic2 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   2500
      Left            =   8400
      ScaleHeight     =   2475
      ScaleWidth      =   2475
      TabIndex        =   8
      Top             =   240
      Width           =   2500
      Begin Klotskii.klotski kl 
         Height          =   500
         Index           =   1
         Left            =   0
         TabIndex        =   9
         Top             =   0
         Width           =   500
         _ExtentX        =   873
         _ExtentY        =   873
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   15.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ShowArrows      =   0   'False
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "Size and Level"
      Height          =   2500
      Left            =   5520
      TabIndex        =   5
      Top             =   240
      Width           =   2655
      Begin VB.ListBox lst 
         Height          =   1425
         Left            =   180
         Sorted          =   -1  'True
         TabIndex        =   7
         Top             =   960
         Width           =   2295
      End
      Begin VB.ListBox lstSize 
         Height          =   645
         Left            =   180
         TabIndex        =   6
         Top             =   240
         Width           =   2295
      End
   End
   Begin VB.Frame Frame2 
      Caption         =   "Top Scores"
      Height          =   1755
      Left            =   5520
      TabIndex        =   3
      Top             =   2880
      Width           =   5400
      Begin VB.ListBox lstTop 
         Height          =   1230
         Left            =   180
         TabIndex        =   4
         Top             =   300
         Width           =   5055
      End
   End
   Begin VB.PictureBox pic 
      Appearance      =   0  'Flat
      ForeColor       =   &H80000008&
      Height          =   5000
      Left            =   240
      ScaleHeight     =   4965
      ScaleWidth      =   4965
      TabIndex        =   1
      Top             =   240
      Width           =   5000
      Begin Klotskii.klotski klMain 
         Height          =   1000
         Index           =   1
         Left            =   0
         TabIndex        =   2
         Top             =   0
         Width           =   1000
         _ExtentX        =   1773
         _ExtentY        =   1773
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   21.75
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
      End
   End
   Begin VB.Timer tmr 
      Interval        =   500
      Left            =   5400
      Top             =   5160
   End
   Begin VB.Label lbl 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Time: 0 seconds"
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   5520
      TabIndex        =   0
      Top             =   4865
      Width           =   5400
      WordWrap        =   -1  'True
   End
   Begin VB.Menu menuGame 
      Caption         =   "&Game"
      Begin VB.Menu mnuNew 
         Caption         =   "&New Game"
         Shortcut        =   {F2}
      End
      Begin VB.Menu sg 
         Caption         =   "-"
      End
      Begin VB.Menu mnuSize 
         Caption         =   "&Small Coins"
         Index           =   1
         Shortcut        =   {F6}
      End
      Begin VB.Menu mnuSize 
         Caption         =   "&Medium Coins"
         Index           =   2
         Shortcut        =   {F7}
      End
      Begin VB.Menu mnuSize 
         Caption         =   "&Large Coins"
         Index           =   3
         Shortcut        =   {F8}
      End
      Begin VB.Menu sg2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuArrows 
         Caption         =   "Show &Arrows"
         Checked         =   -1  'True
         Shortcut        =   ^A
      End
      Begin VB.Menu mnuBold 
         Caption         =   "Bold Text"
         Checked         =   -1  'True
         Shortcut        =   ^B
      End
      Begin VB.Menu sg3 
         Caption         =   "-"
      End
      Begin VB.Menu mnuTopScores 
         Caption         =   "Show All Top Scores"
      End
      Begin VB.Menu sg4 
         Caption         =   "-"
      End
      Begin VB.Menu mnuExit 
         Caption         =   "E&xit"
         Shortcut        =   ^X
      End
   End
End
Attribute VB_Name = "frmKlotski"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim cnt As Byte, sid As Byte  'cnt=no of squares; sid^2=cnt

Dim Invisible As Integer

Dim Mov As Integer, tm As Date  'tm As Single,

Dim Invi(29) As Byte, Vals(29, 25) As Byte, solCnt(2) As Byte  'small

Dim ind As Integer 'the current answer frame that is selected (and being targetted)

Dim apComp As String, apProd As String

Private Sub Form_Load()
apComp = App.CompanyName: apProd = App.ProductName

'read solutions from text file
Dim fso As New FileSystemObject, fil As File, ts As TextStream
Dim lin As String, i As Byte, cnt As Byte, n As Byte

Set fil = fso.GetFile(App.Path & "\solutions.txt")
Set ts = fil.OpenAsTextStream(ForReading)

If ts.AtEndOfStream = False Then ts.ReadLine
If ts.AtEndOfStream = False Then ts.ReadLine

i = 0
Do Until ts.AtEndOfStream
  lin = ts.ReadLine
  If lin <> "" Then
    Invi(i * 10 + cnt) = Mid(lin, 1, InStr(lin, ";") - 1)
    lin = Mid(lin, InStr(lin, ";") + 1)
    For n = 1 To (3 + i) ^ 2
      If InStr(lin, ",") = 0 Then
        Vals(i * 10 + cnt, n) = Val(lin)
      Else
        Vals(i * 10 + cnt, n) = Val(Mid(lin, 1, InStr(lin, ",") - 1))
        lin = Mid(lin, InStr(lin, ",") + 1)
      End If
    Next
    cnt = cnt + 1
  Else
    solCnt(i) = cnt
    i = i + 1
    cnt = 0
  End If

Loop
'since al end of textstream , the last solCnt wasnt done (unless someone adds a blank line at end of solns.txt)
solCnt(2) = cnt

ts.Close


'Add board sizes
lstSize.AddItem "3x3 Matrix (8 squares)"
lstSize.AddItem "4x4 Matrix (15 squares)"
lstSize.AddItem "5x5 Matrix (24 squares)"

lstSize.ListIndex = 0
lst.ListIndex = 0

mnuSize_Click (1)
End Sub

Private Sub Form_Resize()
If Me.Tag = "loading" Then mnuNew_Click: Me.Tag = ""
End Sub

Private Sub klmain_MoveDirection(Index As Integer, Direction As Integer)
If klMain(Index).Show <> 0 Then
  SetNewInvisible Index
  Mov = Mov + 1
End If

CheckForCompletion
End Sub

Private Sub CheckForCompletion()
If pic.Enabled = False Then Exit Sub

'look for Finished results
Dim inv As Byte, i As Byte
inv = Invi(lstSize.ListIndex * 10 + lst.ListIndex)
If klMain(inv).Visible = False Then
  For i = 1 To cnt
    If i <> inv And klMain(i).Value <> kl(i).Value Then Exit Sub
  Next
Else
  Exit Sub
End If

'if not exitted sub then has finished level
Dim secs As Integer '9hr time limit
Dim topKy As String, Disp(4) As String, top(4, 1) As Integer '1/2/3 & Moves/Secs
secs = DateDiff("s", tm, Now)
tmr.Enabled = False

topKy = apProd & "\Top " & Mid(lstSize.Text, 1, 3)
top(1, 0) = Val(GetSetting(apComp, topKy, lst.Text & " - 1st.Moves"))
  top(1, 1) = Val(GetSetting(apComp, topKy, lst.Text & " - 1st.Secs"))
  Disp(1) = GetSetting(apComp, topKy, lst.Text & " - 1st.Disp")
top(2, 0) = Val(GetSetting(apComp, topKy, lst.Text & " - 2nd.Moves"))
  top(2, 1) = Val(GetSetting(apComp, topKy, lst.Text & " - 2nd.Secs"))
  Disp(2) = GetSetting(apComp, topKy, lst.Text & " - 2nd.Disp")
top(3, 0) = Val(GetSetting(apComp, topKy, lst.Text & " - 3rd.Moves"))
  top(3, 1) = Val(GetSetting(apComp, topKy, lst.Text & " - 3rd.Secs"))
  Disp(3) = GetSetting(apComp, topKy, lst.Text & " - 3rd.Disp")

Dim inter As Integer, str As String, ip As String

ip = InputBox("Congratulations, You have completed the game." & vbCrLf & "Please enter your name", "Game Completed", GetSetting(apComp, apProd, "Last Completer", "[Your Name]"))
If ip <> "" Then SaveSetting apComp, apProd, "Last Completer", ip
'set new at bottom
Disp(4) = ip & "  - " & Mov & " moves in " & secs & " seconds [" & Now & "]"
top(4, 0) = Mov: top(4, 1) = secs

'Move up if better than previous
'if 4 better than 3 then
If top(3, 0) = 0 Or top(4, 0) < top(3, 0) Or (top(4, 0) = top(3, 0) And top(4, 1) < top(3, 1)) Then
  'move up
  top(3, 0) = top(4, 0): top(3, 1) = top(4, 1)
  Disp(3) = Disp(4)
  'if 3 better than 2 then
  If top(2, 0) = 0 Or top(3, 0) < top(2, 0) Or (top(3, 0) = top(2, 0) And top(3, 1) < top(2, 1)) Then
    'Move up
    inter = top(2, 0): top(2, 0) = top(3, 0): top(3, 0) = inter
    inter = top(2, 1): top(2, 1) = top(3, 1): top(3, 1) = inter
    str = Disp(2): Disp(2) = Disp(3): Disp(3) = str
    'if 2 better than 1 then
    If top(1, 0) = 0 Or top(2, 0) < top(1, 0) Or (top(2, 0) = top(1, 0) And top(2, 1) < top(1, 1)) Then
      'move up
      inter = top(1, 0): top(1, 0) = top(2, 0): top(2, 0) = inter
      inter = top(1, 1): top(1, 1) = top(2, 1): top(2, 1) = inter
      str = Disp(1): Disp(1) = Disp(2): Disp(2) = str
    End If
  End If
End If

lstTop.Clear
'save scores to registry & load in top scores
  SaveSetting apComp, topKy, lst.Text & " - 1st.Moves", top(1, 0)
  SaveSetting apComp, topKy, lst.Text & " - 1st.Secs", top(1, 1)
  SaveSetting apComp, topKy, lst.Text & " - 1st.Disp", Disp(1)
  lstTop.AddItem Disp(1)
If top(2, 0) <> 0 Then
  SaveSetting apComp, topKy, lst.Text & " - 2nd.Moves", top(2, 0)
  SaveSetting apComp, topKy, lst.Text & " - 2nd.Secs", top(2, 1)
  SaveSetting apComp, topKy, lst.Text & " - 2nd.Disp", Disp(2)
  lstTop.AddItem Disp(2)
End If
If top(3, 0) <> 0 Then
  SaveSetting apComp, topKy, lst.Text & " - 3rd.Moves", top(3, 0)
  SaveSetting apComp, topKy, lst.Text & " - 3rd.Secs", top(3, 1)
  SaveSetting apComp, topKy, lst.Text & " - 3rd.Disp", Disp(3)
  lstTop.AddItem Disp(3)
End If

tmr.Enabled = True

Dim m As VbMsgBoxResult
m = MsgBox("Would you like to begin a new game?", vbQuestion + vbYesNo)
  If m = vbYes Then mnuNew_Click Else pic.Enabled = False

End Sub



Private Sub lst_Click()
Dim ind As Integer, siz As Integer
ind = lst.ListIndex
siz = lstSize.ListIndex

For i = 1 To cnt
  kl(i).Value = Vals(ind + siz * 10, i)
  kl(i).Visible = True
Next
kl(Invi(ind + siz * 10)).Visible = False

'load scores if available
Dim topKy As String
lstTop.Clear
topKy = apProd & "\Top " & Mid(lstSize.Text, 1, 3)
If GetSetting(apComp, topKy, lst.Text & " - 1st.Disp") <> "" Then lstTop.AddItem GetSetting(apComp, topKy, lst.Text & " - 1st.Disp")
If GetSetting(apComp, topKy, lst.Text & " - 2nd.Disp") <> "" Then lstTop.AddItem GetSetting(apComp, topKy, lst.Text & " - 2nd.Disp")
If GetSetting(apComp, topKy, lst.Text & " - 3rd.Disp") <> "" Then lstTop.AddItem GetSetting(apComp, topKy, lst.Text & " - 3rd.Disp")

CheckForCompletion
End Sub

Private Sub lstSize_Click()
sid = lstSize.ListIndex + 3
cnt = sid ^ 2

'pic1.Visible = False: pic2.Visible = False

'load/unload to get reqd pieces
Do Until kl.Count = cnt
  If kl.Count < cnt Then
    Load kl(kl.Count + 1)
      Load klMain(klMain.Count + 1)
    kl(kl.Count).Visible = True
      klMain(kl.Count).Visible = True
  Else
    Unload kl(kl.Count)
    Unload klMain(klMain.Count)
  End If
Loop

'position first piece
If cnt = 25 Then kl(1).top = 0: kl(1).Left = 0: klMain(1).top = 0: klMain(1).Left = 0
If cnt = 16 Then kl(1).top = kl(1).Height / 2: kl(1).Left = kl(1).Width / 2: _
  klMain(1).top = klMain(1).Height / 2: klMain(1).Left = klMain(1).Width / 2
If cnt = 9 Then kl(1).top = kl(1).Height: kl(1).Left = kl(1).Width: _
  klMain(1).top = klMain(1).Height: klMain(1).Left = klMain(1).Width

'position other pieces
Dim i As Integer, j As Integer
For i = 1 To cnt Step sid
  If i > 1 Then kl(i).top = kl(i - sid).top + kl(1).Height: kl(i).Left = kl(1).Left: _
                klMain(i).top = klMain(i - sid).top + klMain(1).Height: klMain(i).Left = klMain(1).Left
  For j = 1 To sid - 1
    kl(i + j).top = kl(i).top
      klMain(i + j).top = klMain(i).top
    kl(i + j).Left = kl(i + j - 1).Left + kl(1).Width
      klMain(i + j).Left = klMain(i + j - 1).Left + klMain(1).Width
  Next
Next

'load levels for current size in lst
lst.Clear
For i = 1 To solCnt(lstSize.ListIndex)
  lst.AddItem "Solution " & i
Next
lst.ListIndex = 0

mnuNew_Click

'pic1.Visible = True: pic2.Visible = True
End Sub

Private Sub mnuArrows_Click()
mnuArrows.Checked = Not mnuArrows.Checked

'set arrow visibility (off for all small size)
Dim i As Integer
If mnuSize(1).Checked = False Then
  For i = 1 To cnt
    klMain(i).ShowArrows = mnuArrows.Checked
  Next
End If
End Sub

Private Sub mnuBold_Click()
mnuBold.Checked = Not mnuBold.Checked
For i = 1 To cnt
  klMain(i).Font.Bold = mnuBold.Checked
  klMain(i).Refresh
Next
End Sub

Private Sub mnuExit_Click()
End
End Sub

Private Sub mnuNew_Click()
Dim l As Byte, iCol As New Collection ', str As String

'make all invisible & load collection
For i = 1 To cnt
  klMain(i).Visible = False
  iCol.Add i, "K" & i
Next

Randomize
For i = 1 To cnt - 1
  l = iCol(Int(Rnd * (iCol.Count - 1)) + 1)
  iCol.Remove ("K" & l)
  klMain(l).Value = i
  klMain(l).Visible = True
'  str = str & "," & l
Next

Invisible = 0
For i = 1 To cnt
  If klMain(i).Visible = False Then SetNewInvisible CInt(i): Exit For
Next

Mov = 0: tm = Now 'tm = Timer():
tmr_Timer
End Sub

Private Sub mnuSize_Click(Index As Integer)
'declare coin variables
Dim sz As Integer, fsz As Integer, shw As Boolean

pic.Visible = False

'make board changes and set coin variables
If Index = 1 Then 'small
  pic.Left = 240 + 1250: pic.top = 1250
  pic.Width = 2500: pic.Height = 2500
  sz = 500: fsz = 14
ElseIf Index = 2 Then 'medium
  pic.Left = 865: pic.top = 865
  pic.Width = 3750: pic.Height = 3750
  sz = 750: fsz = 18
Else 'large
  pic.Left = 240: pic.top = 240
  pic.Width = 5000: pic.Height = 5000
  sz = 1000: fsz = 22
End If

If Index > 1 Then shw = mnuArrows.Checked Else shw = False

'now change widths & other
Dim i As Integer
For i = 1 To klMain.Count
  klMain(i).Width = sz
    klMain(i).Height = sz
  klMain(i).Font.Size = fsz
  klMain(i).ShowArrows = shw
  klMain(i).Refresh
Next

'check current menu size
For i = 1 To 3: mnuSize(i).Checked = False: Next: mnuSize(Index).Checked = True

'position first piece (copied from lstSize_Click)
If cnt = 25 Then klMain(1).top = 0: klMain(1).Left = 0
If cnt = 16 Then klMain(1).top = klMain(1).Height / 2: klMain(1).Left = klMain(1).Width / 2
If cnt = 9 Then klMain(1).top = klMain(1).Height: klMain(1).Left = klMain(1).Width

'position other pieces (copied from lstSize_Click)
Dim j As Integer
For i = 1 To cnt Step sid
  If i > 1 Then klMain(i).top = klMain(i - sid).top + klMain(1).Height: klMain(i).Left = klMain(1).Left
  For j = 1 To sid - 1
    klMain(i + j).top = klMain(i).top
    klMain(i + j).Left = klMain(i + j - 1).Left + klMain(1).Width
  Next
Next

pic.Visible = True
End Sub

Private Sub SetNewInvisible(Index As Integer)
'clear all shows
For i = 1 To cnt: klMain(i).Show = 0: Next

If Index = 1 Then 'top left
  klMain(2).Show = 4: klMain(sid + 1).Show = 1
ElseIf Index = sid Then 'top right
  klMain(sid - 1).Show = 2: klMain(2 * sid).Show = 1
ElseIf Index = cnt Then 'bottom right
  klMain(cnt - sid).Show = 3: klMain(cnt - 1).Show = 2
ElseIf Index = cnt - sid + 1 Then 'bottom left
  klMain(cnt - 2 * sid + 1).Show = 3: klMain(cnt - sid + 2).Show = 4
ElseIf Index < sid Then 'top row
  klMain(Index - 1).Show = 2: klMain(Index + 1).Show = 4: klMain(Index + sid).Show = 1
ElseIf Index > cnt - sid + 1 Then 'bottom row
  klMain(Index - 1).Show = 2: klMain(Index + 1).Show = 4: klMain(Index - sid).Show = 3
ElseIf Index Mod sid = 0 Then 'rightmost col
  klMain(Index - sid).Show = 3: klMain(Index + sid).Show = 1: klMain(Index - 1).Show = 2
ElseIf (Index - 1) Mod sid = 0 Then  'leftmost col
  klMain(Index - sid).Show = 3: klMain(Index + sid).Show = 1: klMain(Index + 1).Show = 4
Else 'all 4 sides available
  klMain(Index - sid).Show = 3: klMain(Index + sid).Show = 1
  klMain(Index - 1).Show = 2: klMain(Index + 1).Show = 4
End If

'  klMain(8).Show = 1: klMain(4).Show = 2: klMain(2).Show = 3: klMain(6).Show = 4

klMain(Index).Visible = False
If Invisible <> 0 Then klMain(Invisible).Visible = True: klMain(Invisible).Value = klMain(Index).Value

Invisible = Index
End Sub

Private Sub tmr_Timer()
'  lbl = "Moves: " & mov & vbCrLf & "Time: " & Int(Timer() - tm) & " seconds"
  lbl = "Moves: " & Mov & "  (Time: " & Format(Now - tm, "hh:mm:ss") & ")"
End Sub
