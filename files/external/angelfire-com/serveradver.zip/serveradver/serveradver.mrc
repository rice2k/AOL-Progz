;Name: Servers Advertisers Auto Kick.
;Written By: JAMARO
;jamaro@37.com
;http://come.to/jamaro
;Feb 2001
;==================================

;===Server Advertiser Kick===>>
#server on
on @1:TEXT:*/server *.**:#:{
  if ($network isin $1-) || ($server isin $1-) { halt }
  if ($nick isop $chan) || ($nick isvo $chan) { halt }
  ban -u180 $chan $nick 3 | kick $chan $nick Servers Advertiser
}

on @1:ACTION:*/server *.**:#:{
  if ($network isin $1-) || ($server isin $1-) { halt }
  if ($nick isop $chan) || ($nick isvo $chan) { halt }
  ban -u180 $chan $nick 3 | kick $chan $nick Servers Advertiser
}

on @1:NOTICE:*/server *.**:#:{
  if ($network isin $1-) || ($server isin $1-) { halt }
  if ($nick isop $chan) || ($nick isvo $chan) { halt }
  ban -u180 $chan $nick 3 | kick $chan $nick Servers Advertiser
}
#server End
menu status,menubar,channel {
  Servers Advertisers Kick
  .ON:.enable #server | echo 3 *** The servers advertisers auto kick is now ON
  .OFF:.disable #server | echo 3 *** The servers advertisers auto kick is now OFF
}
alias thank dialog -mo thank thank
dialog thank {
  title "Add-ons By Jamaro 2001"
  size -1 -1 200 180
  box "",1,5 0 190 70
  text "Thank you for loading this Add-on written by jamaro. Please visit my website for more add-ons and other IRC tools. Have fun.",2,10 12 180 50,left
  box "",3,5 68 190 86
  text "jamaro@37.com",4,10 80 180 15,center
  edit "http://come.to/jamaro",5,33 100 130 22,center,read
  button "Visit",6,70 127 50 20
  button "Close",7,5 158 190 20,ok
}
on *:dialog:thank:init:0:/did -f thank 6
on *:dialog:thank:sclick:6:/run http://come.to/jamaro
on *:load:if ($version > 5.41) { thank }