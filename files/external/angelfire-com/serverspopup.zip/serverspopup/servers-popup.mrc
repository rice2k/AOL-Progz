;Name: Dalnet Servers Popup
;Written By: JAMARO
;jamaro@37.com
;http://come.to/jamaro
;Feb 2001
;==================================

menu status,menubar,channel {
  Dalnet Servers
  .Last Server:/server
  .-
  .Dalnet USA
  ..&Random:/server irc.dal.net
  ..-
  ..&Apollo:/server apollo.dal.net 6667,7000
  ..Arabian { server arabian.dal.net 6667,7000 }
  ..Armory { server armory.dal.net 6667,7000 }
  ..-
  ..&Barovia:/server barovia.dal.net 6667,6668,6669,7000
  ..-
  ..&Chrome:/server chrome.dal.net
  ..Cin:/server cin.dal.net 6667,7000
  ..Crush:/server crush.dal.net 6660,6661,6662,6663,6664,6665,6666,6667,6668,6669,7000,7001,7002
  ..-
  ..Dragon { server dragon.dal.net 6667,7000 }
  ..-
  ..&Empire { server empire.dal.net 6667 }
  ..Enigma:/server enigma.dal.net 6667,7000
  ..-
  ..&Farside { server farside.dal.net 6667,7000 }
  ..Freedom:/server freedom.dal.net
  ..-
  ..&Galaxy:/server galaxy.dal.net 6660,6661,6662,6663,6664,6665,6666,6667,6668,6669,6670,7000
  ..Glass:/server glass.dal.net 6660,6661,6662,6663,6664,6665,6666,6667,7000
  ..Gulf:/server gulf.dal.net
  ..Groucho:/server groucho.dal.net 6667,7000
  ..-
  ..&Hebron:/server hebron.dal.net 6661,6662,6663,6664,6665,6666,6667,6668,6669,7000
  ..Hebron-h:/server hebron-h.dal.net
  ..-
  ..&Jade:/server jade.dal.net 6660,6666,6667,6668,6669,7000,6060,6070
  ..-
  ..&Keen:/server keen.dal.net 6666,6667,7000,7001
  ..Kechara.ma:/server kechara.ma.us.dal.net 6667
  ..-
  ..&Liberty:/server liberty.dal.net 6660,6661,6662,6663,6664,6665,6666,6667,6668,6669,6670,7000
  ..Lomag:/server lomag.dal.net 6660,6661,6662,6663,6664,6665,6666,6667,6668,6669,7000
  ..-
  ..&Mindijari { server mindijari.dal.net 7000,6667 }
  ..Mystic:/server Mystic.dal.net 6667
  ..-
  ..Nethawks { server nethawks.dal.net 6667 }
  ..Nether:/server nether.dal.net 6667
  ..-
  ..&Ohana:/server ohana.dal.net 6667,7000
  ..Opus:/server opus.dal.net 6667,7000
  ..Ozbytes { server ozbytes.dal.net 6667,7000 }
  ..-
  ..&Paradise:/server paradise.dal.net 6665,6666,6667,6668,6669,7000,7001,7002,7003
  ..&Qis:/server qis.dal.net 6660,6661,6662,6663,6664,6665,6666,6667,6668,6669,7000,7001,7002
  ..-
  ..&Recluse { server recluse.dal.net 6667,7000 }
  ..-
  ..&Sahara:/server sahara.dal.net 6660,6661,6662,6663,6664,6665,6666,6667,6668,6669,7000
  ..Silver:/server silver.dal.net
  ..Skypoint:/server skypoint.dal.net 6667
  ..Sodre:/server sodre.dal.net 6660,6661,6662,6663,6664,6665,6666,6667,6668,6669,7000
  ..Sonic { server sonic.dal.net 6667,7000 }
  ..Spider { server spider.dal.net 6667,7000 }
  ..Splitrock:/server splitrock.dal.net 6660,6661,6662,6663,6664,6665,6666,6667,6668,6669,7000
  ..Stlouis { server stlouis.dal.net 6667 }
  ..-
  ..&Titan { server titan.dal.net 6667 }
  ..Toast:/server toast.dal.net  6667
  ..Trapdoor { server trapdoor.dal.net 6667,7000 }
  ..Traced:/server traced.dal.net 6664,6665,6666,6667,6668,6669,7000
  ..-
  ..&Uncc { server uncc.dal.net 6667 }
  ..&Viper:/server viper.dal.net 6660,6661,6662,6663,6664,6665,6666,6667,7000
  ..-
  ..&Webbernet:/server webbernet.dal.net 6660,6661,6662,6663,6664,6665,6666,6667,6668,6669,6670,6680,7000
  ..Webserve:/server webserve.dal.net 6660,6661,6662,6663,6664,6665,6666,6667,6668,6669,7000
  ..Webzone:/server webzone.dal.net 6664,6665,6666,6667,6668,6669,7000
  .Dalnet Europe
  ..&Random:/server irc.eu.dal.net 6667,7000
  ..-
  ..&Algo:/server algo.dal.net
  ..Algo-u:/server algo-u.dal.net 6667,7000 
  ..-
  ..&Borg:/server borg.dal.net
  ..&Ced:/server ced.dal.net 6660,6661,6662,6663,6664,6665,6666,6667,6668,6669,7000
  ..-
  ..&Lineone-e:/server lineone-e.uk.eu.dal.net 6667
  ..Locutus:/server locutus.dal.net 6667,7000 
  ..-
  ..&Paranoia:/server paranoia.dal.net 6667,7000
  ..Powertech:/server powertech.dal.net 6666,6667,7000
  ..-
  ..&Viking:/server viking.dal.net 6666,6667,6668,6669,7000,4000
  .Dalnet Cananda
  ..&Raptor:/server raptor.dal.net 6667,7000 
  ..&Toronto:/server toronto.dal.net 6667,7000
  ..&Vancouver:/server vancouver.dal.net 6660,6661,6662,6663,6664,6665,6666,6667,6668,6669,66670,6680,6690
  .Dalnet Malaysia
  ..&Coins:/server coins.kl.my.dal.net 
  .-
  .Enter Server:/server $$?="<Server> <Port> ex:(sonic.dal.net 6667)"
}
alias thank dialog -mo thank thank
dialog thank {
  title "Add-ons By Jamaro 2001"
  size -1 -1 200 180
  box "",1,5 0 190 70
  text "Thank you for loading this Add-on written by jamaro. Please visit my website for more add-ons and other IRC tools. Have fun.",2,10 12 180 50,left
  box "",3,5 68 190 86
  text "jamaro@37.com",4,10 80 180 15,center
  edit "http://come.to/jamaro",5,33 100 130 22,center,read
  button "Visit",6,70 127 50 20
  button "Close",7,5 158 190 20,ok
}
on *:dialog:thank:init:0:/did -f thank 6
on *:dialog:thank:sclick:6:/run http://come.to/jamaro
on *:load:if ($version > 5.41) { thank }