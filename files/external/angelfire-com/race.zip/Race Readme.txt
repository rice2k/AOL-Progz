Run 'Race.exe'

5 Input box's will appear one after another

Type a name in each as the appear

Watch the 'race'

Press the restart button up top to restart



CREATED BY BEN LEED