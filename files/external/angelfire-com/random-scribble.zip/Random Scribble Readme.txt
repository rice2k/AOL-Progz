Run 'Random Scribble.exe'

Be sure to change the 'Seed' to allow for more lines

'From Centre' feature makes all the lines flow out fromt the centre.
'Scattered' feature makes all the lines continue from each other.

Please experiment!


CREATED BY BEN LEED