DVBVideoLAN - Live-Streaming Extension for VDR and MSWindows
(C) Markus Winkler <markus.winkler@gmxpro.de> 2001,2002

The patch adds live-streaming functionality to Klaus Schmidingers VDR.
It's partly based on Dave Chapmans dvbstream (C) Dave Chapman <dave@dchapman.com> 2001.
The latest version can be found at http://www.linuxstb.org/dvbstream

DVBVideoLAN LICENSE
-------------------

Linux-Part:
The patch for VDR is under GPL.

Windows-Part
The DVBVideoLAN-Player and the DirectShow Source Filter is free for UNCOMMERCIAL use.
You may distribute unlimited copies of the Software as long as each copy that you make 
and distribute contains this Agreement and the same copyright.
You may NOT modify it in any way.

INSTALLATION
------------

Linux-Part:
Copy the patch to your VDR directory version 1.0.3 and type
- zcat vdr-<VDR-VERSION>-dvbvl-<DVBVL-VERSION>.patch.gz | patch -p1
- make clean
- make [your options] STREAMING=1
restart vdr.

Windows-Part:
Extract the zip somewhere on your harddisk.
Run register.bat to add dvbrtp.ax to your registry.
Start dvbpl.exe and select a channel.


DVBVideoLAN Revision History
----------------------------

2001-12-06 Version 0.01a (Initial revision).

2001-12-07 Version 0.02

- The SourceFilter is now less thirsty regarding processor power.
- Added some more checks for the GraphBuilder.
- Missing copyright infos and references to other projects added.

2002-02-24

- First version of the streaming patch for VDR 0.99 by Klaus Schmidinger.
  The patch and the MPEG-2 TS RTP stack is based on dvbstream-0.3 by Dave Chapman.

2002-02-26

- vdr-0.99-dvbvl-0.2.patch
  - Removed some unnecessary code in dvbapi.c
  - Traces moved to system log.
- dvbpl-020226 (Version 0.03)
  - Fixed start up problems. Should work for most channels now.
  - Known problems with Pro-7.
  - Still crashes sometimes while exiting.

2002-02-27

- dvbpl-020227 (Version 0.04)
  - Fixed Multicast support.
  - Implemented kind of prio-managing-load-balancing-error-detection-algorithm in the source filter.
  - Added a list of known working systems/configurations to the FAQ
  - Added widescreen support.
- vdr-0.99-dvbvl-0.3.patch
  - Fixed a bug regarding the environment vars (Thanks to Robert Schneider).

2002-03-01
- dvbpl-020301 (Version 0.05)
  - Control->Stay on top: Let's the player stay on top of other windows
  - Added some keybindings. See ?->Help<
  - Fast Resync: Pressing <SPACE> while playing causes a fast resync of video and audio.
    (This doesn't always work the first time.)
  - File->Resync: Resyncs the video/audio. Just the same as start and stop
  - If you're interested in the filter graph created by DVBVideoLAN run Graphedit
    and use connect.
  - And of course, some bugfixes.

2002-06-19
- dvbpl-020619 (Version 0.06)
  - Choose from up to four different multicasts
  - Some bugfixes
- vdr-1.0.3-dvbvl-0.4.patch
  - Stream up to 4 different channels at the same time.
  - Added an on screen menu for <live-streaming>
  - Many fixes.


DVBVideoLAN FAQ
---------------
updated 2002-06-19


Q: Which are the requirements?

A: There are several.
   First, the linux machine:
   - A DVB card
   - Linux drivers from www.linuxtv.org
   - VDR 1.0.3 from Klaus Schmidinger
   - A kernel with Multicast networking enabled.
   Second, the windows machine:
   - Lots of MHz. The DirectShow part eats much power. I'm testing with a P3-750 and
     the cpu load is at about 50-80%, depends on the channel. I try to lower this sometimes.
   - A demultiplexer and a mpeg2decoder as a DirectShow filter, which supports mpeg2
     transport streams. You have one, if you can replay a vdr/pva recording with your
     MediaPlayer. If it's not working, dvbpl will not work.
   - A videocard with overlay support
   - WindowsXP or Windows2000. I don't have any other windows operating system to test.
     Perhaps Windows95/98 work as well, but it's untested
   - DirectX8.0a and 8.1. No other version tested.

Q: The Player asks for a msvcrtd.dll, where do i find it?

A: You can download it from the this site. Copy the dll into your player-directory.

Q: Which demuxer and decoder for mpeg2 should I use?

A: As far as I know, there are two. Elecard and Ligos. I prefer the one from Elecard (v1.22).
   www.elecard.com.

Q: How do I apply the patch on VDR?

A: Simply go in your clean VDR-1.0.3 dir and enter zcat vdr-1.0.3-dvbvl...diff.gz | patch -p1

Q: What do I have to do afterwards?

A: First, you have to set the following environment variables:
   Setup the route using something like:
   /sbin/route add -net 224.0.0.0 netmask 240.0.0.0 dev eth0

Q: VDR-Crashes!

A: This is a very new project and I'm sure, there are bugs in it. Please report your problems and
   I'll try to fix it.

Q: DVBVideoLAN Player crashes!

A: See the question above.

Q: DVBVideoLAN Player doesn't stop synchronizing.

A: The reception and decoding of the mpeg2stream is very timecritical. Especially while
   identifying the stream there shouldn't be much stream errors. Try streaming another
   channel. Restart the player.

Q: Player is working, but after some time, audio and video are getting out of sync.

A: Problem is known. As far as I know, this happens after too many stream errors. You can
   check this with the help of dvbrtp.log. Since the decoding of audio and video are
   independent from each other, yet the only solution is to restart the player.

Q: Which channels cause problems, which are know to work.

A; I didn't check all of them of course. The lower the bitrate the better. MTV Europe, Viva
   are working very well, ARD, ZDF, Sat1, RTL are ok. Pro7 isn't working at all, don't know
   why.

Q: What about the sources?

A: You have the sources for the linux part. For the windows part, I didn't release them yet.

Q: On which systems do you know that it works?

A: At least on my environment or other known systems:
   I'm using a 10/100 mbit Switch.
   Server 1:
     Linux with Suse 7.1
     AMD Athlon 500 Mhz
     128MB Ram
     LevelOne 10/100 mbit network controller
     2 Siemens DVB-S
     VDR 0.99

   Server 2:
     Linux with Suse 7.1
     AMD Athlon 800 Mhz
     128MB Ram
     LevelOne 10/100 mbit network controller
     2 Siemens DVB-S
     VDR 0.99

   Client 1:
     Windows XP Pro
     Dell Inspiron 8000
     Intel P3-750
     256MB Ram
     NVidia Gforce 2 MX 16MB AGP 4x running a resolution of 1600x1200
     Intel 10/100 mbit network controller
     (Working perfektly for channels with lower bitrate)

   Client 2:
     Windows XP Pro
     AMD Athlon 800 Mhz
     384MB Ram
     Elsa Victory Erazor 4MB PCI running a resolution of 1200x1024
     LevelOne 10/100 mbit network controller
     (Working perfektly for all tested channels, including ARD, ZDF)

   Client 3:
     Windows 2000 Pro
     AMD Athlon 800 Mhz
     384MB Ram
     Elsa Victory Erazor 4MB PCI running a resolution of 1200x1024
     LevelOne 10/100 mbit network controller

   Client 4:
     Windows XP Pro
     Dell Inspiron 8000
     Intel P3-800
     256MB Ram
     NVidia Gforce 2 MX 16MB AGP 4x running a resolution of 1600x1200
     Intel 10/100 mbit network controller

   Client 5:
     Windows XP Pro
     AMD Thunderbird 800 Mhz
     384MB Ram
     Matrox G400 DH 32MB AGP 2x running a resolution of 1600x1200
     LevelOne 10/100 mbit network controller



(C) Markus Winkler <markus.winkler@gmxpro.de> 2001,2002
