regsvr32 /s dvbrtp.ax
