unzip all files to your desktop
it will create a patchworx folder
open it and run the .exe
While tbh is still down
if you try and update you may
or may not lose your current
patch list