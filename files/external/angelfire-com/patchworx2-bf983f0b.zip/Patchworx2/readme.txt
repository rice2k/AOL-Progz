Patchworx2 - by Archon of The Black Hand
----------

[What is Patchworx2]

	Patchworx2 is the followup to TBH Patchworx, an all-in-one patching program for Virtual Places.  The original Patchworx was released when only one version of VP was in popular use, so when new versions began appearing, it had problems.

	Patchworx was an offset based patching program, meaning a patch was only good for the specific build of VP it was written for.  Patchworx2 is version independant, so a single patch will work on all builds in existence, and very likely on future builds as well.


[What's new in Patchworx2]

Version 1.2

 - Update of search routines to accomodate filename change to ECHAT.EXE
 - Update of search routines to find vplaces.exe's renamed to, say, vplaces132.exe
 - Automatic Update Notification - program will tell you when a new version is available.
 - New splash screen

Version 1.1

 - Unpatch button
 - Patching News Tab

Version 1.0

 - Version Independance (patches work on all builds)
 - Select location of VPLACES.EXE (With searching options)
 - Patching of VPRES.DLL
 - Alternate Web Update sites
 - 3rd party patch lists (Offset based)
 - Version/Build checking for Offset-based Patches


[Making your own Patch List]

	If you wish to provide people with your own patch list (either because you have made your own patches, or because you're one of those people who just likes to be difficult) you can create them as straight text files of the following format.

	The first line must be the text "Patchworx2 Patch List".  After that the patches are formatted as such:

+<patch name>;<patch author>;<vp build>
"<patch description paragraph>
"<patch description paragraph 2... etc>
-<decimal offset>:<decimal byte value>
-<decimal offset 2>:<devilam byte value 2> 

	A new patch can be added immediately after the last offset for a given path.  The finished file should be named patch.dat and placed on your website to be used for web updating.


[Being a Web Update Site]

	Since the vast majority of VP chatters believe whatever you tell them, its likely that many people will be suspicious of patchworx connecting to the TBH webpage.  While these Trojan rumours are just the fabrications of people who would rather see you without programs than with TBH programs, we have added support for non-TBH web update sites.

	To act as a Patchworx2 web update site, simply place patch.dat in the main directory of your webpage.  From then on people can put in your webpage's address as their web update site in Patchworx2 and will download their patch.dat from your site.

	You need not write your own patch.dat file to do this, you can upload the one you get from the TBH site or any other site.


[Made a new patch?]

	If you write a new patch for Virtual Places, and wish to have it added to the main patchworx2 patch list (With you listed as the author, of course) email us a copy of the patch and the name you wish used for the Author credits at the following address:

  patchworx2@theblackhand.net

	
[Need More Info?]

	Too bad.  The Black Hand makes software, we're not digital wetnurses to the mewling masses.  Ask someone with more patience.


		