Starcraft
Protoss Fleet Screen Saver
By X
January 29, 1999

Well, I made this screen saver for the heck of it since I'm a Protoss fan.  I wouldv'
added music but there isn't a midi sequence of any of the Protoss music.  Anyway, the next
Starcraft screen savers I'll probably do are Zerg fleets and the Terran fleets.  Maybe
some miscellaneous unit themes.  But until then enjoy this screen saver.

How to Install:
Just copy "protoss.scr" to your "windows" directory then bring up your display 
configuration in your "Display" panel.

X
B.net Alias: KurenaiJiku
Fusion 601
members.xoom.com/fusion601/index.html
www.densetsu.com/xproductions/index.htm