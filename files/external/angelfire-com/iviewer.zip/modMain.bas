Attribute VB_Name = "modMain"
Option Explicit

Public apComp As String, apProd As String, apPath As String
Public fso As New FileSystemObject

Public Declare Function LockWindowUpdate Lib "user32" (ByVal hwndLock As Long) As Long

Public Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" _
(ByVal hWnd As Long, ByVal lpOperation As String, _
ByVal lpFile As String, ByVal lpParameters As String, _
ByVal lpDirectory As String, ByVal nShowCmd As Long) As Long 'for launching

Sub Main()

'Set fso = New FileSystemObject
apComp = App.CompanyName: apProd = App.ProductName: apPath = App.path


'frmOptions.Show vbModal

'frmSplash.lblStatus = "IViewer is absolutely FREE!!  �2001 No Rights Reserved."
'frmSplash.Show vbModal

'End

'Dim tm As Single
'tm = Timer()

If "True" = GetSetting(apComp, apProd, "Show Splash Screen", "True") Then
  Load frmSplash
  frmSplash.WindowState = 0
  frmSplash.Left = (Screen.Width - frmSplash.Width) / 2: frmSplash.Top = (Screen.Height - frmSplash.Height) / 2
  frmSplash.Show
End If

Load Vdplayer
Vdplayer.Show

'Debug.Print Timer() - tm: Debug.Print
'MsgBox "Start Took " & Timer() - tm & " seconds"

If True = GetSetting(apComp, apProd, "Tips on Startup", True) Then
  If fso.FileExists(apPath & "\tips.txt") = False Then MsgBox "The file 'tips.txt' is not in the program folder." & vbCrLf & _
    "  ('" & apPath & "')" & vbCrLf & "To view Tips, kindly replace the file.", vbCritical, "File Not Found" Else frmTips.Show
End If
End Sub



Public Sub SortLvwColumn(ByVal lvw As MSComctlLib.ListView, ColumnIndex As Integer, SortType As Integer, SortOrder As Integer)
    Dim X As Integer, Y As Integer
    'On Error GoTo ErrHandler
    

Select Case SortType
        
'*** Alphanumeric sort
Case 0 'sortAlphanumeric
  DoSort lvw, SortOrder, ColumnIndex - 1
            
'*** Numeric Sort
Case 1 'sortNumeric
  Dim strMax As String, strNew As String
            
    'Find the longest (whole) number string length in the column

    If ColumnIndex > 1 Then
        For X = 1 To lvw.ListItems.Count
            If Len(lvw.ListItems(X).ListSubItems(ColumnIndex - 1)) <> 0 Then 'ignores 0 length strings
                If Len(CStr(Int(lvw.ListItems(X).ListSubItems(ColumnIndex - 1)))) > Len(strMax) Then
                    strMax = CStr(Int(lvw.ListItems(X).SubItems(ColumnIndex - 1)))
                End If
            End If
        Next
    Else
        For X = 1 To lvw.ListItems.Count
            If Len(lvw.ListItems(X)) <> 0 Then
                If Len(CStr(Int(lvw.ListItems(X)))) > Len(strMax) Then
                    strMax = CStr(Int(lvw.ListItems(X)))
                End If
            End If
        Next
    End If
            
      'hide the control - speeds up the sort
      lvw.Visible = False
            
    If ColumnIndex > 1 Then
        For X = 1 To lvw.ListItems.Count
            If Len(lvw.ListItems(X).ListSubItems(ColumnIndex - 1)) = 0 Then
                lvw.ListItems(X).ListSubItems(ColumnIndex - 1) = "0" 'make 0 length strings = To "0"
            ElseIf Len(CStr(Int(lvw.ListItems(X).ListSubItems(ColumnIndex - 1)))) < Len(strMax) Then
                'prefix all numbers with 0's as required
                strNew = lvw.ListItems(X).ListSubItems(ColumnIndex - 1)

                For Y = 1 To Len(strMax) - Len(CStr(Int(lvw.ListItems(X).ListSubItems(ColumnIndex - 1))))
                    strNew = "0" & strNew
                Next
                lvw.ListItems(X).ListSubItems(ColumnIndex - 1) = strNew
            End If
        Next
    Else
        For X = 1 To lvw.ListItems.Count


            If Len(lvw.ListItems(X).Text) = 0 Then
                lvw.ListItems(X).Text = "0" 'make 0 length strings = To "0"
            ElseIf Len(CStr(Int(lvw.ListItems(X)))) < Len(strMax) Then
                'prefix all numbers with 0's as required
                
                strNew = lvw.ListItems(X).Text


                For Y = 1 To Len(strMax) - Len(CStr(Int(lvw.ListItems(X))))
                    strNew = "0" & strNew
                Next
                lvw.ListItems(X).Text = strNew
            End If
        Next
    End If
            
                DoSort lvw, SortOrder, ColumnIndex - 1
                
    If ColumnIndex > 1 Then
        'Remove preceding 0's
        For X = 1 To lvw.ListItems.Count
            lvw.ListItems(X).ListSubItems(ColumnIndex - 1) = CDbl(lvw.ListItems(X).ListSubItems(ColumnIndex - 1))
            If lvw.ListItems(X).ListSubItems(ColumnIndex - 1) = 0 Then lvw.ListItems(X).ListSubItems(ColumnIndex - 1) = ""
        Next
    Else
        'Remove preceding 0's
        For X = 1 To lvw.ListItems.Count
            lvw.ListItems(X).Text = CDbl(lvw.ListItems(X).Text)
            If lvw.ListItems(X).Text = 0 Then lvw.ListItems(X).Text = ""
        Next
    End If
    lvw.Visible = True
                
'*** Date Sort
Case 2 'sortDate
    lvw.Visible = False

    If ColumnIndex > 1 Then
        'Convert dates to format that can be sorted alphanumerically
        For X = 1 To lvw.ListItems.Count
            lvw.ListItems(X).ListSubItems(ColumnIndex - 1) = Format(lvw.ListItems(X).ListSubItems(ColumnIndex - 1), "YYYY MM DD hh:mm:ss")
        Next

        DoSort lvw, SortOrder, ColumnIndex - 1

        'Convert dates back to General Date format
        For X = 1 To lvw.ListItems.Count
            lvw.ListItems(X).ListSubItems(ColumnIndex - 1) = Format(lvw.ListItems(X).ListSubItems(ColumnIndex - 1), "General Date")
        Next
    Else
        'Convert dates to format that can be sorted alphanumerically
        For X = 1 To lvw.ListItems.Count
            lvw.ListItems(X).Text = Format(lvw.ListItems(X).Text, "YYYY MM DD hh:mm:ss")
        Next
            
        DoSort lvw, SortOrder, ColumnIndex - 1
                
        'Convert dates back to General Date format
        For X = 1 To lvw.ListItems.Count
            lvw.ListItems(X).Text = Format(lvw.ListItems(X).Text, "General Date")
        Next
                
    End If
            
    lvw.Visible = True

End Select

End Sub


Private Sub DoSort(ByVal lvw As ListView, SortOrder As Integer, SortKey As Integer)
    If SortOrder = 3 Then 'sortAscending
        lvw.SortOrder = lvwAscending
    ElseIf SortOrder = 4 Then 'sortDescending
        lvw.SortOrder = lvwDescending
    End If
    lvw.SortKey = SortKey
    lvw.Sorted = True
End Sub
