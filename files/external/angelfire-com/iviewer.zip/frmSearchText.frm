VERSION 5.00
Begin VB.Form frmSearch 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Search for Text"
   ClientHeight    =   1680
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4695
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmSearchText.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1680
   ScaleWidth      =   4695
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.Frame Frame1 
      Caption         =   "Find Text"
      Height          =   1335
      Left            =   165
      TabIndex        =   4
      Top             =   120
      Width           =   4335
      Begin VB.CommandButton cmdFind 
         Caption         =   "&Find"
         Default         =   -1  'True
         Height          =   375
         Left            =   3000
         TabIndex        =   5
         Top             =   360
         Width           =   1095
      End
      Begin VB.CheckBox chk 
         Caption         =   "&Match Case"
         Height          =   240
         Left            =   3000
         TabIndex        =   3
         Top             =   840
         Width           =   1215
      End
      Begin VB.OptionButton opt 
         Caption         =   "&Down"
         Height          =   255
         Index           =   2
         Left            =   1560
         TabIndex        =   2
         Top             =   840
         Width           =   735
      End
      Begin VB.OptionButton opt 
         Caption         =   "&All"
         Height          =   255
         Index           =   1
         Left            =   840
         TabIndex        =   1
         Top             =   840
         Value           =   -1  'True
         Width           =   735
      End
      Begin VB.TextBox txt 
         Height          =   360
         Left            =   240
         TabIndex        =   0
         Top             =   360
         Width           =   2655
      End
   End
End
Attribute VB_Name = "frmSearch"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
'always on top
Private Declare Function SetWindowPos& Lib "user32" (ByVal hWnd As Long, ByVal hWndInsertAfter As Long, ByVal X As Long, ByVal Y As Long, ByVal cx As Long, ByVal cy As Long, ByVal wFlags As Long)

Private Sub cmdFind_Click()
Dim strSearch As String, strIn As String, inSt As Integer
Dim Lposn As Long, Rposn As Long

With Vdplayer.rtb
If opt(2).Value = True Then
  Rposn = .SelStart + .SelLength
Else
  If LCase(.SelText) = LCase(txt) Then
    Rposn = .SelStart + .SelLength
  Else
    Rposn = 1
  End If
End If
Lposn = Rposn - 2

If chk.Value = 1 Then
  strSearch = txt.Text
  strIn = .Text
Else
  strSearch = LCase(txt.Text)
  strIn = LCase(.Text)
End If

inSt = InStr(Mid(strIn, Rposn), strSearch)
If inSt = 0 Then inSt = InStr(strIn, strSearch): Lposn = -1
If inSt = 0 Then MsgBox "Text not found", vbExclamation: Exit Sub

.SelStart = Lposn + inSt
.SelLength = Len(txt)

End With
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
If KeyCode = vbKeyEscape Then Unload Me
End Sub

Private Sub Form_Load()
SetWindowPos Me.hWnd, -1, 0, 0, 0, 0, 3 'makes it stay on top
txt = Vdplayer.rtb.SelText
Me.Top = GetSetting(apComp, apProd, "TextSearch.Top", (Screen.Height - Me.Height) / 2)
Me.Left = GetSetting(apComp, apProd, "TextSearch.Left", (Screen.Width - Me.Width) / 2)
End Sub

Private Sub Form_Unload(Cancel As Integer)
  SaveSetting apComp, apProd, "TextSearch.Top", Me.Top
  SaveSetting apComp, apProd, "TextSearch.Left", Me.Left
End Sub
