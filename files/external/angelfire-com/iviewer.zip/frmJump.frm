VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmJump 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Jump to file..."
   ClientHeight    =   3630
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   6270
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmJump.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3630
   ScaleWidth      =   6270
   ShowInTaskbar   =   0   'False
   StartUpPosition =   1  'CenterOwner
   Begin VB.CommandButton cmdCancel 
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   375
      Left            =   5160
      TabIndex        =   2
      TabStop         =   0   'False
      Top             =   120
      Width           =   855
   End
   Begin VB.TextBox txtFilter 
      Height          =   375
      Left            =   113
      TabIndex        =   0
      Top             =   120
      Width           =   4935
   End
   Begin MSComctlLib.ListView lvwJump 
      Height          =   2895
      Left            =   120
      TabIndex        =   1
      Top             =   600
      Width           =   6015
      _ExtentX        =   10610
      _ExtentY        =   5106
      View            =   3
      LabelEdit       =   1
      LabelWrap       =   -1  'True
      HideSelection   =   0   'False
      HideColumnHeaders=   -1  'True
      HoverSelection  =   -1  'True
      _Version        =   393217
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      NumItems        =   1
      BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         Object.Width           =   10072
      EndProperty
   End
End
Attribute VB_Name = "frmJump"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private lvwCrl As ListView

Public Function DoJump(lvw As ListView)
lvwJump.ListItems.Clear
Dim itm As ListItem
For Each itm In lvw.ListItems
  lvwJump.ListItems.Add lvwJump.ListItems.Count + 1, itm.Key, itm.Text
Next

End Function

Private Sub cmdCancel_Click()
Unload Me
End Sub

Private Sub lvwJump_DblClick()
    Vdplayer.CrlClick , lvwJump.SelectedItem.Key
    lvwCrl.MultiSelect = False
    lvwCrl.ListItems(lvwJump.SelectedItem.Key).Selected = True
    lvwCrl.MultiSelect = True
    Unload Me
    lvwCrl.SetFocus
End Sub

Private Sub lvwJump_KeyDown(KeyCode As Integer, Shift As Integer)
  If KeyCode = vbKeyReturn Then
    lvwJump_DblClick
  End If
End Sub

Private Sub txtFilter_Change()
lvwJump.ListItems.Clear

Dim str As String
str = LCase(txtFilter)

Dim itm As ListItem
For Each itm In lvwCrl.ListItems
  'MsgBox InStr(itm.Text, txtFilter)
  If InStr(LCase(itm.Text), str) > 0 Then
    lvwJump.ListItems.Add lvwJump.ListItems.Count + 1, itm.Key, itm.Text
  End If
Next

End Sub

Private Sub txtFilter_KeyDown(KeyCode As Integer, Shift As Integer)
If KeyCode = vbKeyUp Or KeyCode = vbKeyDown Then lvwJump.SetFocus
End Sub

Private Sub txtFilter_KeyPress(KeyAscii As Integer)
If KeyAscii = vbKeyUp Then
  If lvwJump.SelectedItem.Index > 1 Then lvwJump.ListItems(lvwJump.SelectedItem.Index - 1).Selected = True
ElseIf KeyAscii = vbKeyDown Then
  If lvwJump.SelectedItem.Index < lvwJump.ListItems.Count Then lvwJump.ListItems(lvwJump.SelectedItem.Index + 1).Selected = True
End If
End Sub
