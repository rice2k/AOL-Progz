VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmOptions 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "IViewer Options"
   ClientHeight    =   3630
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5445
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmOptions.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3630
   ScaleWidth      =   5445
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox pic 
      Appearance      =   0  'Flat
      ForeColor       =   &H80000008&
      Height          =   2895
      Index           =   6
      Left            =   1680
      ScaleHeight     =   2865
      ScaleWidth      =   3585
      TabIndex        =   39
      Top             =   120
      Visible         =   0   'False
      Width           =   3615
      Begin VB.CheckBox chkTrashConfirm 
         Caption         =   "&Display Delete Confirmation Dialog"
         Height          =   255
         Left            =   480
         TabIndex        =   19
         Top             =   360
         Width           =   3735
      End
      Begin VB.Frame framTrash 
         Caption         =   "Trash Can Location"
         Height          =   1335
         Left            =   240
         TabIndex        =   44
         Top             =   1200
         Width           =   3135
         Begin VB.TextBox txtTrashLoc 
            Height          =   285
            Left            =   240
            Locked          =   -1  'True
            TabIndex        =   21
            Top             =   360
            Width           =   2655
         End
         Begin VB.CommandButton cmdTrashSet 
            Caption         =   "..."
            Height          =   320
            Left            =   360
            TabIndex        =   22
            Top             =   840
            Width           =   615
         End
         Begin VB.CommandButton cmdTrashView 
            Caption         =   "&View"
            Height          =   320
            Left            =   1140
            TabIndex        =   23
            Top             =   840
            Width           =   735
         End
         Begin VB.CommandButton cmdTrashClear 
            Caption         =   "&Clear"
            Height          =   320
            Left            =   2040
            TabIndex        =   24
            Top             =   840
            Width           =   735
         End
      End
      Begin VB.CheckBox chkTrashEnable 
         Caption         =   "Delete to our '&Trash Can'"
         Height          =   255
         Left            =   480
         TabIndex        =   20
         Top             =   720
         Width           =   3375
      End
   End
   Begin VB.PictureBox pic 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   2895
      Index           =   1
      Left            =   1680
      ScaleHeight     =   2865
      ScaleWidth      =   3585
      TabIndex        =   36
      Top             =   120
      Visible         =   0   'False
      Width           =   3615
      Begin VB.Frame Frame3 
         Caption         =   "Clear Drop-Down Box Entries for"
         Height          =   735
         Left            =   240
         TabIndex        =   67
         Top             =   1200
         Width           =   3135
         Begin VB.CommandButton cmdClearSearchHistory 
            Caption         =   "File Search"
            Height          =   320
            Left            =   1575
            TabIndex        =   69
            Top             =   280
            Width           =   1335
         End
         Begin VB.CommandButton cmdClearFilterHistory 
            Caption         =   "File Filters"
            Height          =   320
            Left            =   240
            TabIndex        =   68
            Top             =   280
            Width           =   1335
         End
      End
      Begin VB.CommandButton cmdRemoveInvalidFolders 
         Caption         =   "&Remove Invalid Folders"
         Height          =   435
         Left            =   360
         TabIndex        =   3
         Top             =   2070
         Width           =   1335
      End
      Begin VB.CommandButton cmdClearTimeLibrary 
         Caption         =   "Clear &Time Library"
         Height          =   435
         Left            =   1935
         TabIndex        =   4
         Top             =   2070
         Width           =   1335
      End
      Begin VB.Frame Frame2 
         Caption         =   "Clear History of Folders"
         Height          =   735
         Left            =   240
         TabIndex        =   51
         Top             =   360
         Width           =   3135
         Begin VB.CommandButton cmdClearFolderHistory 
            Caption         =   "&Visited"
            Height          =   320
            Left            =   240
            TabIndex        =   1
            Top             =   280
            Width           =   1335
         End
         Begin VB.CommandButton cmdClearSearchFolHistory 
            Caption         =   "&Searched In"
            Height          =   320
            Left            =   1575
            TabIndex        =   2
            Top             =   280
            Width           =   1335
         End
      End
   End
   Begin VB.PictureBox pic 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   2895
      Index           =   7
      Left            =   1680
      ScaleHeight     =   2865
      ScaleWidth      =   3585
      TabIndex        =   43
      Tag             =   "Extensions"
      Top             =   120
      Visible         =   0   'False
      Width           =   3615
      Begin MSComctlLib.ListView lst 
         Height          =   2655
         Index           =   1
         Left            =   120
         TabIndex        =   25
         ToolTipText     =   "Right click for Options"
         Top             =   120
         Visible         =   0   'False
         Width           =   3375
         _ExtentX        =   5953
         _ExtentY        =   4683
         View            =   3
         LabelEdit       =   1
         LabelWrap       =   -1  'True
         HideSelection   =   0   'False
         FullRowSelect   =   -1  'True
         _Version        =   393217
         ForeColor       =   -2147483640
         BackColor       =   -2147483643
         BorderStyle     =   1
         Appearance      =   1
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         NumItems        =   1
         BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            Text            =   "Favorite Folders"
            Object.Width           =   2540
         EndProperty
      End
      Begin MSComctlLib.ListView lst 
         Height          =   2655
         Index           =   2
         Left            =   120
         TabIndex        =   26
         ToolTipText     =   "Right click for Options"
         Top             =   120
         Visible         =   0   'False
         Width           =   3375
         _ExtentX        =   5953
         _ExtentY        =   4683
         View            =   3
         LabelEdit       =   1
         LabelWrap       =   -1  'True
         HideSelection   =   0   'False
         FullRowSelect   =   -1  'True
         _Version        =   393217
         ForeColor       =   -2147483640
         BackColor       =   -2147483643
         BorderStyle     =   1
         Appearance      =   1
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         NumItems        =   1
         BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            Text            =   "Favorite Playlists"
            Object.Width           =   2540
         EndProperty
      End
      Begin VB.Label Label1 
         Alignment       =   2  'Center
         Caption         =   "Click on either Folders or Playlists"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   14.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   705
         Left            =   120
         TabIndex        =   45
         Top             =   1080
         Width           =   3390
      End
   End
   Begin VB.PictureBox pic 
      Appearance      =   0  'Flat
      ForeColor       =   &H80000008&
      Height          =   2895
      Index           =   5
      Left            =   1680
      ScaleHeight     =   2865
      ScaleWidth      =   3585
      TabIndex        =   31
      Tag             =   "Extensions"
      Top             =   120
      Visible         =   0   'False
      Width           =   3615
      Begin VB.CommandButton cmdUpdateExtension 
         Caption         =   "&Update"
         Enabled         =   0   'False
         Height          =   320
         Left            =   2610
         TabIndex        =   18
         Top             =   2300
         Width           =   855
      End
      Begin VB.TextBox txtExtension 
         Height          =   360
         Left            =   120
         TabIndex        =   17
         Top             =   2280
         Width           =   2415
      End
      Begin MSComctlLib.ListView lvw 
         Height          =   2055
         Left            =   120
         TabIndex        =   16
         Top             =   120
         Width           =   3375
         _ExtentX        =   5953
         _ExtentY        =   3625
         View            =   3
         LabelEdit       =   1
         LabelWrap       =   -1  'True
         HideSelection   =   0   'False
         FullRowSelect   =   -1  'True
         GridLines       =   -1  'True
         _Version        =   393217
         ForeColor       =   -2147483640
         BackColor       =   -2147483643
         BorderStyle     =   1
         Appearance      =   1
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         NumItems        =   2
         BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            Text            =   "Type"
            Object.Width           =   961
         EndProperty
         BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            SubItemIndex    =   1
            Text            =   "Extensions"
            Object.Width           =   4718
         EndProperty
      End
   End
   Begin VB.PictureBox pic 
      Appearance      =   0  'Flat
      ForeColor       =   &H80000008&
      Height          =   2895
      Index           =   4
      Left            =   1680
      ScaleHeight     =   2865
      ScaleWidth      =   3585
      TabIndex        =   30
      Tag             =   "Filelist"
      Top             =   120
      Visible         =   0   'False
      Width           =   3615
      Begin VB.CheckBox chkShowTime 
         Caption         =   "Show &Time with Date"
         Height          =   255
         Left            =   480
         TabIndex        =   66
         Top             =   720
         Width           =   2175
      End
      Begin VB.CheckBox chkBgd 
         Caption         =   "Use Background Image"
         Height          =   255
         Left            =   1200
         TabIndex        =   13
         Top             =   1080
         Width           =   2055
      End
      Begin VB.TextBox txtBgd 
         Height          =   360
         Left            =   1200
         TabIndex        =   14
         Top             =   1440
         Width           =   2175
      End
      Begin VB.CommandButton cmdLvwFont 
         Caption         =   "Set &Font"
         Height          =   320
         Left            =   2400
         TabIndex        =   15
         Top             =   2277
         Width           =   975
      End
      Begin VB.CheckBox chkLvwGrid 
         Caption         =   "View &Gridlines for Filelists"
         Height          =   255
         Left            =   480
         TabIndex        =   12
         Top             =   480
         Width           =   2175
      End
      Begin VB.CheckBox chkLvwExtn 
         Caption         =   "View only File &Extensions"
         Height          =   255
         Left            =   480
         TabIndex        =   11
         Top             =   240
         Width           =   2175
      End
      Begin VB.Shape Shp 
         Height          =   735
         Left            =   240
         Top             =   1080
         Width           =   735
      End
      Begin VB.Image imBgd 
         Enabled         =   0   'False
         Height          =   735
         Left            =   240
         Stretch         =   -1  'True
         Top             =   1080
         Width           =   735
      End
      Begin VB.Label lblLvw 
         AutoSize        =   -1  'True
         Caption         =   "Foreground Colour"
         Height          =   195
         Index           =   2
         Left            =   840
         TabIndex        =   35
         Top             =   2340
         Width           =   1350
      End
      Begin VB.Label lblColLvwFore 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BorderStyle     =   1  'Fixed Single
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   480
         TabIndex        =   34
         Top             =   2310
         Width           =   255
      End
      Begin VB.Label lblLvw 
         AutoSize        =   -1  'True
         Caption         =   "Background Colour"
         Height          =   195
         Index           =   1
         Left            =   840
         TabIndex        =   33
         Top             =   2025
         Width           =   1350
      End
      Begin VB.Label lblColLvwBack 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BorderStyle     =   1  'Fixed Single
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   480
         TabIndex        =   32
         Top             =   1995
         Width           =   255
      End
   End
   Begin VB.PictureBox pic 
      Appearance      =   0  'Flat
      ForeColor       =   &H80000008&
      Height          =   2895
      Index           =   3
      Left            =   1680
      ScaleHeight     =   2865
      ScaleWidth      =   3585
      TabIndex        =   46
      Tag             =   "Filelist"
      Top             =   120
      Visible         =   0   'False
      Width           =   3615
      Begin VB.Frame Frame1 
         Caption         =   "Media Files"
         Height          =   1035
         Left            =   240
         TabIndex        =   62
         Top             =   1140
         Width           =   3135
         Begin VB.CheckBox chkAudioSwitch 
            Caption         =   "Switch to Horizontal to play Audio"
            Height          =   255
            Left            =   240
            TabIndex        =   65
            Top             =   720
            Width           =   2775
         End
         Begin VB.CheckBox chkMediaBlock 
            Caption         =   "Block Scripts and URL Popups"
            Height          =   255
            Left            =   240
            TabIndex        =   64
            Top             =   480
            Width           =   2415
         End
         Begin VB.CheckBox chkMediaFrame 
            Caption         =   "Show Frame Count"
            Height          =   255
            Left            =   240
            TabIndex        =   63
            Top             =   240
            Width           =   2175
         End
      End
      Begin VB.CommandButton cmdTextFont 
         Caption         =   "Text &Font"
         Height          =   320
         Left            =   2160
         TabIndex        =   59
         Top             =   2307
         Width           =   975
      End
      Begin VB.TextBox txtTimer 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BorderStyle     =   0  'None
         Height          =   240
         Left            =   1995
         TabIndex        =   56
         Text            =   "999"
         Top             =   840
         Width           =   435
      End
      Begin VB.Label lblTxt 
         AutoSize        =   -1  'True
         Caption         =   "Text Background"
         Height          =   195
         Index           =   1
         Left            =   840
         TabIndex        =   61
         Top             =   2370
         Width           =   1215
      End
      Begin VB.Label lblColTextBack 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BorderStyle     =   1  'Fixed Single
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   480
         TabIndex        =   60
         Top             =   2340
         Width           =   255
      End
      Begin VB.Label lblOpt 
         AutoSize        =   -1  'True
         Caption         =   "Change Slide every"
         Height          =   195
         Index           =   1
         Left            =   480
         TabIndex        =   58
         Top             =   870
         Width           =   1395
      End
      Begin VB.Label lblOpt 
         AutoSize        =   -1  'True
         Caption         =   "sec(s)"
         Height          =   195
         Index           =   0
         Left            =   2550
         TabIndex        =   57
         Top             =   870
         Width           =   435
      End
      Begin VB.Label lblColFScrBgd 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BorderStyle     =   1  'Fixed Single
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   480
         TabIndex        =   50
         Top             =   450
         Width           =   255
      End
      Begin VB.Label lblOpt 
         AutoSize        =   -1  'True
         Caption         =   "Full Screen Background Colour"
         Height          =   195
         Index           =   3
         Left            =   840
         TabIndex        =   49
         Top             =   480
         Width           =   2175
      End
      Begin VB.Label lblOpt 
         AutoSize        =   -1  'True
         Caption         =   "Window Background Colour"
         Height          =   195
         Index           =   2
         Left            =   840
         TabIndex        =   48
         Top             =   180
         Width           =   1965
      End
      Begin VB.Label lblColBgd 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BorderStyle     =   1  'Fixed Single
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   480
         TabIndex        =   47
         Top             =   150
         Width           =   255
      End
   End
   Begin VB.PictureBox pic 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   2895
      Index           =   2
      Left            =   1680
      ScaleHeight     =   2865
      ScaleWidth      =   3585
      TabIndex        =   37
      Top             =   120
      Visible         =   0   'False
      Width           =   3615
      Begin VB.Frame framTitleCaption 
         Caption         =   "View Titlebar Caption as:"
         Height          =   615
         Left            =   240
         TabIndex        =   52
         Top             =   2040
         Width           =   3135
         Begin VB.OptionButton optCaption 
            Caption         =   "File &Name"
            Height          =   255
            Index           =   3
            Left            =   1800
            TabIndex        =   55
            Top             =   240
            Width           =   1095
         End
         Begin VB.OptionButton optCaption 
            Caption         =   "&Full"
            Height          =   255
            Index           =   1
            Left            =   240
            TabIndex        =   54
            Top             =   240
            Width           =   615
         End
         Begin VB.OptionButton optCaption 
            Caption         =   "&Path"
            Height          =   255
            Index           =   2
            Left            =   960
            TabIndex        =   53
            Top             =   240
            Width           =   735
         End
      End
      Begin VB.CheckBox chkTBarCaptions 
         Caption         =   "View Captions for Toolbar"
         Height          =   255
         Left            =   480
         TabIndex        =   10
         Top             =   1740
         Width           =   2175
      End
      Begin VB.CheckBox chkHtmlAsText 
         Caption         =   "Show HTML files as Text"
         Height          =   255
         Left            =   480
         TabIndex        =   8
         Top             =   1260
         Width           =   2175
      End
      Begin VB.CheckBox chkSortHistory 
         Caption         =   "Sort Folder History by &Time"
         Height          =   255
         Left            =   480
         TabIndex        =   9
         Top             =   1500
         Width           =   2295
      End
      Begin VB.Frame framStartup 
         Caption         =   "During Startup,"
         Height          =   1035
         Left            =   240
         TabIndex        =   38
         Top             =   120
         Width           =   3135
         Begin VB.CheckBox chkStartFilelists 
            Caption         =   "Load Default &Filelists"
            Height          =   255
            Left            =   240
            TabIndex        =   7
            Top             =   720
            Width           =   1815
         End
         Begin VB.CheckBox chkStartFolder 
            Caption         =   "Load Folder &History"
            Height          =   255
            Left            =   240
            TabIndex        =   6
            Top             =   480
            Width           =   1695
         End
         Begin VB.CheckBox chkStartSplash 
            Caption         =   "Show &Splash Screen"
            Height          =   255
            Left            =   240
            TabIndex        =   5
            Top             =   240
            Width           =   1815
         End
      End
   End
   Begin VB.TextBox txtRtb 
      Height          =   375
      IMEMode         =   3  'DISABLE
      Left            =   360
      TabIndex        =   42
      TabStop         =   0   'False
      Text            =   "Text"
      Top             =   1200
      Visible         =   0   'False
      Width           =   735
   End
   Begin VB.PictureBox picImg 
      BorderStyle     =   0  'None
      Height          =   495
      Left            =   360
      ScaleHeight     =   495
      ScaleWidth      =   735
      TabIndex        =   41
      TabStop         =   0   'False
      Top             =   2160
      Visible         =   0   'False
      Width           =   735
   End
   Begin VB.TextBox txtLvwFont 
      Height          =   375
      Left            =   360
      TabIndex        =   40
      TabStop         =   0   'False
      Text            =   "Lvws"
      Top             =   1680
      Visible         =   0   'False
      Width           =   735
   End
   Begin MSComctlLib.TreeView tvw 
      Height          =   3435
      Left            =   60
      TabIndex        =   0
      Top             =   60
      Width           =   1395
      _ExtentX        =   2461
      _ExtentY        =   6059
      _Version        =   393217
      HideSelection   =   0   'False
      Indentation     =   168
      LabelEdit       =   1
      Sorted          =   -1  'True
      Style           =   7
      Appearance      =   1
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.CommandButton cmdApply 
      Caption         =   "&Apply"
      Height          =   375
      Left            =   3990
      TabIndex        =   29
      Top             =   3120
      Width           =   975
   End
   Begin VB.CommandButton cmdCancel 
      Cancel          =   -1  'True
      Caption         =   "&Cancel"
      Height          =   375
      Left            =   2895
      TabIndex        =   28
      Top             =   3120
      Width           =   975
   End
   Begin VB.CommandButton cmdOk 
      Caption         =   "&OK"
      Height          =   375
      Left            =   1800
      TabIndex        =   27
      Top             =   3120
      Width           =   975
   End
   Begin VB.Menu menuFaves 
      Caption         =   "Options"
      Visible         =   0   'False
      Begin VB.Menu mnuFaves 
         Caption         =   "&Remove [Del]"
         Index           =   1
      End
      Begin VB.Menu mnuFaves 
         Caption         =   "Move &Up [F6]"
         Index           =   2
      End
      Begin VB.Menu mnuFaves 
         Caption         =   "Move &Down [F7]"
         Index           =   3
      End
      Begin VB.Menu mnuFaves 
         Caption         =   "&Sort"
         Index           =   4
      End
   End
End
Attribute VB_Name = "frmOptions"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

'dim all fonts coz they cant just be saved as a tag
Dim clr As Long
Dim isEditExtn As Boolean

Dim Ctrl As Control 'for favorites' lvw control


Private Sub chkAudioSwitch_Click()
If chkAudioSwitch.Value = 1 Then chkAudioSwitch.Tag = "True" Else chkAudioSwitch.Tag = "False"
cmdApply.Enabled = True
End Sub

Private Sub chkBgd_Click()
If chkBgd.Value = 1 Then
  imBgd.Enabled = True: chkBgd.Tag = "True": txtBgd.Enabled = True
  txtBgd.Tag = txtBgd.Text
  If txtBgd.Text = "" Then imBgd_Click
Else
  chkBgd.Tag = "False": imBgd.Enabled = False: txtBgd.Enabled = False
  txtBgd.Tag = ""
End If
cmdApply.Enabled = True
End Sub

Private Sub chkHtmlAsText_Click()
If chkHtmlAsText.Value = 1 Then chkHtmlAsText.Tag = "True" Else chkHtmlAsText.Tag = "False"
cmdApply.Enabled = True
End Sub

Private Sub chkLvwExtn_Click()
If chkLvwExtn.Value = 1 Then chkLvwExtn.Tag = "True" Else chkLvwExtn.Tag = "False"
cmdApply.Enabled = True
End Sub

Private Sub chkLvwGrid_Click()
If chkLvwGrid.Value = 1 Then chkLvwGrid.Tag = "True" Else chkLvwGrid.Tag = "False"
cmdApply.Enabled = True
End Sub

Private Sub chkMediaBlock_Click()
If chkMediaBlock.Value = 1 Then chkMediaBlock.Tag = "True" Else chkMediaBlock.Tag = "False"
cmdApply.Enabled = True
End Sub

Private Sub chkMediaFrame_Click()
If chkMediaFrame.Value = 1 Then chkMediaFrame.Tag = "True" Else chkMediaFrame.Tag = "False"
cmdApply.Enabled = True
End Sub

Private Sub chkShowTime_Click()
If chkShowTime.Value = 1 Then chkShowTime.Tag = "True" Else chkShowTime.Tag = "False"
cmdApply.Enabled = True
End Sub

Private Sub chkSortHistory_Click()
  'mnuHistorySortTime.Checked = Not mnuHistorySortTime.Checked
  If chkSortHistory.Value = 0 Then
    MsgBox "History will be sorted alphabetically properly from the next time the program runs."
    chkSortHistory.Tag = "False"
  Else
    chkSortHistory.Tag = "True"
  End If
cmdApply.Enabled = True
End Sub

Private Sub chkStartFilelists_Click()
If chkStartFilelists.Value = 1 Then chkStartFilelists.Tag = "True" Else chkStartFilelists.Tag = "False"
cmdApply.Enabled = True
End Sub

Private Sub chkStartFolder_Click()
If chkStartFolder.Value = 1 Then chkStartFolder.Tag = "True" Else chkStartFolder.Tag = "False"
cmdApply.Enabled = True
End Sub

Private Sub chkStartSplash_Click()
If chkStartSplash.Value = 1 Then chkStartSplash.Tag = "True" Else chkStartSplash.Tag = "False"
cmdApply.Enabled = True
End Sub

Private Sub chkTBarCaptions_Click()
If chkTBarCaptions.Value = 1 Then chkTBarCaptions.Tag = "True" Else chkTBarCaptions.Tag = "False"
cmdApply.Enabled = True
End Sub

Private Sub chkTrashConfirm_Click()
If chkTrashConfirm.Value = 1 Then chkTrashConfirm.Tag = "True" Else chkTrashConfirm.Tag = "False"
cmdApply.Enabled = True
End Sub

Private Sub chkTrashEnable_Click()
If chkTrashEnable.Value = 1 Then chkTrashEnable.Tag = "True" Else chkTrashEnable.Tag = "False"
cmdApply.Enabled = True
End Sub

Private Sub cmdApply_Click()
'no need to do anything for actions but for all other options
'pane by pane seeing if all controls on it's tag <> "" then saving and or updating change

'action options - 1
If chkSortHistory.Tag <> "" Then Vdplayer.viViewHistoryByTime = chkSortHistory.Tag
  SaveSetting apComp, apProd, "Sort History By Viewed Order", Vdplayer.viViewHistoryByTime

'general options -2
  If chkStartSplash.Tag <> "" Then SaveSetting apComp, apProd, "Show Splash Screen", chkStartSplash.Tag
  If chkStartFolder.Tag <> "" Then SaveSetting apComp, apProd, "RemFolder", chkStartFolder.Tag
  If chkStartFilelists.Tag <> "" Then SaveSetting apComp, apProd, "RemFilelist", chkStartFilelists.Tag
  If chkTBarCaptions.Tag <> "" Then SaveSetting apComp, apProd, "Toolbar.Caption", chkTBarCaptions.Tag: Vdplayer.doTBarCaption
  If txtTimer.Tag <> "" Then Vdplayer.Tmr.Interval = Val(txtTimer.Tag) * 1000: SaveSetting apComp, apProd, "Timer", Vdplayer.Tmr.Interval
  If lblColBgd.Tag <> "" Then Vdplayer.conViewer.BackColor = lblColBgd.BackColor:   SaveSetting apComp, apProd, "Background Color", lblColBgd.BackColor
  If lblColFScrBgd.Tag <> "" Then SaveSetting apComp, apProd, "Full Screen Background Color", lblColFScrBgd.BackColor
  If chkHtmlAsText.Tag <> "" Then
    Vdplayer.viShowHtmlAsText = chkHtmlAsText.Tag
    SaveSetting apComp, apProd, "ShowHtmlAsText", Vdplayer.viShowHtmlAsText
    If Vdplayer.CurFile <> "" And InStr(Vdplayer.strHtml, fso.GetExtensionName(Vdplayer.CurFile)) <> 0 Then Vdplayer.CrlClick
  End If
  
  'media options
  If chkMediaBlock.Tag <> "" Then Vdplayer.ani.InvokeURLs = chkMediaBlock.Tag: _
    SaveSetting apComp, apProd, "Media BlockURLs", chkMediaBlock.Tag
  If chkMediaFrame.Tag <> "" Then SaveSetting apComp, apProd, "Media ViewFrames", chkMediaFrame.Tag: _
    If chkMediaFrame.Value = 0 Then Vdplayer.ani.DisplayMode = mpTime Else Vdplayer.ani.DisplayMode = mpFrames
  If chkAudioSwitch.Tag <> "" Then Vdplayer.viChangeHorz = chkAudioSwitch.Tag: _
    SaveSetting apComp, apProd, "Switch Horizontal for Audio", chkAudioSwitch.Tag

'filelist options -3
  'lvws background images
  SaveSetting apComp, apProd & "\File List", "Background Image", txtBgd.Tag
  Vdplayer.icoLarge.BackColor = lblColLvwBack.BackColor: Vdplayer.icoSmall.BackColor = lblColLvwBack.BackColor

  'lvws font (from txtLvwFont)
  Dim dLvw
  For Each dLvw In Vdplayer.lvw
    dLvw.Font.Name = txtLvwFont.Font.Name
    dLvw.Font.Size = txtLvwFont.Font.Size
    dLvw.Font.Bold = txtLvwFont.Font.Bold
    dLvw.Font.Italic = txtLvwFont.Font.Italic
    dLvw.Font.Underline = txtLvwFont.Font.Underline
    dLvw.ForeColor = lblColLvwFore.BackColor
    dLvw.BackColor = lblColLvwBack.BackColor
    If chkLvwGrid.Tag <> "" Then dLvw.GridLines = chkLvwGrid.Tag
    Set dLvw.Picture = LoadPicture("")
    dLvw.BackColor = lblColLvwBack.BackColor
    Set dLvw.Picture = LoadPicture(txtBgd.Tag)
    DoEvents
    dLvw.Refresh
  Next
  
  If chkLvwGrid.Tag <> "" Then SaveSetting apComp, apProd & "\File List", "Gridlines", chkLvwGrid.Tag
  If chkLvwExtn.Tag <> "" Then Vdplayer.viLvwExtension = chkLvwExtn.Tag: doLvwExt: SaveSetting apComp, apProd & "\File List", "Extension", chkLvwExtn.Tag
  If chkShowTime.Tag <> "" Then Vdplayer.viShowTime = chkShowTime.Tag: doLvwTim: SaveSetting apComp, apProd, "Show Time", chkShowTime.Tag
  If chkBgd.Tag <> "" Then SaveSetting apComp, apProd & "\File List", "View Background Image", chkBgd.Tag
  SaveSetting apComp, apProd & "\File List", "BackColor", lblColLvwBack.BackColor
  SaveSetting apComp, apProd & "\File List", "ForeColor", lblColLvwFore.BackColor
  SaveSetting apComp, apProd & "\File List", "Font", txtLvwFont.Font
  SaveSetting apComp, apProd & "\File List", "FontSize", txtLvwFont.Font.Size

'title bar options
  Dim i As Byte
  For i = 1 To 3
    If optCaption(i).Value = True Then Vdplayer.viTitle = i
  Next
  If Vdplayer.viTitle = 1 Then Vdplayer.Caption = apComp & " " & apProd & " - " & Vdplayer.CurFile & " "
  If Vdplayer.viTitle = 2 Then Vdplayer.Caption = Vdplayer.CurFile & " "
  If Vdplayer.viTitle = 3 Then Vdplayer.Caption = fso.GetFileName(Vdplayer.CurFile) & " "

  SaveSetting apComp, apProd, "Scroll What", Vdplayer.viTitle

'trash options
  If chkTrashEnable.Tag <> "" Then SaveSetting apComp, apProd, "Trash Enable", chkTrashEnable.Tag
  If chkTrashConfirm.Tag <> "" Then SaveSetting apComp, apProd, "Trash Confirm", chkTrashConfirm.Tag
  
  If txtTrashLoc.Tag <> "" Then Vdplayer.TxtTrash = txtTrashLoc: SaveSetting apComp, apProd, "trashloc", txtTrashLoc
  
'text (rtb) options
  With Vdplayer.rtb
    SaveSetting apComp, apProd, "Text.Font.Name", txtRtb.Font.Name
      .Font.Name = txtRtb.Font.Name
    SaveSetting apComp, apProd, "Text.Font.Size", txtRtb.Font.Size
      .Font.Size = txtRtb.Font.Size
    SaveSetting apComp, apProd, "Text.Font.Bold", txtRtb.Font.Bold
      .Font.Bold = txtRtb.Font.Bold
    SaveSetting apComp, apProd, "Text.Font.Italic", txtRtb.Font.Italic
      .Font.Italic = txtRtb.Font.Italic
    SaveSetting apComp, apProd, "Text.Font.Underline", txtRtb.Font.Underline
      .Font.Underline = txtRtb.Font.Underline
    SaveSetting apComp, apProd, "Text.Font.Strikethrough", txtRtb.Font.Strikethrough
      .Font.Strikethrough = txtRtb.Font.Strikethrough
    SaveSetting apComp, apProd, "Text.BackColor", lblColTextBack.BackColor
      .BackColor = lblColTextBack.BackColor
  End With

'favorites options
If pic(7).Tag = "Changed" Then
  SaveSetting apComp, apProd & "\Favorite Folders", "Folder Count", lst(1).ListItems.Count
  For i = 1 To lst(1).ListItems.Count
    SaveSetting apComp, apProd & "\Favorite Folders", "Folder " & i, lst(1).ListItems.Item(i).Text
  Next
  SaveSetting apComp, apProd & "\Favorite Files", "Filelist Count", lst(2).ListItems.Count
  For i = 1 To lst(2).ListItems.Count
    SaveSetting apComp, apProd & "\Favorite Files", "Filelist " & i, lst(2).ListItems.Item(i).Text
  Next
  Vdplayer.LoadFaves
  pic(7).Tag = ""
End If

cmdApply.Enabled = False
'MsgBox "Changes took " & DateDiff("s", tim, Now) & " secs to apply."
End Sub

Private Sub doLvwExt()
On Error Resume Next
Dim strCap As String
If Vdplayer.viLvwExtension = False Then strCap = "Type" Else: strCap = "Ext"

Dim dLvw, itm As ListItem, fil As File
For Each dLvw In Vdplayer.lvw
  dLvw.ColumnHeaders(3).Text = strCap
  
  For Each itm In dLvw.ListItems
  If fso.FileExists(itm.Key) Then
    Set fil = fso.GetFile(itm.Key)
    If Vdplayer.viLvwExtension Then
      itm.SubItems(2) = fso.GetExtensionName(fil.path)
    Else
      If fil.Type <> "File" Then itm.SubItems(2) = fil.Type
    End If
  Else
    itm.SubItems(2) = fso.GetExtensionName(itm.Key)
  End If
  Next
Next
End Sub

Private Sub doLvwTim()
Dim dLvw, itm As ListItem, fil As File
For Each dLvw In Vdplayer.lvw
  For Each itm In dLvw.ListItems
  If fso.FileExists(itm.Key) Then
    Set fil = fso.GetFile(itm.Key)
    If Vdplayer.viShowTime Then
      itm.SubItems(3) = fil.DateLastModified
    Else
      itm.SubItems(3) = Format(fil.DateLastModified, "dd mmm yy")
    End If
  End If
  Next
Next
End Sub

Private Sub cmdCancel_Click()
If cmdApply.Enabled = True Then
  Dim m As VbMsgBoxResult
    m = MsgBox("Are you sure you want to exit the options dialog" & vbCrLf & "without updating all your option changes?", vbQuestion + vbYesNo)
    If m = vbYes Then Unload Me
Else
  Unload Me
End If
End Sub

Private Sub cmdClearFilterHistory_Click()
Dim m As VbMsgBoxResult
  m = MsgBox("Are you sure you want to clear Filter History?" & vbCrLf & "This action cannot be undone.", vbYesNo + vbQuestion)
  If m = vbNo Then Exit Sub
DeleteSetting apComp, apProd & "\Filter History"
Do Until Vdplayer.cmbFilter.ListCount = 8
  Vdplayer.cmbFilter.RemoveItem Vdplayer.cmbFilter.ListCount - 1
Loop
End Sub

Private Sub cmdClearFolderHistory_Click()
Dim m As VbMsgBoxResult
  m = MsgBox("Are you sure you want to clear Folder History?" & vbCrLf & "This action cannot be undone.", vbYesNo + vbQuestion)
  If m = 6 Then Vdplayer.cmbHistory.ComboItems.Clear: Vdplayer.lstSort.Clear: Vdplayer.SetHistoryFolder Mid(Vdplayer.lvw(1).Tag, 1, Len(Vdplayer.lvw(1).Tag) - 1)
End Sub

Private Sub cmdClearSearchFolHistory_Click()
Dim m As VbMsgBoxResult
m = MsgBox("Are you sure you want to remove folders " & vbCrLf & "that have been reecntly searched" & vbCrLf & "in from the 'Search In' combobox?", vbYesNo + vbQuestion)
If m = vbNo Then Exit Sub
  SaveSetting apComp & "\" & apProd, "Search Folders", "Folder Count", 0
With Vdplayer.cmbSearchIn
  If .SelectedItem.Index > .ComboItems("Browse").Index Then .ComboItems("Hard Drives").Selected = True
  Do Until .ComboItems.Count = .ComboItems("Browse").Index
    .ComboItems.Remove (.ComboItems("Browse").Index + 1)
  Loop
  SaveSetting apComp & "\" & apProd, "Search Folders", "Folder Count", 0

End With
MsgBox "Search History Cleared", vbInformation
End Sub

Private Sub cmdClearSearchHistory_Click()
Dim m As VbMsgBoxResult
  m = MsgBox("Are you sure you want to clear Search Text History?" & vbCrLf & "This action cannot be undone.", vbYesNo + vbQuestion)
  If m = vbNo Then Exit Sub
DeleteSetting apComp, apProd & "\Search History"
Do Until Vdplayer.cmbSearch.ListCount = 8
  Vdplayer.cmbSearch.RemoveItem Vdplayer.cmbSearch.ListCount - 1
Loop
End Sub



Private Sub cmdClearTimeLibrary_Click()
Dim m As VbMsgBoxResult
m = MsgBox("Sure you want to clear ALL ENTRIES in Time Library?" & vbCrLf & _
"'No' will clear records of files no longer present" & vbCrLf & vbCrLf & _
"The Time Library keeps track of the duration of media files", vbYesNoCancel + vbQuestion, "Clear Time Library")

If m = vbCancel Then
  Exit Sub
ElseIf m = vbYes Then
  DeleteSetting apComp, apProd & "\Time Library"
ElseIf m = vbNo Then
  Dim strPaths As Variant, i As Integer
  On Error Resume Next
  strPaths = GetAllSettings(apComp, apProd & "\Time Library")
  If IsEmpty(strPaths) Then Exit Sub
  For i = LBound(strPaths, 1) To UBound(strPaths, 1)
    If fso.FileExists(strPaths(i, 0)) = False Then DeleteSetting apComp, apPath & "\Time Library", strPaths(i, 0)
  Next
End If
End Sub

Private Sub cmdLvwFont_Click()
  ShowFont Me, txtLvwFont
  'lblColLvwFore.BackColor = txtLvwFont.ForeColor  'not sure thisll work i think clr dlg can have only intrinsic vb colors
cmdApply.Enabled = True
End Sub

Private Sub cmdOK_Click()
  If cmdApply.Enabled = True Then cmdApply_Click
  Unload Me
End Sub

Private Sub cmdRemoveInvalidFolders_Click()
Dim m  As VbMsgBoxResult, i As Integer, remdrv As String, drv As Drive
m = MsgBox("Would You like to clear Folders on removable drives as well?", vbYesNo + vbQuestion, "Remove Removable folders")

For Each drv In fso.Drives
If drv.DriveType = Removable Or drv.DriveType = CDRom Then remdrv = remdrv & LCase(drv.DriveLetter) & ":,"
Next
'remdrv = ""
  i = 1
With Vdplayer.cmbHistory
  Do Until i > .ComboItems.Count
    If m = vbNo And InStr(remdrv, fso.GetDriveName(.ComboItems(i).Key)) <> 0 Then i = i + 1: GoTo Nxt
    If fso.FolderExists(.ComboItems(i).Key) = False Then .ComboItems.Remove (i) Else i = i + 1
Nxt:
  Loop
  
  Vdplayer.lstSort.Clear
  Dim cmbItm As ComboItem
  For Each cmbItm In .ComboItems
    Vdplayer.lstSort.AddItem cmbItm.Key
  Next
  If Vdplayer.lstSort.ListCount <> .ComboItems.Count Then _
    MsgBox "IViewer created a disparity in Folder History. This may manifest as missing items or improper sorting.", vbInformation
End With
MsgBox "Invalid Folders Removed", vbInformation
End Sub

Private Sub cmdTextFont_Click()
ShowFont Me, txtRtb
cmdApply.Enabled = True
End Sub

Private Sub cmdTrashClear_Click()
Dim fldr As Folder, m As VbMsgBoxResult
m = MsgBox("Sure you wanna empty trash can?" & vbCrLf & Vdplayer.TxtTrash & vbCrLf & "This action is ireversible.", vbQuestion + vbYesNo)
If fso.FolderExists(Vdplayer.TxtTrash) Then Else MsgBox "'" & Vdplayer.TxtTrash & "' does not exist. Click OK to continue.": Exit Sub
If m = 6 Then
  Set fldr = fso.GetFolder(Vdplayer.TxtTrash)
  fldr.Delete
  fso.CreateFolder (Vdplayer.TxtTrash)
End If
End Sub

Private Sub cmdTrashSet_Click()
Dim fl As String
fl = ShowFolder(Me, "Select folder for Trash.", Vdplayer.TxtTrash)
If fl = "" Then Exit Sub
Vdplayer.TrashChk (fl)
txtTrashLoc = fl: txtTrashLoc.ToolTipText = fl: txtTrashLoc.Tag = fl
cmdApply.Enabled = True
End Sub

Private Sub cmdTrashView_Click()
Vdplayer.TrashChk Vdplayer.TxtTrash
Shell "explorer.exe /e," & GetSetting(apComp, apProd, "trashloc", apPath & "\trash"), vbMaximizedFocus
End Sub


Private Sub cmdUpdateExtension_Click()

Dim str As String, m As VbMsgBoxResult  'YesNoCancel ''typ As String, ip As String,

'indices must be verified

m = MsgBox("Are you sure you wish to change the extensions " & vbCrLf & "    associated with files of type " & lvw.SelectedItem.Text & "." & vbCrLf & _
      "No will update to default extensions." & vbCrLf & "Cancel will revert to original", vbYesNoCancel + vbQuestion, "Extension change confirmation")
If m = vbCancel Then
  txtExtension = lvw.SelectedItem.SubItems(1)
  cmdUpdateExtension.Enabled = False
  Exit Sub
ElseIf m = vbNo Then
  Select Case lvw.SelectedItem.Text
  Case "Audio"
    str = "*.mp3;*.wav;*.mid;*.m3u;*.wma"
  Case "Html"
    str = "*.html;*.htm;*.php;*.asp"
  Case "Image"
    str = "*.bmp;*.jpg;*.gif;*.jpeg"
  Case "Office"
    str = "*.doc;*.xls"
  Case "Text"
    str = "*.txt;*.log;*.dat;*.nfo;*.ini;*.bat"
  Case "Video"
    str = "*.avi;*.mpg;*.mpeg;*.asf"
  End Select
Else
  'must try to validate if first
  str = txtExtension
End If

Select Case lvw.SelectedItem.Text
  Case "Audio"
    Vdplayer.strAud = str
  Case "Html"
    Vdplayer.strHtml = str
  Case "Image"
    Vdplayer.strImg = str
  Case "Office"
    Vdplayer.strOff = str
  Case "Text"
    Vdplayer.strText = str
  Case "Video"
    Vdplayer.strVid = str
End Select
  SaveSetting apComp, apProd & "\Extensions", lvw.SelectedItem.Text, str

lvw.SelectedItem.SubItems(1) = str
cmdUpdateExtension.Enabled = False

Vdplayer.loadExtensions
End Sub

Private Sub Form_Load()
'imBgd(2).BorderStyle = 1: Shp(2).Visible = False

tvw.Nodes.Clear
tvw.Nodes.Add , tvwChild, , "Actions" '1

tvw.Nodes.Add , , "Options", "Options" '2
tvw.Nodes("Options").Expanded = True
  If True = GetSetting(apComp, apProd, "Show Splash Screen", True) Then chkStartSplash.Value = 1
  If True = GetSetting(apComp, apProd, "RemFilelist", True) Then chkStartFilelists.Value = 1
  If True = GetSetting(apComp, apProd, "RemFolder", True) Then chkStartFolder.Value = 1

  optCaption(Vdplayer.viTitle).Value = True
  
  If True = GetSetting(apComp, apProd, "Toolbar.Caption", True) Then chkTBarCaptions.Value = 1
  If Vdplayer.viViewHistoryByTime = True Then chkSortHistory.Value = 1
  If Vdplayer.viShowHtmlAsText Then chkHtmlAsText.Value = 1
  
  'media
  If True = GetSetting(apComp, apProd, "Media BlockURLs", True) Then chkMediaBlock.Value = 1
  If False = GetSetting(apComp, apProd, "Media ViewFrames", False) Then chkMediaFrame.Value = 1
  If True = Vdplayer.viChangeHorz Then chkAudioSwitch.Value = 1

tvw.Nodes.Add "Options", tvwChild, "General", "General" '3
  Vdplayer.loadRtbFont txtRtb
  txtTimer = GetSetting(apComp, apProd, "Timer", 1000) / 1000
  
  lblColBgd.BackColor = Vdplayer.conViewer.BackColor
  lblColFScrBgd.BackColor = GetSetting(apComp, apProd, "Full Screen Background Color", 14737632)
  lblColTextBack.BackColor = Vdplayer.rtb.BackColor
  
tvw.Nodes.Add "Options", tvwChild, "File List", "File List" '4
  If True = GetSetting(apComp, apProd & "\File List", "Extension", True) Then chkLvwExtn.Value = 1
  If True = GetSetting(apComp, apProd & "\File List", "Gridlines", "False") Then chkLvwGrid.Value = 1
  If Vdplayer.viShowTime Then chkShowTime.Value = 1
  If True = GetSetting(apComp, apProd & "\File List", "View Background Image", False) Then chkBgd.Value = 1: chkBgd_Click
  BgdSet GetSetting(apComp, apProd & "\File List", "Background Image")
  txtBgd.Tag = GetSetting(apComp, apProd & "\File List", "Background Image")
  lblColLvwBack.BackColor = Vdplayer.lvw(1).BackColor
  lblColLvwFore.BackColor = Vdplayer.lvw(1).ForeColor
  txtLvwFont.ForeColor = lblColLvwFore.BackColor
  txtLvwFont.Font.Name = Vdplayer.lvw(1).Font.Name
  txtLvwFont.Font.Size = Vdplayer.lvw(1).Font.Size

tvw.Nodes.Add "Options", tvwChild, , "Extensions" '5
  lvw.ListItems.Add lvw.ListItems.Count + 1, , "Audio"
    lvw.ListItems(lvw.ListItems.Count).SubItems(1) = Vdplayer.strAud
  lvw.ListItems.Add lvw.ListItems.Count + 1, , "Html"
    lvw.ListItems(lvw.ListItems.Count).SubItems(1) = Vdplayer.strHtml
  lvw.ListItems.Add lvw.ListItems.Count + 1, , "Image"
    lvw.ListItems(lvw.ListItems.Count).SubItems(1) = Vdplayer.strImg
  lvw.ListItems.Add lvw.ListItems.Count + 1, , "Office"
    lvw.ListItems(lvw.ListItems.Count).SubItems(1) = Vdplayer.strOff
  lvw.ListItems.Add lvw.ListItems.Count + 1, , "Text"
    lvw.ListItems(lvw.ListItems.Count).SubItems(1) = Vdplayer.strText
  lvw.ListItems.Add lvw.ListItems.Count + 1, , "Video"
    lvw.ListItems(lvw.ListItems.Count).SubItems(1) = Vdplayer.strVid

tvw.Nodes.Add "Options", tvwChild, , "Trash Can" '6
  If True = GetSetting(apComp, apProd, "Trash Enable", True) Then chkTrashEnable.Value = 1
  If True = GetSetting(apComp, apProd, "Trash Confirm", True) Then chkTrashConfirm.Value = 1
  txtTrashLoc = Vdplayer.TxtTrash

tvw.Nodes.Add , tvwChild, "Favorites", "Favorites" '7
  tvw.Nodes("Favorites").Expanded = True
  tvw.Nodes.Add "Favorites", tvwChild, "Folders", "Folders"
  tvw.Nodes.Add "Favorites", tvwChild, "Playlists", "Playlists"

tvw.Nodes(CInt(GetSetting(apComp, apProd, "Options Tab Index", 3))).Selected = True
If tvw.SelectedItem.Index > 7 Then pic(7).Visible = True: LoadFaves Else pic(tvw.SelectedItem.Index).Visible = True
If tvw.SelectedItem.Index = 10 Then lst(1).Visible = True
If tvw.SelectedItem.Index = 11 Then lst(2).Visible = True
cmdApply.Enabled = False
End Sub

Private Sub Form_Resize()
lst(1).ColumnHeaders(1).Width = lst(1).Width - 300
lst(2).ColumnHeaders(1).Width = lst(2).Width - 300
End Sub

Private Sub Form_Unload(Cancel As Integer)
SaveSetting apComp, apProd, "Options Tab Index", tvw.SelectedItem.Index
End Sub

Private Sub imBgd_Click()
On Error Resume Next
Dim fn As String, slst As String
'must be able to tell user if selected file is an image or not
  
  If fso.FileExists(GetSetting(apComp, apProd & "\File List", "Background Image")) Then slst = GetSetting(apComp, apProd & "\File List", "Background Image") Else slst = apPath
  fn = ShowFileOpenSave(Me, True, Shp.Tag, slst, "Images (" & Vdplayer.strImg & ")" & Chr(0) & Vdplayer.strImg & Chr(0) & "All files(*.*)" & Chr(0) & "*.*", , , OpenSaveFlag.OFN_HIDEREADONLY)
  If fso.FileExists(fn) Then BgdSet fn
End Sub

Private Sub BgdSet(fil As String)
On Error GoTo Serr

imBgd.Picture = LoadPicture(fil)

If imBgd.Picture <> 0 Then
  If imBgd.Picture.Height > imBgd.Picture.Width Then
    imBgd.Top = Shp.Top: imBgd.Height = 735
    imBgd.Width = 735 * imBgd.Picture.Width / imBgd.Picture.Height
    imBgd.Left = Shp.Left + (735 - imBgd.Width) / 2
  Else
    imBgd.Left = Shp.Left
    imBgd.Height = 735 * imBgd.Picture.Height / imBgd.Picture.Width
    imBgd.Top = Shp.Top + (735 - imBgd.Height) / 2
  End If
End If

txtBgd = fil
txtBgd.Tag = fil

cmdApply.Enabled = True

Exit Sub
Serr:
  MsgBox "File is not a valid Image File.", vbInformation
On Error Resume Next
  imBgd(1).Picture = LoadPicture(txtBgd)
End Sub

Private Sub lblColBgd_Click()
  clr = ShowColor(Me, lblColBgd.BackColor, 1)
  If clr <> -1 Then lblColBgd.BackColor = clr: lblColBgd.Tag = clr: cmdApply.Enabled = True
End Sub

Private Sub lblColFScrBgd_Click()
  clr = ShowColor(Me, lblColFScrBgd.BackColor, 1)
  If clr <> -1 Then lblColFScrBgd.BackColor = clr: lblColFScrBgd.Tag = clr: cmdApply.Enabled = True
End Sub

Private Sub lblColLvwBack_Click()
  clr = ShowColor(Me, lblColLvwBack.BackColor, 1)
  If clr <> -1 Then lblColLvwBack.BackColor = clr: lblColLvwBack.Tag = clr: cmdApply.Enabled = True
End Sub

Private Sub lblColLvwFore_Click()
  clr = ShowColor(Me, lblColLvwFore.BackColor, 1)
  If clr <> -1 Then lblColLvwFore.BackColor = clr: txtLvwFont.ForeColor = clr: lblColLvwFore.Tag = clr: cmdApply.Enabled = True
End Sub

Private Sub lblColTextBack_Click()
  clr = ShowColor(Me, lblColTextBack.BackColor, 1)
  If clr <> -1 Then lblColTextBack.BackColor = clr: lblColTextBack.ForeColor = clr: lblColTextBack.Tag = clr: cmdApply.Enabled = True
End Sub

Private Sub lst_KeyDown(Index As Integer, KeyCode As Integer, Shift As Integer)
If KeyCode = vbKeyDelete Then mnuFaves_Click (1)
If KeyCode = vbKeyF6 Then mnuFaves_Click (2)
If KeyCode = vbKeyF7 Then mnuFaves_Click (3)
If KeyCode = vbKeyS And Shift = 2 Then mnuFaves_Click (4)
End Sub

Private Sub lst_MouseDown(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
If Button = 2 Then PopupMenu menuFaves
End Sub

Private Sub lvw_ItemClick(ByVal Item As MSComctlLib.ListItem)
txtExtension = Item.SubItems(1)
cmdUpdateExtension.Enabled = False
End Sub

Private Sub mnuFaves_Click(Index As Integer)
On Error Resume Next
Dim r As Integer, tmp As String, i As Integer
r = Ctrl.SelectedItem.Index

Select Case mnuFaves(Index).Caption
Case "&Remove [Del]"
  If Ctrl.ListItems.Count >= 1 Then Ctrl.ListItems.Remove (Ctrl.SelectedItem.Index) ': If r = lst(Inde).ListCount Then lst(Inde).ListIndex = r - 1 Else lst(Inde).ListIndex = r
Case "Move &Up [F6]"
  If r = 1 Then Exit Sub
  tmp = Ctrl.SelectedItem.Text
  Ctrl.SelectedItem.Text = Ctrl.ListItems(r - 1).Text
  Ctrl.ListItems(r - 1).Text = tmp
  Ctrl.ListItems(r - 1).Selected = True
Case "Move &Down [F7]"
  If r = Ctrl.ListItems.Count Then Exit Sub
  tmp = Ctrl.SelectedItem.Text
  Ctrl.SelectedItem.Text = Ctrl.ListItems(r + 1).Text
  Ctrl.ListItems(r + 1).Text = tmp
  Ctrl.ListItems(r + 1).Selected = True
Case "&Sort"
  Ctrl.Sorted = True
  Ctrl.Sorted = False
Case Else
  MsgBox mnuFaves(Index).Caption
End Select
pic(7).Tag = "Changed"
cmdApply.Enabled = True
If Me.Visible Then Ctrl.SetFocus

End Sub

Private Sub optCaption_Click(Index As Integer)
cmdApply.Enabled = True
End Sub

Private Sub tvw_NodeClick(ByVal Node As MSComctlLib.Node)
Dim pBox As PictureBox
For Each pBox In pic
  If pBox.Index = Node.Index Then pBox.Visible = True Else pBox.Visible = False
Next
'If Node.Key = "Favorites" Then tvw.Nodes("Folders").Selected = True
If Node.Index > 6 Then
'If Node.Key = "Folders" Or Node.Key = "Playlists" Then
  If lst(1).Tag <> "Loaded" Then LoadFaves
  pic(7).Visible = True
  lst(1).Visible = False: lst(2).Visible = False
  If Node.Key = "Folders" Then
    lst(1).Visible = True
    Set Ctrl = lst(1)
  ElseIf Node.Key = "Playlists" Then
    lst(2).Visible = True
    Set Ctrl = lst(2)
  End If
End If
End Sub


Private Sub LoadFaves()
Dim i As Integer
lst(1).ListItems.Clear: lst(2).ListItems.Clear
For i = 1 To GetSetting(apComp, apProd & "\Favorite Folders", "Folder Count", 0)
  lst(1).ListItems.Add i, Chr(64 + i), GetSetting(apComp, apProd & "\Favorite Folders", "Folder " & i, "C:\")
Next
For i = 1 To GetSetting(apComp, apProd & "\Favorite Files", "Filelist Count", 0)
  lst(2).ListItems.Add i, Chr(64 + i), GetSetting(apComp, apProd & "\Favorite Files", "Filelist " & i, apPath & "\listMedia.lst")
Next
lst(1).Tag = "Loaded"
End Sub

Private Sub txtBgd_Change()
If fso.FileExists(txtBgd) And imBgd.Tag <> txtBgd Then BgdSet txtBgd
End Sub

Private Sub txtExtension_Change()
If isEditExtn = True Then cmdUpdateExtension.Enabled = True Else cmdUpdateExtension.Enabled = False
End Sub

Private Sub txtExtension_GotFocus()
isEditExtn = True
End Sub

Private Sub txtExtension_LostFocus()
isEditExtn = False
End Sub

Private Sub txtTimer_Change()
If txtTimer = "" Then Exit Sub
If Val(txtTimer) <= 0 Or Val(txtTimer) > 999 Then MsgBox "Must pick a value between 1 and 999.", vbInformation: Exit Sub
txtTimer.Tag = txtTimer
cmdApply.Enabled = True
End Sub

'Private Sub txtTrashLoc_LostFocus()
'Vdplayer.TrashChk txtTrashLoc
'If txtTrashLoc <> Vdplayer.TxtTrash Then
'End Sub
