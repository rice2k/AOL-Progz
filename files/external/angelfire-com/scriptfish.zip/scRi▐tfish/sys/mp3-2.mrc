/findwinamp {
  /echo -s ~ Aight, im lookin for 4 Winamp.exe
  /set %winamplocation $findfile(C:\,Winamp.exe,1)
  if (%winamplocation == $null) { /echo -a 12Sorry, I couldn't find 14 Winamp.exe12, I'll look for14 coolplayer.exe | goto coolplayer | halt }  
  did -r mp3 4
  did -a mp3 4 %winamplocation
  /echo -a 10Found 12Winamp10 in12 %winamplocation
  halt
  :coolplayer
  /set %winamplocation $findfile(C:\,coolplayer.exe,1)
  if (%winamplocation == $null) { /echo -a 12Sorry, I couldn't find4 coolplayer.exe12 either, Your default player may run it, But you must have mp3's. | halt }  
  did -r mp3 4
  did -a mp3 4 %winamplocation
  /echo -a 10Found 12Coolplayer10 in12 %winamplocation
}

/sdir {
  set %mp3location $sdir="Where are your mp3's located at?"
  if (%mp3location == $null) { /echo -a 10No directory set. | did -r mp3 7 | halt }
  did -r mp3 7
  did -a mp3 7 %mp3location 
  halt 
}

/listmp3 {
  if (%mp3location == $null) { /set %mp3location Please set the mp3's directory | did -r mp3 7 | did -a mp3 7 %mp3location | halt }
  else {
    /write -c mp3.txt
    %mp3list = $findfile(%mp3location,*.mp3,0)
    %mp3list.which = 0
    :loop
    inc %mp3list.which 1
    if ( %mp3list.which > %mp3list ) { goto end }
    else { //write mp3.txt $nopath($findfile(%mp3location,*.mp3,%mp3list.which)) 
      goto loop
    }
    :end
    did -r mp3 8
    loadbuf 1- $+ $lines( [ mp3.txt ] ) -po mp3 8 mp3.txt
    write -i mp3.txt 
    /unset %mp3list*
  }
}

/player {
  if (%winamplocation == $null) { /set %winamplocation Please set mp3 player | did -r mp3 4 | did -a mp3 4 %winamplocation | halt }
  if (%mp3location == $null) { /set %mp3location Please set the mp3 directory | did -r mp3 7 | did -a mp3 7 %mp3location | halt }
  if (%mp3 == $null) { /echo -a 10Please 12select10 a song to play. | halt }
  else {
    /run %mp3dir
    set %mp3size $round($calc($lof(%mp3dir) / 1000000),2) $+ MB 
    if ($server == $null) { /echo -a 10Mp312 $nopath(%mp3) 10Size12 %mp3size | halt }
    else {
      /ame 12|12mp31212| 4[ 4S4ong 4:4 $nopath(%mp3dir) 4] 12[ 12U12sing 12:12 $nopath(%m.player) 12] 4(4 %mp3size 4) 
      halt
    }
  }
}

/player2 {
  if (%winamplocation == $null) { /set %winamplocation Please set mp3 player | did -r mp3 4 | did -a script 4 %winamplocation | halt }
  if (%mp3location == $null) { /set %mp3location Please set the mp3 directory | did -r mp3 7 | did -a mp3 7 %mp3location | halt }
  if (%mp3 == $null) { /echo -a 10Please 12select10 a song to play. | halt }
  else {
    /run %mp3dir
    if ($server == $null) { /echo -a 12Please 4select12 a song to play. | halt }
    else {
      /ame 12|12mp31212| 4[ 4S4ong 4:4 $nopath(%mp3dir) 4] 12[ 12U12sing 12:12 $nopath(%m.player) 12] 4(4 %mp3size 4) 
    }
  }
}

/rplay {
  set %randommp3 $findfile(%mp3location,*.mp?,0)
  set %randommp3* $rand(1,%randommp3)
  set %mp3dir $findfile(%mp3location,*.mp?,%randommp3*)
  set %mp3size $round($calc($lof(%mp3dir) / 1000000),2) $+ MB
  did -ra mp3 9 $nopath(%mp3dir)
  did -ra mp3 10 %mp3size
  run %mp3dir
  if ($server == $null) { /echo -a 12Random mp34 $nopath(%mp3dir) 12Size4 %mp3size | halt }
  else {
    /ame 12|12mp31212| 4[ 4S4ong 4:4 $nopath(%mp3dir) 4] 12[ 12U12sing 12:12 $nopath(%m.player) 12] 4(4 %mp3size 4) 
    halt 
  }
}

/m3u {
  /unset %m3u
  /set %m3u $file="What m3u?" [ C:\*.m3u ]
  if (%m3u == $null) { /echo -a 4No file selected. | halt  }
  else {
    /run %m3u
    /echo -a 10Now running12 %m3u
  }
}

mset {
  set %m.player $dir="Select Your Mp3 Player" [ c:\ $+ *.exe ]
  set %m.dir $sdir="Where Are Your Mp3s Stored?" [ c:\ ]
}
mplay {
  /run %m.player
}
splay {
  set %m.song $dir="What Do You Want To Play?!" [ %m.dir $+ *.mp3 ]
  set %m.size $calc(($lof(%m.song) / 1000) / 1000)
  /run %m.song $+ | /ame 12|12mp31212| 4[ 4S4ong 4:4 $nopath(%m.song) 4] 12[ 12U12sing 12:12 $nopath(%m.player) 12] 4(4 $round(%m.size,2) $+ 4Mb 4) 
}
silentplay {
  set %m.song $dir="What Do You Want To Play?" [ %m.dir $+ *.mp3 ]
  set %m.size $calc(($lof(%m.song) / 1000) / 1000)
  /run %m.song
  echo 5- $+ $me $+ - 12|4mp31212| 4[ 4S4ong 4:4 $nopath(%m.song) 4] 12[ 12U12sing 12:12 $nopath(%m.player) 12] 4(4 $round(%m.size,2) $+ 4Mb 4) 
  /ctcp $chan MP3 $nopath(%m.song)
}

/mp3 /if ( $window(@mp3) != $null ) { window -a @mp3 | halt } | window -dfl42k0pS +Lt @mp3 188 150 210 180 arial,10 | set %mp3.prefix n0 | set %mp3.files 0 | :nextfile | if ($readini system\drscriptmp3.ini mp3 %mp3.prefix == $null) { | titlebar @mp3 Player.�Double Click To Play ( $+ %mp3.files $+ ) Files Loaded. | halt } | aline -l @mp3 $readini system\drscriptmp3.ini mp3 %mp3.prefix | set %mp3.prefix n $+ $calc($remove(%mp3.prefix,n) + 1) | inc %mp3.files | goto nextfile }
/mp3play /if ($findfile(%mp3.drive,$$1-,1) != $null) { set %mp3.song $ifmatch | goto end } | else { set %mp3.song $$1- } | :nextmp3 | set %mp3.drive c:\ | :nextdrive | if ($disk(%mp3.drive) == $false) { if (%mp3.repeat == ON) && ($line(@mp3,$calc($fline(@mp3,$$1-,1,1) +1),1) == $null) { set %mp3.song $line(@mp3,1,1) } | elseif ($line(@mp3,$calc($fline(@mp3,$$1-,1,1) +1),1) != $null) { set %mp3.song $line(@mp3,$calc($fline(@mp3,$$1-,1,1) +1),1) } | else { halt } | goto nextmp3 | halt } | if ($findfile(%mp3.drive,%mp3.song,1) != $null) { set %mp3.song $ifmatch } | else { set %mp3.drive $chr($calc($asc($remove(%mp3.drive,:\)) + 1)) $+ :\ | goto nextdrive } | :end | run -n %mp3.song | mp3display %mp3.song 
/mp3display { bread " $+ $$1- $+ " 0 100 &mp3 | set %mp3.bincount 1 | :nextbin | if ($bvar(&mp3,%mp3.bincount) == $null) { set %mp3.kbs 9 | goto next } | if ($bvar(&mp3,%mp3.bincount) == 255) { if ($bvar(&mp3,$calc(%mp3.bincount + 1)) == 227) || ($bvar(&mp3,$calc(%mp3.bincount + 1)) == 243) || ($bvar(&mp3,$calc(%mp3.bincount + 1)) == 250) || ($bvar(&mp3,$calc(%mp3.bincount + 1)) == 251) { set %mp3.kbs $calc(($bvar(&mp3,$calc(%mp3.bincount + 2)) - $bvar(&mp3,$calc(%mp3.bincount + 2)) % 16)/16) | goto next } | inc %mp3.bincount | goto nextbin } | else { inc %mp3.bincount | goto nextbin }
  :next | if (%mp3.kbs == 1) { set %mp3.kbs 32 } | elseif (%mp3.kbs == 2) { set %mp3.kbs 40 } | elseif (%mp3.kbs == 3) { set %mp3.kbs 48 } | elseif (%mp3.kbs == 4) { set %mp3.kbs 56 } | elseif (%mp3.kbs == 5) { set %mp3.kbs 40 } | elseif (%mp3.kbs == 6) { set %mp3.kbs 80 } | elseif (%mp3.kbs == 7) { set %mp3.kbs 96 } | elseif (%mp3.kbs == 8) { set %mp3.kbs 112 } | elseif (%mp3.kbs == 9) { set %mp3.kbs 128 } | elseif (%mp3.kbs == 10) { set %mp3.kbs 160 } | elseif (%mp3.kbs == 11) { set %mp3.kbs 192 } | elseif (%mp3.kbs == 12) { set %mp3.kbs 224 } | elseif (%mp3.kbs == 13) { set %mp3.kbs 256 } | elseif (%mp3.kbs == 14) { set %mp3.kbs 320 }
  set %mp3.size $file(%mp3.song) | set %mp3.length $int($calc((%mp3.size)/(%mp3.kbs * 125.2))) | set %mp3.min $int($calc((%mp3.length)/60)) | set %mp3.sec $round($calc($calc((%mp3.length)/60-%mp3.min)*60),0) | { if (%mp3.random == ON) { .timermp3 -o 1 %mp3.length mp3play $line(@mp3,$rand(1,%mp3.files),1) } | elseif (%mp3.repeat == ON) && ($line(@mp3,$calc($fline(@mp3,$nopath(%mp3.song),1,1) +1),1) == $null) { .timermp3 -o 1 %mp3.length mp3play $line(@mp3,1,1) } | elseif ($line(@mp3,$calc($fline(@mp3,$nopath(%mp3.song),1,1) +1),1) != $null) { .timermp3 -o 1 %mp3.length mp3play $line(@mp3,$calc($fline(@mp3,$nopath(%mp3.song),1,1) +1),1) } }
  if (%ranmp3 == on) { set %color1  $+ $rand(3,15) $+ }
  if (%mp3.display == on) && ($server != $null) && ($chan(1) != $null) && (%offline != yes) { goto one }
  if (%mp3.display == on) && (%offline == yes) { goto two }
  if (%mp3.display != on) { halt }
  :one
  { ame %color1 $+ is listening to %color1 $+ 14m $+ %color1 $+ p143 $+ %color1 $+ [14 $remove($nopath(%mp3.song),.mp3) %color1 $+ ] �14Size: $+ %color1 $round($calc((%mp3.size)/1048576),2) $+ 14Mb $+ %color1 $+ �(14Quality: $+ %color1 %mp3.kbs $+ 14kbs $+ %color1 $+ )�14Length: $+ %color1 %mp3.min  $+ : $+ %mp3.sec $+ 14sec $+ %color1 $+ � }
  :two
  { echo %color1 $+ You are listening to %color1 $+ 14m $+ %color1 $+ p143 $+ 14[ $remove($nopath(%mp3.song),.mp3) ] %color1 $+ �14Size: $+ %color1 $round($calc((%mp3.size)/1048576),2) $+ 14Mb� $+ %color1 $+ (Quality:14 %mp3.kbs $+  $+ %color1 $+ kbs)�Length: %mp3.min  $+ %color1 $+ :14 $+ %mp3.sec $+  $+ %color1 $+ sec� }
