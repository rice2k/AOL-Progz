alias scan .timer 1 2 scan2 | who # | echo 0. | say 15Please Wait... CloneScan in progress
alias scan2 {
  if ($active !ischan) { halt }
  unset %cl.*
  if ($ial == $false) { .ial on }
  set %cl.a $nick(#,0)
  :loop
  if ($ialchan($address($nick(#,%cl.a),2),#,0) > 1) && ($address($nick(#,%cl.a),2) !isin %cl.l) {
    set %cl.c $ialchan($address($nick(#,%cl.a),2),#,0)
    set %cl.l %cl.l $address($nick(#,%cl.a),2)
    :next
    say 4 $ialchan($address($nick(#,%cl.a),2),#,%cl.c).nick is a clone. 12 ( $+ $address($nick(#,%cl.a),2) $+ )
    set %cl.n %cl.n $ialchan($address($nick(#,%cl.a),2),#,%cl.c).nick 
    dec %cl.c
    if (%cl.c == 0) { say 15- | goto end }
    goto next 
    :end
  }
  dec %cl.a 1
  if (%cl.a == 0) { if (%cl.l == $null) { echo # 3No clones found! } | if (%cl.l != $null) { say 15End of Clone Scan... } | halt }
  goto loop
}

alias scannerp .timer 1 2 scanp2 | who # | echo 0. | echo 15Please Wait... CloneScan in progress
alias scanp2 {
  if ($active !ischan) { halt }
  echo # 0,0.
  unset %cl.*
  if ($ial == $false) { .ial on }
  set %cl.a $nick(#,0)
  :loop
  if ($ialchan($address($nick(#,%cl.a),2),#,0) > 1) && ($address($nick(#,%cl.a),2) !isin %cl.l) {
    set %cl.c $ialchan($address($nick(#,%cl.a),2),#,0)
    set %cl.l %cl.l $address($nick(#,%cl.a),2)
    :next
    echo # 4 $ialchan($address($nick(#,%cl.a),2),#,%cl.c).nick is a clone.12  ( $+ $address($nick(#,%cl.a),2) $+ )
    set %cl.n %cl.n $ialchan($address($nick(#,%cl.a),2),#,%cl.c).nick 
    dec %cl.c
    if (%cl.c == 0) { echo # 15- | goto end }
    goto next 
    :end
  }
  dec %cl.a 1
  if (%cl.a == 0) { if (%cl.l == $null) { echo # 3No clones found! } | if (%cl.l != $null) { echo 15End of Clone Scan... } | echo # 0,0. | halt }
  goto loop
}

alias stats {
  unset %temp.stats.*
  set %temp.stats.chan # | set %temp.stats.op 0 | set %temp.stats.voice 0 | set %temp.stats.normal 0 | set %temp.stats.away 0 | set %temp.stats.ircop 0 | set %temp.stats.total 0
  if ( $1 == -e ) { set %temp.stats.display echo %temp.stats.chan }
  if ( $1 == -p ) { set %temp.stats.display msg %temp.stats.chan }
  .disable #who | .enable #stats | .who %temp.stats.chan
}
#stats off
raw 352:*:{
  if ( @ isin $7 ) { inc %temp.stats.op }
  if ( + isin $7 ) && ( @ !isin $7 ) { inc %temp.stats.voice }
  if ( + !isin $7 ) && ( @ !isin $7 ) { inc %temp.stats.normal }
  if ( G isin $7 ) { inc %temp.stats.away }
  if ( * isin $7 ) { inc %temp.stats.ircop }
  inc %temp.stats.total
  halt
}
raw 315:*:{
  set %temp.stats.opp $remove($round($calc((%temp.stats.op / %temp.stats.total)*100),1),.0)
  set %temp.stats.voicep $remove($round($calc((%temp.stats.voice / %temp.stats.total)*100),1),.0)
  set %temp.stats.normalp $remove($round($calc((%temp.stats.normal / %temp.stats.total)*100),1),.0)
  set %temp.stats.awayp $remove($round($calc((%temp.stats.away / %temp.stats.total)*100),1),.0)
  set %temp.stats.ircopp $remove($round($calc((%temp.stats.ircop / %temp.stats.total)*100),1),.0)
  if ( $len(%temp.stats.op) == 1 ) { set %temp.stats.op 0 $+ %temp.stats.op }
  if ( $len(%temp.stats.voice) == 1 ) { set %temp.stats.voice 0 $+ %temp.stats.voice }
  if ( $len(%temp.stats.normal) == 1 ) { set %temp.stats.normal 0 $+ %temp.stats.normal }
  if ( $len(%temp.stats.away) == 1 ) { set %temp.stats.away 0 $+ %temp.stats.away }
  if ( $len(%temp.stats.ircop) == 1 ) { set %temp.stats.ircop 0 $+ %temp.stats.ircop }
  if ( $len(%temp.stats.total) == 1 ) { set %temp.stats.total 0 $+ %temp.stats.total }
  %temp.stats.display 15 $+ %temp.stats.chan $+ 's Channel Stats
  %temp.stats.display 4 $+ %temp.stats.op $+  12Op Users 14[4 $+ %temp.stats.opp $+ % $+ 14]
  %temp.stats.display 4 $+ %temp.stats.voice $+  12Voice Users 14[4 $+ %temp.stats.voicep $+ % $+ 14]
  %temp.stats.display 4 $+ %temp.stats.normal $+  12Normal Users 14[4 $+ %temp.stats.normalp $+ % $+ 14]
  %temp.stats.display 4 $+ %temp.stats.away $+  12Away Users 14[4 $+ %temp.stats.awayp $+ % $+ 14]
  %temp.stats.display 4 $+ %temp.stats.ircop $+  12IRC Operators 14[4 $+ %temp.stats.ircopp $+ % $+ 14]
  %temp.stats.display 4 $+ %temp.stats.total $+  12Total Users 14[4 $+ 100 $+ % $+ 14]
  %temp.stats.display 15End of Channel Stats
  unset %temp.stats.* | .disable #stats | .enable #Who
  halt
}
#stats end
alias ispscan {
  unset %temp.ispscan.*
  set %temp.ispscan.isp $?="Enter ISP Address to Scan"
  if ( %temp.ispscan.isp == $null ) { halt }
  set %temp.ispscan.chan # | set %temp.ispscan.count 0
  if ( $1 == -e ) { set %temp.ispscan.display echo %temp.ispscan.chan }
  if ( $1 == -p ) { set %temp.ispscan.display msg %temp.ispscan.chan }
  .disable #who | .enable #ispscan
  %temp.ispscan.display 15Scanning for ISP $upper(%temp.ispscan.isp) $+ 
  .who %temp.ispscan.chan
}
#ispscan off
raw 352:*:{
  if ( %temp.ispscan.isp isin $4 ) {
    inc %temp.ispscan.count
    %temp.ispscan.display 4 $+ %temp.ispscan.count $+ .12 $6 $+  $chr(91) $+ $3 $+ @ $+ $4 $+ $chr(93)
  }
  halt
}
raw 315:* {
  if ( %temp.ispscan.count == 0 ) { %temp.ispscan.display 12No user with ISP 4 $+ $upper(%temp.ispscan.isp) $+ 12 found !! }
  %temp.ispscan.display 15End of ISP Scan
  unset %temp.ispscan.* | .disable #ispscan | .enable #who
  halt
}
#ispscan end
alias awayscan {
  unset %temp.awayscan.*
  set %temp.awayscan.chan # | set %temp.awayscan.count 0
  if ( $1 == -e ) { set %temp.awayscan.display echo %temp.awayscan.chan }
  if ( $1 == -p ) { set %temp.awayscan.display msg %temp.awayscan.chan }
  .disable #who | .enable #awayscan
  %temp.awayscan.display 15Away Users on %temp.awayscan.chan $+ 
  .who %temp.awayscan.chan
}
#awayscan off
raw 352:*:{
  if ( G isin $7 ) {
    inc %temp.awayscan.count
    %temp.awayscan.display 4 $+ %temp.awayscan.count $+ .12 $6 $+  $chr(91) $+ $3 $+ @ $+ $4 $+ $chr(93)
  }
  halt
}
raw 315:* {
  if ( %temp.awayscan.count == 0 ) { %temp.awayscan.display 12No 4away user 12found!! }
  %temp.awayscan.display 15End of Away Scan
  unset %temp.awayscan.* | .disable #awayscan | .enable #who
  halt
}
#awayscan end
alias ircopscan {
  unset %temp.ircopscan.*
  set %temp.ircopscan.chan # | set %temp.ircopscan.count 0
  if ( $1 == -e ) { set %temp.ircopscan.display echo %temp.ircopscan.chan }
  if ( $1 == -p ) { set %temp.ircopscan.display msg %temp.ircopscan.chan }
  .disable #who | .enable #ircopscan
  %temp.ircopscan.display 15IRCOps on %temp.ircopscan.chan $+ 
  .who %temp.ircopscan.chan
}
#ircopscan off
raw 352:*:{
  if ( * isin $7 ) {
    inc %temp.ircopscan.count
    %temp.ircopscan.display 4 $+ %temp.ircopscan.count $+ .12 $6 $+  $chr(91) $+ $3 $+ @ $+ $4 $+ $chr(93)
  }
  halt
}
raw 315:* {
  if ( %temp.ircopscan.count == 0 ) { %temp.ircopscan.display 12No 4IRCOp 12found !! }
  %temp.ircopscan.display 15End of IRCOps Scan
  unset %temp.ircopscan.* | .disable #ircopscan | .enable #who
  halt
}
#ircopscan end
