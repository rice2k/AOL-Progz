on *:nick:{
  if ($nick != $me) {
    if (%pro.c.nik = $null) || (%pro.c.nik.max = $null) || (%pro.c.nik.sec = $null) halt
    %chnc_uad = $address($newnick,2)
    %chnc_total = $chan(0)
    inc -u [ $+ [ %pro.c.nik.sec ] ] %pro.c.nik.f [ $+ [ %chnc_uad ] ] 1
    if (%pro.c.nik.f [ $+ [ %chnc_uad ] ] > %pro.c.nik.max) goto searchc
    halt
    :searchc
    inc %chnc_inc 1
    if (%chnc_inc > %chnc_total) { unset %pro.c.nik.f [ $+ [ %chnc_uad ] ] | unset %chnc_* | halt }
    %chnc_n = $chan(%chnc_inc)
    if ($me !isop %chnc_n) || ($newnick !ison %chnc_n) goto searchc
    if ($newnick isop %chnc_n) { mode %chnc_n -o $newnick }
    if (%pro.c.k-b = !) { ban %chnc_n $newnick %pro.s.i-b.typ2 }
    kick %chnc_n $newnick %pro.c.kck.msg (Exceeded %pro.c.nik.max nick changes within %pro.c.nik.sec secs)
    goto searchc
  }
}
on *:join:#:{
  if ($nick != $me) {
    if ($me isop $chan) {
      if (%pro.c.j-p = $null) || %pro.c.j-p.max = $null) || (%pro.c.j-p.sec = $null) halt
      inc -u [ $+ [ %pro.c.j-p.sec ] ] %pro.c.j-p.f [ $+ [ $nick ] ] 1
      if (%pro.c.j-p.f [ $+ [ $nick ] ] > %pro.c.j-p.max) {
        if ($nick isop #) { mode # -o $nick }
        if (%pro.c.k-b = !) { ban # $nick %pro.s.i-b.typ2 }
        kick # $nick %pro.c.kck.msg (Exceeded %pro.c.j-p.max joins within %pro.c.j-p.sec secs) | unset %pro.c.j-p.f [ $+ [ $nick ] ]
      }
    }
  }
}
on !*:part:#:{
  %rjc.chan = # | if ($nick(%rjc.chan,0,o,ahvr) == 0) && ($nick(%rjc.chan,0) == 2) && ($me !isop #) { raw -q part %rjc.chan | raw -q join %rjc.chan | unset %rjc.* }
  if ($me isop $chan) {
    if (%pro.c.j-p = $null) || %pro.c.j-p.max = $null) || (%pro.c.j-p.sec = $null) halt
    inc -u [ $+ [ %pro.c.j-p.sec ] ] %pro.c.j-p.f2 [ $+ [ $nick ] ] 1
    if (%pro.c.j-p.f2 [ $+ [ $nick ] ] > %pro.c.j-p.max) {
      if (%pro.c.k-b = !) { ban # $nick %pro.s.i-b.typ2 }
      kick # $nick %pro.c.kck.msg (Exceeded %pro.c.j-p.max parts within %pro.c.j-p.sec secs) | unset %pro.c.j-p.f2 [ $+ [ $nick ] ]
    }
  }
}
on *:text:*:#:{
  if ($me isop $chan) {
    if (%pro.c.txt = $null) || %pro.c.txt.max = $null) || (%pro.c.txt.sec = $null) halt    
    inc -u [ $+ [ %pro.c.txt.sec ] ] %pro.c.txt.f [ $+ [ $nick ] ] 1
    if (%pro.c.txt.f [ $+ [ $nick ] ] > %pro.c.txt.max) {
      if ($nick isop #) { mode # -o $nick }
      if (%pro.c.k-b = !) { ban # $nick %pro.s.i-b.typ2 }
      kick # $nick %pro.c.kck.msg (Exceeded %pro.c.txt.max lines of text within %pro.c.txt.sec secs) | unset %pro.c.txt.f [ $+ [ $nick ] ]
    }
    if ($len($1-) > %pro.a.len) && (%pro.a.len != $null) && (%pro.a.len != 999) {
      if ($nick isop #) { mode # -o $nick }
      if (%pro.c.k-b = !) { ban # $nick %pro.s.i-b.typ2 }
      kick # $nick %pro.c.kck.msg (Exceeded max text length of %pro.a.len chars | unset %pro.c.txt.f [ $+ [ $nick ] ]
    }
  }
}
on !*:action:*:#:{
  if ($me isop $chan) {
    if (%pro.c.act = $null) || %pro.c.act.max = $null) || (%pro.c.act.sec = $null) halt
    inc -u [ $+ [ %pro.c.act.sec ] ] %pro.c.act.f [ $+ [ $nick ] ] 1
    if (%pro.c.act.f [ $+ [ $nick ] ] > %pro.c.act.max) {
      if ($nick isop #) { mode # -o $nick }
      if (%pro.c.k-b = !) { ban # $nick %pro.s.i-b.typ2 }
      kick # $nick %pro.c.kck.msg (Exceeded %pro.c.act.max actions within %pro.c.act.sec secs) | unset %pro.c.act.f [ $+ [ $nick ] ]
    }
    if ($len($1-) > %pro.a.len) && (%pro.a.len != $null) && (%pro.a.len != 999) {
      if ($nick isop #) { mode # -o $nick }
      if (%pro.c.k-b = !) { ban # $nick %pro.s.i-b.typ2 }
      kick # $nick %pro.c.kck.msg (Exceeded max text length of %pro.a.len chars | unset %pro.c.act.f [ $+ [ $nick ] ]
    }
  }
}
on !*:notice:*:#:{
  if ($me isop $chan) {
    if (%pro.c.not = $null) || %pro.c.not.max = $null) || (%pro.c.not.sec = $null) halt
    inc -u [ $+ [ %pro.c.not.sec ] ] %pro.c.not.f [ $+ [ $nick ] ] 1
    if (%pro.c.not.f [ $+ [ $nick ] ] > %pro.c.not.max) {
      if ($nick isop #) { mode # -o $nick }
      if (%pro.c.k-b = !) { ban # $nick %pro.s.i-b.typ2 }
      kick # $nick %pro.c.kck.msg (Exceeded %pro.c.not.max notices within %pro.c.not.sec secs) | unset %pro.c.not.f [ $+ [ $nick ] ]
    }
    if ($len($1-) > %pro.a.len) && (%pro.a.len != $null) && (%pro.a.len != 999) {
      if ($nick isop #) { mode # -o $nick }
      if (%pro.c.k-b = !) { ban # $nick %pro.s.i-b.typ2 }
      kick # $nick %pro.c.kck.msg (Exceeded max text length of %pro.a.len chars | unset %pro.c.not.f [ $+ [ $nick ] ]
    }
  }
}
ctcp !*:*:#:{
  if ($me isop $chan) {
    if (%pro.c.ctc = $null) || %pro.c.ctc.max = $null) || (%pro.c.ctc.sec = $null) goto end
    inc -u [ $+ [ %pro.c.ctc.sec ] ] %pro.c.ctc.f [ $+ [ $nick ] ] 1
    if (%pro.c.ctc.f [ $+ [ $nick ] ] > %pro.c.ctc.max) {
      if ($nick isop #) { mode # -o $nick }
      if (%pro.c.k-b = !) { ban # $nick %pro.s.i-b.typ2 }
      kick # $nick %pro.c.kck.msg (Exceeded %pro.c.ctc.max ctcps within %pro.c.ctc.sec secs) | unset %pro.c.ctc.f [ $+ [ $nick ] ]
    }
    if ($len($1-) > %pro.a.len) && (%pro.a.len != $null) && (%pro.a.len != 999) {
      if ($nick isop #) { mode # -o $nick }
      if (%pro.c.k-b = !) { ban # $nick %pro.s.i-b.typ2 }
      kick # $nick %pro.c.kck.msg (Exceeded max text length of %pro.a.len chars | unset %pro.c.ctc.f [ $+ [ $nick ] ]
    }
    :end
  }
}
on !*:text:*:?:{
  if (%pro.s.n-m = $null) || %pro.s.n-m.max = $null) || (%pro.s.n-m.sec = $null) halt
  inc -u [ $+ [ %pro.s.n-m.sec ] ] %pro.s.n-m.f [ $+ [ $nick ] ] 1
  if (%pro.s.n-m.f [ $+ [ $nick ] ] > %pro.s.n-m.max) || ($len($1-) > %pro.a.len) {
    if (%pro.s.ign.tmp = !) { ignore -pntiu [ $+ [ %pro.s.ign.sec ] ] $mask($fulladdress,%pro.s.i-b.typ2) }
    if (%pro.s.ign.prm = !) { ignore -pnti $mask($fulladdress,%pro.s.i-b.typ2) }
    notice $nick NOTICE - 12,12 2,2 4,2 Doctors'15,2 Pre4S�RIPT15ion 2,2 12,12  152000 - Enhanced Edition You have been placed on ignore for private notice/msg flooding
    unset %pro.s.n-m.f [ $+ [ $nick ] ]
  }
}
ctcp !*:dcc send:?:{
  if (%pro.s.snd = $null) || %pro.s.snd.max = $null) || (%pro.s.snd.sec = $null) goto end
  inc -u [ $+ [ %pro.s.snd.sec ] ] %pro.s.snd.f [ $+ [ $nick ] ] 1
  if (%pro.s.snd.f [ $+ [ $nick ] ] > %pro.s.snd.max) || ($len($1-) > %pro.a.len) {
    if (%pro.s.ign.tmp = !) { ignore -pntiu [ $+ [ %pro.s.ign.sec ] ] $mask($fulladdress,%pro.s.i-b.typ2) }
    if (%pro.s.ign.prm = !) { ignore -pnti $mask($fulladdress,%pro.s.i-b.typ2) }
    notice $nick NOTICE - You have been placed on ignore for dcc send request flooding
    unset %pro.s.snd.f [ $+ [ $nick ] ] 
  }
  :end
}
ctcp !*:dcc chat:?:{
  if (%pro.s.cht = $null) || %pro.s.cht.max = $null) || (%pro.s.cht.sec = $null) goto end
  inc -u [ $+ [ %pro.s.cht.sec ] ] %pro.s.cht.f [ $+ [ $nick ] ] 1
  if (%pro.s.cht.f [ $+ [ $nick ] ] > %pro.s.cht.max) || ($len($1-) > %pro.a.len) {
    if (%pro.s.ign.tmp = !) { ignore -pntiu [ $+ [ %pro.s.ign.sec ] ] $mask($fulladdress,%pro.s.i-b.typ2) }
    if (%pro.s.ign.prm = !) { ignore -pnti $mask($fulladdress,%pro.s.i-b.typ2) }
    notice $nick NOTICE - You have been placed on ignore for dcc chat request flooding
    unset %pro.s.cht.f [ $+ [ $nick ] ]
  }
  :end
}
ctcp !*:*:?:{
  if (%pro.s.ctc = $null) || %pro.s.ctc.max = $null) || (%pro.s.ctc.sec = $null) goto end
  inc -u [ $+ [ %pro.s.ctc.sec ] ] %pro.s.ctc.f [ $+ [ $nick ] ] 1
  if (%pro.s.ctc.f [ $+ [ $nick ] ] > %pro.s.ctc.max) || ($len($1-) > %pro.a.len) {
    if (%pro.s.ign.tmp = !) { ignore -pntiu [ $+ [ %pro.s.ign.sec ] ] $mask($fulladdress,%pro.s.i-b.typ2) }
    if (%pro.s.ign.prm = !) { ignore -pnti $mask($fulladdress,%pro.s.i-b.typ2) }
    notice $nick NOTICE - You have been placed on ignore for ctcp flooding
    unset %pro.s.ctc.f [ $+ [ $nick ] ]
  }
  :end
}
on !*:invite:#:{
  if (%pro.s.inv = $null) || %pro.s.inv.max = $null) || (%pro.s.inv.sec = $null) halt
  inc -u [ $+ [ %pro.s.inv.sec ] ] %pro.s.inv.f [ $+ [ $nick ] ] 1
  if (%pro.s.inv.f [ $+ [ $nick ] ] > %pro.s.inv.max) || ($len($1-) > %pro.a.len) {
    if (%pro.s.ign.tmp = !) { ignore -pntiu [ $+ [ %pro.s.ign.sec ] ] $mask($fulladdress,%pro.s.i-b.typ2) }
    if (%pro.s.ign.prm = !) { ignore -pnti $mask($fulladdress,%pro.s.i-b.typ2) }
    notice $nick NOTICE - You have been placed on ignore for invite flooding
    unset %pro.s.inv.f [ $+ [ $nick ] ]
  }
}
on !*:notice:*:?:{
  if (%pro.s.n-m = $null) || %pro.s.n-m.max = $null) || (%pro.s.n-m.sec = $null) halt
  inc -u [ $+ [ %pro.s.n-m.sec ] ] %pro.s.n-m.f2 [ $+ [ $nick ] ] 1
  if (%pro.s.n-m.f2 [ $+ [ $nick ] ] > %pro.s.n-m.max) || ($len($1-) > %pro.a.len) {
    if (%pro.s.ign.tmp = !) { ignore -pntiu [ $+ [ %pro.s.ign.sec ] ] $mask($fulladdress,%pro.s.i-b.typ2) }
    if (%pro.s.ign.prm = !) { ignore -pnti $mask($fulladdress,%pro.s.i-b.typ2) }
    notice $nick NOTICE - You have been placed on ignore for private notice/msg flooding
    unset %pro.s.n-m.f2 [ $+ [ $nick ] ]
  }
}
