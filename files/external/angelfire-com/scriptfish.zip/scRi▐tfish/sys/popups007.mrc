menu status,menubar {
  MP3
  .MP3 Control Central 1:/mp3
  .MP3 Control Central 2:/dmp3
  .MP3 Control Central 3
  ..Setup Mp3:/mset
  ..-
  ..Run Mp3 Player:/mplay
  ..Play Mp3:/splay
  ..Silent Mp3 Play:/silentplay
  Personal Stuff
  .A/S/L
  ..Set:set %asl $$?="Enter Age/Sex/Location" | /echo 2���9,2 Age/Sex/Loc Reply Is Set To: %asl 
  ..Echo:echo %asl
  .Email
  ..Set:set %email $$?="Enter Your E-Mail Address" | /echo 2���9,2 E-Mail Address Now Set To: %email 
  ..Echo:echo %email
  .ICQ Number
  ..Set:set %icq $$?="Enter Your ICQ Number" | /echo 2���9,2 ICQ Number Is Set To: %icq 
  ..Echo:echo %icq
  .Web Url
  ..Set:set %url $$?="Enter A Web Url (Web Page)" | /echo 2���9,2 Web Url Now Set To: %url 
  ..Echo:echo %url
  War Stuff
  .Ping Flood
  ..Fast:/timer0 0 0 /ping $$?="Enter Victims Nick"
  ..Medium:/timer1 0 1 /ping $$?="Enter Victims Nick"
  ..Slow:/timer1 0 2 /ping $$?="Enter Victims Nick"
  ..-
  ..Stop:/timers off
  -
  Your IP Is $ip:/echo $ip
  $fulldate:/
  -
  Quit IRC
  .Enter Message:/quit %quit $$?="Enter The Quit Message"
  .Normal DrScript Quit:/quit %quit $read $mircdirsystem\quit.txt
  .-

}

menu query {
  -
  MP3
  .MP3 Control Central 1:/mp3
  .MP3 Control Central 2:/dmp3
  .MP3 Control Central 3
  ..Setup Mp3:/mset
  ..-
  ..Run Mp3 Player:/mplay
  ..Play Mp3:/splay
  ..Silent Mp3 Play:/silentplay
  Personal Stuff
  .A/S/L
  ..Set:set %asl $$?="Enter Age/Sex/Location" | /echo 2���9,2 Age/Sex/Loc Reply Is Set To: %asl 
  ..Tell:/say %asl
  .Email
  ..Set:set %email $$?="Enter Your E-Mail Address" | /echo 2���9,2 E-Mail Address Now Set To: %email 
  ..Tell:/say %email
  .Web Url
  ..Set:set %url $$?="Enter A Web Url (Web Page)" | /echo 2���9,2 Web Url Now Set To: %url 
  ..Tell:/say %url
  .ICQ Number
  ..Set:set %icq $$?="Enter Your ICQ Number" | /echo 2���9,2 ICQ Number Is Set To: %icq 
  ..Tell:/say %icq
  War Stuff
  .Ping Flood
  ..Fast:/timer0 0 0 /ping $$1
  ..Medium:/timer1 0 1 /ping $$1
  ..Slow:/timer1 0 2 /ping $$1
  ..-
  ..Stop:/timers off
  -
  Your IP Is $ip:/echo $ip
  $fulldate:/
  -
  Close Query:/closemsg $active
  Quit IRC
  .Enter Message:/quit %quit $$?="Enter The Quit Message"
  .Normal DrScript Quit:/quit %quit $read $mircdirsystem\quit.txt
  -
}

menu nicklist {
  Fake Quit
  .Fake Abuse:/msg $chan 2*** $$1 has quit IRC (Killed (sprint.austnet.org (Banned from AustNet: Abuse)))
  .Fake Error:/msg $chan 2*** $$1 has quit IRC (Read error to $$1 $+ : Connection reset by peer)
  .Fake Excess Flood:/msg $chan 2*** $$1 has quit IRC (Excess Flood)
  .Fake G-Lined Clone:/msg $chan 2*** $$1 has quit IRC (G-Lined: Banned from AustNet: No clones on Austnet. You have been warned)
  .Fake G-Line, Customisable Message:/msg $chan 2*** $$1 has quit IRC (Killed (sprint.austnet.org (Banned from AustNet: $$?="What Is Your Gline Message?" $+ )))
  .Fake G-Line Evansion:/msg $chan 2*** $$1 has quit IRC (Killed (sprint.austnet.org (Banned from AustNet: Gline evasion is bad)))
  .Fake G-Lined Excessive Connections:{ /set %clients $$?="Number Of Clients?"
    /msg $chan 2*** $$1 has quit IRC (Killed (Lwaxana (Clones or Excessive connections are Nottie, and therefore not Allowed on Austnet !!! < $+ 1/ $+ %clients clients>)))
    /msg $chan 2*** $$2 has quit IRC (Killed (Lwaxana (Clones or Excessive connections are Nottie, and therefore not Allowed on Austnet !!! < $+ 2/ $+ %clients clients>)))
    /msg $chan 2*** $$3 has quit IRC (Killed (Lwaxana (Clones or Excessive connections are Nottie, and therefore not Allowed on Austnet !!! < $+ 3/ $+ %clients clients>)))
    /msg $chan 2*** $$4 has quit IRC (Killed (Lwaxana (Clones or Excessive connections are Nottie, and therefore not Allowed on Austnet !!! < $+ 4/ $+ %clients clients>)))
    /msg $chan 2*** $$5 has quit IRC (Killed (Lwaxana (Clones or Excessive connections are Nottie, and therefore not Allowed on Austnet !!! < $+ 5/ $+ %clients clients>)))
    /msg $chan 2*** $$6 has quit IRC (Killed (Lwaxana (Clones or Excessive connections are Nottie, and therefore not Allowed on Austnet !!! < $+ 6/ $+ %clients clients>)))
  }
  .Fake G-Lined Script:/msg $chan 2*** $$1 has quit IRC (G-Lined: Banned from AustNet: Clone script, FOAD)
  .Fake G-Lined Spam:/msg $chan 2*** $$1 has quit IRC (G-Lined: Banned from AustNet: Advertising and Spamming are not permitted on AustNet)
  .Fake Kill:/msg $chan 2*** $$1 has quit IRC (Killed (NickOP (Kill requested by $me $+ )))
  .Fake Ping:/msg $chan 2*** $$1 has quit IRC (Ping timeout for $$1 $+ )
  .Fake Server:/msg $chan 2*** $$1 has quit IRC (You are banned from this server. Email help@austnet.org for assistance)
  .Fake Service:/msg $chan 2*** $$1 has quit IRC (Killed (services.austnet.org (Flooding the AustNet services will not be tolerated)))
  -
  F Keys Menu:/fkeys
}

menu channel {
  Games
  .8ball � %ball �
  ..On: {
    set %ball On
    set %gamechan #
    /msg %gamechan 158Ball now set to 4On15. Type 4@8ball2 <Yes / No questions>. %logo
  }
  ..Off: {
    set %ball Off
    /msg %gamechan 158ball now set to 4Off15. %logo
    unset %gamechan
  }
  .Number Guessing � %guess �
  ..On:{
    set %guess On
    set %b.gamechan #
    set %g.number $$?="What Number?"
    /msg %b.gamechan 15Number Guessing Game Is Now 4On15. Type 4@guess2 <number> To Have A Guess. %logo 
  }
  ..Off: {
    set %guess Off
    /msg %b.gamechan 15Number Guessing Game Is Now 4Off15. %logo 
    unset %g.gamechan
  }
  .Voting Booth
  ..Start:/startvoting
  ..Stop:/stopvoting
  MP3
  .MP3 Control Central 1:/mp3
  .MP3 Control Central 2:/dmp3
  .MP3 Control Central 3
  ..Setup Mp3:/mset
  ..-
  ..Run Mp3 Player:/mplay
  ..Play Mp3:/splay
  ..Silent Mp3 Play:/silentplay
  Personal Stuff
  .A/S/L
  ..Set:set %asl $$?="Enter Age/Sex/Location" | /echo 2���9,2 Age/Sex/Loc Reply Is Set To: %asl 
  ..Tell:/say %asl
  .Email
  ..Set:set %email $$?="Enter Your E-Mail Address" | /echo 2���9,2 E-Mail Address Now Set To: %email 
  ..Tell:/say %email
  .Web Url
  ..Set:set %url $$?="Enter A Web Url (Web Page)" | /echo 2���9,2 Web Url Now Set To: %url 
  ..Tell:/say %url
  .ICQ Number
  ..Set:set %icq $$?="Enter Your ICQ Number" | /echo 2���9,2 ICQ Number Is Set To: %icq 
  ..Tell:/say %icq
  War Stuff
  .Ping Flood
  ..Fast:/timer0 0 0 /ping $$?="Enter Victims Nick"
  ..Medium:/timer1 0 1 /ping $$?="Enter Victims Nick"
  ..Slow:/timer1 0 2 /ping $$?="Enter Victims Nick"
  ..-
  ..Stop:/timers off
  -
  Your IP Is $ip:/echo $ip
  $fulldate:/
  -
  Part Channel:/part $chan 15http://welcome.to/drscript/
  Quit IRC
  .Enter Message:/quit %quit $$?="Enter The Quit Message"
  .Normal DrScript Quit:/quit %quit $read $mircdirsystem\quit.txt
  -
}
