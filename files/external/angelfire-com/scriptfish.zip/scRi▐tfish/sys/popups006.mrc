menu status,menubar,channel {
  Text Decorations
  .3D Box:/box $$?="Enter Message"
  .Asian � %asian �
  ..On:{ 
    /set %asian On
    /set %colour Off
    /set %blue Off
    /set %roses Off
    /set %scheme 02
    /set %blue Off
    /set %exodus Off
  }
  ..Off:/set %asian Off
  .ASCII � %ascii �
  ..On:{
    /set %ascii On
    /set %blue Off
    /set %ascii2 Off
    /set %exodus Off
  }
  ..Off:/set %ascii Off
  .ASCII2 � %ascii2 �
  ..On:{
    /set %ascii2 On
    /set %ascii Off
    /set %blue Off
    /set %exodus Off
  }
  ..Off:/set %ascii2 Off
  .Cool Writing � %blue �
  ..On:{ 
    /set %blue On
    /set %ascii Off
    /set %ascii2 Off
    /set %colour On
    /set %exodus Off
  }
  ..Off:/set %blue Off
  .SumJai Colours � %exodus �
  ..Set SumJai Colours
  ...White
  ....Black:{ /set %double1 00 | /set %double2 01 }
  ....Light Blue:{ /set %double1 00 | /set %double2 1 }
  ....Blue:{ /set %double1 00 | /set %double2 12 }
  ....Navy:{ /set %double1 00 | /set %double2 02 }
  ....Red:{ /set %double1 00 | /set %double2 04 }
  ....Brown:{ /set %double1 00 | /set %double2 05 }
  ....Purple:{ /set %double1 00 | /set %double2 06 }
  ....Orange:{ /set %double1 00 | /set %double2 07 }
  ....Yellow:{ /set %double1 00 | /set %double2 08 }
  ....Green:{ /set %double1 00 | /set %double2 03 }
  ....Light Green:{ /set %double1 00 | /set %double2 09 }
  ....Aqua:{ /set %double1 00 | /set %double2 10 }
  ....Light Grey:{ /set %double1 00 | /set %double2 15 }
  ....Dark Grey:{ /set %double1 00 | /set %double2 14 }
  ....Pink:{ /set %double1 00 | /set %double2 13 }
  ...Black
  ....White:{ /set %double1 01 | /set %double2 00 }
  ....Light Blue:{ /set %double1 01 | /set %double2 11 }
  ....Blue:{ /set %double1 01 | /set %double2 12 }
  ....Navy:{ /set %double1 01 | /set %double2 02 }
  ....Red:{ /set %double1 01 | /set %double2 04 }
  ....Brown:{ /set %double1 01 | /set %double2 05 }
  ....Purple:{ /set %double1 01 | /set %double2 06 }
  ....Orange:{ /set %double1 01 | /set %double2 07 }
  ....Yellow:{ /set %double1 01 | /set %double2 08 }
  ....Green:{ /set %double1 01 | /set %double2 03 }
  ....Light Green:{ /set %double1 01 | /set %double2 09 }
  ....Aqua:{ /set %double1 01 | /set %double2 10 }
  ....Light Grey:{ /set %double1 01 | /set %double2 15 }
  ....Dark Grey:{ /set %double1 01 | /set %double2 14 }
  ....Pink:{ /set %double1 01 | /set %double2 13 }
  ...Light Blue
  ....White:{ /set %double1 11 | /set %double2 00 }
  ....Black:{ /set %double1 11 | /set %double2 01 }
  ....Blue:{ /set %double1 11 | /set %double2 12 }
  ....Navy:{ /set %double1 11 | /set %double2 02 }
  ....Red:{ /set %double1 11 | /set %double2 04 }
  ....Brown:{ /set %double1 11 | /set %double2 05 }
  ....Purple:{ /set %double1 11 | /set %double2 06 }
  ....Orange:{ /set %double1 11 | /set %double2 07 }
  ....Yellow:{ /set %double1 11 | /set %double2 08 }
  ....Green:{ /set %double1 11 | /set %double2 03 }
  ....Light Green:{ /set %double1 11 | /set %double2 09 }
  ....Aqua:{ /set %double1 11 | /set %double2 10 }
  ....Light Grey:{ /set %double1 11 | /set %double2 15 }
  ....Dark Grey:{ /set %double1 11 | /set %double2 14 }
  ....Pink:{ /set %double1 11 | /set %double2 13 }
  ...Blue
  ....White:{ /set %double1 12 | /set %double2 00 }
  ....Black:{ /set %double1 12 | /set %double2 01 }
  ....Light Blue:{ /set %double1 12 | /set %double2 11 }
  ....Navy:{ /set %double1 12 | /set %double2 02 }
  ....Red:{ /set %double1 12 | /set %double2 04 }
  ....Brown:{ /set %double1 12 | /set %double2 05 }
  ....Purple:{ /set %double1 12 | /set %double2 06 }
  ....Orange:{ /set %double1 12 | /set %double2 07 }
  ....Yellow:{ /set %double1 12 | /set %double2 08 }
  ....Green:{ /set %double1 12 | /set %double2 03 }
  ....Light Green:{ /set %double1 12 | /set %double2 09 }
  ....Aqua:{ /set %double1 12 | /set %double2 10 }
  ....Light Grey:{ /set %double1 12 | /set %double2 15 }
  ....Dark Grey:{ /set %double1 12 | /set %double2 14 }
  ....Pink:{ /set %double1 12 | /set %double2 13 }
  ...Navy
  ....White:{ /set %double1 02 | /set %double2 00 }
  ....Black:{ /set %double1 02 | /set %double2 01 }
  ....Light Blue:{ /set %double1 02 | /set %double2 11 }
  ....Blue:{ /set %double1 02 | /set %double2 12 }
  ....Red:{ /set %double1 02 | /set %double2 04 }
  ....Brown:{ /set %double1 02 | /set %double2 05 }
  ....Purple:{ /set %double1 02 | /set %double2 06 }
  ....Orange:{ /set %double1 02 | /set %double2 07 }
  ....Yellow:{ /set %double1 02 | /set %double2 08 }
  ....Green:{ /set %double1 02 | /set %double2 03 }
  ....Light Green:{ /set %double1 02 | /set %double2 09 }
  ....Aqua:{ /set %double1 02 | /set %double2 10 }
  ....Light Grey:{ /set %double1 02 | /set %double2 15 }
  ....Dark Grey:{ /set %double1 02 | /set %double2 14 }
  ....Pink:{ /set %double1 02 | /set %double2 13 }
  ...Red
  ....White:{ /set %double1 04 | /set %double2 00 }
  ....Black:{ /set %double1 04 | /set %double2 01 }
  ....Light Blue:{ /set %double1 04 | /set %double2 11 }
  ....Blue:{ /set %double1 04 | /set %double2 12 }
  ....Navy:{ /set %double1 04 | /set %double2 02 }
  ....Brown:{ /set %double1 04 | /set %double2 05 }
  ....Purple:{ /set %double1 04 | /set %double2 06 }
  ....Orange:{ /set %double1 04 | /set %double2 07 }
  ....Yellow:{ /set %double1 04 | /set %double2 08 }
  ....Green:{ /set %double1 04 | /set %double2 03 }
  ....Light Green:{ /set %double1 04 | /set %double2 09 }
  ....Aqua:{ /set %double1 04 | /set %double2 10 }
  ....Light Grey:{ /set %double1 04 | /set %double2 15 }
  ....Dark Grey:{ /set %double1 04 | /set %double2 14 }
  ....Pink:{ /set %double1 04 | /set %double2 13 }
  ...Brown
  ....White:{ /set %double1 05 | /set %double2 00 }
  ....Black:{ /set %double1 05 | /set %double2 01 }
  ....Light Blue:{ /set %double1 05 | /set %double2 1 }
  ....Blue:{ /set %double1 05 | /set %double2 12 }
  ....Navy:{ /set %double1 05 | /set %double2 02 }
  ....Red:{ /set %double1 05 | /set %double2 04 }
  ....Purple:{ /set %double1 05 | /set %double2 06 }
  ....Orange:{ /set %double1 05 | /set %double2 07 }
  ....Yellow:{ /set %double1 05 | /set %double2 08 }
  ....Green:{ /set %double1 05 | /set %double2 03 }
  ....Light Green:{ /set %double1 05 | /set %double2 09 }
  ....Aqua:{ /set %double1 05 | /set %double2 10 }
  ....Light Grey:{ /set %double1 05 | /set %double2 15 }
  ....Dark Grey:{ /set %double1 05 | /set %double2 14 }
  ....Pink:{ /set %double1 05 | /set %double2 13 }
  ...Purple
  ....White:{ /set %double1 06 | /set %double2 00 }
  ....Black:{ /set %double1 06 | /set %double2 01 }
  ....Light Blue:{ /set %double1 06 | /set %double2 11 }
  ....Blue:{ /set %double1 06 | /set %double2 12 }
  ....Navy:{ /set %double1 06 | /set %double2 02 }
  ....Red:{ /set %double1 06 | /set %double2 04 }
  ....Brown:{ /set %double1 06 | /set %double2 05 }
  ....Orange:{ /set %double1 06 | /set %double2 07 }
  ....Yellow:{ /set %double1 06 | /set %double2 08 }
  ....Green:{ /set %double1 06 | /set %double2 03 }
  ....Light Green:{ /set %double1 06 | /set %double2 09 }
  ....Aqua:{ /set %double1 06 | /set %double2 10 }
  ....Light Grey:{ /set %double1 06 | /set %double2 15 }
  ....Dark Grey:{ /set %double1 06 | /set %double2 14 }
  ....Pink:{ /set %double1 06 | /set %double2 13 }
  ...Orange
  ....White:{ /set %double1 07 | /set %double2 00 }
  ....Black:{ /set %double1 07 | /set %double2 01 }
  ....Light Blue:{ /set %double1 07 | /set %double2 11 }
  ....Blue:{ /set %double1 07 | /set %double2 12 }
  ....Navy:{ /set %double1 07 | /set %double2 02 }
  ....Red:{ /set %double1 07 | /set %double2 04 }
  ....Brown:{ /set %double1 07 | /set %double2 05 }
  ....Purple:{ /set %double1 07 | /set %double2 06 }
  ....Yellow:{ /set %double1 07 | /set %double2 08 }
  ....Green:{ /set %double1 07 | /set %double2 03 }
  ....Light Green:{ /set %double1 07 | /set %double2 09 }
  ....Aqua:{ /set %double1 07 | /set %double2 10 }
  ....Light Grey:{ /set %double1 07 | /set %double2 15 }
  ....Dark Grey:{ /set %double1 07 | /set %double2 14 }
  ....Pink:{ /set %double1 07 | /set %double2 13 }
  ...Yellow
  ....White:{ /set %double1 08 | /set %double2 00 }
  ....Black:{ /set %double1 08 | /set %double2 01 }
  ....Light Blue:{ /set %double1 08 | /set %double2 11 }
  ....Blue:{ /set %double1 08 | /set %double2 12 }
  ....Navy:{ /set %double1 08 | /set %double2 02 }
  ....Red:{ /set %double1 08 | /set %double2 04 }
  ....Brown:{ /set %double1 08 | /set %double2 05 }
  ....Purple:{ /set %double1 08 | /set %double2 06 }
  ....Orange:{ /set %double1 08 | /set %double2 07 }
  ....Green:{ /set %double1 08 | /set %double2 03 }
  ....Light Green:{ /set %double1 08 | /set %double2 09 }
  ....Aqua:{ /set %double1 08 | /set %double2 10 }
  ....Light Grey:{ /set %double1 08 | /set %double2 15 }
  ....Dark Grey:{ /set %double1 08 | /set %double2 14 }
  ....Pink:{ /set %double1 08 | /set %double2 13 }
  ...Green
  ....White:{ /set %double1 03 | /set %double2 00 }
  ....Black:{ /set %double1 03 | /set %double2 01 }
  ....Light Blue:{ /set %double1 03 | /set %double2 11 }
  ....Blue:{ /set %double1 03 | /set %double2 12 }
  ....Navy:{ /set %double1 03 | /set %double2 02 }
  ....Red:{ /set %double1 03 | /set %double2 04 }
  ....Brown:{ /set %double1 03 | /set %double2 05 }
  ....Purple:{ /set %double1 03 | /set %double2 06 }
  ....Orange:{ /set %double1 03 | /set %double2 07 }
  ....Yellow:{ /set %double1 03 | /set %double2 08 }
  ....Light Green:{ /set %double1 03 | /set %double2 09 }
  ....Aqua:{ /set %double1 03 | /set %double2 10 }
  ....Light Grey:{ /set %double1 03 | /set %double2 15 }
  ....Dark Grey:{ /set %double1 03 | /set %double2 14 }
  ....Pink:{ /set %double1 03 | /set %double2 13 }
  ...Light Green
  ....White:{ /set %double1 09 | /set %double2 00 }
  ....Black:{ /set %double1 09 | /set %double2 01 }
  ....Light Blue:{ /set %double1 09 | /set %double2 11 }
  ....Blue:{ /set %double1 09 | /set %double2 12 }
  ....Navy:{ /set %double1 09 | /set %double2 02 }
  ....Red:{ /set %double1 09 | /set %double2 04 }
  ....Brown:{ /set %double1 09 | /set %double2 05 }
  ....Purple:{ /set %double1 09 | /set %double2 06 }
  ....Orange:{ /set %double1 09 | /set %double2 07 }
  ....Yellow:{ /set %double1 09 | /set %double2 08 }
  ....Green:{ /set %double1 09 | /set %double2 03 }
  ....Aqua:{ /set %double1 09 | /set %double2 10 }
  ....Light Grey:{ /set %double1 09 | /set %double2 15 }
  ....Dark Grey:{ /set %double1 09 | /set %double2 14 }
  ....Pink:{ /set %double1 09 | /set %double2 13 }
  ...Aqua
  ....White:{ /set %double1 10 | /set %double2 00 }
  ....Black:{ /set %double1 10 | /set %double2 01 }
  ....Light Blue:{ /set %double1 10 | /set %double2 11 }
  ....Blue:{ /set %double1 10 | /set %double2 12 }
  ....Navy:{ /set %double1 10 | /set %double2 02 }
  ....Red:{ /set %double1 10 | /set %double2 04 }
  ....Brown:{ /set %double1 10 | /set %double2 05 }
  ....Purple:{ /set %double1 10 | /set %double2 06 }
  ....Orange:{ /set %double1 10 | /set %double2 07 }
  ....Yellow:{ /set %double1 10 | /set %double2 08 }
  ....Green:{ /set %double1 10 | /set %double2 03 }
  ....Light Green:{ /set %double1 10 | /set %double2 09 }
  ....Light Grey:{ /set %double1 10 | /set %double2 15 }
  ....Dark Grey:{ /set %double1 10 | /set %double2 14 }
  ....Pink:{ /set %double1 10 | /set %double2 13 }
  ...Light Grey
  ....White:{ /set %double1 15 | /set %double2 00 }
  ....Black:{ /set %double1 15 | /set %double2 01 }
  ....Light Blue:{ /set %double1 15 | /set %double2 11 }
  ....Blue:{ /set %double1 15 | /set %double2 12 }
  ....Navy:{ /set %double1 15 | /set %double2 02 }
  ....Red:{ /set %double1 15 | /set %double2 04 }
  ....Brown:{ /set %double1 15 | /set %double2 05 }
  ....Purple:{ /set %double1 15 | /set %double2 06 }
  ....Orange:{ /set %double1 15 | /set %double2 07 }
  ....Yellow:{ /set %double1 15 | /set %double2 08 }
  ....Green:{ /set %double1 15 | /set %double2 03 }
  ....Light Green:{ /set %double1 15 | /set %double2 09 }
  ....Aqua:{ /set %double1 15 | /set %double2 10 }
  ....Dark Grey:{ /set %double1 15 | /set %double2 14 }
  ....Pink:{ /set %double1 15 | /set %double2 13 }
  ...Dark Grey
  ....White:{ /set %double1 14 | /set %double2 00 }
  ....Black:{ /set %double1 14 | /set %double2 01 }
  ....Light Blue:{ /set %double1 14 | /set %double2 11 }
  ....Blue:{ /set %double1 14 | /set %double2 12 }
  ....Navy:{ /set %double1 14 | /set %double2 02 }
  ....Red:{ /set %double1 14 | /set %double2 04 }
  ....Brown:{ /set %double1 14 | /set %double2 05 }
  ....Purple:{ /set %double1 14 | /set %double2 06 }
  ....Orange:{ /set %double1 14 | /set %double2 07 }
  ....Yellow:{ /set %double1 14 | /set %double2 08 }
  ....Green:{ /set %double1 14 | /set %double2 03 }
  ....Light Green:{ /set %double1 14 | /set %double2 09 }
  ....Aqua:{ /set %double1 14 | /set %double2 10 }
  ....Light Grey:{ /set %double1 14 | /set %double2 15 }
  ....Pink:{ /set %double1 14 | /set %double2 13 }
  ...Pink
  ....Black:{ /set %double1 13 | /set %double2 01 }
  ....Light Blue:{ /set %double1 13 | /set %double2 11 }
  ....Blue:{ /set %double1 13 | /set %double2 12 }
  ....Navy:{ /set %double1 13 | /set %double2 02 }
  ....Red:{ /set %double1 13 | /set %double2 04 }
  ....Brown:{ /set %double1 13 | /set %double2 05 }
  ....Purple:{ /set %double1 13 | /set %double2 06 }
  ....Orange:{ /set %double1 13 | /set %double2 07 }
  ....Yellow:{ /set %double1 13 | /set %double2 08 }
  ....Green:{ /set %double1 13 | /set %double2 03 }
  ....Light Green:{ /set %double1 13 | /set %double2 09 }
  ....Aqua:{ /set %double1 13 | /set %double2 01 }
  ....Light Grey:{ /set %double1 13 | /set %double2 15 }
  ....Dark Grey:{ /set %double1 13 | /set %double2 14 }
  ....White:{ /set %double1 13 | /set %double2 00 }
  ..Set SumJai Background Colour
  ...Default/No Background:{ /set %exobg  | /set %exoback off }
  ...White:{ /set %exobg 1,00 | /set %exoback on }
  ...Black:{ /set %exobg 0,01 | /set %exoback on }
  ...Navy:{ /set %exobg 0,02 | /set %exoback on }
  ...Green:{ /set %exobg 0,03 | /set %exoback on } 
  ...Red:{ /set %exobg 0,04 | /set %exoback on }
  ...Brown:{ /set %exobg 0,05 | /set %exoback on }
  ...Purple:{ /set %exobg 0,06 | /set %exoback on }
  ...Orange:{ /set %exobg 0,07 | /set %exoback on }
  ...Yellow:{ /set %exobg 0,08 | /set %exoback on }
  ...Light Green:{ /set %exobg 0,09 | /set %exoback on }
  ...Aqua:{ /set %exobg 0,10 | /set %exoback on }
  ...Light Blue:{ /set %exobg 0,11 | /set %exoback on }
  ...Blue:{ /set %exobg 0,12 | /set %exoback on }
  ...Pink:{ /set %exobg 0,13 | /set %exoback on }
  ...Dark Grey:{ /set %exobg 0,14 | /set %exoback on }
  ...Light Grey:{ /set %exobg 0,15 | /set %exoback on }
  ..On:{
    /set %asian Off
    /set %colour Off
    /set %blue Off
    /set %ascii Off
    /set %ascii Off
    /set %roses Off
    /set %exodus On
  }
  ..Off:/set %exodus Off
  .Roses � %roses �
  ..On:{
    /set %asian Off
    /set %colour Off
    /set %blue Off
    /set %roses On
    /set %scheme 12
    /set %blue Off
    /set %exodus Off
  }
  ..Off:/set %roses Off
  .-
  .Coloured � %colour �
  ..Set Colours
  ...Default Colours:{ /set %colour Off | /set %scheme  }
  ...White
  ....Black:/set %scheme 0,01
  ....Light Blue:/set %scheme 0,11
  ....Blue:/set %scheme 0,12
  ....Navy:/set %scheme 0,02
  ....Red:/set %scheme 0,04
  ....Brown:/set %scheme 0,05
  ....Purple:/set %scheme 0,06
  ....Orange:/set %scheme 0,07
  ....Yellow:/set %scheme 0,08
  ....Green:/set %scheme 0,03
  ....Light Green:/set %scheme 0,09
  ....Aqua:/set %scheme 0,10
  ....Light Grey:/set %scheme 0,15
  ....Dark Grey:/set %scheme 0,14
  ....Pink:/set %scheme 0,13
  ...Black
  ....White:/set %scheme 1,00
  ....Light Blue:/set %scheme 1,11
  ....Blue:/set %scheme 1,12
  ....Navy:/set %scheme 1,02
  ....Red:/set %scheme 1,04
  ....Brown:/set %scheme 1,05
  ....Purple:/set %scheme 1,06
  ....Orange:/set %scheme 1,07
  ....Yellow:/set %scheme 1,08
  ....Green:/set %scheme 1,03
  ....Light Green:/set %scheme 1,09
  ....Aqua:/set %scheme 1,10
  ....Light Grey:/set %scheme 1,15
  ....Dark Grey:/set %scheme 1,14
  ....Pink:/set %scheme 1,13
  ...Light Blue
  ....No Background:/set %scheme 11
  ....White:/set %scheme 11,00
  ....Black:/set %scheme 11,01
  ....Blue:/set %scheme 11,12
  ....Navy:/set %scheme 11,02
  ....Red:/set %scheme 11,04
  ....Brown:/set %scheme 11,05
  ....Purple:/set %scheme 11,06
  ....Orange:/set %scheme 11,07
  ....Yellow:/set %scheme 11,08
  ....Green:/set %scheme 11,03
  ....Light Green:/set %scheme 11,09
  ....Aqua:/set %scheme 11,10
  ....Light Grey:/set %scheme 11,15
  ....Dark Grey:/set %scheme 11,14
  ....Pink:/set %scheme 11,13
  ...Blue
  ....No Background:/set %scheme 12
  ....White:/set %scheme 12,00
  ....Black:/set %scheme 12,01
  ....Light Blue:/set %scheme 12,11
  ....Navy:/set %scheme 12,02
  ....Red:/set %scheme 12,04
  ....Brown:/set %scheme 12,05
  ....Purple:/set %scheme 12,06
  ....Orange:/set %scheme 12,07
  ....Yellow:/set %scheme 12,08
  ....Green:/set %scheme 12,03
  ....Light Green:/set %scheme 12,09
  ....Aqua:/set %scheme 12,10
  ....Light Grey:/set %scheme 12,15
  ....Dark Grey:/set %scheme 12,14
  ....Pink:/set %scheme 12,13
  ...Navy
  ....No Background:/set %scheme 02
  ....White:/set %scheme 02,00
  ....Black:/set %scheme 2,01
  ....Light Blue:/set %scheme 2,11
  ....Blue:/set %scheme 2,12
  ....Red:/set %scheme 2,04
  ....Brown:/set %scheme 2,05
  ....Purple:/set %scheme 2,06
  ....Orange:/set %scheme 2,07
  ....Yellow:/set %scheme 2,08
  ....Green:/set %scheme 2,03
  ....Light Green:/set %scheme 2,09
  ....Aqua:/set %scheme 2,10
  ....Light Grey:/set %scheme 2,15
  ....Dark Grey:/set %scheme 2,14
  ....Pink:/set %scheme 2,13
  ...Red
  ....No Background:/set %scheme 04
  ....White:/set %scheme 04,00
  ....Black:/set %scheme 4,01
  ....Light Blue:/set %scheme 4,11
  ....Blue:/set %scheme 4,12
  ....Navy:/set %scheme 4,02
  ....Brown:/set %scheme 4,05
  ....Purple:/set %scheme 4,06
  ....Orange:/set %scheme 4,07
  ....Yellow:/set %scheme 4,08
  ....Green:/set %scheme 4,03
  ....Light Green:/set %scheme 4,09
  ....Aqua:/set %scheme 4,10
  ....Light Grey:/set %scheme 4,15
  ....Dark Grey:/set %scheme 4,14
  ....Pink:/set %scheme 4,13
  ...Brown
  ....No Background:/set %scheme 05
  ....White:/set %scheme 05,00
  ....Black:/set %scheme 5,01
  ....Light Blue:/set %scheme 5,11
  ....Blue:/set %scheme 5,12
  ....Navy:/set %scheme 5,02
  ....Red:/set %scheme 5,04
  ....Purple:/set %scheme 5,06
  ....Orange:/set %scheme 5,07
  ....Yellow:/set %scheme 5,08
  ....Green:/set %scheme 5,03
  ....Light Green:/set %scheme 5,09
  ....Aqua:/set %scheme 5,10
  ....Light Grey:/set %scheme 5,15
  ....Dark Grey:/set %scheme 5,14
  ....Pink:/set %scheme 5,13
  ...Purple
  ....No Background:/set %scheme 06
  ....White:/set %scheme 06,00
  ....Black:/set %scheme 6,01
  ....Light Blue:/set %scheme 6,11
  ....Blue:/set %scheme 6,12
  ....Navy:/set %scheme 6,02
  ....Red:/set %scheme 6,04
  ....Brown:/set %scheme 6,05
  ....Orange:/set %scheme 6,07
  ....Yellow:/set %scheme 6,08
  ....Green:/set %scheme 6,03
  ....Light Green:/set %scheme 6,09
  ....Aqua:/set %scheme 6,10
  ....Light Grey:/set %scheme 6,15
  ....Dark Grey:/set %scheme 6,14
  ....Pink:/set %scheme 6,13
  ...Orange
  ....No Background:/set %scheme 07
  ....White:/set %scheme 07,00
  ....Black:/set %scheme 7,01
  ....Light Blue:/set %scheme 7,11
  ....Blue:/set %scheme 7,12
  ....Navy:/set %scheme 7,02
  ....Red:/set %scheme 7,04
  ....Brown:/set %scheme 7,05
  ....Purple:/set %scheme 7,06
  ....Yellow:/set %scheme 7,08
  ....Green:/set %scheme 7,03
  ....Light Green:/set %scheme 7,09
  ....Aqua:/set %scheme 7,10
  ....Light Grey:/set %scheme 7,15
  ....Dark Grey:/set %scheme 7,14
  ....Pink:/set %scheme 7,13
  ...Yellow
  ....No Background:/set %scheme 08
  ....White:/set %scheme 08,00
  ....Black:/set %scheme 8,01
  ....Light Blue:/set %scheme 8,11
  ....Blue:/set %scheme 8,12
  ....Navy:/set %scheme 8,02
  ....Red:/set %scheme 8,04
  ....Brown:/set %scheme 8,05
  ....Purple:/set %scheme 8,06
  ....Orange:/set %scheme 8,07
  ....Green:/set %scheme 8,03
  ....Light Green:/set %scheme 8,09
  ....Aqua:/set %scheme 8,10
  ....Light Grey:/set %scheme 8,15
  ....Dark Grey:/set %scheme 8,14
  ....Pink:/set %scheme 8,13
  ...Green
  ....No Background:/set %scheme 03
  ....White:/set %scheme 03,00
  ....Black:/set %scheme 3,01
  ....Light Blue:/set %scheme 3,11
  ....Blue:/set %scheme 3,12
  ....Navy:/set %scheme 3,02
  ....Red:/set %scheme 3,04
  ....Brown:/set %scheme 3,05
  ....Purple:/set %scheme 3,06
  ....Orange:/set %scheme 3,07
  ....Yellow:/set %scheme 3,08
  ....Light Green:/set %scheme 3,09
  ....Aqua:/set %scheme 3,10
  ....Light Grey:/set %scheme 3,15
  ....Dark Grey:/set %scheme 3,14
  ....Pink:/set %scheme 3,13
  ...Light Green
  ....No Background:/set %scheme 09
  ....White:/set %scheme 09,00
  ....Black:/set %scheme 9,01
  ....Light Blue:/set %scheme 9,11
  ....Blue:/set %scheme 9,12
  ....Navy:/set %scheme 9,02
  ....Red:/set %scheme 9,04
  ....Brown:/set %scheme 9,05
  ....Purple:/set %scheme 9,06
  ....Orange:/set %scheme 9,07
  ....Yellow:/set %scheme 9,08
  ....Green:/set %scheme 9,03
  ....Aqua:/set %scheme 9,10
  ....Light Grey:/set %scheme 9,15
  ....Dark Grey:/set %scheme 9,14
  ....Pink:/set %scheme 9,13
  ...Aqua
  ....No Background:/set %scheme 10
  ....White:/set %scheme 10,00
  ....Black:/set %scheme 10,01
  ....Light Blue:/set %scheme 10,11
  ....Blue:/set %scheme 10,12
  ....Navy:/set %scheme 10,02
  ....Red:/set %scheme 10,04
  ....Brown:/set %scheme 10,05
  ....Purple:/set %scheme 10,06
  ....Orange:/set %scheme 10,07
  ....Yellow:/set %scheme 10,08
  ....Green:/set %scheme 10,03
  ....Light Green:/set %scheme 10,09
  ....Light Grey:/set %scheme 10,15
  ....Dark Grey:/set %scheme 10,14
  ....Pink:/set %scheme 10,13
  ...Light Grey
  ....No Background:/set %scheme 15
  ....White:/set %scheme 15,00
  ....Black:/set %scheme 15,01
  ....Light Blue:/set %scheme 15,11
  ....Blue:/set %scheme 15,12
  ....Navy:/set %scheme 15,02
  ....Red:/set %scheme 15,04
  ....Brown:/set %scheme 15,05
  ....Purple:/set %scheme 15,06
  ....Orange:/set %scheme 15,07
  ....Yellow:/set %scheme 15,08
  ....Green:/set %scheme 15,03
  ....Light Green:/set %scheme 15,09
  ....Aqua:/set %scheme 15,10
  ....Dark Grey:/set %scheme 15,14
  ....Pink:/set %scheme 15,13
  ...Dark Grey
  ....No Background:/set %scheme 14
  ....White:/set %scheme 14,00
  ....Black:/set %scheme 14,01
  ....Light Blue:/set %scheme 14,11
  ....Blue:/set %scheme 14,12
  ....Navy:/set %scheme 14,02
  ....Red:/set %scheme 14,04
  ....Brown:/set %scheme 14,05
  ....Purple:/set %scheme 14,06
  ....Orange:/set %scheme 14,07
  ....Yellow:/set %scheme 14,08
  ....Green:/set %scheme 14,03
  ....Light Green:/set %scheme 14,09
  ....Aqua:/set %scheme 14,10
  ....Light Grey:/set %scheme 14,15
  ....Pink:/set %scheme 14,13
  ...Pink
  ....No Background:/set %scheme 13
  ....Black:/set %scheme 13,01
  ....Light Blue:/set %scheme 13,11
  ....Blue:/set %scheme 13,12
  ....Navy:/set %scheme 13,02
  ....Red:/set %scheme 13,04
  ....Brown:/set %scheme 13,05
  ....Purple:/set %scheme 13,06
  ....Orange:/set %scheme 13,07
  ....Yellow:/set %scheme 13,08
  ....Green:/set %scheme 13,03
  ....Light Green:/set %scheme 13,09
  ....Aqua:/set %scheme 13,10
  ....Light Grey:/set %scheme 13,15
  ....Dark Grey:/set %scheme 13,14
  ....White:/set %scheme 13,00
  ..On:{
    /set %asian Off
    /set %colour On
    /set %roses Off
    /set %exodus Off
  }
  ..Off:/set %colour Off
}
