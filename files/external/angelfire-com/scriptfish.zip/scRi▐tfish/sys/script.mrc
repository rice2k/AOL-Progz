on 1:START:{
  inc %Scriptrun 1 
  /drscript
  /echo -------------------------------------------------------------
  /echo 4"MoLeSta'S ADVICE"12 $read $mircdirsystem\Advice.txt
  /echo -------------------------------------------------------------

on 1:connect:{
  /titlebar sCri�t|m0nkey - MooT !~Connected~!
  /set %server $server
  if (%autoident == on) { /msg nickop@austnet.org identify %autoident-pass }

on 1:disconnect:{
  /titlebar sCri�t|m0nkey - MooT !~Disconnected~!
}

on 1:part:#: {
  if ($nick == $me) { /part $chan sCri�t|m0nkey }
}

on 1:CLOSE:@mp3:{ remini system\drscriptmp3.ini mp3 | set %mp3.prefix n0 | set %mp3.count 1 | :nextfile | if ($line(@mp3,%mp3.count,1) == $null) { .timermp3 off | halt } | writeini -n system\drscriptmp3.ini mp3 %mp3.prefix $line(@mp3,%mp3.count,1) | set %mp3.prefix n $+ $calc($remove(%mp3.prefix,n) + 1) | inc %mp3.count | goto nextfile }


menu @welcome {
  Auto
  .Auto Tell Asl � %autoasl �
  ..On:/set %autoasl On
  ..Off:/set %autoasl Off
  .Auto Identify On Connect � %autoident �
  ..On: {
    /set %autoident On
    /set %autoident-pass $$?="Set Your Nick Password"
  }
  Channels
  .Add A Channel: {
    if ( %channel1 == $null ) { set %channel1 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel2 == $null ) { set %channel2 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel3 == $null ) { set %channel3 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel4 == $null ) { set %channel4 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel5 == $null ) { set %channel5 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel6 == $null ) { set %channel6 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel7 == $null ) { set %channel7 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel8 == $null ) { set %channel8 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel9 == $null ) { set %channel9 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel10 == $null ) { set %channel10 .  #$$?="Enter A Channel:" | goto end }
    else { echo 2���4 You have too many CHANNELS in your nick list  | halt }
    :end
    echo 2���4 $! has been added to your CHANNELS list 
  }
  .Unset A Channel
  ..%channel1:/unset %channel1
  ..%channel2:/unset %channel2
  ..%channel3:/unset %channel3
  ..%channel4:/unset %channel4
  ..%channel5:/unset %channel5
  ..%channel6:/unset %channel6
  ..%channel7:/unset %channel7
  ..%channel8:/unset %channel8
  ..%channel9:/unset %channel9
  ..%channel10:/unset %channel10
  Nicknames
  .Add A Nickname: {
    if ( %nick1 == $null ) { set %nick1 . $$?="Enter A Nick:" | goto end }
    if ( %nick2 == $null ) { set %nick2 . $$?="Enter A Nick:" | goto end }
    if ( %nick3 == $null ) { set %nick3 . $$?="Enter A Nick:" | goto end }
    if ( %nick4 == $null ) { set %nick4 . $$?="Enter A Nick:" | goto end }
    if ( %nick5 == $null ) { set %nick5 . $$?="Enter A Nick:" | goto end }
    if ( %nick6 == $null ) { set %nick6 . $$?="Enter A Nick:" | goto end }
    if ( %nick7 == $null ) { set %nick7 . $$?="Enter A Nick:" | goto end }
    if ( %nick8 == $null ) { set %nick8 . $$?="Enter A Nick:" | goto end }
    if ( %nick9 == $null ) { set %nick9 . $$?="Enter A Nick:" | goto end }
    if ( %nick10 == $null ) { set %nick10 . $$?="Enter A Nick:" | goto end }
    else { echo 2���4 You have too many NICKS in your nick list  | halt }
    :end
    echo 2���4 $! has been added to your NICKNAMES list 
  }
  .Unset A Nickname
  ..%nick1:/unset %nick1
  ..%nick2:/unset %nick2
  ..%nick3:/unset %nick3
  ..%nick4:/unset %nick4
  ..%nick5:/unset %nick5
  ..%nick6:/unset %nick6
  ..%nick7:/unset %nick7
  ..%nick8:/unset %nick8
  ..%nick9:/unset %nick9
  ..%nick10:/unset %nick10
  -
  Altenating Text � %alt-text �
  .On:/set %alt-text On
  .Off:/set %alt-text Off
  Set Flood Protection:/afp
  Set MP3 Announcer:/mset
  Set   Personal Stuff
  .A/S/L
  ..Set:set %asl $$?="Enter Age/Sex/Location" | /echo 2���4 Age/Sex/Loc Reply Is Set To: %asl 
  ..Tell:/aline -p @welcome %asl
  .Email
  ..Set:set %email $$?="Enter Your E-Mail Address" | /echo 2���4 E-Mail Address Now Set To: %email 
  ..Tell:/aline -p @welcome %email
  .Web Url
  ..Set:set %url $$?="Enter A Web Url (Web Page)" | /echo 2���4 Web Url Now Set To: %url 
  ..Tell:/aline -p @welcome %url
  .ICQ Number
  ..Set:set %icq $$?="Enter Your ICQ Number" | /echo 2���4 ICQ Number Is Set To: %icq 
  ..Tell:/aline -p @welcome %icq
  -
  Close Window:/close -@ @welcome
}

on 1:NOTICE:DCC SEND*:?:{
  /fsend on | /dcc packetsize 4096 | /pdcc 9999999999999999
}
