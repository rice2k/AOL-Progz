menu status,menubar {
  -
  Clones Control
  .-
  .Clone Manager:clones
  .-
  .Load: clones connect $$?="Server?" $$?="Port?" $$?="Number of Clones?"
  .Kill: clones kill
  .-
  .Flood
  ..Ping:clones flood $$?="Flood Ping Nick:" ping
  ..Time:clones flood $$?="Flood Time Nick:" time
  ..Version:clones flood $$?="Flood Version Nick:" version
  ..Privmsg:clones flood $$?="Flood Privmsg Nick:" privmsg $$?="MSG:"
  ..-
  ..Halt Flood:.timerCLONE_* off | .timerCOMPLETE_* off | echo 5 -st Clones: Halt Flood
  .-
  .Join a Channel:clones command join $$?="Channel:"
  .Part a Channel:clones command part $$?="Channel:"
  .-
  .Command:clones command $$?="Command?"
  .-
  .Nick
  ..$sock(clone*,1).name [ %clones.sock. [ $+ [ $remove($sock(clone*,1).name,clone) ] ] ]:sockwrite -tn $sock(clone*,1).name nick $$?="Nickname:"
  ..$sock(clone*,2).name [ %clones.sock. [ $+ [ $remove($sock(clone*,2).name,clone) ] ] ]:sockwrite -tn $sock(clone*,2).name nick $$?="Nickname:"
  ..$sock(clone*,3).name [ %clones.sock. [ $+ [ $remove($sock(clone*,3).name,clone) ] ] ]:sockwrite -tn $sock(clone*,3).name nick $$?="Nickname:"
  ..$sock(clone*,4).name [ %clones.sock. [ $+ [ $remove($sock(clone*,4).name,clone) ] ] ]:sockwrite -tn $sock(clone*,4).name nick $$?="Nickname:"
  ..$sock(clone*,5).name [ %clones.sock. [ $+ [ $remove($sock(clone*,5).name,clone) ] ] ]:sockwrite -tn $sock(clone*,5).name nick $$?="Nickname:"
  ..$sock(clone*,6).name [ %clones.sock. [ $+ [ $remove($sock(clone*,6).name,clone) ] ] ]:sockwrite -tn $sock(clone*,6).name nick $$?="Nickname:"
  ..$sock(clone*,7).name [ %clones.sock. [ $+ [ $remove($sock(clone*,7).name,clone) ] ] ]:sockwrite -tn $sock(clone*,7).name nick $$?="Nickname:"
  ..$sock(clone*,8).name [ %clones.sock. [ $+ [ $remove($sock(clone*,8).name,clone) ] ] ]:sockwrite -tn $sock(clone*,8).name nick $$?="Nickname:"
  Others
  .AllAdvantage Hack
  ..Make Money
  ...While Your
  ....Chatting:/allad
  .Alternating Text � %alt-text �
  ..On (e.g, Brb > Be Rite Back) :/set %alt-text On
  ..Off (e.g, Brb > Brb) :/set %alt-text Off
  .Auto
  ..Auto Tell Asl � %autoasl �
  ...On:/set %autoasl On
  ...Off:/set %autoasl Off
  ..Auto Identify On Connect � %autoident �
  ...On: {
    /set %autoident On
    /set %autoident-pass $$?="Set Your Nick Password"
  }
  ...Off: {
    /set %autoident Off
    /unset %autoident-pass $?!="Your Password Has Been Unset"
  }
  .DCC Log Box:/disp.dcc
  .F Keys Menu:/fkeys
  .Mass Closing
  ..Sends:{ close -s }
  ..Queries:{ close -m }
  ..Fserves:{ close -f }
  ..Chats:{ close -c }
  .Personal Notes:/run notepad.exe $mircdir\notes.txt
  .Tools:/tools
  .-
  .Advice:/echo 4"TODAY'S ADVICE"12 $read $mircdirsystem\Advice.txt
  .Date:/echo 12Today's Date Is4 $date
  .Message All Channels:/amsg 4[12GLOBAL4] $$?="What Is Your Message:"
  .System Uptime:/echo 7Booted Computer:12 $replace($duration($calc($ticks / 1000)),wk,�Week,day,�Day,hr,�Hour,min,�Minute,sec,�Second) Ago
  .Time:/echo 12The Time Now Is4 $time(hh:nn:ss TT)
  Protection
  .Ban Protection � %banprot �
  ..Ban Protection On:/set %banprot On
  ..Ban Protection Off:/set %banprot Off
  .Flood Protection:/afp
}

menu channel {
  -
  Clones Control
  .-
  .Clone Manager:clones
  .-
  .Load: clones connect $$?="Server?" $$?="Port?" $$?="Number of Clones?"
  .Kill: clones kill
  .-
  .Flood
  ..Ping:clones flood $$?="Flood Ping Nick:" ping
  ..Time:clones flood $$?="Flood Time Nick:" time
  ..Version:clones flood $$?="Flood Version Nick:" version
  ..Privmsg:clones flood $$?="Flood Privmsg Nick:" privmsg $$?="MSG:"
  ..-
  ..Halt Flood:.timerCLONE_* off | .timerCOMPLETE_* off | echo 5 -st Clones: Halt Flood
  .-
  .Join #:clones command join $active
  .Part #:clones command part $active
  .-
  .Join a Channel:clones command join $$?="Channel:"
  .Part a Channel:clones command part $$?="Channel:"
  .-
  .Command:clones command $$?="Command?"
  .-
  .Nick
  ..$sock(clone*,1).name [ %clones.sock. [ $+ [ $remove($sock(clone*,1).name,clone) ] ] ]:sockwrite -tn $sock(clone*,1).name nick $$?="Nickname:"
  ..$sock(clone*,2).name [ %clones.sock. [ $+ [ $remove($sock(clone*,2).name,clone) ] ] ]:sockwrite -tn $sock(clone*,2).name nick $$?="Nickname:"
  ..$sock(clone*,3).name [ %clones.sock. [ $+ [ $remove($sock(clone*,3).name,clone) ] ] ]:sockwrite -tn $sock(clone*,3).name nick $$?="Nickname:"
  ..$sock(clone*,4).name [ %clones.sock. [ $+ [ $remove($sock(clone*,4).name,clone) ] ] ]:sockwrite -tn $sock(clone*,4).name nick $$?="Nickname:"
  ..$sock(clone*,5).name [ %clones.sock. [ $+ [ $remove($sock(clone*,5).name,clone) ] ] ]:sockwrite -tn $sock(clone*,5).name nick $$?="Nickname:"
  ..$sock(clone*,6).name [ %clones.sock. [ $+ [ $remove($sock(clone*,6).name,clone) ] ] ]:sockwrite -tn $sock(clone*,6).name nick $$?="Nickname:"
  ..$sock(clone*,7).name [ %clones.sock. [ $+ [ $remove($sock(clone*,7).name,clone) ] ] ]:sockwrite -tn $sock(clone*,7).name nick $$?="Nickname:"
  ..$sock(clone*,8).name [ %clones.sock. [ $+ [ $remove($sock(clone*,8).name,clone) ] ] ]:sockwrite -tn $sock(clone*,8).name nick $$?="Nickname:"
  Mass Stuff
  .Mass Op:/mass +o
  .Mass Deop:/mass -o
  .-
  .Mass Voice:/mass +v
  .Mass Devoice:/mass -v
  .-
  .Mass Kick
  ..Normal Users:/mk -normal
  ..-
  ..Non-Op Users:/mk -nonop
  ..Voice Users:/mk -voice
  ..Op Users:/mk -op
  ..-
  ..All Users:/mk -all
  .Mass Ban
  ..Normal Users:/mb -normal
  ..-
  ..Non-Op Users:/mb -nonop
  ..Voice Users:/mb -voice
  ..Op Users:/mb -op
  ..-
  ..All Users:/mb -all
  .Mass Ban-Kick
  ..Normal Users:/mbk -normal
  ..-
  ..Non-Op Users:/mbk -nonop
  ..Voice Users:/mbk -voice
  ..Op Users:/mbk -op
  ..-
  ..All Users:/mbk -all
  .-
  .Mass Message
  ..Normal Users:/mmsg -normal
  ..-
  ..Non-Op Users:/mmsg -nonop
  ..Voice Users:/mmsg -voice
  ..Op Users:/mmsg -op
  ..-
  ..All Users:/mmsg -all
  .Mass Notice
  ..Normal Users:/mnot -normal
  ..-
  ..Non-Op Users:/mnot -nonop
  ..Voice Users:/mnot -voice
  ..Op Users:/mnot -op
  ..-
  ..All Users:/mnot -all
  Other
  .AllAdvantage Hack
  ..Make Money
  ...While Your
  ....Chatting:/allad
  .Alternating Text � %alt-text �
  ..On (e.g, Brb > Be Rite Back) :/set %alt-text On
  ..Off (e.g, Brb > Brb) :/set %alt-text Off
  .Auto
  ..Auto Tell Asl � %autoasl �
  ...On:/set %autoasl On
  ...Off:/set %autoasl Off
  ..Auto Identify On Connect � %autoident �
  ...On: {
    /set %autoident On
    /set %autoident-pass $$?="Set Your Nick Password"
  }
  ...Off: {
    /set %autoident Off
    /unset %autoident-pass $?!="Your Password Has Been Unset"
  }
  .DCC Log Box:/disp.dcc
  .F Keys Menu:/fkeys
  .Personal Notes:/run notepad.exe $mircdir\notes.txt
  .Tools:/tools
  .-
  .Give Advice:/me : Advice Is $read $mircdirsystem\Advice.txt
  .Make Money:/msg # %money
  .Message All Channels:/amsg 4[12GLOBAL4] $$?="What Is Your Message:"
  .Poems:/say $read $mircdirsystem\poems.txt
  .System Uptime:/say 7Booted Computer:12 $replace($duration($calc($ticks / 1000)),wk,�Week,day,�Day,hr,�Hour,min,�Minute,sec,�Second) Ago
  .Tell
  ..Date:/say 12Today's Date Is4 $date
  ..Time:/say 12The time now is4 $time(hh::ss TT)
  Protection
  .Ban Protection � %banprot �
  ..Ban Protection On:/set %banprot On
  ..Ban Protection Off:/set %banprot Off
  .Flood Protection:/afp
  Scan Channel
  .Clone Scanner
  ..Private:/scannerp
  ..Public:/scan
  .Channel Stats
  ..Private:/stats -e
  ..Public:/stats -p
  .-
  .ISP Address
  ..Private:/ispscan -e
  ..Public:/ispscan -p
  .Away Users
  ..Private:/awayscan -e
  ..Public:/awayscan -p
  .IRCOps
  ..Private:/ircopscan -e
  ..Public:/ircopscan -p
  -
  Pictures
  .Pictures:/play $file="Select .txt file to play:" [ $mircdirPictures\ $+ *.txt ] 1000

}
