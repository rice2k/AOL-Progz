on 1:BAN:#:{
  if (%banprot != off) {
    if ( $banmask iswm $address($me,0) ) && ( $nick != $me ) { .msg ChanOP unban $chan $address($me,0) | goto A }
    if ( $banmask iswm $address($me,1) ) && ( $nick != $me ) { .msg ChanOP unban $chan $address($me,1) | goto A }
    if ( $banmask iswm $address($me,2) ) && ( $nick != $me ) { .msg ChanOP unban $chan $address($me,2) | goto A }
    if ( $banmask iswm $address($me,3) ) && ( $nick != $me ) { .msg ChanOP unban $chan $address($me,3) | goto A }
    if ( $banmask iswm $address($me,4) ) && ( $nick != $me ) { .msg ChanOP unban $chan $address($me,4) | goto A }
    if ( $banmask iswm $address($me,5) ) && ( $nick != $me ) { .msg ChanOP unban $chan $address($me,5) | goto A }
    if ( $banmask iswm $address($me,6) ) && ( $nick != $me ) { .msg ChanOP unban $chan $address($me,6) | goto A }
    if ( $banmask iswm $address($me,7) ) && ( $nick != $me ) { .msg ChanOP unban $chan $address($me,7) | goto A }
    if ( $banmask iswm $address($me,8) ) && ( $nick != $me ) { .msg ChanOP unban $chan $address($me,8) | goto A }
    if ( $banmask iswm $address($me,9) ) && ( $nick != $me ) { .msg ChanOP unban $chan $address($me,9) | goto A }
    else { goto end }
  :A
  if ( $me isop $chan ) && ( $nick != ChanOP ) { mode $chan -ob+bb $nick $banmask $address($nick,2) $address($nick,3) | kick $chan $nick %bot  Ban Protection }
  if ( $me !isop $chan ) && ( $nick != ChanOP ) { set %temp.kickp.chan $chan | set %temp.kickp.nick $nick | set %temp.kickp.add1 $address($nick,2) | set %temp.kickp.add2 $address($nick,3) | set %temp.kickp.banmask $banmask | .msg ChanOP OP $chan | .enable #C }
  .msg Chanop unban $chan $me
  .timer 10 2 .join $chan
  :end
}
}
