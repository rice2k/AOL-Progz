alias dmp3 {
  if ($dialog(mp3) == $null) { dialog -md mp3 mp3 }
  else { /echo -a 10Dialog already in 12use10. Check your 12start menu10. } 
}
dialog mp3 {
  title "MP3 Player"
  size -1 -1 375 325
  button "&Ok"1, 285 265 65 25, ok
  text "Location of mp3 player:"3, 25 25 120 20
  edit ""4, 140 23 165 20, autohs   
  button "Auto"5, 310 23 40 20
  text "Location of mp3s:"6, 25 55 100 20
  edit ""7, 115 52 190 20
  button "Browse"16, 310 52 40 20
  list 8, 25 80 325 150
  edit ""9, 25 235 225 22, read center
  edit ""10, 255 235 95 22, read center
  button "^Refresh^"11, 25 265 65 25
  button "Play"12, 90 265 65 25
  button "Stop"13, 155 265 65 25
  button "Random"14, 220 265 65 25
  box "Setup"15, 15 10 345 65
  button "Load an m3u list"17, 25 290 325 20
}


on 1:dialog:mp3:init:*:{
  /.timer -m 1 1 /listmp3
  did -a mp3 4 %winamplocation
  did -a mp3 7 %Mp3location
}

on 1:DIALOG:mp3:*:*:{
  if ($devent == edit) {
    if ($did == 4) { set %winamplocation $did(4) }
    if ($did == 7) { set %mp3location $did(7) }
  }
  if ($devent == sclick) {
    if ($did == 5) { /.timer -m 1 1 /findwinamp }
    if ($did == 16) { /.timer -m 1 1 /sdir } 
    if ($did == 11) { /.timer -m 1 1 /listmp3 }
    if ($did == 8) {  set %mp3 $did(8,$did(8).sel) | did -ra mp3 9 %mp3 | /set %mp3dir %mp3location $+ \ $+ %mp3 | did -ra mp3 10 $round($calc($lof(%mp3dir) / 1000000),2) $+ MB }
    if ($did == 12) { /.timer -m 1 1 /player }
    if ($did == 13) { run %winamplocation stop }
    if ($did == 14) { /.timer -m 1 1 /rplay }
    if ($did == 17) { /.timer -m 1 1 /m3u }
  }
  if ($devent == dclick) && ($did == 8) { set %mp3 $did(8,$did(8).sel) | /player }
}

menu @mp3 {
  dclick: .timermp3 off | mp3play $sline(@mp3,1)
  Next: if ($timer(mp3).com != $null) { $timer(mp3).com } | elseif ($line(@mp3,$calc($fline(@mp3,$nopath(%mp3.song),1,1) +1),1) == $null) { mp3play $line(@mp3,1,1) } | else { mp3play $line(@mp3,$calc($fline(@mp3,$nopath(%mp3.song),1,1) +1),1) }
  Play: set %mp3.random off | .timermp3 off | mp3play $sline(@mp3,1)
  Prev: if ($calc($fline(@mp3,$nopath(%mp3.song),1,1) -1) == 0) { mp3play $line(@mp3,%mp3.files,1) } | else { mp3play $line(@mp3,$calc($fline(@mp3,$nopath(%mp3.song),1,1) -1),1) }
  &Stop: .timermp3 off | run -n %mp3.player stop 
  -
  Add Song: set %mp3.song $$file="Select mp3 To Add" [ %mp3.drive $+ *.mp3 ] | aline -l @mp3 $nopath(%mp3.song) | inc %mp3.files | if ($readini system\drscriptmp3.ini mp3 %mp3.prefix == $null) { | titlebar @mp3 Playa.�Double Click To Play ( $+ %mp3.files $+ ) Files Loaded. | halt }
  Add Dir: set %mp3.drive $$sdir="Select mp3 Directory To Add" %mp3.drive | set %mp3.count 1 | :nextfile | if ($findfile(%mp3.drive,*.mp3,%mp3.count) != $null) { aline -l @mp3 $nopath($findfile(%mp3.drive,*.mp3,%mp3.count)) | inc %mp3.count | inc %mp3.files | goto nextfile } | if ($readini system\drscriptmp3.ini mp3 %mp3.prefix == $null) { | titlebar @mp3 Playa.�Double Click To Play ( $+ %mp3.files $+ ) Files Loaded. | halt }
  Del Songs: :nextdir | if ($sline(@mp3,1) != $null) { dline -l @mp3 $sline(@mp3,1).ln | dec %mp3.files | goto nextdir } | if ($readini system\drscriptmp3.ini mp3 %mp3.prefix == $null) { | titlebar @mp3 Playa.�Double Click To Play ( $+ %mp3.files $+ ) Files Loaded. | halt }
  Del All: clear -l @mp3 | set %mp3.files 0 | if ($readini system\drscriptmp3.ini mp3 %mp3.prefix == $null) { | titlebar @mp3 Playa.�Double Click To Play ( $+ %mp3.files $+ ) Files Loaded. | halt }
  -
  Options
  .Display ( %discol )
  ..Blue: set %ranmp3 off | set %color1 12 | set %discol Blue | echo 12-14=12-14=12- | echo 14m $+ %color1 $+ p143  %color1 $+ D14isplay  %color1 $+ N14ow  %color1 $+ S14et  %color1 $+ O14n %color1 $+ Blue 14And Grey | echo 12-14=12-14=12- 
  ..Light Blue: set %ranmp3 off | set %color1 11 | set %discol L.Blue | echo 12-14=12-14=12- | echo 14m $+ %color1 $+ p143  %color1 $+ D14isplay  %color1 $+ N14ow  %color1 $+ S14et  %color1 $+ O14n %color1 $+ Light Blue 14And Grey | echo 12-14=12-14=12- 
  ..Navy: set %ranmp3 off | set %color1 02 | set %discol Navy | echo 12-14=12-14=12- | echo 14m $+ %color1 $+ p143  %color1 $+ D14isplay  %color1 $+ N14ow  %color1 $+ S14et  %color1 $+ O14n %color1 $+ Navy 14And Grey | echo 12-14=12-14=12- 
  ..Grey: set %ranmp3 off | set %color1 15 | set %discol L.Grey | echo 12-14=12-14=12- | echo 14m $+ %color1 $+ p143  %color1 $+ D14isplay  %color1 $+ N14ow  %color1 $+ S14et  %color1 $+ O14n %color1 $+ Light Grey 14And Grey | echo 12-14=12-14=12- 
  ..Pink: set %ranmp3 off | set %color1 13 | set %discol Pink | echo 12-14=12-14=12- | echo 14m $+ %color1 $+ p143  %color1 $+ D14isplay  %color1 $+ N14ow  %color1 $+ S14et  %color1 $+ O14n %color1 $+ Pink 14And Grey | echo 12-14=12-14=12- 
  ..Purple: set %ranmp3 off | set %color1 06 | set %discol Purple | echo 12-14=12-14=12- | echo 14m $+ %color1 $+ p143  %color1 $+ D14isplay  %color1 $+ N14ow  %color1 $+ S14et  %color1 $+ O14n %color1 $+ Purple 14And Grey | echo 12-14=12-14=12- 
  ..Red: set %ranmp3 off | set %color1 04 | set %discol Red | echo 12-14=12-14=12- | echo 14m $+ %color1 $+ p143  %color1 $+ D14isplay  %color1 $+ N14ow  %color1 $+ S14et  %color1 $+ O14n %color1 $+ Red 14And Grey | echo 12-14=12-14=12- 
  ..Maroon: set %ranmp3 off | set %color1 05 | set %discol Maroon | echo 12-14=12-14=12- | echo 14m $+ %color1 $+ p143  %color1 $+ D14isplay  %color1 $+ N14ow  %color1 $+ S14et  %color1 $+ O14n %color1 $+ Maroon 14And Grey | echo 12-14=12-14=12- 
  ..Green: set %ranmp3 off | set %color1 09 | set %discol Green | echo 12-14=12-14=12- | echo 14m $+ %color1 $+ p143  %color1 $+ D14isplay  %color1 $+ N14ow  %color1 $+ S14et  %color1 $+ O14n %color1 $+ Green 14And Grey | echo 12-14=12-14=12- 
  ..Orange: set %ranmp3 off | set %color1 07 | set %discol Orange | echo 12-14=12-14=12- | echo 14m $+ %color1 $+ p143  %color1 $+ D14isplay  %color1 $+ N14ow  %color1 $+ S14et  %color1 $+ O14n %color1 $+ Orange 14And Grey | echo 12-14=12-14=12- 
  ..Yellow: set %ranmp3 off | set %color1 08 | set %discol Yellow | echo 12-14=12-14=12- | echo 14m $+ %color1 $+ p143  %color1 $+ D14isplay  %color1 $+ N14ow  %color1 $+ S14et  %color1 $+ O14n %color1 $+ Yellow 14And Grey | echo 12-14=12-14=12- 
  ..-
  ..Random ( %ranmp3 )
  ...on: set %ranmp3 on | set %discol Ran | echo 12-14=12-14=12- | echo 14m12p143 12D14isplay 4C13o11l7o8u12r11s 12A14re 12N14ow 12R14andom | echo 12-14=12-14=12- 
  ...off: set %ranmp3 off | set %discol Blue | echo 12-14=12-14=12- | set %color1 12 | echo 12R14andom 4C13o11l7o8u12r11s 12A14re 12N14ow 12O14ff. | echo 14m $+ %color1 $+ p143  %color1 $+ D14isplay  %color1 $+ N14ow  %color1 $+ S14et  %color1 $+ O14n %color1 $+ Blue 14And Grey | echo 12-14=12-14=12- 
  .-
  .Continuous�( %mp3.continuous ): if (%mp3.continuous == on) { set %mp3.continuous off | .timermp3 off | halt } | set %mp3.continuous on
  .Repeat�( %mp3.repeat ): if (%mp3.repeat == on) { set %mp3.repeat off | halt } | set %mp3.repeat on
  .Random�( %mp3.random ): if (%mp3.random == on) { set %mp3.random off | if ($timer(mp3).com != $null) { .timermp3 1 $timer(mp3).secs mp3play $line(@mp3,$calc($fline(@mp3,$nopath(%mp3.song),1,1) +1),1) } | halt } | set %mp3.random on | if ($timer(mp3).com != $null) { .timermp3 1 $timer(mp3).secs mp3play $line(@mp3,$rand(1,%mp3.files),1) }
  .Display�( %mp3.display ): if (%mp3.display == on) { set %mp3.display off | halt } | set %mp3.display on
  .-
  .Set Player: set %mp3.player $$dir="Select mp3 player" C:\*.exe
