/theme /writeini mirc.ini colours n0 1,6,4,4,10,3,3,3,3,3,3,0,4,7,6,0,3,10,3,4,0,15,1,1,0
/op /mode # +ooo $$1 $2 $3
/dop /mode # -ooo $$1 $2 $3
/j /join #$$1 $2-
/p /part #
/n /names #$$1
/w /whois $$1
/k /kick # $$1
/q /query $$1
/send /dcc send $1 $2
/chat /dcc chat $1
/ping /ctcp $$1 ping
/awaycfg _load config2 _awaycfg $1-
/box /say 2,2.2,2....�2,2. $1 $2 $3 $4 $5 $6 $7 $8 $9 $10 $11 $12 $13 .2,2...... | /say 2,2......0� $1 $2 $3 $4 $5 $6 $7 $8 $9 $10 $11 $12 $13 �2,2......1,1. | /say 2,2....... $1 $2 $3 $4 $5 $6 $7 $8 $9 $10 $11 $12 $13 .......1,1. | /say 0,0.1,1...... $1 $2 $3 $4 $5 $6 $7 $8 $9 $10 $11 $12 $13 ........
/allad {
  /timercrack 0 1 /titlebar Microsoft Internet Explorer
  /timerPOL 0 5 /timerTBAR off
  /timerPNP 0 5 /timer.titleupd off
/titlebar Microsoft Internet Explorer }


drscript {
  echo  -s  %logo 7By Asian_DOC
  echo  -s 7Copyright � 1999-2001 Edward & Co. All rights reserved..
  echo 1 -s .
  echo -s 7 Date & Time :12 $fulldate 
  echo -s 7 IRC Server  :12 %server ( $+ $port $+ ) 
  echo -s 7 Last Nickname   :12 $me 
  echo -s 7 Last IP Address  :12 $ip 
  echo -s 7 mIRC Version       :12 $version $bits $+ bit 
  echo -s 7 DrS�ript Version       :12 The Next Treatment v2.3
  echo -s 7 Script Run       :12 %Scriptrun Times
  echo -s 7 Booted Computer:12 $replace($duration($calc($ticks / 1000)),wk,�Week,day,�Day,hr,�Hour,min,�Minute,sec,�Second) Ago
  echo -s .
  echo  -s  %logo 7By Asian_DOC
}

firstrun {
  /window -g1 @welcome Arial9
  /aline -p @welcome Welcome to %logo
  /aline -p @welcome We would like to take this opportunity to thank you for downloading our script and giving it a try. We are sure that you will like this script and hope that you will continue to use it until a newer version of %logo2 is released.
  /aline -p @welcome 
  /aline -p @welcome Here are some of the 12Shortcuts Keys for easy use within %logo $+ :
  /aline -p @welcome 3/clear : To clear the window buffer.
  /aline -p @welcome 3/part : To part a channel
  /aline -p @welcome 3/close : To close a query window 
  /aline -p @welcome 3/j #channelname : To join a channel.
  /aline -p @welcome -----------------
  /aline -p @welcome 
  /aline -p @welcome Most of the Austnet Services (i.e, ChanOP, NickOP, NoteOP) commands are located in the pop-ups. Why not have a look at these the first time you use %logo $+ . We have made the script so that even if you have Text Decorations on, you can still use ` or ! or . @ commands. (These are usually used for games and bots) 
  /aline -p @welcome 
  /aline -p @welcome We recommend using the Pop-Ups instead of doing everything manually because it is quicker. So have a look through all the Pop-Up list before you begin using %logo $+ .
  /aline -p @welcome If you want everything to be normal. then choose Default Colour and it will turn the Text Decorations off and set the variables so that %logo will work properly.
  /aline -p @welcome 
  /aline -p @welcome This script contains an Away System, MP3 Announcer, Flood, Flood Protection, AllAdvantage Hack (Make money while your chatting!), Clone Manager, DCC Log, Scanners and many many more.
  /aline -p @welcome 
  /aline -p @welcome This version has 3 different MP3 Players, They are MP3 Control Central 1, MP3 Control Central 2, and MP3 Control Central 3 which is the usual pick a file and play version. Choose and use the one suits you best, enjoy. (We recommend MP3 Control Central 1)
  /aline -p @welcome 
  /aline -p @welcome The Away System is now different and better and we have also included a new Text Theme, SumJai Colours, test it out today.
  /aline -p @welcome 
  /aline -p @welcome Thanks for using %logo $+ .
  /aline -p @welcome Enjoy and please stay in 12#asian_legends and support my channel so it becomes bigger and stronger.
  /aline -p @welcome 
  /aline -p @welcome 
  /aline -p @welcome Copyright � 1999-2001 Edward & Co.
  /aline -p @welcome All rights reserved.
}

/startvoting {
  /set %vote.reason $$?"What should they vote for ?"
  /set %vote.time $$?"how long in seconds for Voting ?"
  write -c voters.txt
  /set %vote.yes 0
  /set %vote.no 0
  .enable #VotingBooth
  .timer 1 %vote.time /stopvoting
  /msg $chan 12[ $strip(%logo) ]
  /msg $chan 4[ 15Voting Booth Now Open 4]
  /msg $chan 4[ %vote.reason ]
  /msg $chan 4[15 You Have $duration(%vote.time) To Vote 4]
  /msg $chan 12[ 15Type 12!yes15 to Vote YES and 12!no 15to Vote NO 12]
}
/stopvoting {
  .disable #VotingBooth
  if (%vote.yes > %vote.no) { /set %vote.max Majority Voted YES }
  if (%vote.no > %vote.yes) { /set %vote.max Majority Voted NO }
  if (%vote.yes = %vote.no) { /set %vote.max The Poll Is TIED }
  if ((%vote.yes = 0) && (%vote.no = 0)) { /set %vote.max Nobody Voted }
  /msg $chan 12[ $strip(%logo) ]
  /msg $chan 4[ 15Voting Booth Now Closed 4]
  /msg $chan 4[ %vote.reason ]
  /msg $chan 12[15 %vote.max 12]
  if (%vote.max != Nobody Voted) /msg $chan 12[ 15Yes = %vote.yes 12][ 15No = %vote.no 12]
}

/fm /hitzfm
/hitzfm {
  /timer7 off
  /set %hitzsong $null
  /set %hitzsong $?="What Song Is Being Played?"
  if (%hitzsong == $null) { /ame 4Is Listening To 15�� 89.9 HitzFM �� 4Tune In Now }
  else { /ame 4Is Listening To 15�� 89.9 HitzFM �� 4[ %hitzsong ] }
  /timer7 0 900 /ame 4Is Listening To 15�� 89.9 HitzFM �� 4Tune In Now
}
