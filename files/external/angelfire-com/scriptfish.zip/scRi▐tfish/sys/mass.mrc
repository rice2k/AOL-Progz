/mass {
  if ( $me !isop # ) { echo 4 -a %as.error You're not a channel operator on  $+ # $+  !! | halt }
  unset %temp.mass.* | set %temp.mass.nick "" | set %temp.mass.count 0
  if ( $1 == +o ) {
    :A
    inc %temp.mass.count
    if ( %temp.mass.count > $nopnick(#,0) ) {
      if ( $len(%temp.mass.nick) > 0 ) { raw -q mode # +oooooo %temp.mass.nick }
      halt
    }
    if ( $count(%temp.mass.nick,$chr(32)) == 5 ) {
      raw -q mode # +oooooo %temp.mass.nick
      set %temp.mass.nick ""
    }
    set %temp.mass.nick %temp.mass.nick $nopnick(#,%temp.mass.count)
    goto A
  }
  if ( $1 == -o ) {
    :B
    inc %temp.mass.count
    if ( %temp.mass.count > $opnick(#,0) ) {
      if ( $len(%temp.mass.nick) > 0 ) { raw -q mode # -oooooo %temp.mass.nick }
      halt
    }
    if ( $count(%temp.mass.nick,$chr(32)) == 5 ) {
      raw -q mode # -oooooo %temp.mass.nick
      set %temp.mass.nick ""
    }
    if ( $opnick(#,%temp.mass.count) == $me ) || ( $opnick(#,%temp.mass.count) == ChanOP ) { goto B }
    else {
      set %temp.mass.nick %temp.mass.nick $nick(#,%temp.mass.count)
      goto B
    }
  }
  if ( $1 == +v ) {
    :C
    inc %temp.mass.count
    if ( %temp.mass.count > $nvnick(#,0) ) {
      if ( $len(%temp.mass.nick) > 0 ) { raw -q mode # +vvvvvv %temp.mass.nick }
      halt
    }
    if ( $count(%temp.mass.nick,$chr(32)) == 5 ) {
      raw -q mode # +vvvvvv %temp.mass.nick
      set %temp.mass.nick ""
    }
    set %temp.mass.nick %temp.mass.nick $nvnick(#,%temp.mass.count)
    goto C
  }
  if ( $1 == -v ) {
    :D
    inc %temp.mass.count
    if ( %temp.mass.count > $vnick(#,0) ) {
      if ( $len(%temp.mass.nick) > 0 ) { raw -q mode # -vvvvvv %temp.mass.nick }
      halt
    }
    if ( $count(%temp.mass.nick,$chr(32)) == 5 ) {
      raw -q mode # -vvvvvv %temp.mass.nick
      set %temp.mass.nick ""
    }
    set %temp.mass.nick %temp.mass.nick $vnick(#,%temp.mass.count)
    goto D
  }
}
/mk {
  if ( $me !isop # ) { echo 4 -a %as.error You're not a channel operator on  $+ # $+  !! | halt }
  unset %temp.mk.* | set %temp.mk.chan # | set %temp.mk.count 1
  if ( $1 == -normal ) {
    :A
    set %temp.mk.nick $nvnick(#,%temp.mk.count)
    if ( %temp.mk.nick == $null ) { echo 2 -a %as.note Mass Kick normal users on  $+ %temp.mk.chan $+  in progress | halt }
    kick %temp.mk.chan %temp.mk.nick 12-Mass ]{ick- 3Normal Users!!
    inc %temp.mk.count 1
    goto A
  }
  if ( $1 == -voice ) {
    :B
    set %temp.mk.nick $vnick(#,%temp.mk.count)
    if ( %temp.mk.nick == $null ) { echo 2 -a %fsx2 Mass Kick voice users on  $+ %temp.mk.chan $+  in progress | halt }
    kick %temp.mk.chan %temp.mk.nick 12-Mass ]{ick- 3Voiced Users!!
    inc %temp.mk.count 1
    goto B
  }
  if ( $1 == -op ) {
    :C
    set %temp.mk.nick $opnick(#,%temp.mk.count)
    if ( %temp.mk.nick == $null ) { echo 2 -a %fsx2 Mass Kick op users on  $+ %temp.mk.chan $+  in progress | halt }
    if ( %temp.mk.nick != $me ) && ( %temp.mk.nick != ChanOP ) { kick %temp.mk.chan %temp.mk.nick 12-Mass ]{ick- 3Op Users!! }
    inc %temp.mk.count 1
    goto C
  }
  if ( $1 == -all ) {
    :D
    set %temp.mk.nick $nick(#,%temp.mk.count)
    if ( %temp.mk.nick == $null ) { echo 2 -a %fsx2 Mass Kick all users on  $+ %temp.mk.chan $+  in progress | halt }
    if ( %temp.mk.nick != $me ) && ( %temp.mk.nick != ChanOP ) { kick %temp.mk.chan %temp.mk.nick 12-Mass ]{ick- 3All Users!! }
    inc %temp.mk.count 1
    goto D
  }
  if ( $1 == -nonop ) {
    :E
    set %temp.mk.nick $nopnick(#,%temp.mk.count)
    if ( %temp.mk.nick == $null ) { echo 2 -a %fsx2 Mass Kick non-op users on  $+ %temp.mk.chan $+  in progress | halt }
    kick %temp.mk.chan %temp.mk.nick 14[5=3M�ss K��k5=14] Non-Op Users !!
    inc %temp.mk.count 1
    goto E
  }
}
/mb {
  if ( $me !isop # ) { echo 4 -a %as.error You're not a channel operator on  $+ # $+  !! | halt }
  unset %temp.mb.* | set %temp.mb.chan # | set %temp.mb.count 1
  if ( $1 == -normal ) {
    :A
    set %temp.mb.nick $nvnick(#,%temp.mb.count)
    if ( %temp.mb.nick == $null ) { echo 2 -a %fsx2 Mass Ban normal users on  $+ %temp.mb.chan $+  in progress | halt }
    mode %temp.mb.chan +b $address(%temp.mb.nick,3)
    inc %temp.mb.count 1
    goto A
  }
  if ( $1 == -voice ) {
    :B
    set %temp.mb.nick $vnick(#,%temp.mb.count)
    if ( %temp.mb.nick == $null ) { echo 2 -a %fsx2 Mass Ban voice users on  $+ %temp.mb.chan $+  in progress | halt }
    mode %temp.mb.chan +b $address(%temp.mb.nick,3)
    inc %temp.mb.count 1
    goto B
  }
  if ( $1 == -op ) {
    :C
    set %temp.mb.nick $opnick(#,%temp.mb.count)
    if ( %temp.mb.nick == $null ) { echo 2 -a %fsx2 Mass Ban op users on  $+ %temp.mb.chan $+  in progress | halt }
    if ( %temp.mb.nick != $me ) && ( %temp.mb.nick != ChanOP ) { mode %temp.mb.chan +b $address(%temp.mb.nick,3) }
    inc %temp.mb.count 1
    goto C
  }
  if ( $1 == -all ) {
    :D
    set %temp.mb.nick $nick(#,%temp.mb.count)
    if ( %temp.mb.nick == $null ) { echo 2 -a %fsx2 Mass Ban all users on  $+ %temp.mb.chan $+  in progress | halt }
    if ( %temp.mb.nick != $me ) && ( %temp.mb.nick != ChanOP ) { mode %temp.mb.chan +b $address(%temp.mb.nick,3) }
    inc %temp.mb.count 1
    goto D
  }
  if ( $1 == -nonop ) {
    :E
    set %temp.mb.nick $nopnick(#,%temp.mb.count)
    if ( %temp.mb.nick == $null ) { echo 2 -a %fsx2 Mass Ban non-op users on  $+ %temp.mb.chan $+  in progress | halt }
    mode %temp.mb.chan +b $address(%temp.mb.nick,3)
    inc %temp.mb.count 1
    goto E
  }
}
/mbk {
  if ( $me !isop # ) { echo 4 -a %as.error You're not a channel operator on  $+ # $+  !! | halt }
  unset %temp.mbk.* | set %temp.mbk.chan # | set %temp.mbk.count 1
  if ( $1 == -normal ) {
    :A
    set %temp.mbk.nick $nvnick(#,%temp.mbk.count)
    if ( %temp.mbk.nick == $null ) { echo 2 -a %fsx2 Mass Ban-Kick normal users on  $+ %temp.mbk.chan $+  in progress | halt }
    mode %temp.mbk.chan +b $address(%temp.mbk.nick,3)
    kick %temp.mbk.chan %temp.mbk.nick 12-Mass Ban ]{ick- 3Normal Users!!
    inc %temp.mbk.count 1
    goto A
  }
  if ( $1 == -voice ) {
    :B
    set %temp.mbk.nick $vnick(#,%temp.mbk.count)
    if ( %temp.mbk.nick == $null ) { echo 2 -a %fsx2 Mass Ban-Kick voice users on  $+ %temp.mbk.chan $+  in progress | halt }
    mode %temp.mbk.chan +b $address(%temp.mbk.nick,3)
    kick %temp.mbk.chan %temp.mbk.nick 12-Mass Ban ]{ick- 3Voice Users!!
    inc %temp.mbk.count 1
    goto B
  }
  if ( $1 == -op ) {
    :C
    set %temp.mbk.nick $opnick(#,%temp.mbk.count)
    if ( %temp.mbk.nick == $null ) { echo 2 -a %fsx2 Mass Ban-Kick op users on  $+ %temp.mbk.chan $+  in progress | halt }
    if ( %temp.mbk.nick != $me ) && ( %temp.mbk.nick != ChanOP ) {
      mode %temp.mbk.chan +b $address(%temp.mbk.nick,3)
      kick %temp.mbk.chan %temp.mbk.nick 12-Mass Ban ]{ick- 3Op Users!!
    }
    inc %temp.mbk.count 1
    goto C
  }
  if ( $1 == -all ) {
    :D
    set %temp.mbk.nick $nick(#,%temp.mbk.count)
    if ( %temp.mbk.nick == $null ) { echo 2 -a %fsx2 Mass Ban-Kick all users on  $+ %temp.mbk.chan $+  in progress | halt }
    if ( %temp.mbk.nick != $me ) && ( %temp.mbk.nick != ChanOP ) {
      mode %temp.mbk.chan +b $address(%temp.mbk.nick,3)
      kick %temp.mbk.chan %temp.mbk.nick 12-Mass Ban ]{ick- 3All Users!!
    }
    inc %temp.mbk.count 1
    goto D
  }
  if ( $1 == -nonop ) {
    :E
    set %temp.mbk.nick $nopnick(#,%temp.mbk.count)
    if ( %temp.mbk.nick == $null ) { echo 2 -a %fsx2 Mass Ban-Kick non-op users on  $+ %temp.mbk.chan $+  in progress | halt }
    mode %temp.mbk.chan +b $address(%temp.mbk.nick,3)
    kick %temp.mbk.chan %temp.mbk.nick 12-Mass Ban ]{ick- 3Non-Op Users!!
    inc %temp.mbk.count 1
    goto E
  }
}
/mmsg {
  unset %temp.mmsg.* | set %temp.mmsg.chan # | set %temp.mmsg.count 1
  set %temp.mmsg.msg $?="Enter Your Message"
  if ( %temp.mmsg.msg == $null ) { halt }
  if ( $1 == -normal ) {
    :A
    set %temp.mmsg.nick $nvnick(#,%temp.mmsg.count)
    if ( %temp.mmsg.nick == $null ) { echo 2 -a %as.note Mass Message to normal users on  $+ %temp.mmsg.chan $+  complete | halt }
    if ( %temp.mmsg.nick != $me ) { .msg %temp.mmsg.nick %temp.mmsg.msg }
    inc %temp.mmsg.count 1
    goto A
  }
  if ( $1 == -voice ) {
    :B
    set %temp.mmsg.nick $vnick(#,%temp.mmsg.count)
    if ( %temp.mmsg.nick == $null ) { echo 2 -a %as.note Mass Message to voice users on  $+ %temp.mmsg.chan $+  complete | halt }
    if ( %temp.mmsg.nick != $me ) { .msg %temp.mmsg.nick %temp.mmsg.msg }
    inc %temp.mmsg.count 1
    goto B
  }
  if ( $1 == -op ) {
    :C
    set %temp.mmsg.nick $opnick(#,%temp.mmsg.count)
    if ( %temp.mmsg.nick == $null ) { echo 2 -a %as.note Mass Message to op users on  $+ %temp.mmsg.chan $+  complete | halt }
    if ( %temp.mmsg.nick != $me ) && ( %temp.mmsg.nick != ChanOP ) { .msg %temp.mmsg.nick %temp.mmsg.msg }
    inc %temp.mmsg.count 1
    goto C
  }
  if ( $1 == -all ) {
    :D
    set %temp.mmsg.nick $nick(#,%temp.mmsg.count)
    if ( %temp.mmsg.nick == $null ) { echo 2 -a %as.note Mass Message to all users on  $+ %temp.mmsg.chan $+  complete | halt }
    if ( %temp.mmsg.nick != $me ) && ( %temp.mmsg.nick != ChanOP ) { .msg %temp.mmsg.nick %temp.mmsg.msg }
    inc %temp.mmsg.count 1
    goto D
  }
  if ( $1 == -nonop ) {
    :E
    set %temp.mmsg.nick $nopnick(#,%temp.mmsg.count)
    if ( %temp.mmsg.nick == $null ) { echo 2 -a %as.note Mass Message to non-op users on  $+ %temp.mmsg.chan $+  complete | halt }
    if ( %temp.mmsg.nick != $me ) { .msg %temp.mmsg.nick %temp.mmsg.msg }
    inc %temp.mmsg.count 1
    goto E
  }
}
/mnot {
  unset %temp.mnot.* | set %temp.mnot.chan # | set %temp.mnot.count 1
  set %temp.mnot.not $?="Enter Your Notice"
  if ( %temp.mnot.not == $null ) { halt }
  if ( $1 == -normal ) {
    :A
    set %temp.mnot.nick $nvnick(#,%temp.mnot.count)
    if ( %temp.mnot.nick == $null ) { echo 2 -a %as.note Mass Notice to normal users on  $+ %temp.mnot.chan $+  complete | halt }
    if ( %temp.mnot.nick != $me ) { .notice %temp.mnot.nick %temp.mnot.not }
    inc %temp.mnot.count 1
    goto A
  }
  if ( $1 == -voice ) {
    :B
    set %temp.mnot.nick $vnick(#,%temp.mnot.count)
    if ( %temp.mnot.nick == $null ) { echo 2 -a %as.note Mass Notice to voice users on  $+ %temp.mnot.chan $+  complete | halt }
    if ( %temp.mnot.nick != $me ) { .notice %temp.mnot.nick %temp.mnot.not }
    inc %temp.mnot.count 1
    goto B
  }
  if ( $1 == -op ) {
    :C
    set %temp.mnot.nick $opnick(#,%temp.mnot.count)
    if ( %temp.mnot.nick == $null ) { echo 2 -a %as.note Mass Notice to op users on  $+ %temp.mnot.chan $+  complete | halt }
    if ( %temp.mnot.nick != $me ) && ( %temp.mnot.nick != ChanOP ) { .notice %temp.mnot.nick %temp.mnot.not }
    inc %temp.mnot.count 1
    goto C
  }
  if ( $1 == -all ) {
    :D
    set %temp.mnot.nick $nick(#,%temp.mnot.count)
    if ( %temp.mnot.nick == $null ) { echo 2 -a %as.note Mass Notice to all users on  $+ %temp.mnot.chan $+  complete | halt }
    if ( %temp.mnot.nick != $me ) && ( %temp.mnot.nick != ChanOP ) { .notice %temp.mnot.nick %temp.mnot.not }
    inc %temp.mnot.count 1
    goto D
  }
  if ( $1 == -nonop ) {
    :E
    set %temp.mnot.nick $nopnick(#,%temp.mnot.count)
    if ( %temp.mnot.nick == $null ) { echo 2 -a %as.note Mass Notice to non-op users on  $+ %temp.mnot.chan $+  complete | halt }
    if ( %temp.mnot.nick != $me ) { .notice %temp.mnot.nick %temp.mnot.not }
    inc %temp.mnot.count 1
    goto E
  }
}
