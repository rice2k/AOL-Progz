on 1:text:*@guess*:%b.gamechan: {
  if (%guess == on) { goto one }
  else halt
  :one
  set %number.g $$2
  if ((%number.g > %g.number) && (%number.g < $calc(%g.number + 5))) { msg $chan 15,0Your guess is abit over $nick | goto end }
  if ((%number.g > %g.number) && (%number.g > $calc(%g.number + 5))) { msg $chan 15,0Your guess is to high $nick | goto end }
  if ((%number.g < %g.number) && (%number.g > $calc(%g.number - 5))) { msg $chan 15,0Your guess is abit under $nick | goto end }
  if ((%number.g < %g.number) && (%number.g < $calc(%g.number - 5))) { msg $chan 15,0Your guess is to low $nick | goto end }
  if (%number.g == %g.number) { 
    msg $chan 15You guess it right $nick  | msg $chan 15The number was %g.number
    msg $chan 15Number Guessing game is now 4off. %logo 
    unset %g.gamechan
    set %guess off
    goto end
  }
  :end
}

on 1:TEXT:@8ball*:%gamechan: {
  if (%ball == on) { /msg %gamechan $nick : 15The 8ball Says :12 $READ $mircdirsystem/8ball.txt }
}

#VotingBooth off
on *:text:*!yes*:#: {
  /set %votecheck2 0
  :nextvotecheck
  /inc %votecheck2 1
  /set %votecheck $read -l $+ %votecheck2 voters.txt
  if (%votecheck = $nick) halt
  if (%votecheck = $null) goto writevoter
  goto nextvotecheck
  :writevoter
  /write voters.txt $nick
  .notice $nick Thanx for Voting Yes %logo
  /inc %vote.yes 1
}
on *:text:*!no*:#: {
  /set %votecheck2 0
  :nextvotecheck
  /inc %votecheck2 1
  /set %votecheck $read -l $+ %votecheck2 voters.txt
  if (%votecheck = $nick) halt
  if (%votecheck = $null) goto writevoter
  goto nextvotecheck
  :writevoter
  /write voters.txt $nick
  .notice $nick Thanx for Voting No %logo
  /inc %vote.no 1
}
#VotingBooth end
