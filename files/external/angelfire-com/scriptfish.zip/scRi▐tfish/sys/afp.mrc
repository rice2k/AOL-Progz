alias afp { if ($dialog(afpd) == $null) dialog -m afpd afpd }
dialog afpd {
  title "DrS�ript Advanced Flood Protection"
  size -1 -1 257 178
  option dbu
  button "&Apply", 1, 10 147 37 11, ok default
  button "&Reset", 2, 192 147 26 11
  button "&Close", 3, 5 165 37 11, cancel
  button "C&lear All", 35, 221 147 26 11
  button "&Enable All", 65, 50 147 37 11
  button "&Disable All", 66, 90 147 37 11
  box "Channel Protection (requires ops)", 4, 10 20 117 123
  box "Self Protection", 5, 130 20 117 95
  text "TEXT              Max         within         secs", 6, 24 30 100 8
  check "", 7, 15 30 8 8
  edit "", 8, 72 29 8 9
  edit "", 9, 99 29 8 9
  text "ACTION          Max         within         secs", 10, 24 40 99 8
  check "", 11, 15 40 8 8
  edit "", 12, 72 39 8 9
  edit "", 13, 99 39 8 9
  text "NOTICE          Max         within         secs", 14, 24 50 99 8
  check "", 15, 15 50 8 8
  edit "", 16, 72 49 8 9
  edit "", 17, 99 49 8 9
  text "CTCP              Max         within         secs", 18, 24 60 99 8
  check "", 19, 15 60 8 8
  edit "", 20, 72 59 8 9
  edit "", 21, 99 59 8 9
  text "NICK               Max         within         secs", 22, 24 70 99 8
  check "", 23, 15 70 8 8
  edit "", 24, 72 69 8 9
  edit "", 25, 99 69 8 9
  text "JOIN/PART    Max         within         secs", 26, 24 80 99 8
  check "", 27, 15 80 8 8
  edit "", 28, 72 79 8 9
  edit "", 29, 99 79 8 9
  text "Penalty for exceeding max:", 30,  15 95 64 9
  radio "Kick/Ban", 31, 20 103 33 8, group
  radio "Kick Only", 32, 20 112 33 8
  text "Kick Msg:", 33, 15 129 24 8
  edit "", 34, 41 127 81 11, autohs
  text "MSG/NTC      Max         within         secs", 36, 144 30 99 8
  check "", 37, 135 30 8 8
  edit "", 38, 192 29 8 9
  edit "", 39, 219 29 8 9
  text "CTCP              Max         within         secs", 40, 144 40 99 8
  check "", 41, 135 40 8 8
  edit "", 42, 192 39 8 9
  edit "", 43, 219 39 8 9
  text "INVITE           Max         within         secs", 44, 144 50 99 8
  check "", 45, 135 50 8 8
  edit "", 46, 192 49 8 9
  edit "", 47, 219 49 8 9
  text "DCC SEND     Max         within         secs", 48, 144 60 99 8
  check "", 49, 135 60 8 8
  edit "", 50, 192 59 8 9
  edit "", 51, 219 59 8 9
  text "DCC CHAT     Max         within         secs", 52, 144 70 99 8
  check "", 53, 135 70 8 8
  edit "", 54, 192 69 8 9
  edit "", 55, 219 69 8 9
  text "Ignore Type:", 56,  135 85 30 8
  radio "", 57, 140 93 7 8, group
  radio "", 58, 140 102 7 8
  text "Ignore for          min(s)", 59, 149 93 53 8
  edit "20", 60, 174 92 11 10
  text "Permanent", 61, 149 102 27 8
  box "Mask Type (ban and ignore)", 62, 130 116 88 27
  combo 63, 135 127 78 53, hsbar size drop
  ;------------------- icon 64, -1 -1 569 351
  box "CPL", 67, 221 116 26 27
  edit "", 68, 227 127 14 11
  text "2000", 69, 183 167 70 9, disable
  tab "Flood Control", 70, 5 2 247 160
  tab "Help", 71
  edit "", 72, 7 23 243 138, read return multi vsbar hide
}
on *:dialog:afpd:init:*:{
  %afp_hlp = $scriptdirafp-hlp.txt | if ($ial == $false) .ial on
  did -a afpd 63 [0] *!user@host.domain
  did -a afpd 63 [1] *!*user@host.domain
  did -a afpd 63 [2] *!*@host.domain
  did -a afpd 63 [3] *!*user@*.domain
  did -a afpd 63 [4] *!*@*.domain
  did -a afpd 63 [5] nick!user@host.domain
  did -a afpd 63 [6] nick!*user@host.domain
  did -a afpd 63 [7] nick!*@host.domain
  did -a afpd 63 [8] nick!*user@*.domain
  did -a afpd 63 [9] nick!*@*.domain
  did -b afpd 1 | .timer 1 0 did -f afpd 34
  if (%pro.s.i-b.typ == $null) { %pro.s.i-b.typ = 3 | %pro.s.i-b.sel = $gettok($did(63,%pro.s.i-b.typ),2,32) } | did -c afpd 63 %pro.s.i-b.typ
  if (%pro.c.kck.msg == $null) { %pro.c.kck.msg = Flood control kick (AFP v2.0) } | did -a afpd 34 %pro.c.kck.msg
  if (%pro.a.len == $null) { %pro.a.len = 300 } | did -a afpd 68 %pro.a.len
  checkeditb
  if (%pro.s.n-m.max != $null) { did -a afpd 38 %pro.s.n-m.max }
  if (%pro.s.n-m.sec != $null) { did -a afpd 39 %pro.s.n-m.sec }
  if (%pro.s.ctc.max != $null) { did -a afpd 42 %pro.s.ctc.max }
  if (%pro.s.ctc.sec != $null) { did -a afpd 43 %pro.s.ctc.sec }
  if (%pro.s.inv.max != $null) { did -a afpd 46 %pro.s.inv.max }
  if (%pro.s.inv.sec != $null) { did -a afpd 47 %pro.s.inv.sec }
  if (%pro.s.snd.max != $null) { did -a afpd 50 %pro.s.snd.max }
  if (%pro.s.snd.sec != $null) { did -a afpd 51 %pro.s.snd.sec }
  if (%pro.s.cht.max != $null) { did -a afpd 54 %pro.s.cht.max }
  if (%pro.s.cht.sec != $null) { did -a afpd 55 %pro.s.cht.sec }
  if (%pro.c.txt.max != $null) { did -a afpd 8 %pro.c.txt.max }
  if (%pro.c.txt.sec != $null) { did -a afpd 9 %pro.c.txt.sec }
  if (%pro.c.act.max != $null) { did -a afpd 12 %pro.c.act.max }
  if (%pro.c.act.sec != $null) { did -a afpd 13 %pro.c.act.sec }
  if (%pro.c.not.max != $null) { did -a afpd 16 %pro.c.not.max }
  if (%pro.c.not.sec != $null) { did -a afpd 17 %pro.c.not.sec }
  if (%pro.c.ctc.max != $null) { did -a afpd 20 %pro.c.ctc.max }
  if (%pro.c.ctc.sec != $null) { did -a afpd 21 %pro.c.ctc.sec }
  if (%pro.c.nik.max != $null) { did -a afpd 24 %pro.c.nik.max }
  if (%pro.c.nik.sec != $null) { did -a afpd 25 %pro.c.nik.sec }
  if (%pro.c.j-p.max != $null) { did -a afpd 28 %pro.c.j-p.max }
  if (%pro.c.j-p.sec != $null) { did -a afpd 29 %pro.c.j-p.sec }
  if (%pro.s.n-m = !) { did -c afpd 37 } | else { did -b afpd 38,39 }
  if (%pro.s.ctc = !) { did -c afpd 41 } | else { did -b afpd 42,43 }
  if (%pro.s.inv = !) { did -c afpd 45 } | else { did -b afpd 46,47 }
  if (%pro.s.snd = !) { did -c afpd 49 } | else { did -b afpd 50,51 }
  if (%pro.s.cht = !) { did -c afpd 53 } | else { did -b afpd 54,55 }
  if (%pro.c.txt = !) { did -c afpd 7 } | else { did -b afpd 8,9 }
  if (%pro.c.act = !) { did -c afpd 11 } | else { did -b afpd 12,13 }
  if (%pro.c.not = !) { did -c afpd 15 } | else { did -b afpd 16,17 }
  if (%pro.c.ctc = !) { did -c afpd 19 } | else { did -b afpd 20,21 }
  if (%pro.c.nik = !) { did -c afpd 23 } | else { did -b afpd 24,25 }
  if (%pro.c.j-p = !) { did -c afpd 27 } | else { did -b afpd 28,29 }
  if (%pro.c.kik = !) { did -c afpd 32 | unset %pro.c.k-b } | else { did -c afpd 31 }
  if (%pro.s.ign.prm = $null) && (%pro.s.ign.tmp = $null) { %pro.s.ign.tmp = ! | %pro.s.ign.min = 5 | %pro.s.ign.sec = 300 }
  if (%pro.s.ign.prm = !) { did -c afpd 58 | did -u afpd 57 | did -m afpd 60 }
  if (%pro.s.ign.tmp = !) { did -c afpd 57 | did -u afpd 58 | did -n afpd 60 }
  did -o afpd 60 1 %pro.s.ign.min
}
on *:dialog:afpd:edit:*:{
  if ($did = 34) { did -e afpd 1,2 | halt }
  if ($did($did) != $null) { unset %pro.chk.edt | did -e afpd 1,2 }
  if ($did($did) = $null) || ($did($did) !isnum) || ($left($did($did),1) == 0) || (- isin $did($did)) || (+ isin $did($did)) || (. isin $did($did)) { set %pro.chk.edt ! | did -b afpd 1 | halt }
}
on *:dialog:afpd:sclick:*:{
  if ($did = 1) {
    if (%pro.chk.edt != $null) halt | if ($did(68) < 50) { did -o afpd 68 1 50 | halt }
    %pro.a.len = $did(68) | %pro.c.txt.max = $did(8) | %pro.c.txt.sec = $did(9) | %pro.c.act.max = $did(12) | %pro.s.ign.min = $did(60) | %pro.s.ign.sec = %pro.s.ign.min * 60
    %pro.c.act.sec = $did(13) | %pro.c.not.max = $did(16) | %pro.c.not.sec = $did(17) | %pro.c.ctc.max = $did(20) | %pro.c.ctc.sec = $did(21)
    %pro.c.nik.max = $did(24) | %pro.c.nik.sec = $did(25) | %pro.c.j-p.max = $did(28) | %pro.c.j-p.sec = $did(29) | %pro.s.n-m.max = $did(38)
    %pro.s.n-m.sec = $did(39) | %pro.s.ctc.max = $did(42) | %pro.s.ctc.sec = $did(43) | %pro.s.inv.max = $did(46) | %pro.s.inv.sec = $did(47)
    %pro.s.snd.max = $did(50) | %pro.s.snd.sec = $did(51) | %pro.s.cht.max = $did(54) | %pro.s.cht.sec = $did(55) | %pro.c.kck.msg = $did(34)
    %pro.s.i-b.typ = $did(63).sel | %pro.s.i-b.sel = $gettok($did(63,%pro.s.i-b.typ),2,32) | %pro.s.i-b.typ2 = %pro.s.i-b.typ - 1
    did -b afpd 1 | halt
  }
  if ($did = 2) {
    %pro.s.n-m = ! | did -c afpd 37 | did -o afpd 38 1 3 | did -o afpd 39 1 2 | %pro.s.n-m.max = 3 | %pro.s.n-m.sec = 2
    %pro.s.ctc = ! | did -c afpd 41 | did -o afpd 42 1 2 | did -o afpd 43 1 5 | %pro.s.ctc.max = 2 | %pro.s.ctc.sec = 5
    %pro.s.inv = ! | did -c afpd 45 | did -o afpd 46 1 2 | did -o afpd 47 1 5 | %pro.s.inv.max = 2 | %pro.s.inv.sec = 5
    %pro.s.snd = ! | did -c afpd 49 | did -o afpd 50 1 3 | did -o afpd 51 1 5 | %pro.s.snd.max = 3 | %pro.s.snd.sec = 5
    %pro.s.cht = ! | did -c afpd 53 | did -o afpd 54 1 2 | did -o afpd 55 1 9 | %pro.s.cht.max = 2 | %pro.s.cht.sec = 9
    %pro.c.txt = ! | did -c afpd 7 | did -o afpd 8 1 3 | did -o afpd 9 1 2 | %pro.c.txt.max = 3 | %pro.c.txt.sec = 2
    %pro.c.act = ! | did -c afpd 11 | did -o afpd 12 1 3 | did -o afpd 13 1 2 | %pro.c.act.max = 3 | %pro.c.act.sec = 2
    %pro.c.not = ! | did -c afpd 15 | did -o afpd 16 1 3 | did -o afpd 17 1 2 | %pro.c.not.max = 3 | %pro.c.not.sec = 2
    %pro.c.ctc = ! | did -c afpd 19 | did -o afpd 20 1 2 | did -o afpd 21 1 5 | %pro.c.ctc.max = 2 | %pro.c.ctc.sec = 5
    %pro.c.nik = ! | did -c afpd 23 | did -o afpd 24 1 2 | did -o afpd 25 1 5 | %pro.c.nik.max = 2 | %pro.c.nik.sec = 5
    %pro.c.j-p = ! | did -c afpd 27 | did -o afpd 28 1 1 | did -o afpd 29 1 5 | %pro.c.j-p.max = 1 | %pro.c.j-p.sec = 5
    %pro.c.kik = ! | unset %pro.c.k-b | did -c afpd 32 | did -u afpd 31 | %pro.c.kck.msg = Flood control kick (AFP v2.0) | did -o afpd 34 1 %pro.c.kck.msg
    did -e afpd 8,9,12,13,16,17,20,21,24,25,28,29,38,39,42,43,46,47,50,51,54,55 | %pro.a.len = 300 | did -o afpd 68 1 300 | did -b afpd 1,2
    %pro.s.ign.tmp = ! | %pro.s.ign.min = 5 | %pro.s.ign.sec = 300 | did -c afpd 57 | did -u afpd 58 | did -n afpd 60 | did -o afpd 60 1 %pro.s.ign.min
    %pro.s.i-b.typ = 3 | did -c afpd 63 %pro.s.i-b.typ | %pro.s.i-b.sel = $gettok($did(63,%pro.s.i-b.typ),2,32) | %pro.s.i-b.typ2 = %pro.s.i-b.typ - 1
  }
  if ($did = 3) unset %afp_hlp
  if ($did = 7) { if (%pro.c.txt = !) { did -e afpd 2 | unset %pro.c.txt | did -u afpd 7 | did -b afpd 8,9 } | else { %pro.c.txt = ! | did -c afpd 7 | did -e afpd 8,9 } }
  if ($did = 11) { if (%pro.c.act = !) { did -e afpd 2 | unset %pro.c.act | did -u afpd 11 | did -b afpd 12,13 } | else { %pro.c.act = ! | did -c afpd 11 | did -e afpd 12,13 } }
  if ($did = 15) { if (%pro.c.not = !) { did -e afpd 2 | unset %pro.c.not | did -u afpd 15 | did -b afpd 16,17 } | else { %pro.c.not = ! | did -c afpd 15 | did -e afpd 16,17 } }
  if ($did = 19) { if (%pro.c.ctc = !) { did -e afpd 2 | unset %pro.c.ctc | did -u afpd 19 | did -b afpd 20,21 } | else { %pro.c.ctc = ! | did -c afpd 19 | did -e afpd 20,21 } }
  if ($did = 23) { if (%pro.c.nik = !) { did -e afpd 2 | unset %pro.c.nik | did -u afpd 23 | did -b afpd 24,25 } | else { %pro.c.nik = ! | did -c afpd 23 | did -e afpd 24,25 } }
  if ($did = 27) { if (%pro.c.j-p = !) { did -e afpd 2 | unset %pro.c.j-p | did -u afpd 27 | did -b afpd 28,29 } | else { %pro.c.j-p = ! | did -c afpd 27 | did -e afpd 28,29 } }
  if ($did = 31) { %pro.c.k-b = ! | unset %pro.c.kik | did -c afpd 31 | did -u afpd 32 | did -e afpd 2 }
  if ($did = 32) { %pro.c.kik = ! | unset %pro.c.k-b | did -c afpd 32 | did -u afpd 31 | did -e afpd 2 }
  if ($did = 35) { did -r afpd 8,9,12,13,16,17,20,21,24,25,28,29,34,38,39,42,43,46,47,50,51,54,55,60,68 | did -e afpd 2 }
  if ($did = 37) { if (%pro.s.n-m = !) { did -e afpd 2 | unset %pro.s.n-m | did -u afpd 37 | did -b afpd 38,39 } | else { %pro.s.n-m = ! | did -c afpd 37 | did -e afpd 38,39 } }
  if ($did = 41) { if (%pro.s.ctc = !) { did -e afpd 2 | unset %pro.s.ctc | did -u afpd 41 | did -b afpd 42,43 } | else { %pro.s.ctc = ! | did -c afpd 41 | did -e afpd 42,43 } }
  if ($did = 45) { if (%pro.s.inv = !) { did -e afpd 2 | unset %pro.s.inv | did -u afpd 45 | did -b afpd 46,47 } | else { %pro.s.inv = ! | did -c afpd 45 | did -e afpd 46,47 } }
  if ($did = 49) { if (%pro.s.snd = !) { did -e afpd 2 | unset %pro.s.snd | did -u afpd 49 | did -b afpd 50,51 } | else { %pro.s.snd = ! | did -c afpd 49 | did -e afpd 50,51 } }
  if ($did = 53) { if (%pro.s.cht = !) { did -e afpd 2 | unset %pro.s.cht | did -u afpd 53 | did -b afpd 54,55 } | else { %pro.s.cht = ! | did -c afpd 53 | did -e afpd 54,55 } }
  if ($did = 57) { %pro.s.ign.tmp = ! | did -c afpd 57 | did -u afpd 58 | did -n afpd 60 | did -e afpd 2 | unset %pro.s.ign.prm }
  if ($did = 58) { %pro.s.ign.prm = ! | did -u afpd 57 | did -c afpd 58 | did -m afpd 60 | did -e afpd 2 | unset %pro.s.ign.tmp }
  if ($did = 63) { did -e afpd 1,2 }
  if ($did = 65) {
    did -c afpd 7,11,15,19,23,27,37,41,45,49,53 | did -e afpd 8,9,12,13,16,17,20,21,24,25,28,29,38,39,42,43,46,47,50,51,54,55
    %pro.s.n-m = ! | %pro.s.ctc = ! | %pro.s.inv = ! | %pro.s.snd = ! | %pro.s.cht = ! | %pro.c.txt = ! | %pro.c.act = ! | %pro.c.not = ! | %pro.c.ctc = ! | %pro.c.nik = ! | %pro.c.j-p = !
  }
  if ($did = 66) {
    did -u afpd 7,11,15,19,23,27,37,41,45,49,53 | did -b afpd 8,9,12,13,16,17,20,21,24,25,28,29,38,39,42,43,46,47,50,51,54,55 | did -e afpd 2
    unset %pro.s.n-m %pro.s.ctc %pro.s.inv %pro.s.snd %pro.s.cht %pro.c.txt %pro.c.act %pro.c.not %pro.c.ctc %pro.c.nik %pro.c.j-p
  }
  if ($did = 70) { did -h afpd 72 | did -v afpd 1,2,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,65,66,67,68 }
  if ($did = 71) {
    did -h afpd 1,2,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,65,66,67,68
    did -r afpd 72 | did -v afpd 72
    if ($exists(%afp_hlp) == $true) loadbuf -o afpd 72 %afp_hlp
    else { did -a afpd 72 Missing afp-hlp.txt. $+ $crlf | did -a afpd 72 Make sure this file is located in: $scriptdir }
  }
}
alias -l checkeditb {
  if (%pro.s.n-m.max = $null) || (%pro.s.n-m.sec = $null) unset %pro.s.n-m
  if (%pro.s.ctc.max = $null) || (%pro.s.ctc.sec = $null) unset %pro.s.ctc
  if (%pro.s.inv.max = $null) || (%pro.s.inv.sec = $null) unset %pro.s.inv
  if (%pro.s.snd.max = $null) || (%pro.s.snd.sec = $null) unset %pro.s.snd
  if (%pro.s.cht.max = $null) || (%pro.s.cht.sec = $null) unset %pro.s.cht
  if (%pro.c.txt.max = $null) || (%pro.c.txt.sec = $null) unset %pro.c.txt
  if (%pro.c.act.max = $null) || (%pro.c.act.sec = $null) unset %pro.c.act
  if (%pro.c.not.max = $null) || (%pro.c.not.sec = $null) unset %pro.c.not
  if (%pro.c.ctc.max = $null) || (%pro.c.ctc.sec = $null) unset %pro.c.ctc
  if (%pro.c.nik.max = $null) || (%pro.c.nik.sec = $null) unset %pro.c.nik
  if (%pro.c.j-p.max = $null) || (%pro.c.j-p.sec = $null) unset %pro.c.j-p
}
