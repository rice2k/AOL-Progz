menu status,menubar {
  Access
  .Access List:/msg chanop access #$$?="Enter Channel To Retrieve Access List:" *
  .Check Access:/msg chanop access #$$?="Enter Channel To Check Access " $$?="Enter Nick Of Whom You Want To Check Access:"
  .-
  .Confirm Access:/msg chanop confirm #$$?="Enter Channel You Want To Confirm Access:" $me
  .Give Access:/msg chanop adduser #$$?="Enter Channel To Give Access:" $$?="Enter Nick To Give Access To:"
  .Delete Access:/msg chanop deluser #$$?="Enter Channel To Delete User:" $$?="Enter Nick To Delete:"
  .Set Access Level:/msg chanop setuser #$$?="Enter Channel To Set Access Level:" $$?="Enter Nick To Set Access Level:" level $$?="Enter Access Level From 1 to 199:"
  .-
  .Seek:/msg chanop seek #$$?="Enter Channel To Seek:" $$?="Enter Seek Message:"
  .-
  .Auto
  ..Auto-Op
  ...On:/msg chanop setuser #$$?="Enter Channel To Set AOP On:" $$?="Enter Nick To Set AOP On:" aop on
  ...Off:/msg chanop setuser #$$?="Enter Channel To Set AOP Off:" $$?="Enter Nick To Set AOP Off:" aop off
  ..Auto-Voice
  ...On:/msg chanop setuser #$$?="Enter Channel To Set AOV On:" $$?="Enter Nick To Set AOV On:" aov on
  ...Off:/msg chanop setuser #$$?="Enter Channel To Set AOV Off:" $$?="Enter Nick To Set AOV Off:" aov off
  .Protection
  ..On:/msg chanop setuser #$$?="Enter Channel To Set PROT On:" $$?="Enter Nick To Set PROT On:" prot on
  ..Off:/msg chanop setuser #$$?="Enter Channel To Set PROT Off:" $$?="Enter Nick To Set PROT Off:" prot off
  .Suspend
  ..Suspend:/msg chanop setuser #$$?="Enter Channel To Suspend:" $$?="Enter Nick To Suspend:" suspend $$?="Enter Time To Be Suspended For (In Minutes):"
  ..Unsuspend:/msg chanop setuser #$$?="Enter Channel To Set Suspend Off:" $$?="Enter Nick To Unuspend:" suspend off
  .-
  .ChanOP Help:/msg chanop help
  Channels
  .Add A Channel: {
    if ( %channel1 == $null ) { set %channel1 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel2 == $null ) { set %channel2 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel3 == $null ) { set %channel3 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel4 == $null ) { set %channel4 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel5 == $null ) { set %channel5 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel6 == $null ) { set %channel6 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel7 == $null ) { set %channel7 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel8 == $null ) { set %channel8 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel9 == $null ) { set %channel9 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel10 == $null ) { set %channel10 .  #$$?="Enter A Channel:" | goto end }
    else { echo 2���4 You have too many CHANNELS in your nick list  | halt }
    :end
    echo 2���4 $! has been added to your CHANNELS list 
  }
  .Join Channels
  ..%channel1:/join $remove(%channel1,. )
  ..%channel2:/join $remove(%channel2,. )
  ..%channel3:/join $remove(%channel3,. )
  ..%channel4:/join $remove(%channel4,. )
  ..%channel5:/join $remove(%channel5,. )
  ..%channel6:/join $remove(%channel6,. )
  ..%channel7:/join $remove(%channel7,. )
  ..%channel8:/join $remove(%channel8,. )
  ..%channel9:/join $remove(%channel9,. )
  ..%channel10:/join $remove(%channel10,. )
  ..Join A Channel...:/join #$$?="Enter A Channel To Join:"
  .Unset A Channel
  ..%channel1:/unset %channel1
  ..%channel2:/unset %channel2
  ..%channel3:/unset %channel3
  ..%channel4:/unset %channel4
  ..%channel5:/unset %channel5
  ..%channel6:/unset %channel6
  ..%channel7:/unset %channel7
  ..%channel8:/unset %channel8
  ..%channel9:/unset %channel9
  ..%channel10:/unset %channel10
  .-
  .Channel Info:/msg chanop info #$$?="Enter Channel To Retrieve Info:" 
  .List Channels
  ..All Channels:/list
  ..Specific Channels:/list * $+ $$?="What Type Of Channel Do You Want?:" $+ *
  Channel
  .Try double-clicking in a channel window!:
  Extra AustNet Services
  .LoveOp
  ..Presents/Gifts
  ...Present:/msg LoveOP present $$?="Enter Nick Of Your Lover:" $$?="Enter Present You Want To Give To Your Lover:" 
  ...Gifts
  ....Anklet:/msg LoveOP present $$?="Enter Nick Of Your Lover:" Anklet
  ....Bracelet:/msg LoveOP present $$?="Enter Nick Of Your Lover:" Bracelet
  ....Car:/msg LoveOP present $$?="Enter Nick Of Your Lover:" Car
  ....Cd:/msg LoveOP present $$?="Enter Nick Of Your Lover:" Cd
  ....Computer:/msg LoveOP present $$?="Enter Nick Of Your Lover:" Computer
  ....Earring/msg LoveOP present $$?="Enter Nick Of Your Lover:" Earring
  ....Harley/msg LoveOP present $$?="Enter Nick Of Your Lover:" Harley
  ....Ring:/msg LoveOP present $$?="Enter Nick Of Your Lover:" Ring
  ..-
  ..Misc.
  ...Kisses
  ....Gentle:/msg Loveop kiss $$?="Enter Nick Of Your Lover:" gentle
  ....Tonsil:/msg LoveOP kiss $$?="Enter Nick Of Your Lover:" tonsil
  ...Admirer:/msg LoveOP admire $$?="Enter Nick Of Your Lover:"
  ...Rose:/msg Loveop rose $$?="Enter Nick Of Your Lover:"
  ...-
  ...LoveNote:/msg LoveOP lovenote $$?="Enter Nick Of Your Lover:" $$?="What Would You Like To Say To Your Lover?"
  ...-
  ...Candy:/msg LoveOP candy $$?="Enter Nick Of Your Lover:"
  ...Chocolate:/msg Loveop chocolate $$?="Enter Nick Of Your Lover:"
  ...Hug:/msg LoveOP hug $$?="Enter Nick Of Your Lover:"
  ...Cookie:/msg LoveOP Cookie $$?="Enter Nick Of Your Lover:"
  ..-
  ..NetCouple Related
  ...Add to NetCouple:/msg LoveOP netcouple add $$?="Enter Nick Of Your Lover:"
  ...Get Engaged:/msg LoveOP book $me $$?="Enter Nick Of Your Lover:"
  ...Divorce:/msg LoveOP netcouple del $me
  ..Listed Cyber-Couples
  ...List Waiting:/msg LoveOP netcouple list waiting
  ...List NetCouples:/msg LoveOP netcouple list couple
  ...List Engaged:/msg LoveOP netcouple list engaged
  ...List Married Couples:/msg LoveOP netcouple list married 
  ..-
  ..LoveOP Help:/msg LoveOP help
  .NoteOP
  ..Send
  ...To a Person:/msg NoteOP send $$?="Enter Nickname To Send Note TO:" $$?="Enter Message:" : Note Generated By %logo
  ...To a Channel:/msg NoteOP send $$?="Enter Channel Name To Send Note To:" $$?="Enter Message:" : Note Generated By %logo
  ..-
  ..List:/.msg NoteOP list
  ..Read:/.msg NoteOP read $?="Enter Note Number:"
  ..-
  ..Delete: { /msg NoteOP del $?="Enter Note Number:"
  /msg noteop purge }
  ..Purge:/.msg NoteOP purge
  ..-
  ..Block
  ...Add:/.msg NoteOP block add $?="Enter Nickname/Hostmask:"
  ...Delete:/.msg NoteOP block del $?="Enter Nickname/Hostmask:"
  ...-
  ...List:/.msg NoteOP block list
  ..-
  ..NoteOP Help:/.msg noteop help
  Nicknames
  .Add A Nickname: {
    if ( %nick1 == $null ) { set %nick1 . $$?="Enter A Nick:" | goto end }
    if ( %nick2 == $null ) { set %nick2 . $$?="Enter A Nick:" | goto end }
    if ( %nick3 == $null ) { set %nick3 . $$?="Enter A Nick:" | goto end }
    if ( %nick4 == $null ) { set %nick4 . $$?="Enter A Nick:" | goto end }
    if ( %nick5 == $null ) { set %nick5 . $$?="Enter A Nick:" | goto end }
    if ( %nick6 == $null ) { set %nick6 . $$?="Enter A Nick:" | goto end }
    if ( %nick7 == $null ) { set %nick7 . $$?="Enter A Nick:" | goto end }
    if ( %nick8 == $null ) { set %nick8 . $$?="Enter A Nick:" | goto end }
    if ( %nick9 == $null ) { set %nick9 . $$?="Enter A Nick:" | goto end }
    if ( %nick10 == $null ) { set %nick10 . $$?="Enter A Nick:" | goto end }
    else { echo 2���4 You have too many NICKS in your nick list  | halt }
    :end
    echo 2���4 $! has been added to your NICKNAMES list 
  }
  .Change Nicknames
  ..%nick1:/nick $remove(%nick1,.)
  ..%nick2:/nick $remove(%nick2,. )
  ..%nick3:/nick $remove(%nick3,. )
  ..%nick4:/nick $remove(%nick4,. )
  ..%nick5:/nick $remove(%nick5,. )
  ..%nick6:/nick $remove(%nick6,. )
  ..%nick7:/nick $remove(%nick7,. )
  ..%nick8:/nick $remove(%nick8,. )
  ..%nick9:/nick $remove(%nick9,. )
  ..%nick10:/nick $remove(%nick10,. )
  ..Change Nicknames...:/nick $$?="Enter Your New Nickname:"
  .Unset A Nickname
  ..%nick1:/unset %nick1
  ..%nick2:/unset %nick2
  ..%nick3:/unset %nick3
  ..%nick4:/unset %nick4
  ..%nick5:/unset %nick5
  ..%nick6:/unset %nick6
  ..%nick7:/unset %nick7
  ..%nick8:/unset %nick8
  ..%nick9:/unset %nick9
  ..%nick10:/unset %nick10
  .-
  .Register Nick:/msg nickop@austnet.org register $$?="Enter Password (Remember This Password):" $$?="Enter Your Email Address:"
  .Un-Register Nick:/msg NickOP drop
  .-
  .Nick Info:/msg nickop info $$?="Enter Nick For Info Acquire:"
  .Link
  ..Add:/msg nickop link add $$?="Nick to Link:" $$?="Password Of Linking Nick:"
  ..Delete:/msg nickop link del $$?="Nick To Delete Link:"
  ..List:/msg nickop link list
  .Nickname Kill
  ..On:/msg nickop set kill on
  ..Off:/msg nickop set kill off
  ..Now:/msg nickop@austnet.org kill $$?="Enter Nickname To Kill:" $$?="Enter Password Of Nickname You Want To Kill:"
  .Set
  ..Set New Password:/msg nickop set pass $$?="Enter New Password:"
  ..Set New Email:/msg nickop set email $$?="Enter New Email:"
  .-
  .NickOP Help:/msg nickop help
  List Bans
  .Normal:/msg chanop listban $$?="Enter Name Of Channel:"
  .Who Set:/msg chanop listban $$?="Enter Name Of Channel:" -whoset
  .Reason:/msg chanop listban $$?="Enter Name Of Channel:" -reason
  .When Set:/msg chanop listban $$?="Enter Name Of Channel:" -whenset
  Other
  .Whois User?:/whois $$?="Enter Nickname To Get Whois:"
  .-
  .Invite User:/invite $$?="Enter Nickname To Invite:" #$$?="Enter Channel To Invite To:"
  .Message User:/msg $$?="Enter Nickname You Want To Message:" $$?="Enter Message:"
  .Query User:/query $$?="Enter Nickname You Want To Open A Query Window To:"
  .-
  .Ban User:/msg chanop ban #$$?="Enter Channel To Ban On:" $$?="Enter Nickname To Ban:" $?="Reason For Ban:"
  .Kick User:/msg chanop kick #$$?="Enter Channel To Kick On:" $$?="Enter Nickname To Kick:" $?="Reason For Kick:"
  .Unban User:/msg chanop unban #$$?="Enter Channel To Unban On:" $$?="Enter Nickname To Unban:"
  .-
  .Ignore User:/ignore $$?="Enter Nickname You Want To Ignore:" 3
  .Unignore User:/ignore -r $$?="Enter Nickname You Want To Unignore:" 3
}

menu query {
  Ignore
  .Ignore User:/ignore $$1 3
  .Unignore User:/ignore -r $$1 3
  Nick Info:/msg nickop info $$1
  Whois User:/whois $$1
  UCentral:/uwho $$1
  -
  CTCP
  .Ping:/ctcp $$1 ping
  .Time:/ctcp $$1 time
  .Version:/ctcp $$1 version
  DCC
  .Chat:/dcc chat $$1
  .Send:/dcc send $$1
  -
  LoveOp
  .Presents/Gifts
  ..Present:/msg LoveOP present $$1 $$?="Enter Present You Want To Give To Your Lover:" 
  ..Gifts
  ...Anklet:/msg LoveOP present $$1 anklet
  ...Bracelet:/msg LoveOP present $$1 Bracelet
  ...Car:/msg LoveOP present $$1 Car
  ...Cd:/msg LoveOP present $$1 Cd
  ...Computer:/msg LoveOP present $$1 Computer
  ...Earring/msg LoveOP present $$1 Earring
  ...Harley/msg LoveOP present $$1 Harley
  ...Ring:/msg LoveOP present $$1 Ring
  .-
  .Misc.
  ..Kisses
  ...Gentle:/msg Loveop kiss $$1 gentle
  ...Tonsil:/msg LoveOP kiss $$1 tonsil
  ..Admirer:/msg LoveOP admire $$1
  ..Rose:/msg Loveop rose $$1
  ..-
  ..LoveNote:/msg LoveOP lovenote $$1 $$?="What Would You Like To Say To Your Lover?"
  ..-
  ..Candy:/msg LoveOP candy $$1
  ..Chocolate:/msg Loveop chocolate $$1
  ..Hug:/msg LoveOP hug $$1
  ..Cookie:/msg LoveOP Cookie $$1
  .-
  .NetCouple Related
  ..Add to NetCouple:/msg LoveOP netcouple add $$1
  ..Get Engaged:/msg LoveOP book $me $$1
  ..Divorce:/msg LoveOP netcouple del $me
  .Listed Cyber-Couples
  ..List Waiting:/msg LoveOP netcouple list waiting
  ..List NetCouples:/msg LoveOP netcouple list couple
  ..List Engaged:/msg LoveOP netcouple list engaged
  ..List Married Couples:/msg LoveOP netcouple list married 
  .-
  .LoveOP Help:/msg LoveOP help
  Others
  .Alternating Text � %alt-text �
  ..On (e.g, Brb > Be Rite Back) :/set %alt-text On
  ..Off (e.g, Brb > Brb) :/set %alt-text Off
  .F Keys Menu:/fkeys
  .Personal Notes:/run notepad.exe $mircdir\notes.txt
  .-
  .Fake
  ..Fake Lag:{ 
    echo 6 -a *** %sd Now Playing The �(4Fake Lag)� 4Joke To4 $1 ! Please Wait About4 1 Minute Without Speaking To Him To See The4 End Of The Joke !
    /msg $1 Hey $1 ! Are you there ? | .timer 1 13 /msg $1 Are you still alive ? | .timer 1 20 .ctcp $1 PING
    .timer 1 26 /msg $1 You must be ignoring me or something... | .timer 1 30 /msg $1 You must be lagging... HELLLOOOO !!
    .timer 1 42 /msg $1 WOHOO 30 second PING reply wow ! | .timer 1 60 /msg $1 You are LAGGED like hell ! Someone has to be ICMP'ing you...
    .timer 1 75 /msg $1 You better disconnect and change server... | .timer 1 78 /msg $1 ...6Got you !
    .timer 1 80 /msg $1 4MuUuAaAaAaHaHaHaHaHaHaHaHeHeHeHeHeHeHeHeHee ! You have fallen into the fake 6Lag joke :)
  }
  ..Fake Scare:{
    echo 6 -a *** %sd Now Playing The �(4Fake Virus Send)� 4Joke To4 $1 ! Please Wait4 30 Seconds Without Speaking To Him To See The4 End Of The Joke !
    /msg $1 U know... this is a pretty nice script cos it tells you when the DCC send is completed... Hey let's test this $nick $+ , wait a second !
    .timer 1 8 msg $1 4*** %sd �(6Succesfully Sent4)� Infected 6DCC SEND4: (6 $+ Back-Orifice-Trojan.EXE $+ 4) To (6 $+ $1 $+ 4) !
    .timer 1 16 msg $1 Wow... it went fast... about 2000 cps. Good you had your autoget on ! | .timer 1 22 msg $1 Oops... Just sent you the wrong file... damn ! I hope the file did not autorun yet, cos it will format your hard drive...
    .timer 1 30 msg $1 ...6Got you ! | .timer 1 32 msg $1 4MuUuAaAaAaHaHaHaHaHaHaHaHeHeHeHeHeHeHeHeHee ! You have fallen into the fake 6Virus Send joke :)
  }
  .Give Advice:/me : Advice Is $read $mircdirsystem\Advice.txt
  .Make Money:/msg $active %money
  .Poems:/say $read $mircdir\system\poems.txt
  .System Uptime:/say 7Booted Computer:12 $replace($duration($calc($ticks / 1000)),wk,�Week,day,�Day,hr,�Hour,min,�Minute,sec,�Second) Ago
  .Tell
  ..Tell Date:/say 12Today's date is4 $date
  ..Tell Time:/say 12The time now is4 $time(hh:nn:ss TT)
  Pictures
  .Pictures:/play $file="Select .txt file to play:" [ $mircdirPictures\ $+ *.txt ] 1000
}
