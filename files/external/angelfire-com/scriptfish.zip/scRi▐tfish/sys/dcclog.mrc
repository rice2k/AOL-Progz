; DCC logger v2.0
; By Asian_DOC
; � 1999-2001 Edward & Co.
; The purpose of this script is to log DCC transfers

on *:load:{
  if ($isfile(DCClog.txt) == $true) { echo 12 -a Thank you for loading DCC Logger v2.0 by Asian_DOC. A logfile was detected and will not be overwritten. | disp.dcc | return }
  else { echo 12 -a Thank you for loading DCC Logger v2.0 by Asian_DOC. No log file was detected and one will be created. | disp.dcc | write DCClog.txt ;This file was created by DCC logger v2.0 by Asian_DOC. Do no delete or modify this file. | set %dcc.total 0 | return }
}
#dcclog off
on *:filercvd:*: {
  set %dcc.filename $filename
  set %dcc.filesize $lof($filename)
  set %dcc.nick $nick
  set %dcc.address $address  
  set %dcc.timedone $asctime(h:n:ss) $+ ( $+ $asctime(TT) $+ ) $+ $chr(44) $asctime(mmm) $ord($asctime(d)) $+ $chr(44) $asctime(yyyy)
  inc %dcc.total
  writeini -n dcclog.txt %dcc.total file %dcc.filename
  writeini -n dcclog.txt %dcc.total size %dcc.filesize Bytes
  writeini -n dcclog.txt %dcc.total nick %dcc.nick
  writeini -n dcclog.txt %dcc.total address %dcc.address
  writeini -n dcclog.txt %dcc.total status Completed
  writeini -n dcclog.txt %dcc.total time %dcc.timedone
  writeini -n dcclog.txt %dcc.total direct rcvd
  dcc.update
}
on *:getfail:*: {
  set %dcc.filename $filename
  set %dcc.filesize $lof($filename)
  set %dcc.nick $nick
  set %dcc.address $address  
  set %dcc.timedone $asctime(h:n:ss) $+ ( $+ $asctime(TT) $+ ) $+ $chr(44) $asctime(mmm) $ord($asctime(d)) $+ $chr(44) $asctime(yyyy)
  inc %dcc.total
  writeini -n dcclog.txt %dcc.total file %dcc.filename
  writeini -n dcclog.txt %dcc.total size %dcc.filesize Bytes
  writeini -n dcclog.txt %dcc.total nick %dcc.nick
  writeini -n dcclog.txt %dcc.total address %dcc.address
  writeini -n dcclog.txt %dcc.total status Failed
  writeini -n dcclog.txt %dcc.total time %dcc.timedone
  writeini -n dcclog.txt %dcc.total direct rcvd
  dcc.update
}
on *:filesent:*: {
  set %dcc.filename $filename
  set %dcc.filesize $lof($filename)
  set %dcc.nick $nick
  set %dcc.address $address  
  set %dcc.timedone $asctime(h:n:ss) $+ ( $+ $asctime(TT) $+ ) $+ $chr(44) $asctime(mmm) $ord($asctime(d)) $+ $chr(44) $asctime(yyyy)
  inc %dcc.total
  writeini -n dcclog.txt %dcc.total file %dcc.filename
  writeini -n dcclog.txt %dcc.total size %dcc.filesize Bytes
  writeini -n dcclog.txt %dcc.total nick %dcc.nick
  writeini -n dcclog.txt %dcc.total address %dcc.address
  writeini -n dcclog.txt %dcc.total status Completed
  writeini -n dcclog.txt %dcc.total time %dcc.timedone
  writeini -n dcclog.txt %dcc.total direct sent
  dcc.update
}
on *:sendfail:*: {
  set %dcc.filename $filename
  set %dcc.filesize $lof($filename)
  set %dcc.nick $nick
  set %dcc.address $address  
  set %dcc.timedone $asctime(h:n:ss) $+ ( $+ $asctime(TT) $+ ) $+ $chr(44) $asctime(mmm) $ord($asctime(d)) $+ $chr(44) $asctime(yyyy)
  inc %dcc.total
  writeini -n dcclog.txt %dcc.total file %dcc.filename
  writeini -n dcclog.txt %dcc.total size %dcc.filesize Bytes
  writeini -n dcclog.txt %dcc.total nick %dcc.nick
  writeini -n dcclog.txt %dcc.total address %dcc.address
  writeini -n dcclog.txt %dcc.total status Failed
  writeini -n dcclog.txt %dcc.total time %dcc.timedone
  writeini -n dcclog.txt %dcc.total direct sent
  dcc.update
}
alias dcc.update {
  if ($dialog(dcc) !== $null) {
    did -r dcc 22
    var %dcc.temp.num = 1
    while (%dcc.temp.num <= %dcc.total) {
      dcc.read %dcc.temp.num 
      did -a dcc 22 %dcc.file
      inc %dcc.temp.num
    }
  }
  else { return }
}
#dcclog end
alias disp.dcc {
  dialog -dmr dcc dcc
  if ($group(#dcclog) == on) { did -c dcc 4 }
  var %dcc.temp.num = 1
  while (%dcc.temp.num <= %dcc.total) {
    dcc.read %dcc.temp.num 
    did -a dcc 22 %dcc.file
    inc %dcc.temp.num
  }
}
alias dcc.read {
  set %dcc.nick $readini -n dcclog.txt $1- nick
  set %dcc.file $readini -n dcclog.txt $1- file
  set %dcc.size $readini -n dcclog.txt $1- size
  set %dcc.addy $readini -n dcclog.txt $1- address
  set %dcc.status $readini -n dcclog.txt $1- status
  set %dcc.time $readini -n dcclog.txt $1- time
  set %dcc.direct $readini -n dcclog.txt $1- direct
}
alias dcclog {
  dcc.read $1-
  if ($prop == nick) { return %dcc.nick }
  if ($prop == name) { return %dcc.file }
  if ($prop == time) { return %dcc.time }
  if ($prop == addy) { return %dcc.addy }
  if ($prop == size) { return %dcc.size }
  if ($prop == stat) { return %dcc.status }
  if ($prop == direct) { return %dcc.direct }
}
alias dcc.sr {
  if ($dcclog($1).direct == sent ) { return Sent }
  elseif ($dcclog($1).direct == rcvd) { return Recieved }
}
on *:dialog:dcc:*:*: {
  if ($devent == sclick) && ($did == 22) {
    did -r dcc 11,13,15,17,19,21,25
    did -a dcc 11 $dcclog($did(22,1).sel).nick
    did -a dcc 13 $dcclog($did(22,1).sel).time
    did -a dcc 15 $dcclog($did(22,1).sel).addy
    did -a dcc 17 $dcclog($did(22,1).sel).name
    did -a dcc 19 $dcclog($did(22,1).sel).size
    did -a dcc 21 $dcclog($did(22,1).sel).stat
    did -a dcc 25 $dcc.sr($did(22,1).sel)
    dialog -t dcc DCC Log - $chr(91) $+ $dcclog($did(22,1).sel).name $+ $chr(93) $+ ( $+ $dcc.sr($did(22,1).sel) $+ )
  }
  if ($devent == sclick) && ($did == 4) {
    if ($group(#dcclog) == on) { .disable #dcclog }
    elseif ($group(#dcclog) == off) { .enable #dcclog }
  }
  if ($devent == sclick) && ($did == 23) {
    .remove DCClog.txt
    write DCClog.txt ;This file was created by DCC logger v2.0 by Asian_DOC. Do no delete or modify this file.
    set %dcc.total 0
    dcc.update
    did -r dcc 11,13,15,17,19,21,25
    dialog -t dcc DCC Log
  }
}
dialog dcc {
  title "DCC Log"
  size -1 -1 250 120
  option dbu
  button "Close", 1, 229 110 20 10, ok
  box "Logged Transfers", 2, 1 1 100 117
  box "Information", 3, 102 1 147 70
  check "Log DCC transfers?", 4, 102 72 55 7
  text "DCC logger is � 2000 Edward & Co.", 5, 111 81 87 7
  text "(http://welcome.to/drscript/)", 6, 118 88 80 7
  text "Code and Concept: James D. Edward", 7, 111 95 66 7
  text "Thanks: Hoo Did This and SumJai", 8, 111 102 130 7
  text "For helping me write this add-on.",9, 118 109 110 7
  text "Nickname:", 10, 105 9 25 7
  edit "",11, 132 8 40 10, read
  text "Time:", 12, 105 19 20 7
  edit "",13, 120 18 70 10, read
  text "Address:", 14, 105 29 30 7
  edit "",15, 127 28 70 10, read
  text "File name:", 16, 105 39 25 7
  edit "", 17, 130 38 117 10, read
  text "File Size:", 18, 105 49 30 7
  edit "",19, 127 48 70 10, read
  text "Status:", 20, 175 9 30 7
  edit "",21, 192 8 30 10, read
  list 22, 5 10 91 107, vsbar, hsbar
  button "Clear log", 23, 205 85 30 10
  text "Direction:", 24, 105 59 30 7
  edit "", 25, 129 58 30 10, read
} 
