menu channel {
  Access
  .Access List:/msg chanop access # *
  .Check Access:/msg chanop access # $$?="Enter Nick Of Whom You Want To Check Access and/or Check Access Parameters? (e.g., -ls, -lm, -min level, -max level):"
  .-
  .Confirm Access
  ..Current Nick:/msg chanop confirm # $me
  ..Different Nick:/msg chanop confirm # $$?="Enter Nick To Confirm Access With (You Will Need To Of Had Identified With That Nick):"
  .Give Access:/msg chanop adduser # $$?="Enter Nick To Give Access To:"
  .Delete Access:/msg chanop deluser # $$?="Enter Nick To Delete Access:"
  .Set Access Level:/msg chanop setuser # $$?="Enter Nick To Set Access Level:" level $$?="Enter Access Level From 1 to 199:"
  .-
  .Seek:/msg chanop seek # $$?="Enter Seek Message:"
  .-
  .Auto
  ..Auto-Op
  ...On:/msg chanop setuser # $$?="Enter Nick To Set AOP On:" aop on
  ...Off:/msg chanop setuser # $$?="Enter Nick To Set AOP Off:" aop off
  ..Auto-Voice
  ...On:/msg chanop setuser # $$?="Enter Nick To Set AOV On:" aov on
  ...Off:/msg chanop setuser # $$?="Enter Nick To Set AOV Off:" aov off
  .Protection
  ..On:/msg chanop setuser # $$?="Enter Nick To Set PROT On:" prot on
  ..Off:/msg chanop setuser # $$?="Enter Nick To Set PROT Off:" prot off
  .Op
  ..Op:{
    if ($me isop $chan) { /mode # +o $me }
    else { /msg chanop op # $me }
  }
  ..Deop:{
    if ($me isop $chan) { /mode # -o $me }
    else { /msg chanop deop # $me }
  }
  .Suspend
  ..Suspend:/msg chanop setuser # $$?="Enter Nick To Suspend:" suspend $$?="Enter Time To Be Suspended For (In Minutes):"
  ..Unsuspend:/msg chanop setuser # $$?="Enter Nick To Unuspend:" suspend off
  .Voice
  ..Voice:{
    if ($me isop $chan) { /mode # +v $me }
    else { /msg chanop voice # $me }
  }
  ..De-voice:{
    if ($me isop $chan) { /mode # -v $me }
    else { /msg chanop devoice # $me }
  }
  .-
  .ChanOP Help:/msg chanop help
  Channels
  .Add A Channel: {
    if ( %channel1 == $null ) { set %channel1 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel2 == $null ) { set %channel2 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel3 == $null ) { set %channel3 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel4 == $null ) { set %channel4 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel5 == $null ) { set %channel5 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel6 == $null ) { set %channel6 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel7 == $null ) { set %channel7 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel8 == $null ) { set %channel8 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel9 == $null ) { set %channel9 .  #$$?="Enter A Channel:" | goto end }
    if ( %channel10 == $null ) { set %channel10 .  #$$?="Enter A Channel:" | goto end }
    else { echo 2���4 You have too many CHANNELS in your nick list  | halt }
    :end
    echo 2���4 $! has been added to your CHANNELS list 
  }
  .Join Channels
  ..%channel1:/join $remove(%channel1,. )
  ..%channel2:/join $remove(%channel2,. )
  ..%channel3:/join $remove(%channel3,. )
  ..%channel4:/join $remove(%channel4,. )
  ..%channel5:/join $remove(%channel5,. )
  ..%channel6:/join $remove(%channel6,. )
  ..%channel7:/join $remove(%channel7,. )
  ..%channel8:/join $remove(%channel8,. )
  ..%channel9:/join $remove(%channel9,. )
  ..%channel10:/join $remove(%channel10,. )
  ..Join A Channel...:/join #$$?="Enter A Channel To Join:"
  .Unset A Channel
  ..%channel1:/unset %channel1
  ..%channel2:/unset %channel2
  ..%channel3:/unset %channel3
  ..%channel4:/unset %channel4
  ..%channel5:/unset %channel5
  ..%channel6:/unset %channel6
  ..%channel7:/unset %channel7
  ..%channel8:/unset %channel8
  ..%channel9:/unset %channel9
  ..%channel10:/unset %channel10
  .-
  .Register Channel:/msg chanop register #
  .Un-Register Channel:/msg chanop drop #
  .-
  .Channel Info:/msg chanop info #
  .List Channels
  ..All Channels:/list
  ..Specific Channels:/list * $+ $$?="What Type Of Channel Do You Want?:" $+ *
  .Settings
  ..Channel Mode(s)
  ...Clear All modes:/msg ChanOP clean #
  ...Set Modes:/msg ChanOP set #  mode $$?="Enter Level Required to Change Mode" $$?="Enter Mode(s)  Ex: +tn-slimpk"
  ..Channel Note Block
  ...On:/msg ChanOP set # nonote $$?="Enter  Access Required to Send Channel Note"
  ...Off:/msg ChanOP set # nonote off
  ..Channel Restriction
  ...On:/msg ChanOP set # restrict $$?="Enter Access Required to Join"
  ...Off:/msg ChanOP set # restrict 0
  ..Channel's URL:/msg ChanOP set # url $$?="Enter Channel's URL"
  ..`Command
  ...Disable:/msg ChanOP set # nochanmsg on
  ...Enable:/msg ChanOP set # nochanmsg off
  ..Fun Message
  ...On:/msg ChanOP set # funmsg on
  ...Off:/msg ChanOP set # funmsg off
  ..Op Restriction
  ...On:/msg ChanOP set # oprestrict on
  ...Off:/msg ChanOP set # oprestrict off
  ..Identify Protection
  ...On:/msg ChanOP set # mustid on
  ...Off:/msg ChanOP set # mustid off
  ..Report Log
  ...On:/msg ChanOP set # log on
  ...Off:/msg ChanOP set # log off
  ..Tell on Add
  ...On:/msg ChanOP set # telladd on
  ...Off:/msg ChanOP set # telladd off
  ..Tell on Delete
  ...On:/msg ChanOP set # telldel on
  ...Off:/msg ChanOP set # telldel off
  ..Tell on Set
  ...On:/msg ChanOP set # tellset on
  ...Off:/msg ChanOP set # tellset off
  ..Topic Protection
  ...On:/msg ChanOP set # keeptopic $$?="Enter Level Required to Change Topic"
  ...Off:/msg ChanOP set # keeptopic 0
  .Topics
  ..Set
  ...Keep Topic Level:/msg chanop set # keeptopic $$?="Enter Level To Keep Topic"
  ..-
  ..No Special Effects:{
    if ($me isop $chan) { /topic # $$?="Enter Topic" }
    else { /msg chanop topic # $$?="Enter Topic" }
  }
  ..Welcome:{
    if ($me isop $chan) { /topic # 12���������������� 4\\/\//elcome To # 12���������������� }
    else { /msg chanop topic # 12���������������� 4\\/\//elcome To # 12���������������� }
  }
  ..Designs
  ...�~`~*��� :{
    if ($me isop $chan) { /topic # 4,9�~`~*���12 $$?="Enter Topic" 4���*~`~� }
    else { /msg chanop topic # 4,9�~`~*���12 $$?="Enter Topic" 4���*~`~� }
  }
  ...���������������� :{
    if ($me isop $chan) { /topic # 4����������������12 $$?="Enter Topic" 4���������������� }
    else { /msg chanop topic # 4����������������12 $$?="Enter Topic" 4���������������� }
  }
  ...(�`�._(�`�._(�`�._( :{
    if ($me isop $chan) { /topic # 12(�`�._(�`�._(�`�._(4 $$?="Enter Topic" 12)_.���)_.���)_.���) }
    else { /msg chanop topic # 12(�`�._(�`�._(�`�._(4 $$?="Enter Topic" 12)_.���)_.���)_.���) }
  }
  ...(�`�.��.���`�.��.-> :{
    if ($me isop $chan) { /topic # 4 (�`�.��.���`�.��.->12 $$?="Enter Topic" 8<-.��.���`�.��.���) }
    else { /msg chanop topic # 4 (�`�.��.���`�.��.->12 $$?="Enter Topic" 8<-.��.���`�.��.���) }
  }
  ...���.��.�����.��.�����.��.->:{
    if ($me isop $chan) { /topic # 4���.��.�����.��.�����.��.->12 $$?="Enter Topic" 4<-.��.�����.��.�����.��.��� }
    else { /msg chanop topic # 4���.��.�����.��.�����.��.->12 $$?="Enter Topic" 4<-.��.�����.��.�����.��.��� }
  }
  ...,-*-,._.,-*'^'~*-,._.,-*~>:{
    if ($me isop $chan) { /topic # 8,12.,-*-,._.,-*'^'~*-,._.,-*~>4 $$?="Enter Topic" 8<~*-,._.,-*~'^'~*-,._.,-*-,. }
    else { /msg chanop topic # 8,12.,-*-,._.,-*'^'~*-,._.,-*~>4 $$?="Enter Topic" 8<~*-,._.,-*~'^'~*-,._.,-*-,. }
  }
  ...|!�*'~``~'*�!||!�*'~``~'*�!|:{
    if ($me isop $chan) { /topic # 11|!�*'~``~'*�!||!�*'~``~'*�!|13 $$?="Enter Topic" 11|!�*'~``~'*�!||!�*'~``~'*�!| }
    else { /msg chanop topic # 11|!�*'~``~'*�!||!�*'~``~'*�!|13 $$?="Enter Topic" 11|!�*'~``~'*�!||!�*'~``~'*�!| }
  }
  ...��*~`~*��|��*~`~*��|��*~ -=�=-:{
    if ($me isop $chan) { /topic # 4.8��*~`~*��|��*~`~*��|��*~ -=�=-12 $$?="Enter Topic" 4-=�=- ~*��|��*~`~*��|��*~`~*�� }
    else { /msg chanop topic # 4.8��*~`~*��|��*~`~*��|��*~ -=�=-12 $$?="Enter Topic" 4-=�=- ~*��|��*~`~*��|��*~`~*�� }
  }
  ...-
  ...Diamonds:{
    if ($me isop $chan) { /topic # 4,2�2,4�13,2�2,13�15,2�2,15�8,2�2,8�11,2�2,11�9,2�2,9�0,1 $$?="Enter Topic:" 2,9�9,2�2,11�11,2�2,8�8,2�2,15�15,2�2,13�13,2�2,4�4,2� }
    else { /msg chanop topic # 4,2�2,4�13,2�2,13�15,2�2,15�8,2�2,8�11,2�2,11�9,2�2,9�0,1 $$?="Enter Topic:" 2,9�9,2�2,11�11,2�2,8�8,2�2,15�15,2�2,13�13,2�2,4�4,2� }
  }
  ...Firespikes:{
    if ($me isop $chan) { /topic # 8,0|0,8|7,8|8,7|4,7|7,4|5,4|4,5|1,5|5,1| 9,1 $$?="Enter Topic" 5,1 |1,5|4,5|5,4|7,4|4,7|8,7|7,8| }
    else { /msg chanop topic # 8,0|0,8|7,8|8,7|4,7|7,4|5,4|4,5|1,5|5,1| 9,1 $$?="Enter Topic" 5,1 |1,5|4,5|5,4|7,4|4,7|8,7|7,8| }
  }
  ...Green Abyss:{
    if ($me isop $chan) { /topic # 3,1\1,3\9,3\3,9\0,9\9,0\0,0-15,0\0,15\14,15\15,14\1,14\14,1\1,1-0,1 $$?="Enter Topic" 1,1-14,1/1,14/15,14/14,15/0,15/15,0/0,0-9,0/0,9/3,9/9,3/1,3/3,1/0,0 }
    else { /msg chanop topic # 3,1\1,3\9,3\3,9\0,9\9,0\0,0-15,0\0,15\14,15\15,14\1,14\14,1\1,1-0,1 $$?="Enter Topic" 1,1-14,1/1,14/15,14/14,15/0,15/15,0/0,0-9,0/0,9/3,9/9,3/1,3/3,1/0,0 }
  }
  ...Lines:{
    if ($me isop $chan) { /topic # 15/0,15/15,14/14,1/0,1 $$?="Enter Topic" 14,1\15,14\0,15\15,0\ }
    else { /msg chanop topic # 15/0,15/15,14/14,1/0,1 $$?="Enter Topic" 14,1\15,14\0,15\15,0\ }
  }
  ...Pennies:{
    if ($me isop $chan) { /topic # 8,1�8,14�8,15�8,0�8,15�8,14�8,1� 0 $$?="Enter Topic"  8,1�8,14�8,15�8,0�8,15�8,14�8,1� }
    else { /msg chanop topic # 8,1�8,14�8,15�8,0�8,15�8,14�8,1� 0 $$?="Enter Topic"  8,1�8,14�8,15�8,0�8,15�8,14�8,1� }
  }
  ...Purple Design:{
    if ($me isop $chan) { /topic # 8,6�0`���4�8�=�0�.,�8_0,6 $$?="Enter Topic" 8,6_�,.0��=8�4�0���`8� }
    else { /msg chanop topic # 8,6�0`���4�8�=�0�.,�8_0,6 $$?="Enter Topic" 8,6_�,.0��=8�4�0���`8� }
  }
  ...Rainbow:{
    if ($me isop $chan) { /topic # 2{3{4{5{6{7{8{9{10{11{12{13{14{15{2{3{4{5{6{7{8{9{10{11{12{13{14{15{1 $$?="Enter Topic:" 15}14}13}12}11}10}9}8}7}6}5}4}3}2}15}14}13}12}11}10}9}8}7}6}5}4}3}2} }
    else { /msg chanop topic # 2{3{4{5{6{7{8{9{10{11{12{13{14{15{2{3{4{5{6{7{8{9{10{11{12{13{14{15{1 $$?="Enter Topic:" 15}14}13}12}11}10}9}8}7}6}5}4}3}2}15}14}13}12}11}10}9}8}7}6}5}4}3}2} }
  }
  ...Squares:{
    if ($me isop $chan) { /topic # 1,11,21,31,41,51,61,71,81,91,108,1  $$?="Enter Topic"  1,101,91,81,71,61,51,41,31,21 }
    else { /msg chanop topic # 1,11,21,31,41,51,61,71,81,91,108,1  $$?="Enter Topic"  1,101,91,81,71,61,51,41,31,21 }
  }
  ..Color Topics
  ...Boldfire:{
    if ($me isop $chan) { /topic # 1215,8%8,8|4,8%8,4%4,4|5,4%4,5%5,5|1,5%5,1%1-- 16 $$?="Enter Topic:" 1--5,1%1,5%5,5|4,5%5,4%4,4|8,4%4,8%8,8|15,8%1 }
    else { /msg chanop topic # 1215,8%8,8|4,8%8,4%4,4|5,4%4,5%5,5|1,5%5,1%1-- 16 $$?="Enter Topic:" 1--5,1%1,5%5,5|4,5%5,4%4,4|8,4%4,8%8,8|15,8%1 }
  }
  ...Green:{
    if ($me isop $chan) { /topic # 9`%16,9%,  3,9`%9,3%,  1,3`%3,1%,16,1 $$?="Enter Topic:" 3,1`%1,3%,  9,3`%3,9%,  16,9`%9,16%, 1 }
    else { /msg chanop topic # 9`%16,9%,  3,9`%9,3%,  1,3`%3,1%,16,1 $$?="Enter Topic:" 3,1`%1,3%,  9,3`%3,9%,  16,9`%9,16%, 1 }
  }
  ...Grey:{
    if ($me isop $chan) { /topic # 0,15%,14`%15,14%,1`%14,1%,15,1 $$?="Enter Topic"  14,1`%1,14%,15`%14,15%,0`%3,0 }
    else { /msg chanop topic # 0,15%,14`%15,14%,1`%14,1%,15,1 $$?="Enter Topic"  14,1`%1,14%,15`%14,15%,0`%3,0 }
  }
  ...Grey Purple:{
    if ($me isop $chan) { /topic # 15,0,%0,15%`13,15,%15,13%`6,13,%13,6%`5,6,% 8 $$?="Enter Topic:" 5,6%,13,6`%6,13%,15,13`%13,15%,0,15`%15,0%, }
    else { /msg chanop topic # 15,0,%0,15%`13,15,%15,13%`6,13,%13,6%`5,6,% 8 $$?="Enter Topic:" 5,6%,13,6`%6,13%,15,13`%13,15%,0,15`%15,0%, }
  }
  ...Hotfire:{
    if ($me isop $chan) { /topic # 8,0 ,%0,8%`7,8,%8,7%`4,7,%7,4%`8,4 $$?="Enter Topic:" 7,4`%4,7%,8,7`%7,8%,0,8`%8,0%,  }
    else { /msg chanop topic # 8,0 ,%0,8%`7,8,%8,7%`4,7,%7,4%`8,4 $$?="Enter Topic:" 7,4`%4,7%,8,7`%7,8%,0,8`%8,0%,  }
  }
  ...Purple:{
    if ($me isop $chan) { /topic # 13,0<0,13>6,13<13,6>2,6<6,2>1,2<2,1>0,1 $$?="Enter Topic:" 2,1<1,2>6,2<2,6>13,6<6,13>0,13<13,0> }
    else { /msg chanop topic # 13,0<0,13>6,13<13,6>2,6<6,2>1,2<2,1>0,1 $$?="Enter Topic:" 2,1<1,2>6,2<2,6>13,6<6,13>0,13<13,0> }
  }
  ...Redfire:{
    if ($me isop $chan) { /topic # 4,0%0,4%4,4 5,4%4,5%5,5 1,5%5,1%1,1 15,1 $$?="Enter topic:" 5,1%1,5%5,5 4,5%5,4%4,4 0,4%4,0% }
    else { /msg chanop topic # 4,0%0,4%4,4 5,4%4,5%5,5 1,5%5,1%1,1 15,1 $$?="Enter topic:" 5,1%1,5%5,5 4,5%5,4%4,4 0,4%4,0% }
  }
  ...Seablue:{
    if ($me isop $chan) { /topic # 11,0%0,11% 10,11%11,10% 2,10%10,2% 1,2%2,1%0,1  $$?="Enter Topic"  2,1%1,2% 10,2%2,10% 11,10%10,11% 0,11%11,0% }
    else { /msg chanop topic # 11,0%0,11% 10,11%11,10% 2,10%10,2% 1,2%2,1%0,1  $$?="Enter Topic"  2,1%1,2% 10,2%2,10% 11,10%10,11% 0,11%11,0% }
  }
  ...Seagrey:{
    if ($me isop $chan) { /topic # 16,15%,14,15`%15,14%,10,14`%14,10%,2,10`%10,2%,15,2  $$?="Enter Topic" 10,2`%2,10%,14,10`%10,14%,15,14`%14,1516,1514,15`% 16,15%, }
    else { /msg chanop topic # 16,15%,14,15`%15,14%,10,14`%14,10%,2,10`%10,2%,15,2  $$?="Enter Topic" 10,2`%2,10%,14,10`%10,14%,15,14`%14,1516,1514,15`% 16,15%, }
  }
  ..Nice-Jagged Fades
  ...Blue:{
    if ($me isop $chan) { /topic # 12-�0,12�2,12`�12,2�1,2`�2,1�0,1 -= $$?="Enter Topic:" =-  2,1`�1,2�12,2`�2,12�0,12`�12,0�- }
    else { /msg chanop topic # 12-�0,12�2,12`�12,2�1,2`�2,1�0,1 -= $$?="Enter Topic:" =-  2,1`�1,2�12,2`�2,12�0,12`�12,0�- }
  }
  ...Bold-Fire:{
    if ($me isop $chan) { /topic # 8,16�16,8�7,8�8,7�1,7�7,1�8,1 $$?="Enter Topic" 7,1�1,7�8,7�7,8�16,8�8,16� }
    else { /msg chanop topic # 8,16�16,8�7,8�8,7�1,7�7,1�8,1 $$?="Enter Topic" 7,1�1,7�8,7�7,8�16,8�8,16� }
  }
  ...Fire:{
    if ($me isop $chan) { /topic # 8,0�0,8�7,8�8,7�4,7�7,4�5,4�4,5�1,5�5,1�8,1 $$?="Enter Topic" 5,1�1,5�4,5�5,4�7,4�4,7�8,7�7,8�0,8�8,0� }
    else { /msg chanop topic # 8,0�0,8�7,8�8,7�4,7�7,4�5,4�4,5�1,5�5,1�8,1 $$?="Enter Topic" 5,1�1,5�4,5�5,4�7,4�4,7�8,7�7,8�0,8�8,0� }
  }
  ...Green:{
    if ($me isop $chan) { /topic # 9,0�0,9�3,9�9,3�1,3�3,1� 9,1 $$?="Enter Topic" 3,1�1,3�9,3�3,9�0,9�9,0� }
    else { /msg chanop topic # 9,0�0,9�3,9�9,3�1,3�3,1� 9,1 $$?="Enter Topic" 3,1�1,3�9,3�3,9�0,9�9,0� }
  }
  ..-
  ..Funny Topics 
  ...Voices:{
    if ($me isop $chan) { /topic # I do whatever the voices in my head tell me to do }
    else { /msg chanop topic # I do whatever the voices in my head tell me to do }
  }
  ...Lie so much:{
    if ($me isop $chan) { /topic # You lie so much you believe yourself }
    else { /msg chanop topic # You lie so much you believe yourself }
  }
  ...The Man:{
    if ($me isop $chan) { /topic # Who is the man?  I am The man. I am...The Man!!! }
    else { /msg chanop topic # Who is the man?  I am The man. I am...The Man!!! }
  }
  ...Turn around:{
    if ($me isop $chan) { /topic # Turn around....run }
    else { /msg chanop topic # Turn around....run }
  }
  ...Memory:{
    if ($me isop $chan) { /topic # Your memory has been erased...now think about it }
    else { /msg chanop topic # Your memory has been erased...now think about it }
  }
  ...Dont tap on glass:{
    if ($me isop $chan) { /topic # Dont tap on the glass }
    else { /msg chanop topic # Dont tap on the glass }
  }
  ...Quit staring:{
    if ($me isop $chan) { /topic # Are you staring at me???  QUIT STARING AT ME!!! }
    else { /msg chanop topic # Are you staring at me???  QUIT STARING AT ME!!! }
  }
  ...Why are you reading:{
    if ($me isop $chan) { /topic # Why are you reading this????  Don't you have better things to do???!! }
    else { /msg chanop topic # Why are you reading this????  Don't you have better things to do???!! }
  }
  ...Favorite number:{
    if ($me isop $chan) { /topic # My favorite number is really big }
    else { /msg chanop topic # My favorite number is really big }
  }
  ...Clap you feet and stomp your hands:{
    if ($me isop $chan) { /topic # If you're a psycopath and you know it clap your feet and stomp your hands }
    else { /msg chanop topic # If you're a psycopath and you know it clap your feet and stomp your hands }
  }
  ...Toothpaste on the wall:{
    if ($me isop $chan) { /topic # Toothpaste can be used to clean your teeth or decorate the wall }
    else { /msg chanop topic # Toothpaste can be used to clean your teeth or decorate the wall }
  }
  ...Confusing:{
    if ($me isop $chan) { /topic # If you're wondering why i'm so cofusing, you just figured it out }
    else { /msg chanop topic # If you're wondering why i'm so cofusing, you just figured it out }
  }
  ...Liver:{
    if ($me isop $chan) { /topic # Look inside yourself....deeply...and see what you find.  I found a liver }
    else { /msg chanop topic # Look inside yourself....deeply...and see what you find.  I found a liver }
  }
  ...Photo memory:{
    if ($me isop $chan) { /topic # Everyone has a photographic memory. Some don't have film }
    else { /msg chanop topic # Everyone has a photographic memory. Some don't have film }
  }
  ...Sponges:{
    if ($me isop $chan) { /topic # I wonder how much deeper the ocean would be without sponges }
    else { /msg chanop topic # I wonder how much deeper the ocean would be without sponges }
  }
  ...Honk for quiet:{
    if ($me isop $chan) { /topic # *Honk* if you love peace and quiet }
    else { /msg chanop topic # *Honk* if you love peace and quiet }
  }
  ...Nothing fool proof:{
    if ($me isop $chan) { /topic # Nothing is foolproof to a sufficiently talented fool }
    else { /msg chanop topic # Nothing is foolproof to a sufficiently talented fool }
  }
  ..Funny Topics 2
  ...Save the whales:{
    if ($me isop $chan) { /topic # Save the whales. Collect the whole set }
    else { /msg chanop topic # Save the whales. Collect the whole set }
  }
  ...Other hand:{
    if ($me isop $chan) { /topic # On the other hand, you have different fingers }
    else { /msg chanop topic # On the other hand, you have different fingers }
  }
  ...Big monster mother:{
    if ($me isop $chan) { /topic # There's a big, drooling monster behind you...it has big teeth and is really hairy...wait...it's your mother }
    else { /msg chanop topic # There's a big, drooling monster behind you...it has big teeth and is really hairy...wait...it's your mother }
  }
  ...Laughs last slow thinker:{
    if ($me isop $chan) { /topic # He who laughs last thinks slowest }
    else { /msg chanop topic # He who laughs last thinks slowest }
  }
  ...Lottery:{
    if ($me isop $chan) { /topic # Lottery...a tax on people who are bad at math }
    else { /msg chanop topic # Lottery...a tax on people who are bad at math }
  }
  ...Rehab:{
    if ($me isop $chan) { /topic # Rehab is for quitters }
    else { /msg chanop topic # Rehab is for quitters }
  }
  ...Go make news:{
    if ($me isop $chan) { /topic # If you don't like the news, go out and make some. }
    else { /msg chanop topic # If you don't like the news, go out and make some. }
  }
  ...Reality is a crutch:{
    if ($me isop $chan) { /topic # Reality is a crutch for people who can't handle drugs }
    else { /msg chanop topic # Reality is a crutch for people who can't handle drugs }
  }
  ...Lazy pays now:{
    if ($me isop $chan) { /topic # Hard work has future payoff.  Laziness pays off NOW. }
    else { /msg chanop topic # Hard work has future payoff.  Laziness pays off NOW. }
  }
  ...Some people alive b.c. illegal 2 kill:{
    if ($me isop $chan) { /topic # Some people are alive only because it's illegal to kill }
    else { /msg chanop topic # Some people are alive only because it's illegal to kill }
  }
  ...Bartender is pharmacist:{
    if ($me isop $chan) { /topic # A bartender is just a Pharmacist whith a limited inventory }
    else { /msg chanop topic # A bartender is just a Pharmacist whith a limited inventory }
  }
  ...Friends and real friends:{
    if ($me isop $chan) { /topic # Friends help you move.  Real friends help you move bodies. }
    else { /msg chanop topic # Friends help you move.  Real friends help you move bodies. }
  }
  ...Three kinds of people:{
    if ($me isop $chan) { /topic # There are three kinds of people...Those who can count and those who can't }
    else { /msg chanop topic # There are three kinds of people...Those who can count and those who can't }
  }
  Channel
  .Try double-clicking in a channel window!:
  Nicknames
  .Add A Nickname: {
    if ( %nick1 == $null ) { set %nick1 . $$?="Enter A Nick:" | goto end }
    if ( %nick2 == $null ) { set %nick2 . $$?="Enter A Nick:" | goto end }
    if ( %nick3 == $null ) { set %nick3 . $$?="Enter A Nick:" | goto end }
    if ( %nick4 == $null ) { set %nick4 . $$?="Enter A Nick:" | goto end }
    if ( %nick5 == $null ) { set %nick5 . $$?="Enter A Nick:" | goto end }
    if ( %nick6 == $null ) { set %nick6 . $$?="Enter A Nick:" | goto end }
    if ( %nick7 == $null ) { set %nick7 . $$?="Enter A Nick:" | goto end }
    if ( %nick8 == $null ) { set %nick8 . $$?="Enter A Nick:" | goto end }
    if ( %nick9 == $null ) { set %nick9 . $$?="Enter A Nick:" | goto end }
    if ( %nick10 == $null ) { set %nick10 . $$?="Enter A Nick:" | goto end }
    else { echo 2���4 You have too many NICKS in your nick list  | halt }
    :end
    echo 2���4 $! has been added to your NICKNAMES list 
  }
  .Change Nicknames
  ..%nick1:/nick $remove(%nick1,.)
  ..%nick2:/nick $remove(%nick2,. )
  ..%nick3:/nick $remove(%nick3,. )
  ..%nick4:/nick $remove(%nick4,. )
  ..%nick5:/nick $remove(%nick5,. )
  ..%nick6:/nick $remove(%nick6,. )
  ..%nick7:/nick $remove(%nick7,. )
  ..%nick8:/nick $remove(%nick8,. )
  ..%nick9:/nick $remove(%nick9,. )
  ..%nick10:/nick $remove(%nick10,. )
  ..Change Nicknames...:/nick $$?="Enter Your New Nickname:"
  .Unset A Nickname
  ..%nick1:/unset %nick1
  ..%nick2:/unset %nick2
  ..%nick3:/unset %nick3
  ..%nick4:/unset %nick4
  ..%nick5:/unset %nick5
  ..%nick6:/unset %nick6
  ..%nick7:/unset %nick7
  ..%nick8:/unset %nick8
  ..%nick9:/unset %nick9
  ..%nick10:/unset %nick10
  .-
  .Register Nick:/msg nickop@austnet.org register $$?="Enter Password (Remember This Password):" $$?="Enter Your Email Address:"
  .Un-Register Nick:/msg NickOP drop
  .-
  .Nick Info:/msg nickop info $$?="Enter Nick For Info Acquire:"
  .Link
  ..Add:/msg nickop link add $$?="Nick to Link:" $$?="Password Of Linking Nick:"
  ..Delete:/msg nickop link del $$?="Nick To Delete Link:"
  ..List:/msg nickop link list
  .Nickname Kill
  ..On:/msg nickop set kill on
  ..Off:/msg nickop set kill off
  ..Now:/msg nickop@austnet.org kill $$?="Enter Nickname To Kill:" $$?="Enter Password Of Nickname You Want To Kill:"
  .Set
  ..Set New Password:/msg nickop set pass $$?="Enter New Password:"
  ..Set New Email:/msg nickop set email $$?="Enter New Email:"
  .-
  .NickOP Help:/msg nickop help
  List Bans
  .Normal:/msg chanop listban $chan
  .Who Set:/msg chanop listban $chan -whoset
  .Reason:/msg chanop listban $chan -reason
  .When Set:/msg chanop listban $chan -whenset
  NoteOP
  .Send
  ..To a Person:/msg NoteOP send $$?="Enter Nickname To Send Note TO:" $$?="Enter Message:" : Note Generated By %logo
  ..To a Channel:/msg NoteOP send $$?="Enter Channel Name To Send Note To:" $$?="Enter Message:" : Note Generated By %logo
  .-
  .List:/.msg NoteOP list
  .Read:/.msg NoteOP read $?="Enter Note Number:"
  .-
  .Delete: { /msg NoteOP del $?="Enter Note Number:"
  /msg noteop purge }
  .Purge:/.msg NoteOP purge
  .-
  .Block
  ..Add:/.msg NoteOP block add $?="Enter Nickname/Hostmask:"
  ..Delete:/.msg NoteOP block del $?="Enter Nickname/Hostmask:"
  ..-
  ..List:/.msg NoteOP block list
  .-
  .NoteOP Help:/.msg noteop help
  Other
  .Whois User?:/whois $$?="Enter Nickname To Whois:"
  .-
  .Invite User:/invite $$?="Enter Nickname To Invite:" #
  .Message User:/msg $$?="Enter Nickname You Want To Message:" $$?="Enter Message:"
  .Query User:/query $$?="Enter Nickname You Want To Open A Query Window To:"
  .-
  .Ban User:/msg chanop ban # $$?="Enter Nickname To Ban:" $?="Reason For Ban:" 
  .Kick User:{
    if ($me isop $chan) { /kick # $$?="Enter Nickname To Kick:" $?="Reason For Kick:" }
    else { /msg chanop kick # $$?="Enter Nickname To Kick:" $?="Reason For Kick:" }
  }
  .Unban User:/msg chanop unban # $$?="Enter Nickname To Unban:"
  .-
  .Ignore User:/ignore $$?="Enter Nickname You Want To Ignore:" 3
  .Unignore User:/ignore -r $$?="Enter Nickname You Want To Unignore:" 3
  .-
  .Part channel:/part # %logo
}
