menu nicklist {
  Give Advice:/me advices $$1 $read $mircdirsystem\Advice.txt
  Nick Info:/msg nickop info $$1
  Query User:/query $$1
  Whois User:/whois $$1
  UCentral:/uwho $$1
  -
  Access
  .Access List:/msg chanop access # *
  .Check Access:/msg chanop access # -check $$1
  .-
  .Give Access:/msg chanop adduser # $$1
  .Delete Access:/msg chanop deluser # $$1
  .Set Access Level:/msg chanop setuser # $* level $$?="Enter Access Level From 1 to 199:"
  .-
  .Auto
  ..Auto-Op
  ...On:/msg chanop setuser # $$1 aop on
  ...Off:/msg chanop setuser # $$1 aop off
  ..Auto-Voice
  ...On:/msg chanop setuser # $$1 aov on
  ...Off:/msg chanop setuser # $$1 aov off
  .Protection
  ..On:/msg chanop setuser # $$1 prot on
  ..Off:/msg chanop setuser # $$1 prot off
  .Op
  ..Op:{
    if ($me isop $chan) { /mode # +o $$1 }
    else { /msg chanop op # $$1 }
  }
  ..Deop:{
    if ($me isop $chan) { /mode # -o $$1 }
    else { /msg chanop deop # $$1 }
  }
  .Suspend
  ..Suspend:/msg chanop setuser # $$1 suspend $$?="Enter Time To Be Suspended For (In Minutes)"
  ..Unsuspend:/msg chanop setuser # $$1 suspend off
  .Voice
  ..Voice:{
    if ($me isop $chan) { /mode # +v $$1 }
    else { /msg chanop voice # $$1 }
  }
  ..De-voice:{
    if ($me isop $chan) { /mode # -v $$1 }
    else { /msg chanop devoice # $$1 }
  }
  Control
  .Kick User:{
    if ($me isop $chan) { /kick # $$1 $?="Reason For Kick:" }
    else { /msg chanop kick # $$1 $?="Reason For Kick:" }
  }
  .BanUser:/msg chanop ban # $$1 $?="Reason for ban:"
  .Unban:/msg chanop unban # $$?="Nick To Unban:"
  .-
  .Ignore User:/ignore $$1 3
  .Unignore User:/ignore -r $$1 3
  .-
  .Notice:/notice $* $$?="Type in the Message:"
  CTCP
  .Ping User:/ctcp $$1 ping
  .Finger User:/ctcp $$1 finger
  .Version:/ctcp $$1 version
  .Time:/ctcp $$1 time
  DCC
  .Chat:/dcc chat $$1
  .Send:/dcc send $$1
  -
  Commands (How-To)
  .Access
  ..Access List:/say 4[7 $+ $$1 $+ 4] : /msg chanop access #Channel *
  ..Check Access:/say 4[7 $+ $$1 $+ 4] : /msg chanop access #Channel Nick
  ..-
  ..Confirm:/say 4[7 $+ $$1 $+ 4] : /msg chanop confirm #Channel Nick
  ..Give Acess:/say 4[7 $+ $$1 $+ 4] : /msg chanop adduser #Channel Nick
  ..Delete Access:/say 4[7 $+ $$1 $+ 4] : /msg chanop deluser #Channel Nick
  ..Set Access Level:/say 4[7 $+ $$1 $+ 4] : /msg chanop setuser #Channel Nick Level
  ..-
  ..Seek:/say 4[7 $+ $$1 $+ 4] : /msg chanop seek #Channel Message
  ..Set
  ...Keep Topic:/say 4[7 $+ $$1 $+ 4] : /msg chanop set #Channel keeptopic level
  ...Topic:/say 4[7 $+ $$1 $+ 4] : /msg chanop topic #Channel Topic
  ...URL:/msg chanop set #Channel url URL
  .Nickname
  ..Identify:/say 4[7 $+ $$1 $+ 4] : /msg nickop@austnet.org identify Password
  ..Info:/say 4[7 $+ $$1 $+ 4] : /msg nickop info Nick
  ..Kill
  ...Now:/say 4[7 $+ $$1 $+ 4] : /msg nickop@austnet.org kill nick password
  ...On:/say 4[7 $+ $$1 $+ 4] : /msg nickop set kill on
  ...Off:/say 4[7 $+ $$1 $+ 4] : /msg nickop set kill off
  ..Set
  ...New Password:/say 4[7 $+ $$1 $+ 4] : /msg nickop set pass New-Password
  ...New Email:/say 4[7 $+ $$1 $+ 4] : /msg nickop set email New-Email
  .NoteOP
  ..Send
  ...To a Person:/say 4[7 $+ $$1 $+ 4] : /msg NoteOP send Nick-To-Send-To NoteHere
  ...To a Channel:/say 4[7 $+ $$1 $+ 4] : /msg NoteOP send Channel-To-Send-To NoteHere
  ..-
  ..List:/say 4[7 $+ $$1 $+ 4] : /msg NoteOP list
  ..Read:/say 4[7 $+ $$1 $+ 4] : /msg NoteOP read NoteNumber
  ..-
  ..Delete:/say 4[7 $+ $$1 $+ 4] : /msg NoteOP del NoteNumber
  ..Purge:/say 4[7 $+ $$1 $+ 4] : /msg NoteOP purge
  ..-
  ..Block
  ...Add:/say 4[7 $+ $$1 $+ 4] : /msg NoteOP block add NICKNAME/HOSTMASK
  ...Delete:/say 4[7 $+ $$1 $+ 4] : /msg NoteOP block del NICKNAME/HOSTMASK
  ...-
  ...List:/.msg NoteOP block list
  .Op / Voice
  ..Op:/say 4[7 $+ $$1 $+ 4] : /msg chanop op #Channel Nick
  ..Deop:/say 4[7 $+ $$1 $+ 4] : /msg chanop deop #Channel Nick
  ..-
  ..Voice:/say 4[7 $+ $$1 $+ 4] : /msg chanop voice #Channel Nick
  ..De-Voice:/say 4[7 $+ $$1 $+ 4] : /msg chanop devoice #Channel Nick
  .Other
  ..Ban User:/say 4[7 $+ $$1 $+ 4] : /ban #Channel Nick
  ..Unban User:/say 4[7 $+ $$1 $+ 4] : /msg chanop unban #Channel Nick
  ..Kick User:/say 4[7 $+ $$1 $+ 4] : /kick #Channel Nick
  ..-
  ..Ignore User:/say 4[7 $+ $$1 $+ 4] : /ignore Nick
  ..Unignore User:/say 4[7 $+ $$1 $+ 4] : /ignore -r Nick
  ..-
  ..Away
  ...Set Away:/say 4[7 $+ $$1 $+ 4] : /away AwayMessage
  ...Set Back:/say 4[7 $+ $$1 $+ 4] : /away
  .Protection
  ..Prot On:/say 4[7 $+ $$1 $+ 4] : /msg chanop setuser #Channel prot on
  ..Prot Off:/say 4[7 $+ $$1 $+ 4] : /msg chanop setuser #Channel prot off
  .Register
  ..Register Nick:/say 4[7 $+ $$1 $+ 4] : /msg nickop@austnet.org register Password Email
  ..Un-Register Nick:/say 4[7 $+ $$1 $+ 4] : /msg NickOP drop
  ..-
  ..Register Channel:/say 4[7 $+ $$1 $+ 4] : /msg chanop register #Channel and follow ChanOp's commands
  ..Un-Register Channel:/say 4[7 $+ $$1 $+ 4] : /msg chanop drop #Channel
  .Message:/say 4[7 $+ $$1 $+ 4] : $$?="Type Message!"
}
