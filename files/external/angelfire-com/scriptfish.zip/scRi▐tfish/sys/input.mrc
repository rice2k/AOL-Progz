On 1:input:*:{
  if ($1 = /close) { /closemsg $active
  halt }
  elseif ($1 = /part) { /part $active 15http://molesta/huh/
  halt }
  elseif ($left($1,1) = !) { /say $1- | halt }
  elseif ($left($1,1) = `) { /say $1- | halt }
  elseif ($left($1,1) = @) { /say $1- | halt }
  elseif ($left($1,1) != /) {
    /set %strip $1-
    IF (%blue == On) { /b }
    IF (%red == On) {  /r | halt }
    IF (gtg isin %strip) && (%exodus == on) { set %strip $replace(%strip,gtg,*Got To Go*) }
    IF (lol isin %strip) && (%exodus == on) { set %strip $replace(%strip,lol,*Laughin Out Loud*) }
    IF (brb isin %strip) && (%exodus == on) { set %strip $replace(%strip,brb,*Be Rite Back*) }
    IF (loq isin %strip) && (%exodus == on) { set %strip $replace(%strip,loq,*Laughin Out Quietly*) }
    IF (omg isin %strip) && (%exodus == on) { set %strip $replace(%strip,omg,*Oh My God*) }
    IF (bbl isin %strip) && (%exodus == on) { set %strip $replace(%strip,bbl,*Be Back Later*) }
    IF (bbs isin %strip) && (%exodus == on) { set %strip $replace(%strip,bbs,*Be Back Soon*) }
    IF (wtf isin %strip) && (%exodus == on) { set %strip $replace(%strip,wtf,*What The Fuk*) }
    IF (ppl isin %strip) && (%exodus == on) { set %strip $replace(%strip,ppl,People) }
    IF (wdf isin %strip) && (%exodus == on) { set %strip $replace(%strip,wdf,*What Da Fuk*) }
    IF (btw isin %strip) && (%exodus == on) { set %strip $replace(%strip,btw,*By The Way*) }
    IF (npz isin %strip) && (%exodus == on) { set %strip $replace(%strip,npz,*No Problemz*) }
    IF (jk isin %strip) && (%exodus == on) { set %strip $replace(%strip,jk,*Just Kidding*) }
    IF (wb isin %strip) && (%exodus == on) { set %strip $replace(%strip,wb,*Welcome Back*) }
    IF (gf isin %strip) && (%exodus == on) { set %strip $replace(%strip,gf,*GirlFriend*) }
    IF (cbf isin %strip) && (%exodus == on) { set %strip $replace(%strip,cbf,*Can't Be Farked*) }
    IF (bf isin %strip) && (%exodus == on) { set %strip $replace(%strip,bf,*BoyFriend*) }
    IF (hw isin %strip) && (%exodus == on) { set %strip $replace(%strip,hw,*Homework*) }
    IF (lmao isin %strip) && (%exodus == on) { set %strip $replace(%strip,lmao,*Laughin Ma Ass Off*) }
    IF (moot isin %strip) && (%exodus == on) { set %strip $replace(%strip,moot,*M00t*) }
    IF (%exodus == On) { /double | halt }
    IF (lol isin %strip) && (%alt-text == on) { /lol
    set %strip $replace(%strip,lol,%lol) }
    IF (brb isin %strip) && (%alt-text == on) { /brb 
    set %strip $replace(%strip,brb,%brb) }
    IF (jk isin %strip) && (%alt-text == on) { /jk 
    set %strip $replace(%strip,jk,%jk) }
    IF (bf isin %strip) && (%alt-text == on) { /bf 
    set %strip $replace(%strip,bf,%bf) }
    IF (gf isin %strip) && (%alt-text == on) { /gf 
    set %strip $replace(%strip,gf,%gf) }
    IF (bbl isin %strip) && (%alt-text == on) { /bbl
    set %strip $replace(%strip,bbl,%bbl) }
    IF (ppl isin %strip) && (%alt-text == on) { /ppl
    set %strip $replace(%strip,ppl,%ppl) }
    IF (hehe isin %strip) && (%alt-text == on) { /hehe
    set %strip $replace(%strip,hehe,%hehe) }
    IF (keke isin %strip) && (%alt-text == on) { /keke
    set %strip $replace(%strip,keke,%keke) }
    IF (haha isin %strip) && (%alt-text == on) { /haha
    set %strip $replace(%strip,haha,%haha) }
    IF (gtg isin %strip) && (%alt-text == on) { /gtg
    set %strip $replace(%strip,gtg,%gtg) }
    IF (wtf isin %strip) && (%alt-text == on) { /wtf
    set %strip $replace(%strip,wtf,%wtf) }
    IF (? isin %strip) && (%alt-text == on) { /?
    set %strip $replace(%strip,?,%?) }
    IF (! isin %strip) && (%alt-text == on) { /Quote
    set %strip $replace(%strip,!,%!!) }
    IF (wb isin %strip) && (%alt-text == on) { /wb
    set %strip $replace(%strip,wb,%wb) }
    IF (npz isin %strip) && (%alt-text == on) { /npz
    set %strip $replace(%strip,npz,%npz) }
    IF (btw isin %strip) && (%alt-text == on) { /btw
    set %strip $replace(%strip,btw,%btw) }
    IF (moot isin %strip) && (%alt-text == on) { /moot
    set %strip $replace(%strip,moot,%moot) }
    IF (%ascii == On) { /ascii }
    IF (%ascii2 == On) { /ascii2 }
    IF (%roses == On) { /say 4�3}-- �12 %strip 3� --{12� | halt }
    elseIF (%asian == On) { /say 8,1�� �02 %strip � 8,1�� | halt }
    elseIF (%colour == On) { /say %scheme $+ %strip  | halt }
    elseIF (%colour == Off) { /say %strip | halt }
  }
}

on 1:text:*asl*:?: {
  if (%asl == $null) { halt }
  elseif (%autoasl == on) { /msg $nick %asl
  halt }
}

on 1:text:*a/s/l*:?: {
  if (%asl == $null) { halt }
  elseif (%autoasl == on) { /msg $nick %asl
  halt }
}

alias -l _centerwin { return $int($calc(($window(-1).w - $1) / 2)) $int($calc(($window(-1).h - $2) / 2)) }
alias -l _fullsize { return $window(-1).w $window(-1).h }
alias -l _centerwidth { return $round($calc( [ $calc($window($1).dw - $width($2,%cool.font,%cool.size,0,0)) ] / 2),0) }
alias -l _centerheight { return $round($calc($window($1).dh / 2 - $height($2,$gettok(%cool.font,1,32),$gettok(%cool.font,2,32))),0) }
alias -l _min { if ($1 < $2) return $1 | else return $2 }
alias -l _max { if ($1 > $2) return $1 | else return $2 }
alias -l _modcolor {
  var %cool.r = $calc((%cool.colourtargetr / 10) * $1)
  var %cool.g = $calc((%cool.colourtargetg / 10) * $1)
  var %cool.b = $calc((%cool.colourtargetb / 10) * $1)
  var %cool.r = $calc(((%cool.colourtargetr / 10) * $1) + ((%cool.colourtargetbgr / 10) * (10 - $1)))
  var %cool.g = $calc(((%cool.colourtargetg / 10) * $1) + ((%cool.colourtargetbgg / 10) * (10 - $1)))
  var %cool.b = $calc(((%cool.colourtargetb / 10) * $1) + ((%cool.colourtargetbgb / 10) * (10 - $1)))
  %cool.colour = $rgb(%cool.r,%cool.g,%cool.b)
}
alias intro {
  if (%cool.busy) { return }
  set %cool.busy $true
  if ($window(@Welcome!)) { window -c @Welcome! }
  set %cool.colour 16777104
  set %cool.back 6291456
  window -adohkp +blt @Welcome! 0 0 _fullsize
  window -adokp +tL @Welcome! $_centerwin(396,264) 396 264
  drawrect -rf @Welcome! %cool.back 1 0 0 $window(@Welcome!).w $window(@Welcome!).h
  cool.fading
}
alias -l cool.fading {
  set %cool.file $mircdir/system/intro.txt
  set %cool.font "Century Gothic"
  set %cool.size 20
  set %cool.colourtargetr 144
  set %cool.colourtargetg 255
  set %cool.colourtargetb 255
  set %cool.colour 16777104
  set %cool.back 6291456
  set %cool.colourtargetbgr $gettok($rgb(%cool.back),1,44)
  set %cool.colourtargetbgg $gettok($rgb(%cool.back),2,44)
  set %cool.colourtargetbgb $gettok($rgb(%cool.back),3,44)
  set %cool.i 1
  set %cool.dec $true
  set %cool.line 1
  .timercool.ptext -m 0 200 cool.ptext
}
alias -l cool.ptext {
  gettext
  if (%cool.line > $lines(%file)) { .timercool.ptext off | unset %cool.* | cool.fading }
  drawrect -rnf @Welcome! %cool.back 1 0 0 $window(@Welcome!).w $window(@Welcome!).h
  drawtext -rn @Welcome! %cool.colour %cool.font %cool.size $_centerwidth(@Welcome! ,%cool.text) $_centerheight(@Welcome! ,%cool.text) %cool.text
  drawdot @Welcome!
  inc %cool.step
  if (%cool.dec) { _modcolor $calc(10 - %cool.step) }
  else { _modcolor %cool.step }
  if (%cool.colour == 16777104) { set %cool.dec $true | %cool.step = 0 }
  if (%cool.colour == %cool.back) { set %cool.dec $false | inc %cool.line | %cool.step = 0 }
}
alias -l gettext {
  :loop
  if (%cool.line > $lines(%cool.file)) { .timercool.ptext off | unset %cool.* | cool.fading }
  set %cool.text $read -l [ $+ [ %cool.line ] ] %cool.file
  if (%cool.text == $null) { inc %cool.line | goto loop }
}
on *:close:@ { .timercool.* off | unset %cool.* }
menu @Welcome! {
  dclick: cool.close
  &Close: cool.close
}
alias -l cool.close { .timercool.* off | unset %cool.* | window -c @Welcome! }
