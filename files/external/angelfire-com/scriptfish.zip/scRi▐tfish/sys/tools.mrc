alias tools dialog -m tools tools
dialog tools {
  title "Misc Tools"
  size -1 -1 345 220
  box "Web Browser",1, 10 10 150 70
  button "Exit", 17, 260 190 70 25,ok
  button "explorer",2, 20 35 60 25
  button "netscape",3, 90 35 60 25
  box "Socks",4, 10 90 150 120
  button "port scanner",5, 25 110 120 25
  button "run telnet",6, 25 140 120 25
  button "ip configuration",7,25 170 120 25
  box "Windows",8, 170 10 165 165
  button "calculator",9, 185 30 60 25
  button "wordpad",10, 260 30 60 25
  button "paint",11, 185 65 60 25
  button "notepad",12, 260 65 60 25
  button "ms-dos",13,185 100 60 25
  button "cd-player",14,260 100 60 25
  button "char-map",15,185 135 60 25
  button "explorer",16,260 135 60 25
}

on *:dialog:tools:sclick:2:run iexplore 
on *:dialog:tools:sclick:3:run netscape 
on *:dialog:tools:sclick:5:pscanip
on *:dialog:tools:sclick:6:run telnet 
on *:dialog:tools:sclick:7:run winipcfg.exe
on *:dialog:tools:sclick:9:run calc
on *:dialog:tools:sclick:10:run wordpad
on *:dialog:tools:sclick:11:run mspaint
on *:dialog:tools:sclick:12:run notepad
on *:dialog:tools:sclick:13:run command
on *:dialog:tools:sclick:14:run cdplayer
on *:dialog:tools:sclick:15:run charmap
on *:dialog:tools:sclick:16:run explorer.exe
