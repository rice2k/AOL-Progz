Run 'Acid Rain.exe'

You will be presented with an option menu

Recommended use 'Smashing' quality unless your using a very slow computer

Make sure you try 'Cool sparkles' colour

Controls:
Left arrow: Left
Right arrow: Right
Esc: Quit

Any other than the above: Pause

CREATED BY BEN LEED