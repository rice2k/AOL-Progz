
#ifndef maplay_h
#define maplay_h

class TPlayThread : public TThread {
public:
  MPEG_Args *maplay_args;
  virtual int Run();
};

#endif