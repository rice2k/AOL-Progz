
/* -*-Java-*- */
/*
 *  Copyright (C) 2000  Rakesh Sawan <sawan@mailcity.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
class ServerChatPacket{
	protected int code;
	protected int destid;
	protected int from;
	protected String mesg;
	protected char ch;
	ServerChatPacket(int code,int from,int destid,String mesg){
		this.code=code;
		this.destid=destid;
		this.from=from;
		this.mesg=mesg;
	}
	ServerChatPacket(int code,int from,int destid,char ch){
		this.code=code;
		this.destid=destid;
		this.from=from;
		this.ch=ch;
	}
	public int getCode(){
		return code;
	}
	public int getDestId(){
		return destid;
	}
	public String getMesg(){
		return mesg;
	}
	public int getSenderId(){
		return from;
	}
	public char getChar(){
		return ch;
	}
}
