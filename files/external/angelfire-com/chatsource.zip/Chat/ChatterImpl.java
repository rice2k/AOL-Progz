
/* -*-Java-*- */
/*
 *  Copyright (C) 2000  Rakesh Sawan <sawan@mailcity.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
interface ChatterImpl{
	/**
	* name of your or your friend chatter
	**/
	static final int INFORM_NAME_CODE=50000;
	/**
	* represents the code for chat message
	**/
	static final int CHAT_CODE=50001;
	/**
	* represents the code for the new chatter who just
	*entered
	**/
	static final int ENTER_CODE=50002;
	/**
	*Code for the request to talk
	**/
	static final int REQUEST_CODE=50003;
	/**
	*code for the acceptance of the request
	**/
	static final int ACCEPT_CODE=50004;
	/**
	*code for rejecting the request
	**/

	 static final int REJECT_CODE=50005;
	 /**
	 * code to indicate session between two chatter's
	 **/
	 static final int SESSION_CODE=50006;
	 /**
	 *code for the chater when left
	 **/
	 static final int QUIT_CODE=50007;
   //Code to tell the client it's ID
   static final int ASSIGN_ID_CODE=50009;
   //Send this to say hello
   static final int HELLO_CODE=50010;
   //Server ID
   static final int SERVER_ID=50011;
	/**
	 * This represents enter key code
	 */
   static final int MAGIC_ENTER_KEY=(int)'\\';

}
