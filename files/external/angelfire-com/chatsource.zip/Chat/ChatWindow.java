
/* -*-Java-*- */
/*
 *  Copyright (C) 2000  Rakesh Sawan <sawan@mailcity.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
import java.awt.*;
import java.io.*;
class ChatWindow extends Frame{
  private ChatFrame chatFrame;
  private Button   quit;
  private ChatServerHandler serverHandler;
  ChatWindow(String s,ChatServerHandler serverHandler){
    super(s);
    this.serverHandler=serverHandler;
    setLayout(new BorderLayout(2,1));
    quit=new Button("quit");
    chatFrame=new ChatFrame(s,serverHandler);
    add("Center",chatFrame);
    add("South",quit);
System.out.println("ChatWindow Initialization rutine over");
  }
  public void appendToMe(){
    chatFrame.appendToMe();
  }
  public void appendToHis(String s){
   chatFrame.appendToHis(s);
  }
  public boolean keyDown(Event evt,int key){
		if((char)key!='\n'){
		chatFrame.iWrote[chatFrame.myLineCount]+=(char)key;
		try{
		chatFrame.server.chat((char)key);
		}catch(IOException e){}
		chatFrame.appendToMe();
		}
		return true;
	}
}
