
/* -*-Java-*- */
/*
 *  Copyright (C) 2000  Rakesh Sawan <sawan@mailcity.com>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
import java.io.*;
import java.net.*;
class ChatSocket {
	Socket socket;
	
	ChatSocket(String host,int port) throws IOException{
		socket=new Socket(host,port);
	}
	ChatSocket(Socket socket){
		this.socket=socket;
	}
	public ChatInputStream getChatInputStream() throws IOException{
		return new ChatInputStream(socket.getInputStream());
	}
	public ChatOutputStream getChatOutputStream() throws IOException{
		return new ChatOutputStream(socket.getOutputStream());
	}
}
