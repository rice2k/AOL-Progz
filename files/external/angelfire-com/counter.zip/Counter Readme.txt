Run 'Counter.exe'

In the bottom combo boxes fill out the date on which you want to be counted down

Include a description as to what it is

To delete, double click on the item in the list box


CREATED BY BEN LEED