SECONDARY WEAPON CHANGING SCRIPT FOR Q3A BY TopGear with help from the bind.
http://www.planetquake.com/thebind/

Place all the files in your q3demo dir.
PRIMARY WEAPON IS THE RL, change it to anything you want by replacing weapon 5 in the sec*.cfg files to the desired primary weapon.
Hit weapon changing button/key once to change to the desired secondary weapon and once after that to change back to the primary weapon.
+mouse2 is binded as the weapon changing button/key by default change it to any key/button you want in the last line in all the sec*.cfg files.

type in quake3 console once: exec bind.cfg to set f1 till f5 keys to the secondary weapon selections shortcuts
(rail/shaft/plasma/shotgun/machinegun)

Have fun and watch out for those deadly combo's now ;)