Run 'Comaptibility Calc.exe'

This is very straight forward

Type in the two names in the two text boxes: Example: 'John Smith' and 'Jane Smith'

The result will appear up the top

NOTE: Names are not case sensitive

CREATED BY BEN LEED