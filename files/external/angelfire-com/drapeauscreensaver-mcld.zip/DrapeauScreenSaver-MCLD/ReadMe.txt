(c)2005 Screen saver by mclodo
freeware
INSTALLATION:
right click on DrapeauScreenSaver-MCLD.scr and choose Install...
you can change the picture (save over ImageCLD.jpg and reinstall with it)

bouton droit de la souris sur DrapeauScreenSaver-MCLD.scr et choississez Installer...
changez l'image: (ecrasez ImageCLD.jpg et r�installez)

