;jamaro@37.com
;http://come.to/Jamaro
;Feb 2001
;==================================
; Email Checker
; 1.2
; Pasmal
; Lets you check pop3 email accounts for new email. 
;http://www.helpdesk.mircx.com/scripts
on *:LOAD: {
  if ($version < 5.51) { echo Warning: This script requires mIRC 5.51 or higher. You are using mIRC $version which is incompatiable with this Email Checker. Please download the latest copy of mIRC from www.mirc.co.uk | halt }
  echo E-Mail Checker is now loaded. You can access this script via the Status or Menu "Email Checker" section. 
}

alias emailunload {
  ;removes any files and variables created by this script
  .remove $scriptdiremail.dat
  .remove $scriptdiremail.hdr
  .remove $scriptdiremail.nfo
  unset %helpdesk*.email 
  unset %email-*
  echo -a Email Checker Script Unloaded
  .timer 1 1 unload -rs $script
}
alias email-list-profiles {
  ;displays the list of email profiles into a dialog id
  ; format: /email-list-profiles dialog-name id
  if ($exists($scriptdiremail.dat) == $true) {
    set %email-list-profiles-lines $lines($scriptdiremail.dat)
    set %email-list-profiles-count 1
    :start
    inc %email-list-profiles-count 1
    set %email-list-profiles-temp $read -l $+ %email-list-profiles-count $scriptdiremail.dat
    set %email-list-profiles-temp $gettok(%email-list-profiles-temp,1,61)
    if (%email-list-profiles-temp) && ($dialog($2) != $null) { did -a $2 $1 %email-list-profiles-temp }
    if (%email-list-profiles-count < %email-list-profiles-lines) { goto start }
  }
}
;opens the email-set dialog only if its not already open
alias email-set if ($dialog(email-set) == $null) { dialog -md email-set email-set }
;opens the email-check dialog only if its not already open
alias email-check if ($dialog(email-check) == $null) { dialog -md email-check email-check }
on *:DIALOG:email-check:init:0: {
  ;puts the name of the current profile onto the titlebar of the Email Checker dialog
  dialog -t email-check Email Checker - Current Profile is %email-set-current-account
  ;puts a list of all profiles into a drop down combo
  email-list-profiles 10 email-check
  did -f email-check 23
}
on *:DIALOG:email-check:sclick:*:{ 
  ; if you click on the hd now icon the below web site will open as long as you are not already there
  if ($did == 23) && ($url != http://home.dreamhaven.org/~hdesk/documents/) {
    run http://home.dreamhaven.org/~hdesk/documents/ 
    if ($dialog(email-check) != $null) { did -r email-check 24 | did -a email-check 24 Status: Opening your Web Browser to http://home.dreamhaven.org/~hdesk/documents }
  }
  ; id 1 is the OK button, when click this closes the socket connected to the email server
  if ($did == 1) { sockclose treb | .timeremcd OFF }
  if ($did == 6) && ($did(5,$did(5).sel).text != $null) {
    ; if you click on the View email button, then this clears the body, subject, to, from & date editboxes
    did -r email-check 13
    did -r email-check 15
    did -r email-check 17
    did -r email-check 19
    did -r email-check 20
    ;asks the pop3 server for the email message
    sockwrite -n treb RETR $gettok($did(5,$did(5).sel).text,1,41) 
    if ($dialog(email-check) != $null) { did -r email-check 24 | did -a email-check 24 Status: Requesting Email $gettok($did(5,$did(5).sel).text,1,41) $+ . One moment... }
  }
  if ($did == 11) && ($did(10,$did(10).sel).text != $null) {
    ;this happens when you click on "check email" after selecting a new profile to become the autocheck profile
    ;it clears any data relating to the old email account
    did -r email-check 5
    did -r email-check 8
    did -r email-check 13
    did -r email-check 15
    did -r email-check 17
    did -r email-check 19
    did -r email-check 20
    set %email-set-current-account $did(10,$did(10).sel).text
    dialog -t email-check Email Checker - Current Profile is %email-set-current-account
    ;closes email server connection
    sockclose treb
    .timer 1 1 checkmail
    if ($dialog(email-check) != $null) { did -r email-check 24 | did -a email-check 24 Status: Trying To Connect To %email-set-current-account $+ 's mail server... }
  }
  if ($did == 21) { .timer -m 1 1 email-set }
  if ($did == 22) { run email-help.txt }
}
dialog email-check {
  title "Email Checker"
  size -1 -1 630 415
  button "OK",1,450 362 175 30,OK
  box "Email Body",2,5 110 440 280
  box "Email Information",3, 5 5 440 100
  text "Select Email:",4,450 15 80 20
  combo 5,450 35 175 410,drop
  button "View Email",6,450 60 175 25
  text "Total Emails:",7,450 95 100 20
  edit "",8,516 92 50 20,read autohs
  text "Change Profile:",9,450 120 80 20
  combo 10,450 140 175 130,drop
  button "Check Email",11,450 165 175 25
  text "To:",12,15 25 40 20
  edit "",13,60 25 170 20,autohs read
  text "From:",14,15 50 40 20
  edit "",15,60 50 170 20,autohs read
  text "Subject:",16,15 75 40 20
  edit "",17,60 75 375 20,autohs read
  text "Time:",18,245 25 30 20
  edit "",19,275 25 160 20,autohs read
  edit "",20,15 130 420 255,multi return hsbar vsbar read
  button "Profile Editor",21,450 195 175 25
  button "Help",22,450 225 175 25
  icon 23, 490 290 88 31, hd.bmp
  edit "Status:",24,1 395 630 20,read autohs
}
on *:DIALOG:email-set:init:0: {
  ;this event reacts when the email settings window is first opened
  ;puts the profiles list into two ids: 4 & 20
  email-list-profiles 4 email-set
  email-list-profiles 20 email-set
  ;if you had previously checked id 15, then this will re-check it (wow the script has a memory)
  if (%email-set-autocheck-state == 1) { did -c email-set 15 }
  ;same here, if you entered a time between autochecks then this will put that time onto the dialog
  if (%email-set-autocheck-duration != $null) { did -a email-set 16 %email-set-autocheck-duration }
  ;if you selected the new mail sound option then this will check its check box
  if (%email-set-new-sound == 1) { did -c email-set 22  }
  ;this will put the filename of the sound to play into an editbox
  if (%email-set-new-sound-filename != $null) { did -a email-set 23 %email-set-new-sound-filename }
}
on *:DIALOG:email-set:edit:*: {
  ;sets the duration between email checks whenever something changes in the id16 editbox
  if ($did == 16) {  set %email-set-autocheck-duration $did(16).text }
}
alias email-set-sound {
  ;asks the user to select a sound to play when new email is found
  unset %email-set-new-sound-temp
  set %email-set-new-sound-temp $dir="Select Wav File", $wavedir*.wav
  if (%email-set-new-sound-temp != $null) {   set %email-set-new-sound-filename %email-set-new-sound-temp | did -r email-set 23 | did -a email-set 23 %email-set-new-sound-filename }
  if (%email-set-new-sound-temp == $null) { echo -a E-mail Checker: No new sound selected, thus no change has been made }
}
on *:DIALOG:email-set:sclick:*: {
  if ($did == 21) && ($url != http://home.dreamhaven.org/~hdesk/documents/) { run http://home.dreamhaven.org/~hdesk/documents/ }
  ;calculates the time between email checkers after you click the OK button.
  if ($did == 1) && (%email-set-autocheck-state == 1) { .timerCHECKM 0 $round($calc(%email-set-autocheck-duration * 60),0) /checkmail }
  ;if you choose not to autocheck anymore then this will turn the auto check timer off
  if ($did == 1) && (%email-set-autocheck-state == 0) { .timerCHECKM OFF }
  ;this reacts whenever someone (1=yes,0=no) checks/unchecks the "autocheck" checkbox
  if ($did == 15) { set %email-set-autocheck-state $did(15).state }
  ;reacts when someone checks/unchecks the new email sound checkbox
  if ($did == 22) { set %email-set-new-sound $did(22).state }
  ;runs an alias which allows you to change your email sound when you click on the SOUND button.
  if ($did == 24) { .timer -m 1 1 email-set-sound }
  if ($did == 4) { 
    ;when you select a new profile, this will put that profiles info in the appropiate places, and remove the old info.
    did -r email-set 6
    did -r email-set 8
    did -r email-set 10
    did -a email-set 6 $readini $scriptdiremail.nfo $did(4,$did(4).sel).text username
    did -a email-set 8 $readini $scriptdiremail.nfo $did(4,$did(4).sel).text host
    did -a email-set 10 $readini $scriptdiremail.nfo $did(4,$did(4).sel).text pass
  }
  if ($did == 11) && ($did(4,$did(4).sel).text != $null) {
    ;if you click Update Profile & you have selected a valid profile this will update that profile
    writeini $scriptdiremail.nfo $did(4,$did(4).sel).text username $did(6).text
    writeini $scriptdiremail.nfo $did(4,$did(4).sel).text host $did(8).text
    writeini $scriptdiremail.nfo $did(4,$did(4).sel).text pass $did(10).text
  }
  ;this reacts when you select a new current email checking account, it changes the script to check under this account
  if ($did == 20) && ($did(20,$did(20).sel).text != $null) { set %email-set-current-account $did(20,$did(20).sel).text }
  if ($did == 12) && ($did(4,$did(4).sel).text != $null) {
    ;this script deletes a valid profile
    remini $scriptdiremail.dat email $did(4,$did(4).sel).text
    remini $scriptdiremail.nfo $did(4,$did(4).sel).text
    did -d email-set 4 $did(4).sel
    did -r email-set 6
    did -r email-set 8
    did -r email-set 10
  }
  if ($did == 13) { 
    ;this opens the dialog that lets you create a new profile name.
    .timer -m 1 1 dialog -mdo email-add email-add
  }
}
dialog email-add {
  title "Enter Name Of New Profile"
  size -1 -1 375 85
  button "Create Profile",1,5 55 100 25,OK
  button "Cancel",2,110 55 100 25,Cancel
  edit "",3,5 25 370 25,autohs
  text "Enter Name Of New Profile That You Wish To Create (One Word Please)",4,5 5 370 20
}
on *:DIALOG:email-add:sclick:1: {
  ;this reacts when you click on "Create profile" in the add new profile dialog
  ;if you did enter some text then this will add that text as a new profile
  if ($did(3).text != $null) { 
    did -a email-set 4 $did(3).text
    writeini $scriptdiremail.dat email $did(3).text $did(3).text
  }
}
dialog email-set {
  title "Email Checker Settings"
  size -1 -1 320 320
  button "OK",1,240 160 72 153, OK
  box "Profile Settings",2,5 5 310 145
  text "Profile Name:",3,10 25 80 20
  combo 4, 110 25 150 130,drop
  text "Username:",5,10 50 60 20
  edit "",6,110 50 150 20,autohs
  text "POP3 (Mail) Server:",7, 10 70 110 20
  edit "",8,110 70 150 20,autohs
  text "Password:",9, 10 90 110 20
  edit "",10,110 90 150 20,autohs pass
  button "Update Profile",11, 12 115 90 25
  button "Remove Profile",12, 115 115 90 25
  button "New Profile",13, 215 115 90 25
  box "Auto Check Settings",14, 5 155 230 160
  check "Auto Check Mail every",15, 15 170 125 20
  edit "",16,145 170 30 20,autohs
  text "min(s)",17,177 175 50 20
  text "Profile To Auto Check:",19, 15 190 115 20
  combo 20,15 205 210 130,drop
  icon 21, 80 275 88 31, hd.bmp
  check "New E-Mail Sound",22,15 228 115 20
  edit "",23,15 250 210 20, autohs read
  button "Sound",24,135 230 70 18
}
on *:SOCKOPEN:treb: {
  ;this event reacts when you open a socket to the email pop3 server
  ;it sends some commands to login to your account and check (stat) your email status
  set -u1 %email-temp-username $readini $scriptdiremail.nfo %email-set-current-account username
  set -u1 %email-temp-password $readini $scriptdiremail.nfo %email-set-current-account pass
  sockwrite -n treb USER %email-temp-username
  sockwrite -n treb PASS %email-temp-password
  sockwrite -n treb STAT
  set %email-temp-counter 0
  if ($dialog(email-check) != $null) { did -r email-check 24 | did -a email-check 24 Status: Sending Username and Password to email server... }
}
on *:SOCKCLOSE:treb: .timeremcd off
on *:SOCKREAD:treb: {
  ;this event reacts when information is sent to you from the email pop3 server.  
  sockread %email-socket-date
  ;  if (%email-socket-date) { echo -s %email-socket-date }
  ;-ER occurs when you receive an error from the pop3 server
  if ( -ER isin %email-socket-date ) { 
    if ($dialog(email-check) != $null) { did -r email-check 24 | did -a email-check 24 Status: An Error Has Occured, See Status Window For Details }
    echo -s Email Checker: %email-socket-date 
  }
  if ( +OK isin %email-socket-date ) && ( octets isin %email-socket-date ) { 
    ;checks how many email messages are on the server, reacts accordinly
    if ( $gettok(%email-socket-date,4,32) > 0 ) { 
      .timerOCM -m 1 1 email-check
      if (%email-set-new-sound == 1) && ($exists(%email-set-new-sound-filename) == $true) { .timer 1 3 splay %email-set-new-sound-filename }
      if ($dialog(email-check)) { did -r email-check 8 }
      ;if there is new email the script trys to open the email-check dialog
      ;sets off a timer to display the number of emails at the server to id 8
      .timer 1 1 did -a email-check 8 $gettok(%email-socket-date,4,32)
      .timeremcd off     
      echo -a You have $gettok(%email-socket-date,4,32) message(s) 
      ;sets var to number of messages received
      set %helpdesk-tot.msg $gettok(%email-socket-date,4,32)
      unset %helpdesk-from.mail
      unset %helpdesk-to.mail
      unset %helpdesk-date.mail
      unset %helpdesk-sender.mail
      unset %helpdesk-subject.mail
      if ( %helpdesk-tot.msg > 0 ) { 
        set %helpdesk-this.msg 0
        :sdtart
        inc %helpdesk-this.msg 1
        ;asks the server for the header information of each message       
        sockwrite -n treb TOP %helpdesk-this.msg 0
        if ( %helpdesk-this.msg < %helpdesk-tot.msg ) { goto sdtart }
        if ($dialog(email-check) != $null) { did -r email-check 24 | did -a email-check 24 Status: You Have %helpdesk-tot.msg Messages }
      }
      :end
    }
    if ( $gettok(%email-socket-date,4,32) == 0 ) { 
      echo -a You have no messages | sockclose treb |  .timeremcd off 
      if ($dialog(email-check) != $null) { did -r email-check 24 | did -a email-check 24 Status: You Have No Messages }
    }
  }
  if ( $gettok(%email-socket-date,1,32) != Received: ) && ( $gettok(%email-socket-date,1,32) != date: ) && ( $gettok(%email-socket-date,1,32) != subject: ) && ( mime !isin $gettok(%email-socket-date,1,32) ) && ( Sender !isin $gettok(%email-socket-date,1,32) ) && ( From !isin $gettok(%email-socket-date,1,32) ) && ( message-id !isin $gettok(%email-socket-date,1,32) ) && ( to: !isin $gettok(%email-socket-date,1,32) ) && ( content- !isin $gettok(%email-socket-date,1,32) ) && ( X-UI !isin $gettok(%email-socket-date,1,32) ) && ( +OK !isin $gettok(%email-socket-date,1,32) ) {
    if ( Return-path !isin $gettok(%email-socket-date,1,32) ) {
      if ( X- !isin $gettok(%email-socket-date,1,32) ) && ( : !isin %gettok(%email-socket-date,1,32) ) {
        ;if the text does not appear to be header info this will put the text into the body editbox (id 20, styles: return multi vsbar hsbar)
        if (%email-socket-date == $null) { did -a email-check 20 $crlf }
        if ( %email-socket-date != $null ) && (%email-socket-date != .) {
          if ($dialog(email-check)) {  did -a email-check 20 %email-socket-date $crlf }
        }
      }
    }  
  }
  if ( $gettok(%email-socket-date,1,32)  == From: ) { 
    set %helpdesk-from.mail $deltok(%email-socket-date,1,32)
  }
  if ($dialog(email-check) != $null) { .timerOCM -m 1 1 email-check  }
  if ($gettok(%email-socket-date,1,32)  == To: ) { 
    ;when it finds out who this email was sent to, it clears any old info about any other email
    if ($dialog(email-check) != $null) {
      did -r email-check 13
      did -r email-check 15
      did -r email-check 19
      did -r email-check 17
    }
    set %helpdesk-to.mail $deltok(%email-socket-date,1,32)
  }
  if ( $gettok(%email-socket-date,1,32)  == Date: ) { 
    set %helpdesk-date.mail $deltok(%email-socket-date,1,32)
    .timeremail-check 1 3 email-check-update   
  }
  if ( $gettok(%email-socket-date,1,32)  == Sender: ) { 
    set %helpdesk-sender.mail $deltok(%email-socket-date,1,32)
  }
  if ( $gettok(%email-socket-date,1,32)  == Subject: ) { 
    set %helpdesk-subject.mail $deltok(%email-socket-date,1,32)
    if ($dialog(email-check) != $null) {    did -a email-check 17 %helpdesk-subject.mail }
  }
  if ($gettok(%email-socket-date,1,32) == X-UIDL:) {
    if ($dialog(email-check) == $null) { echo 2 -a ��� Please wait ten seconds as mIRC has yet to properly close/restart the email checker dialog | sockclose treb | .timerOCM off | halt }
    ;the X-UIDL: part of the header is in all emails, and is a uniqure id for each email
    did -r email-check 20
    set %helpdesk-xuid.mail $deltok(%email-socket-date,1,32)
    .timeremail-check 1 1 email-check-update  
    if (%helpdesk-subject.mail == $null) {  set %helpdesk-subject.mail NoSub. $ticks }
    ;this makes sure that the email is put into the drop down combo list of all emails
    ; and adds the UIDL to a ini file, and then uses this ref to make sure it dosnt display the same email more than once
    if  ($dialog(email-check) != $null) && ($readini $scriptdiremail.hdr header %helpdesk-xuid.mail == $null) {
      inc %email-temp-counter 1 | did -a email-check 5 %email-temp-counter $+ ) %helpdesk-subject.mail 
      writeini $scriptdiremail.hdr header %helpdesk-xuid.mail %email-temp-counter
    }
    if ($dialog(email-check) != $null) { did -r email-check 24 | did -a email-check 24 Status: Downloading Header for: " $+ %helpdesk-subject.mail $+ " from %helpdesk-from.mail - %helpdesk-sender.mail }
  }
  :slep
  ;this will close the connection to the pop3 server after 120 seconds of no activity
  .timeremcd 1 120 /sockclose treb
}
alias email-check-update {
  ;this alias updates the date,to,from,subject, etc... about the currently selected email
  if ($did(email-check,17).text == $null) { did -a email-check 17 %helpdesk-subject.mail }
  if ( %helpdesk-to.mail != $null ) && ($dialog(email-check) != $null) { did -a email-check 13 %helpdesk-to.mail }
  if ( %helpdesk-date.mail != $null ) && ($dialog(email-check) != $null) { did -a email-check 19 %helpdesk-date.mail GMT  }
  if ( %helpdesk-from.mail != $null ) && ($dialog(email-check) != $null) {  did -a email-check 15 %helpdesk-from.mail  | unset %helpdesk-from.mail  }
  if ( %helpdesk-sender.mail != $null ) && ($dialog(email-check) != $null) {  did -a email-check 15 %helpdesk-sender.mail  }
  unset %helpdesk-from.mail %helpdesk-to.mail %helpdesk-date.mail
  unset %helpdesk-sender.mail 
  set %helpdesk-subject.mail Unknown Subject. $ticks 
}
alias checkmail {
  ;checks to see if you are not already checking your mail
  if ($sock(treb) != $null) { halt } 
  ;if the dialog email-check is open, remove the email listings
  if ($dialog(email-check)) { did -r email-check 5 }
  ;reset the X-UIDL list
  remini $scriptdiremail.hdr header
  set -u1 %email-temp-servername $readini $scriptdiremail.nfo %email-set-current-account host
  if (%email-temp-servername == $null) { echo 4 -a * /checkmail: You have not seleceted an auto check account | halt }
  sockopen treb %email-temp-servername 110
  echo -a Checking for new mail
  ;if the script does not connect to the server within 20 seconds then this timer will close the connection
  .timeremcd 1 20 /sockclose treb
}
alias stopmail { 
  .timercheckm off
}
on *:START: {
  .remove $scriptdiremail.hdr
  if (%email-set-autocheck-state == 1) { 
    .timer 1 10 /checkmail
    .timercheckm 0 $round($calc(%email-set-autocheck-duration * 60),0) /checkmail 
  }
}
menu channel,menubar,status {
  Email Checker
  .Settings: email-set
  .-
  .Email Checker Window: email-check
  .Check Current Profile Now: checkmail
}
