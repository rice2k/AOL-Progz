Run 'Unriged Beta.exe'

*This is only a beta version*

press the ready button

When the white box says 'GO' press any 'letter' key

make sure the 'Ready' button is 'infocus' or it wont work


CREATED BY BEN LEED