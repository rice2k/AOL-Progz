Embrosia's
SIMfully Delicious
WWW.angelfire.com/freak/SIMfullyDelicious

Thanks for downloading! To install, put in the Sims/Gamedata/Skins folder.
Please do not re-post or alter for distributation without my permission.
E-mail me at starrr777@hotmail.com


NO REQUESTS!