Othello
by
Jeremiah J. Jones

original concept by some guy a bunch of years ago

here's how it works:

controls: (case sensitive)
N	start a new game
a	toggle fast ai
S	save replay
P	play replay
H	toggle help
left click	place piece for the current player
right click	tell the ai player to move (only works when it's white's turn)

when fast ai is on, the ai player moves as soon as it becomes its turn. This makes
the game go much faster, but can be nerve-wracking for new players, especially since
the ai is so ruthless. Being eliminated in less than thirty seconds is irritating,
I assure you.

When help is on and the mouse is over the board, the legal moves are all highlighted.
The color is based on the ai. When the ai looks at the board it assigns a score to
each legal move. The higher the score, the better it thinks the move is. The scores
are color coded to make it easier to see good moves. The brighter green the move, the
better it is. The brighter red the move, the worse it is. The ai is not perfect, so
a green move can be bad and a red move can be good. I made the ai look one move ahead
when considering certain situations, but not all, so it will often make some pretty
bad mistakes. It used to be a WHOLE lot worse. Tricking the ai used to be a piece of
cake, but every time I see a trick that almost always works I add conditions to the
ai to make it recognize the trick, so it will rarely fall for it again.

NOTE:
There will occasionally be times when a player (often the ai) will move twice in a row.
This is not a bug. When a player has no available moves, the turn is forfeit. If
neither player can move, the game is over and the highest scoring player wins. This
usually means the board is full, but games can end without filling the board. I have
played games where there were three open spots, but no one could move. I have also seen
players totally eliminated. The fastest I have ever seen a player eliminated is with 13
pieces on the board. This was with a version I had years ago (not mine). The ai was so
crappy that the same sequence of moves resulted in the same game EVERY TIME. Mine used
to do that, but I changed it. Now it might do it for a small number of cases, but I
haven't seen any yet.

Pieces:
The piece is defined in the text file "out.txt". There are also several different
versions, each at a different resolution. To change pieces, just change the name of the
file for the piece you want to use to "out.txt" and run the program.

Model.exe:
This is a program to view the piece close up. Name the piece file "piece.txt" and run
this program to view the piece. This is helpful when creating your own pieces or just
viewing pieces of different resolution.

controls:
x/X	rotate about the x axis
y/Y	rotate about the y axis
z/Z	rotate about the x axis
different cases rotate in different directions.

The textures:
black.bmp and white.bmp are the textures for the black and white sides, respectively.
side.bmp is the texture for the side of the piece. This should be a mirrored image
left to right for the pieces included with this program.
board.bmp is the texture for the board. It is tiled over the board (currently 10x10).
All textures should be 24-bit bitmaps and their dimensions should each be a power of 2.