VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Object = "{753FEE6F-A545-4EAA-AAC8-87512ED29F21}#3.0#0"; "CCRPDTP6.OCX"
Begin VB.Form frmAddress 
   Caption         =   "Address Book"
   ClientHeight    =   6825
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   13560
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   9.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmAddress.frx":0000
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   MDIChild        =   -1  'True
   ScaleHeight     =   6825
   ScaleWidth      =   13560
   WindowState     =   2  'Maximized
   Begin VB.Frame fram 
      Caption         =   "Contact Information"
      Height          =   2055
      Left            =   120
      TabIndex        =   12
      Top             =   120
      Width           =   14895
      Begin CCRPDTP6.ccrpDtp bDay 
         Height          =   375
         Left            =   4440
         TabIndex        =   23
         Top             =   1320
         Width           =   1695
         _ExtentX        =   2990
         _ExtentY        =   661
         Min             =   -109205
         Max             =   2958465
         CCRPVer         =   1
         Var             =   "frmAddress.frx":014A
         XD              =   "frmAddress.frx":017E
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Tahoma"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Text            =   "15/Dec/02"
      End
      Begin VB.TextBox txtColumn 
         Height          =   360
         Index           =   7
         Left            =   10680
         TabIndex        =   8
         Top             =   1320
         Width           =   1455
      End
      Begin MSComctlLib.ListView lvwGrp 
         Height          =   1335
         Left            =   12480
         TabIndex        =   9
         Top             =   360
         Width           =   2295
         _ExtentX        =   4048
         _ExtentY        =   2355
         View            =   3
         LabelEdit       =   1
         LabelWrap       =   -1  'True
         HideSelection   =   -1  'True
         HideColumnHeaders=   -1  'True
         Checkboxes      =   -1  'True
         _Version        =   393217
         ForeColor       =   -2147483640
         BackColor       =   -2147483643
         BorderStyle     =   1
         Appearance      =   1
         NumItems        =   1
         BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            Text            =   "Contact Groups"
            Object.Width           =   3528
         EndProperty
      End
      Begin VB.ComboBox cmbGrp 
         Height          =   360
         Left            =   6480
         Style           =   2  'Dropdown List
         TabIndex        =   5
         Top             =   1320
         Width           =   1455
      End
      Begin VB.TextBox txtColumn 
         Height          =   360
         Index           =   3
         Left            =   4440
         TabIndex        =   3
         Top             =   360
         Width           =   3495
      End
      Begin VB.TextBox txtColumn 
         Height          =   360
         Index           =   6
         Left            =   9120
         TabIndex        =   7
         Top             =   1320
         Width           =   855
      End
      Begin VB.TextBox txtColumn 
         Height          =   840
         Index           =   5
         Left            =   9120
         MultiLine       =   -1  'True
         TabIndex        =   6
         Top             =   360
         Width           =   3015
      End
      Begin VB.TextBox txtColumn 
         Height          =   360
         Index           =   4
         Left            =   4440
         TabIndex        =   4
         Top             =   840
         Width           =   1695
      End
      Begin VB.TextBox txtColumn 
         Height          =   360
         Index           =   2
         Left            =   1440
         TabIndex        =   2
         Top             =   1320
         Width           =   1695
      End
      Begin VB.TextBox txtColumn 
         Height          =   360
         Index           =   1
         Left            =   1440
         TabIndex        =   1
         Top             =   840
         Width           =   1695
      End
      Begin VB.TextBox txtColumn 
         Height          =   360
         Index           =   0
         Left            =   1440
         TabIndex        =   0
         Top             =   360
         Width           =   1695
      End
      Begin VB.Label lblColumn 
         AutoSize        =   -1  'True
         Caption         =   "City"
         Height          =   240
         Index           =   7
         Left            =   10200
         TabIndex        =   22
         Top             =   1380
         Width           =   315
      End
      Begin VB.Label lblColumn 
         Caption         =   "Group"
         Height          =   255
         Index           =   9
         Left            =   6960
         TabIndex        =   21
         Tag             =   "900"
         Top             =   1020
         Width           =   735
      End
      Begin VB.Label lblColumn 
         AutoSize        =   -1  'True
         Caption         =   "Birthday"
         Height          =   240
         Index           =   8
         Left            =   3600
         TabIndex        =   20
         Tag             =   "1125"
         Top             =   1380
         Width           =   690
      End
      Begin VB.Label lblColumn 
         AutoSize        =   -1  'True
         Caption         =   "Email"
         Height          =   240
         Index           =   3
         Left            =   3600
         TabIndex        =   19
         Tag             =   "2400"
         Top             =   420
         Width           =   465
      End
      Begin VB.Label lblColumn 
         AutoSize        =   -1  'True
         Caption         =   "Pin Code"
         Height          =   240
         Index           =   6
         Left            =   8280
         TabIndex        =   18
         Tag             =   "960"
         Top             =   1380
         Width           =   750
      End
      Begin VB.Label lblColumn 
         AutoSize        =   -1  'True
         Caption         =   "Address"
         Height          =   240
         Index           =   5
         Left            =   8280
         TabIndex        =   17
         Tag             =   "2500"
         Top             =   420
         Width           =   690
      End
      Begin VB.Label lblColumn 
         AutoSize        =   -1  'True
         Caption         =   "Phone"
         Height          =   240
         Index           =   4
         Left            =   3600
         TabIndex        =   16
         Tag             =   "1020"
         Top             =   900
         Width           =   525
      End
      Begin VB.Label lblColumn 
         AutoSize        =   -1  'True
         Caption         =   "Last Name"
         Height          =   240
         Index           =   2
         Left            =   240
         TabIndex        =   15
         Top             =   1380
         Width           =   900
      End
      Begin VB.Label lblColumn 
         AutoSize        =   -1  'True
         Caption         =   "Middle Name"
         Height          =   240
         Index           =   1
         Left            =   240
         TabIndex        =   14
         Top             =   900
         Width           =   1110
      End
      Begin VB.Label lblColumn 
         AutoSize        =   -1  'True
         Caption         =   "First Name"
         Height          =   240
         Index           =   0
         Left            =   240
         TabIndex        =   13
         Top             =   420
         Width           =   930
      End
   End
   Begin MSComctlLib.ListView lvwAdd 
      Height          =   3975
      Left            =   120
      TabIndex        =   10
      Top             =   2400
      Width           =   9255
      _ExtentX        =   16325
      _ExtentY        =   7011
      View            =   3
      LabelWrap       =   -1  'True
      HideSelection   =   -1  'True
      Checkboxes      =   -1  'True
      FullRowSelect   =   -1  'True
      _Version        =   393217
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      NumItems        =   0
   End
   Begin MSComctlLib.ListView lvwGrpAdd 
      Height          =   3975
      Left            =   120
      TabIndex        =   11
      Top             =   2400
      Visible         =   0   'False
      Width           =   10335
      _ExtentX        =   18230
      _ExtentY        =   7011
      View            =   3
      LabelWrap       =   -1  'True
      HideSelection   =   -1  'True
      Checkboxes      =   -1  'True
      FullRowSelect   =   -1  'True
      _Version        =   393217
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      NumItems        =   0
   End
   Begin VB.Menu mnuAB 
      Caption         =   "&Address Book"
      Begin VB.Menu mnuABLoad 
         Caption         =   "Load"
         Shortcut        =   ^L
      End
      Begin VB.Menu mnuABSave 
         Caption         =   "Save"
         Shortcut        =   ^S
      End
      Begin VB.Menu s1 
         Caption         =   "-"
      End
      Begin VB.Menu mnuClose 
         Caption         =   "Close"
      End
   End
   Begin VB.Menu menuGroups 
      Caption         =   "&Groups"
      Begin VB.Menu mnuGroup 
         Caption         =   "Add Group"
         Index           =   1
      End
      Begin VB.Menu mnuGroup 
         Caption         =   "Delete Group"
         Index           =   2
      End
   End
   Begin VB.Menu menuEntry 
      Caption         =   "&Entry"
      Begin VB.Menu mnuEntry 
         Caption         =   "Clear"
         Index           =   1
      End
      Begin VB.Menu mnuEntry 
         Caption         =   "Add"
         Index           =   2
      End
      Begin VB.Menu mnuEntry 
         Caption         =   "Update Changes"
         Index           =   3
      End
      Begin VB.Menu mnuEntry 
         Caption         =   "Delete"
         Index           =   4
      End
   End
   Begin VB.Menu menuOptions 
      Caption         =   "Options"
      Begin VB.Menu mnuCheck 
         Caption         =   "Check All"
         Index           =   1
      End
      Begin VB.Menu mnuCheck 
         Caption         =   "Invert Selection"
         Index           =   2
      End
      Begin VB.Menu so 
         Caption         =   "-"
      End
      Begin VB.Menu mnuGen 
         Caption         =   "Generate Mail list"
      End
   End
   Begin VB.Menu menuWin 
      Caption         =   "&Window"
      WindowList      =   -1  'True
      Begin VB.Menu mnuWinArrange 
         Caption         =   "Cascade"
         Index           =   0
      End
      Begin VB.Menu mnuWinArrange 
         Caption         =   "Horizontally"
         Index           =   1
      End
      Begin VB.Menu mnuWinArrange 
         Caption         =   "Vertically"
         Index           =   2
      End
   End
End
Attribute VB_Name = "frmAddress"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim itm As ListItem, fso As New FileSystemObject
Dim ts As TextStream, filAddy As File
Dim Editable As Boolean

Private Sub cmdDrop_Click()
If mView.Visible = False Then mView.Visible = True
End Sub

Private Sub Form_Load()
For Each Control In lblColumn
lvwAdd.ColumnHeaders.Add Control.Index + 1, Control.Caption, Control.Caption ': Debug.Print Control.Name
lvwGrpAdd.ColumnHeaders.Add Control.Index + 1, Control.Caption, Control.Caption ': Debug.Print Control.Name
If Control.Tag <> "" Then lvwAdd.ColumnHeaders(Control.Caption).Width = Val(Control.Tag): lvwGrpAdd.ColumnHeaders(Control.Caption).Width = Val(Control.Tag)
Next

loadAddressBook
'mView.Top = txtColumn(8).Top + txtColumn(8).Height

'load groups
lvwGrp.ListItems.Add , "All Groups", "All Groups"
For i = 1 To GetSetting(apComp, apProd, "Number of Groups", 1)
grp = GetSetting(apComp, apProd, "Group" & i, "Default")
cmbGrp.AddItem grp
lvwGrp.ListItems.Add , grp, grp
Next
lvwGrp.ListItems("All Groups").Checked = True
End Sub

Private Sub Form_Resize()
lvwAdd.Width = Me.ScaleWidth - 2 * lvwAdd.Left
fram.Width = lvwAdd.Width
'For Each Control In cmdOpt: Control.Left = fram.Width - Control.Width - 500: Next
lvwAdd.Height = Me.ScaleHeight - lvwAdd.Top - 120

lvwGrpAdd.Height = lvwAdd.Height
lvwGrpAdd.Width = lvwAdd.Width
End Sub

Private Sub saveAddressBook()
'On Error Resume Next
'Set filAddy = fso.CreateTextFile(App.Path & "\Address.txt", True)
Set fso = CreateObject("scripting.filesystemobject")
Set ts = fso.CreateTextFile("Address.txt", True)

For Each ListItem In lvwAdd.ListItems
ts.WriteLine "<start entry>"
With ListItem 'lvwAdd.ListItems(i) 'ListItem '
  ts.WriteLine "<" & lvwAdd.ColumnHeaders(1).Text & ">" & .Text & "</" & lvwAdd.ColumnHeaders(1).Text & ">"
  
  For i = 1 To lvwAdd.ColumnHeaders.Count - 1
    tg = lvwAdd.ColumnHeaders(i + 1).Text
    If .SubItems(i) <> "" Then
      'MsgBox .SubItems(i)
      If i < txtColumn.Count Then
        If txtColumn(i).MultiLine = True Then
          ts.WriteLine "<" & tg & ">"
          'ts.WriteBlankLines 1
          ts.Write .SubItems(i) & vbCrLf
          ts.WriteLine "</" & tg & ">"
        Else
          ts.WriteLine "<" & tg & ">" & .SubItems(i) & "</" & tg & ">"
        End If
      Else
        ts.WriteLine "<" & tg & ">" & .SubItems(i) & "</" & tg & ">"
      End If
    End If
  Next
End With

ts.WriteLine "<finish entry>"
ts.WriteBlankLines 1

Next

ts.Close
End Sub

Public Sub loadAddressBook()
Dim isItm As Boolean, strML As String

Set filAddy = fso.GetFile("Address.txt")
Set ts = filAddy.OpenAsTextStream

If ts.AtEndOfStream Then Else lvwAdd.ListItems.Clear

Do Until ts.AtEndOfStream
  
  Do Until ts.ReadLine = "<start entry>" Or ts.AtEndOfStream
  Loop
  
  isItm = False
  If ts.AtEndOfStream Then Else a = ts.ReadLine
  Do Until a = "<finish entry>" Or ts.AtEndOfStream
  
    If isItm Then
      ln = InStr(a, ">") - 2
      If Len(a) = ln + 2 Then
        strML = ""
        tg = Mid(a, 2, ln)
        a = ts.ReadLine
        Do Until a = "</" & tg & ">"
          strML = strML & a & vbCrLf
          a = ts.ReadLine
        Loop
        itm.SubItems(lvwAdd.ColumnHeaders(tg).Index - 1) = Mid(strML, 1, Len(strML) - 2)
      Else
      'MsgBox Mid(a, ln + 3, Len(a) - 2 * ln - 5)
      'MsgBox lvwAdd.ColumnHeaders(Mid(a, 2, ln)).Text
      itm.SubItems(lvwAdd.ColumnHeaders(Mid(a, 2, ln)).Index - 1) = Mid(a, ln + 3, Len(a) - 2 * ln - 5)
      End If
    Else
      If Mid(a, 2, Len(lvwAdd.ColumnHeaders(1).Text)) = lvwAdd.ColumnHeaders(1).Text Then Set itm = lvwAdd.ListItems.Add(, Mid(a, Len(lvwAdd.ColumnHeaders(1).Text) + 3, Len(a) - 2 * Len(lvwAdd.ColumnHeaders(1).Text) - 5), Mid(a, Len(lvwAdd.ColumnHeaders(1).Text) + 3, Len(a) - 2 * Len(lvwAdd.ColumnHeaders(1).Text) - 5)): isItm = True
    End If
    a = ts.ReadLine
  Loop
  
  isItm = False

Loop
End Sub

Private Sub Form_Unload(Cancel As Integer)
saveAddressBook
End Sub

Private Sub fram_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
If Button = 2 Then PopupMenu menuEntry
End Sub

Private Sub lvwAdd_ColumnClick(ByVal ColumnHeader As MSComctlLib.ColumnHeader)
lvwAdd.Sorted = True
If lvwAdd.SortKey = ColumnHeader.Index - 1 Then
If lvwAdd.SortOrder = lvwAscending Then lvwAdd.SortOrder = lvwDescending Else lvwAdd.SortOrder = lvwAscending
Else
lvwAdd.SortKey = ColumnHeader.Index - 1
lvwAdd.SortOrder = lvwAscending
End If
lvwAdd.Sorted = False
Debug.Print ColumnHeader.Text & " " & ColumnHeader.Width
End Sub

Private Sub lvwAdd_ItemClick(ByVal Item As MSComctlLib.ListItem)
'On Error GoTo Extt
txtColumn(0) = Item.Text

For i = 1 To lvwAdd.ColumnHeaders.Count - 1
  If lvwAdd.ListItems(Item.Index).SubItems(i) = "" Then
    If i < 8 Then txtColumn(i) = ""
  Else
    If i = 8 Then 'bday
      bDay.Value = lvwAdd.ListItems(Item.Index).SubItems(i)
    ElseIf i = 9 Then
      cmbGrp.ListIndex = 0
      For j = cmbGrp.ListCount To 1 Step -1
      If cmbGrp.List(j - 1) = lvwAdd.ListItems(Item.Index).SubItems(i) Then cmbGrp.ListIndex = j - 1: Exit For
      Next
    Else
      txtColumn(i) = lvwAdd.ListItems(Item.Index).SubItems(i)
    End If
  End If
Next
Editable = True
Extt:
End Sub

Private Sub lvwGrp_ItemCheck(ByVal Item As MSComctlLib.ListItem)
If lvwGrp.ListItems("All Groups").Checked Then lvwAdd.Visible = True: lvwGrpAdd.Visible = False: Exit Sub Else lvwAdd.Visible = False: lvwGrpAdd.Visible = True

lvwGrpAdd.ListItems.Clear
For Each ListItem In lvwAdd.ListItems
If lvwGrp.ListItems("All Groups").Checked Or lvwGrp.ListItems(ListItem.SubItems(9)).Checked Then
  Set itm = lvwGrpAdd.ListItems.Add(, ListItem.Key, ListItem.Text)
  For i = 1 To ListItem.ListSubItems.Count
    itm.SubItems(i) = ListItem.SubItems(i)
  Next
  'ListItem.Visible = True Else ListItem.Visible = False
End If
Next
End Sub

Private Sub lvwGrp_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
If Button = 2 Then PopupMenu menuGroups: Button = 0
End Sub

Private Sub mnuABLoad_Click()
loadAddressBook
End Sub

Private Sub mnuABSave_Click()
saveAddressBook
End Sub

Private Sub mnuCheck_Click(Index As Integer)
If Index = 1 Then mnuCheck(1).Checked = Not mnuCheck(1).Checked
Dim ctrl As Control
If lvwAdd.Visible Then Set ctrl = lvwAdd Else Set ctrl = lvwGrpAdd
For Each ListItem In ctrl.ListItems
If Index = 1 Then ListItem.Checked = mnuCheck(1).Checked Else ListItem.Checked = Not ListItem.Checked
Next
End Sub

Private Sub mnuClose_Click()
Unload Me
End Sub

Private Sub mnuEntry_Click(Index As Integer)
Select Case mnuEntry(Index).Caption

Case "Clear"
  For Each Control In Me
  'Debug.Print Control.Name
  If Mid(Control.Name, 1, 3) = "txt" Then Control.Text = ""
  Next
  Editable = False
Case "Add"
  Set itm = lvwAdd.ListItems.Add(, , txtColumn(0).Text)
  For i = 1 To lblColumn.Count - 1
    If i = 9 Then 'bday
      itm.SubItems(i) = cmbGrp.Text
    ElseIf i = 8 Then 'group
      itm.SubItems(i) = bDay.Value
    Else
      itm.SubItems(i) = txtColumn(i).Text
    End If
  Next
  Editable = True
Case "Delete"
  lvwAdd.ListItems.Remove (lvwAdd.SelectedItem.Index)
  Editable = False
Case "Update Changes"
  If Editable Then Else Exit Sub
  lvwAdd.SelectedItem.Text = txtColumn(0)
  'itm.Key = txtColumn(0)
  For i = 1 To lblColumn.Count - 1
    If i = 9 Then 'bday
      lvwAdd.SelectedItem.SubItems(i) = cmbGrp.Text
    ElseIf i = 8 Then 'group
      lvwAdd.SelectedItem.SubItems(i) = bDay.Value
    Else
      lvwAdd.SelectedItem.SubItems(i) = txtColumn(i).Text
    End If
  Next
End Select
End Sub

Private Sub mnuGen_Click()
lstaddys = ""
For Each ListItem In lvwAdd.ListItems
With ListItem 'lvwAdd.ListItems(i)
  If .Checked = True Then
    'MsgBox .SubItems(lvwAdd.ColumnHeaders("Email").Index - 1)
    If .SubItems(lvwAdd.ColumnHeaders("Email").Index - 1) <> "" Then lstaddys = lstaddys & .SubItems(lvwAdd.ColumnHeaders("Email").Index - 1) & ","
  End If
End With
Next
If Len(lstaddys) > 0 Then MsgBox Mid(lstaddys, 1, Len(lstaddys) - 1)
End Sub

Private Sub mnuGroup_Click(Index As Integer)
Select Case mnuGroup(Index).Caption
Case "Add Group"
  ip = InputBox("Enter Group Name", , "[group name]")
  If ip = "" Then Exit Sub
  SaveSetting apComp, apProd, "Number of Groups", Val(GetSetting(apComp, apProd, "Number of Groups", 1)) + 1
  SaveSetting apComp, apProd, "Group" & Val(GetSetting(apComp, apProd, "Number of Groups", 1)), ip
  cmbGrp.AddItem ip
  lvwGrp.ListItems.Add , ip, ip
Case "Delete Group"
  If lvwGrp.SelectedItem.Text = "All Groups" Or lvwGrp.SelectedItem.Text = "Default" Then MsgBox "This item cannot be deleted", vbInformation: Exit Sub
  'MsgBox "Will add code later"
  m = MsgBox("The group '" & lvwGrp.SelectedItem.Text & "' is about to be deleted." & vbCrLf & " Would you like to move its contacts to 'default'?" & vbCrLf & vbCrLf & "Yes - Moves contacts from '" & lvwGrp.SelectedItem.Text & "' to 'default'," & vbCrLf & "No - Allows them to be deleted," & vbCrLf & "Cancel - Cancels this operation", vbYesNoCancel + vbQuestion)
  If m = 2 Then Exit Sub
  If lvwAdd.ListItems.Count > 0 Then
  i = 1
    Do Until i > lvwAdd.ListItems.Count
    If lvwAdd.ListItems(i).SubItems(9) = lvwGrp.SelectedItem.Text Then
      If m = 6 Then lvwAdd.ListItems(i).SubItems(9) = "Default" Else lvwAdd.ListItems.Remove (i)
    End If
    i = i + 1
    Loop
  End If
  
  'remove the group from the combo box
  For i = 0 To cmbGrp.ListCount - 1
  If cmbGrp.List(i) = lvwGrp.SelectedItem.Text Then cmbGrp.RemoveItem (i): Exit For
  Next
  
  'save new groups in registry
  SaveSetting apComp, apProd, "Number of Groups", cmbGrp.ListCount
  For i = 1 To cmbGrp.ListCount
  SaveSetting apComp, apProd, "Group" & i, cmbGrp.List(i - 1)
  Next
  
  lvwGrp.ListItems.Remove (lvwGrp.SelectedItem.Index)
End Select
End Sub

Private Sub mnuWinArrange_Click(Index As Integer)
frmMDI.Arrange Index
End Sub

Private Sub mView_DateClick(ByVal DateClicked As Date)
txtColumn(8).Text = DateClicked
mView.Visible = False
End Sub
