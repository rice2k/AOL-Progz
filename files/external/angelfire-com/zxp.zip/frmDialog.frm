VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Object = "{FE0065C0-1B7B-11CF-9D53-00AA003C9CB6}#1.1#0"; "COMCT232.OCX"
Begin VB.Form frmDialog 
   BorderStyle     =   5  'Sizable ToolWindow
   Caption         =   "Moving"
   ClientHeight    =   4545
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   5970
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4545
   ScaleWidth      =   5970
   StartUpPosition =   2  'CenterScreen
   Begin ZXP.pBar pBar 
      Height          =   255
      Left            =   120
      TabIndex        =   8
      Top             =   3915
      Width           =   5715
      _ExtentX        =   10081
      _ExtentY        =   450
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Val             =   0
   End
   Begin MSComctlLib.ImageList iml 
      Left            =   3600
      Top             =   0
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   18
      ImageHeight     =   18
      MaskColor       =   16777215
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   4
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmDialog.frx":0000
            Key             =   ""
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmDialog.frx":03B0
            Key             =   ""
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmDialog.frx":076C
            Key             =   ""
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmDialog.frx":0B60
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin VB.CommandButton cmdUndo 
      Caption         =   "Undo"
      Height          =   300
      Left            =   4440
      TabIndex        =   6
      Top             =   457
      Width           =   975
   End
   Begin VB.CommandButton cmdClose 
      Caption         =   "Close"
      Enabled         =   0   'False
      Height          =   300
      Left            =   4440
      TabIndex        =   5
      Top             =   795
      Width           =   975
   End
   Begin VB.CommandButton cmdStop 
      Caption         =   "Stop"
      Default         =   -1  'True
      Height          =   300
      Left            =   4440
      TabIndex        =   4
      Top             =   120
      Width           =   975
   End
   Begin MSComctlLib.ListView lvw 
      Height          =   2055
      Left            =   3000
      TabIndex        =   3
      Top             =   1800
      Width           =   2895
      _ExtentX        =   5106
      _ExtentY        =   3625
      View            =   3
      LabelEdit       =   1
      LabelWrap       =   -1  'True
      HideSelection   =   0   'False
      HideColumnHeaders=   -1  'True
      _Version        =   393217
      SmallIcons      =   "iml"
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      NumItems        =   2
      BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         Text            =   "File Name"
         Object.Width           =   3175
      EndProperty
      BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   1
         Text            =   "Size"
         Object.Width           =   2117
      EndProperty
   End
   Begin MSComctlLib.TreeView tvw 
      Height          =   2055
      Left            =   120
      TabIndex        =   2
      Top             =   1800
      Width           =   2895
      _ExtentX        =   5106
      _ExtentY        =   3625
      _Version        =   393217
      HideSelection   =   0   'False
      Indentation     =   450
      LabelEdit       =   1
      Style           =   7
      ImageList       =   "iml"
      Appearance      =   1
   End
   Begin MSComctlLib.StatusBar stbr 
      Align           =   2  'Align Bottom
      Height          =   315
      Left            =   0
      TabIndex        =   1
      Top             =   4230
      Width           =   5970
      _ExtentX        =   10530
      _ExtentY        =   556
      _Version        =   393216
      BeginProperty Panels {8E3867A5-8586-11D1-B16A-00C0F0283628} 
         NumPanels       =   3
         BeginProperty Panel1 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   1
            Object.Width           =   8123
         EndProperty
         BeginProperty Panel2 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   2
            Object.Width           =   1138
            MinWidth        =   706
            Text            =   "Elapsed"
            TextSave        =   "Elapsed"
         EndProperty
         BeginProperty Panel3 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   2
            Object.Width           =   714
            MinWidth        =   706
            Text            =   "Estd"
            TextSave        =   "Estd"
         EndProperty
      EndProperty
   End
   Begin ComCtl2.Animation anm 
      Height          =   975
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   3975
      _ExtentX        =   7011
      _ExtentY        =   1720
      _Version        =   327681
      FullWidth       =   265
      FullHeight      =   65
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Height          =   195
      Left            =   120
      TabIndex        =   7
      Top             =   1290
      Width           =   45
   End
End
Attribute VB_Name = "frmDialog"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Type RECT
        Left As Long
        Top As Long
        Right As Long
        Bottom As Long
End Type

Private Declare Function ScrollWindow Lib "user32" (ByVal hWnd As Long _
  , ByVal XAmount As Long, ByVal YAmount As Long, _
  lpRect As RECT, lpClipRect As RECT) As Long

Dim nod As Node, Operation As Integer
Dim bStop As Boolean, tm As Date, fc As Long

Private Sub cmdClose_Click()
bStop = True
Unload Me
End Sub

Private Sub cmdStop_Click()
bStop = True
anm.Stop
cmdClose.Enabled = True
cmdClose.Default = True
End Sub

Private Sub Form_Load()
anm.Open App.Path & "\FILECOPY.AVI"
pBar.val = 0: pBar.Max = 1
End Sub

Public Sub LoadFil(str As String, pnt As Boolean)
On Error Resume Next
If fso.FileExists(str) Then
  Dim fil As File
  Set fil = fso.GetFile(str)
  tvw.Nodes.Add tvw, tvwChild, str, fil.Name, 3
  pBar.Max = pBar.Max + fil.Size / 1024
ElseIf fso.FolderExists(str) Then
  Dim fol As Folder, fldr As Folder
  Set fldr = fso.GetFolder(str)
  If pnt Then
    Set nod = tvw.Nodes.Add(, tvwChild, fldr.Path, fldr.Name, 1)
    pBar.Max = pBar.Max + fldr.Size / 1024
  Else
    Set nod = tvw.Nodes.Add(tvw.Nodes(fldr.ParentFolder.Path), tvwChild, fldr.Path, fldr.Name, 1)
  End If
  'nod.Expanded = True
  nod.Sorted = True
  For Each fol In fldr.SubFolders
    LoadFil fol.Path, False
  Next
End If
End Sub

Public Sub DoOperation()
Dim nod3 As Node
tm = Now(): fc = 0
anm.Play: bStop = False

Set nod3 = tvw.Nodes(1)
  nod3.Expanded = True
  CopyFiles nod3
  nod3.Expanded = False
Do Until nod3 = nod3.LastSibling
  Set nod3 = nod3.Next
  nod3.Expanded = True
  CopyFiles nod3
  If bStop Then Exit Do
  nod3.Expanded = False
Loop

anm.Stop
anm.Close

'Unload Me
'MsgBox "Process took " & Format(Now - tm, "hh:mm:ss") & " time to move/copy" & fc & " files."
tvw_NodeClick tvw.SelectedItem

If bStop Then lbl = "Copy Process Stopped" Else lbl = "Copy Process Complete. No Errors to report."

cmdClose.Enabled = True
cmdClose.Default = True
End Sub

Sub CopyFiles(nod As Node)

Dim fil As File, itm As ListItem
If fso.FileExists(nod.Key) Then
  Set fil = fso.GetFile(nod.Key)
  pBar.val = pBar.val + fil.Size / 1024
  nod.Selected = True
  'copy/move
  nod.Image = 4
ElseIf fso.FolderExists(nod.Key) Then
  Dim fol As Folder, nod2 As Node, fcc As Long
  Set fol = fso.GetFolder(nod.Key): fcc = fc
  'Static ox As Double, r As RECT, r2 As RECT
  'r.Left = 0: r.Right = lvw.ColumnHeaders(2).Left + lvw.ColumnHeaders(2).Width
  If nod.Children > 0 Then
    nod.Expanded = True
    Set nod2 = nod.Child
      CopyFiles nod2
      If bStop Then Exit Sub
    Do Until nod2 = nod.Child.LastSibling
      Set nod2 = nod2.Next
      CopyFiles nod2
      If bStop Then Exit Sub
    Loop
  End If
  stbr.Panels(1) = fol.Name & " " & StrSiz(fol.Size) & " " & fol.Files.Count & " files."
  lvw.ListItems.Clear
  nod.Selected = True
  
  'load files
  For Each fil In fol.Files
    Set itm = lvw.ListItems.Add(lvw.ListItems.Count + 1, fil.Path, fil.Name, , 4)
    itm.SubItems(1) = StrSiz(fil.Size)
    pBar.val = pBar.val + fil.Size / 1024 'MUST MOVE TO THE COPY PROCESS
  'then move/copy files
  'For Each itm In lvw.ListItems
    'Set fil = fso.GetFile(itm.Key)
    fc = fc + 1
    itm.Selected = True
    'stbr.Panels(2) = itm.Top
    'Sleep Rnd * 100
        'do actual copy/move here
        'do actual copy/move here
    'AutoScroll
    'If itm.Height * itm.Index > lvw.Height Then
      'r.Top = (itm.Index - 1) * itm.Height: r.Bottom = r.Top + itm.Height
      'ScrollWindow lvw.hWnd, itm.Top - ox, 0, r, r2
      'ox = itm.Top
    'End If
    lbl = "Copying " & itm.Text & vbCrLf & "From " & tvw.SelectedItem.Key
    stbr.Panels(2) = "  Elapsed: " & Format(Now - tm, "hh:mm:ss") & "  "
    DoEvents
    If bStop Then Exit Sub
  Next
nod.Tag = stbr.Panels(1) & "   rec files: " & fc - fcc
nod.Expanded = False
nod.Image = 2
End If
End Sub

Private Sub Form_Resize()
If Me.Height < tvw.Top + 1500 Then Me.Height = tvw.Top + 1500: Exit Sub
If Me.Width < 3000 Then Me.Width = 3000: Exit Sub

tvw.Width = 0.5 * (Me.ScaleWidth - 2 * tvw.Left)
lvw.Left = tvw.Left + tvw.Width
lvw.Width = Me.ScaleWidth - lvw.Left - tvw.Left
lvw.ColumnHeaders(1).Width = lvw.Width - lvw.ColumnHeaders(2).Width - 300

tvw.Height = Me.ScaleHeight - stbr.Height - tvw.Top - 2 * pBar.Height
lvw.Height = tvw.Height
pBar.Top = Me.ScaleHeight - stbr.Height - 1.5 * pBar.Height: pBar.Width = Me.ScaleWidth - 2 * pBar.Left
End Sub

Private Sub tvw_NodeClick(ByVal Node As MSComctlLib.Node)
stbr.Panels(1) = Node.Tag
End Sub
