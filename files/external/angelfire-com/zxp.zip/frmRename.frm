VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmRename 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Bulk Rename"
   ClientHeight    =   3465
   ClientLeft      =   45
   ClientTop       =   585
   ClientWidth     =   11220
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3465
   ScaleWidth      =   11220
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox pic 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   3405
      Left            =   25
      ScaleHeight     =   3375
      ScaleWidth      =   3255
      TabIndex        =   0
      Top             =   0
      Width           =   3285
      Begin VB.TextBox txtDig 
         Alignment       =   2  'Center
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   285
         Left            =   2640
         TabIndex        =   4
         Text            =   "3"
         Top             =   2745
         Width           =   495
      End
      Begin VB.PictureBox picSmall 
         Appearance      =   0  'Flat
         AutoRedraw      =   -1  'True
         AutoSize        =   -1  'True
         BorderStyle     =   0  'None
         ForeColor       =   &H80000008&
         Height          =   240
         Left            =   2880
         ScaleHeight     =   240
         ScaleWidth      =   240
         TabIndex        =   13
         TabStop         =   0   'False
         Top             =   2160
         Visible         =   0   'False
         Width           =   240
      End
      Begin VB.TextBox txtFN 
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   6
         Top             =   360
         Width           =   3015
      End
      Begin VB.CheckBox chkDig 
         Caption         =   "fixed Number of digits"
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   5
         Top             =   2760
         Value           =   1  'Checked
         Width           =   2535
      End
      Begin VB.CheckBox chkFile 
         Caption         =   "Lower Case for Filename"
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   3
         Tag             =   " for Filename"
         Top             =   840
         Width           =   2775
      End
      Begin VB.CheckBox chkFol 
         Caption         =   "Lower Case for Folder"
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   2
         Tag             =   " for Folder"
         Top             =   1680
         Width           =   2535
      End
      Begin VB.CheckBox chkDelete 
         Caption         =   "Retain Original Files"
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   120
         TabIndex        =   1
         Top             =   3120
         Width           =   2295
      End
      Begin MSComctlLib.ImageList icoSmall 
         Left            =   2640
         Top             =   1200
         _ExtentX        =   1005
         _ExtentY        =   1005
         BackColor       =   -2147483643
         ImageWidth      =   18
         ImageHeight     =   18
         MaskColor       =   12632256
         _Version        =   393216
         BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
            NumListImages   =   1
            BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "frmRename.frx":0000
               Key             =   "folder"
            EndProperty
         EndProperty
      End
      Begin VB.Label lbl 
         AutoSize        =   -1  'True
         Caption         =   "Enter rule for file renaming"
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   5
         Left            =   360
         TabIndex        =   14
         Top             =   120
         Width           =   2625
      End
      Begin VB.Label lbl 
         AutoSize        =   -1  'True
         Caption         =   "%1 - use Filename"
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   0
         Left            =   480
         TabIndex        =   11
         Top             =   1080
         Width           =   1845
      End
      Begin VB.Label lbl 
         AutoSize        =   -1  'True
         Caption         =   "%2 - use Filename.extn"
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   1
         Left            =   480
         TabIndex        =   10
         Top             =   1320
         Width           =   2355
      End
      Begin VB.Label lbl 
         AutoSize        =   -1  'True
         Caption         =   "%i - Number in array"
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   2
         Left            =   120
         TabIndex        =   9
         Top             =   2520
         Width           =   2055
      End
      Begin VB.Label lbl 
         AutoSize        =   -1  'True
         Caption         =   "%3 - use Folder Name"
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   3
         Left            =   480
         TabIndex        =   8
         Top             =   1920
         Width           =   2205
      End
      Begin VB.Label lbl 
         AutoSize        =   -1  'True
         Caption         =   "%4 - use Folder Path"
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   4
         Left            =   480
         TabIndex        =   7
         Top             =   2160
         Width           =   2115
      End
   End
   Begin MSComctlLib.ListView lvw 
      Height          =   3405
      Left            =   3360
      TabIndex        =   12
      Top             =   0
      Width           =   7815
      _ExtentX        =   13785
      _ExtentY        =   6006
      View            =   3
      Arrange         =   1
      LabelEdit       =   1
      MultiSelect     =   -1  'True
      LabelWrap       =   -1  'True
      HideSelection   =   0   'False
      OLEDropMode     =   1
      AllowReorder    =   -1  'True
      PictureAlignment=   5
      _Version        =   393217
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      Appearance      =   1
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      OLEDropMode     =   1
      NumItems        =   4
      BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         Key             =   "name"
         Text            =   "Old File Name"
         Object.Width           =   5292
      EndProperty
      BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   1
         Key             =   "size"
         Object.Tag             =   "bytes"
         Text            =   "Size"
         Object.Width           =   1764
      EndProperty
      BeginProperty ColumnHeader(3) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   2
         Key             =   "type"
         Text            =   "Type"
         Object.Width           =   2117
      EndProperty
      BeginProperty ColumnHeader(4) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   3
         Text            =   "New File Name"
         Object.Width           =   3704
      EndProperty
   End
   Begin VB.Menu menuLowUp 
      Caption         =   "L/U"
      Visible         =   0   'False
      Begin VB.Menu mnuCase 
         Caption         =   "Lower Case"
         Index           =   1
      End
      Begin VB.Menu mnuCase 
         Caption         =   "Upper Case"
         Index           =   2
      End
   End
   Begin VB.Menu menuRename 
      Caption         =   "Rename"
      Visible         =   0   'False
      Begin VB.Menu mnuShow 
         Caption         =   "Show"
         Shortcut        =   ^S
      End
      Begin VB.Menu mnuRename 
         Caption         =   "Rename"
         Shortcut        =   ^R
      End
   End
End
Attribute VB_Name = "frmRename"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim fldr As Folder, fil As File, chk As CheckBox

'File Copying and moving
Private Declare Function CopyFile Lib "kernel32" Alias "CopyFileA" (ByVal lpExistingFileName As String, ByVal lpNewFileName As String, ByVal bFailIfExists As Long) As Long
Private Declare Function MoveFile Lib "kernel32" Alias "MoveFileA" (ByVal lpExistingFileName As String, ByVal lpNewFileName As String) As Long


Private Sub chkDig_Click()
If chkDig.Value = 1 Then txtDig.Enabled = True Else txtDig.Enabled = False
End Sub

Private Sub chkFile_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
If Button = 2 Then Set chk = chkFile: PopupMenu menuLowUp
End Sub

Private Sub chkFol_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
If Button = 2 Then Set chk = chkFol: PopupMenu menuLowUp
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
If KeyCode = vbKeyInsert Then PopupMenu menuRename
If KeyCode = vbKeyEscape Then Unload Me
End Sub

Private Sub Form_Load()
Set lvw.SmallIcons = frmZXP.icoSmall
End Sub

Private Sub lvw_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
If Button = 2 Then PopupMenu menuRename
End Sub

Private Sub mnuCase_Click(Index As Integer)
  chk.Caption = mnuCase(Index).Caption & chk.Tag
End Sub

Private Sub lvw_KeyDown(KeyCode As Integer, Shift As Integer)
Dim r As Integer
If KeyCode = vbKeyF6 Then 'Down
  r = lvw.ListItems.Count - 1
  Do Until r = 0
    If lvw.ListItems(r).Selected = True And lvw.ListItems(r + 1).Selected = False Then
      Swap r, r + 1
      lvw.ListItems(r).Selected = False
      lvw.ListItems(r + 1).Selected = True
    End If
  r = r - 1
  Loop
ElseIf KeyCode = vbKeyF7 Then  'Up
  r = 2
  Do Until r > lvw.ListItems.Count
    If lvw.ListItems(r).Selected = True And lvw.ListItems(r - 1).Selected = False Then
      Swap r, r - 1
      lvw.ListItems(r).Selected = False
      lvw.ListItems(r - 1).Selected = True
    End If
  r = r + 1
  Loop
End If
End Sub

Sub Swap(j As Integer, k As Integer)
'maybe its possible to set virtual item and delete original & add at other side of one to be swapped with
If k = j Then Exit Sub
Dim i As Integer, tmp As String, tmpKey As String

'swap texts
tmp = lvw.ListItems(j).Text
lvw.ListItems(j).Text = lvw.ListItems(k).Text
lvw.ListItems(k).Text = tmp

'swap subitems
For i = 1 To lvw.ColumnHeaders.Count - 1
  tmp = lvw.ListItems(j).SubItems(i)
  lvw.ListItems(j).SubItems(i) = lvw.ListItems(k).SubItems(i)
  lvw.ListItems(k).SubItems(i) = tmp
Next i

'swap icons
tmp = lvw.ListItems(j).Icon: lvw.ListItems(j).Icon = lvw.ListItems(k).Icon: lvw.ListItems(k).Icon = tmp
tmp = lvw.ListItems(j).SmallIcon: lvw.ListItems(j).SmallIcon = lvw.ListItems(k).SmallIcon: lvw.ListItems(k).SmallIcon = tmp

'swap keys
tmp = lvw.ListItems(j).Key
  tmpKey = lvw.ListItems(k).Key: lvw.ListItems(k).Key = "temporary key"
lvw.ListItems(j).Key = tmpKey
lvw.ListItems(k).Key = tmp

End Sub


Private Sub lvw_OLEDragDrop(Data As MSComctlLib.DataObject, Effect As Long, Button As Integer, Shift As Integer, x As Single, y As Single)
  Dim extn As String

For i = 1 To Data.Files.Count
  If fso.FileExists(Data.Files(i)) Then
  Set fil = fso.GetFile(Data.Files(i))
  extn = fso.GetExtensionName(Data.Files(i))
  If extn = "ico" Or extn = "exe" Or extn = "lnk" Then extn = Data.Files(i)
  GetFilIcon fso.GetFile(fil), extn
  Set itm = lvw.ListItems.Add(, fil, fil.Name, , icoSmall.ListImages(extn).Index)
  itm.SubItems(1) = StrSiz(fil.Size)
  itm.SubItems(2) = fil.Type
  'itm.SubItems(3) = fil.DateCreated
  'itm.SubItems(4) = fil.DateLastModified
  ElseIf fso.FolderExists(Data.Files(i)) Then
    'Debug.Print
  End If
Next
End Sub

Private Sub mnuRename_Click()
For Each ListItem In lvw.ListItems
  Set fil = fso.GetFile(ListItem.Key)
  Set fldr = fil.ParentFolder
  If fldr.IsRootFolder Then fol = fldr Else fol = fldr & "\"
    'Set fil = fso.GetFile(fol & ListItem.Text)
    'fil.Copy fol & ListItem.SubItems(3), True
    If chkDelete.Value = 1 Then
      CopyFile ListItem.Key, fol & ListItem.SubItems(3), False
    Else
      MoveFile ListItem.Key, fol & ListItem.SubItems(3)
    End If
  'addFile fso.GetFile(fol & ListItem.SubItems(3)), lvw
  
  'If chkDelete.Value = 0 Then fil.Delete True: lvw.ListItems.Remove (ListItem.Key)
Next
lvw.ListItems.Clear
frmZXP.lvwLoad frmZXP.tvw.SelectedItem.Key

Me.Hide
frmZXP.SetFocus

End Sub

Private Sub mnuShow_Click()
'this was used to get files for DiaryPad
'For Each ListItem In lvw.ListItems
'  ListItem.SubItems(3) = DateAdd("d", ListItem.Index, Date) & ".enc"
'Next
'Exit Sub


Dim Pos As Integer, nam As String
For Each ListItem In lvw.ListItems
Pos = 1: nam = ""
'txtFN = "an.mpg.%i"
Do Until Pos > Len(txtFN)

  If Mid(txtFN, Pos, 1) = "%" Then
    Pos = Pos + 1
    If Mid(txtFN, Pos, 1) = "2" Then
      nwe = ListItem.Text
      
      If chkFile.Value = 1 Then
        If Mid(chkFile.Caption, 1, 5) = "Lower" Then nwe = LCase(nwe) Else nwe = UCase(nwe)
      End If
      nam = nam & nwe

    ElseIf Mid(txtFN, Pos, 1) = "1" Then
      ext = fso.GetExtensionName(ListItem.Key)
      nwe = ListItem.Text 'name without extension
      If ext <> "" Then nwe = Mid(nwe, 1, Len(ListItem.Text) - Len(ext) - 1)
      
      If chkFile.Value = 1 Then
        If Mid(chkFile.Caption, 1, 5) = "Lower" Then nwe = LCase(nwe) Else nwe = UCase(nwe)
      End If
      nam = nam & nwe

    ElseIf Mid(txtFN, Pos, 1) = "3" Then
      Set fil = fso.GetFile(lvw.ListItems(1).Key)
      fol = fil.ParentFolder.Name
      If chkFol.Value = 1 Then
        If Mid(chkFol.Caption, 1, 5) = "Lower" Then fol = LCase(fol) Else fol = UCase(fol)
      End If
      nam = nam & fol
      
    ElseIf Mid(txtFN, Pos, 1) = "4" Then
      Set fldr = fso.GetFolder(CStr(tvw.SelectedFolder))
      fol = fldr.Path
      
      If chkFol.Value = 1 Then
        If Mid(chkFol.Caption, 1, 5) = "Lower" Then fol = LCase(fol) Else fol = UCase(fol)
      End If
      nam = nam & fol
      
    ElseIf Mid(txtFN, Pos, 1) = "i" Then
      i = ListItem.Index
      If chkDig.Value = 1 Then
        Do Until Len(i) = val(txtDig)
        If Len(i) < val(txtDig) Then i = "0" & i Else i = Mid(i, 2)
        Loop
      End If
      
      nam = nam & i
    End If
  Else
    nam = nam & Mid(txtFN, Pos, 1)
  End If
  Pos = Pos + 1
Loop

ListItem.SubItems(3) = nam

Next
End Sub

Private Sub GetFilIcon(IFile As File, extn As String)
  extn = LCase(extn)
  If extn = "ico" Or extn = "exe" Or extn = "lnk" Then extn = IFile.Path
  If IsNumeric(extn) Then extn = "Numeric" & extn
  'If IsMissing(icoSmall.ListImages(extn)) = False Then Exit Sub
  For i = 1 To icoSmall.ListImages.Count
  If icoSmall.ListImages(i).Key = extn Then Exit Sub
  Next
  
  Dim hImgSmall As Long ', hImgLarge As Long     ' The handle to the system image list

  ' Get the system icons associated with the file
  hImgSmall& = SHGetFileInfo(IFile, 0&, shinfo, Len(shinfo), BASIC_SHGFI_FLAGS Or &H1)
  'hImgLarge& = SHGetFileInfo(IFile, 0&, shinfo, Len(shinfo), BASIC_SHGFI_FLAGS Or &H0)

  ' clear the pictureboxes before receiving the icons.
  picSmall.Picture = LoadPicture():    'picLarge.Picture = LoadPicture()

  ' Draw the associated icons into the picture boxes
  ImageList_Draw hImgSmall&, shinfo.iIcon, picSmall.hdc, 0, 0, &H1
  'ImageList_Draw hImgLarge&, shinfo.iIcon, picLarge.hdc, 0, 0, &H1

  icoSmall.ListImages.Add icoSmall.ListImages.Count + 1, extn, picSmall.Image
  'icoLarge.ListImages.Add icoLarge.ListImages.Count + 1, extn, picLarge.Image
End Sub

