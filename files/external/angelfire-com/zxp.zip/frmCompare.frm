VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmCompare 
   Caption         =   "Compare Folders"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   BeginProperty Font 
      Name            =   "Verdana"
      Size            =   9.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmCompare.frx":0000
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   WindowState     =   2  'Maximized
   Begin VB.TextBox txt 
      Height          =   375
      Index           =   2
      Left            =   6360
      TabIndex        =   7
      Top             =   120
      Width           =   3495
   End
   Begin VB.TextBox txt 
      Height          =   375
      Index           =   1
      Left            =   120
      TabIndex        =   6
      Top             =   120
      Width           =   3495
   End
   Begin MSComctlLib.StatusBar stbr 
      Align           =   2  'Align Bottom
      Height          =   315
      Left            =   0
      TabIndex        =   5
      Top             =   2880
      Width           =   4680
      _ExtentX        =   8255
      _ExtentY        =   556
      _Version        =   393216
      BeginProperty Panels {8E3867A5-8586-11D1-B16A-00C0F0283628} 
         NumPanels       =   2
         BeginProperty Panel1 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   1
            Object.Width           =   3863
         EndProperty
         BeginProperty Panel2 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   1
            Object.Width           =   3863
         EndProperty
      EndProperty
   End
   Begin VB.PictureBox picLarge 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   704
      Left            =   11280
      ScaleHeight     =   705
      ScaleWidth      =   705
      TabIndex        =   4
      TabStop         =   0   'False
      Top             =   480
      Visible         =   0   'False
      Width           =   704
   End
   Begin VB.PictureBox picSmall 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   240
      Left            =   11280
      ScaleHeight     =   240
      ScaleWidth      =   240
      TabIndex        =   3
      TabStop         =   0   'False
      Top             =   120
      Visible         =   0   'False
      Width           =   240
   End
   Begin VB.CommandButton cmd 
      Caption         =   "..."
      Height          =   255
      Index           =   2
      Left            =   10320
      TabIndex        =   2
      Top             =   240
      Width           =   495
   End
   Begin VB.CommandButton cmd 
      Caption         =   "..."
      Height          =   255
      Index           =   1
      Left            =   4440
      TabIndex        =   1
      Top             =   240
      Width           =   495
   End
   Begin MSComctlLib.ListView lvw 
      Height          =   8415
      Left            =   120
      TabIndex        =   0
      Top             =   600
      Width           =   4935
      _ExtentX        =   8705
      _ExtentY        =   14843
      View            =   3
      LabelEdit       =   1
      LabelWrap       =   -1  'True
      HideSelection   =   0   'False
      FullRowSelect   =   -1  'True
      GridLines       =   -1  'True
      _Version        =   393217
      Icons           =   "icoLarge"
      SmallIcons      =   "icoSmall"
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      NumItems        =   10
      BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         Text            =   "FileName"
         Object.Width           =   2540
      EndProperty
      BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   1
         Text            =   "RelativePath"
         Object.Width           =   3881
      EndProperty
      BeginProperty ColumnHeader(3) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   2
         Text            =   "Size1"
         Object.Width           =   1764
      EndProperty
      BeginProperty ColumnHeader(4) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   3
         Text            =   "DateCreated1"
         Object.Width           =   3528
      EndProperty
      BeginProperty ColumnHeader(5) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   4
         Text            =   "DateModified1"
         Object.Width           =   3528
      EndProperty
      BeginProperty ColumnHeader(6) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   5
         Text            =   "Size2"
         Object.Width           =   1764
      EndProperty
      BeginProperty ColumnHeader(7) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   6
         Text            =   "DateCreated2"
         Object.Width           =   3528
      EndProperty
      BeginProperty ColumnHeader(8) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   7
         Text            =   "DateModified2"
         Object.Width           =   3528
      EndProperty
      BeginProperty ColumnHeader(9) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   8
         Text            =   "Bytes1"
         Object.Width           =   0
      EndProperty
      BeginProperty ColumnHeader(10) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   9
         Text            =   "Bytes2"
         Object.Width           =   0
      EndProperty
   End
   Begin MSComctlLib.ImageList icoSmall 
      Left            =   5520
      Top             =   120
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   18
      ImageHeight     =   18
      MaskColor       =   12632256
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   1
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmCompare.frx":0CCA
            Key             =   "folder"
         EndProperty
      EndProperty
   End
   Begin MSComctlLib.ImageList icoLarge 
      Left            =   5160
      Top             =   120
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   18
      ImageHeight     =   18
      MaskColor       =   16777215
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   1
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmCompare.frx":107A
            Key             =   "folder"
         EndProperty
      EndProperty
   End
End
Attribute VB_Name = "frmCompare"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim fldr As Folder, fol(2) As String, indIn As Integer, indTo As Integer, iStart(2) As Integer
Dim itm As ListItem, nFil As File, extnn As String
Dim tSiz(2) As Long, tFil(2) As Integer, tFol(2) As Integer

'icon loading declares
Private Const BASIC_SHGFI_FLAGS = &H400 _
   Or &H4 Or &H4000 _
   Or &H200 Or &H2000

Private Type SHFILEINFO
    hIcon As Long
    iIcon As Long
    dwAttributes As Long
    szDisplayName As String * 260
    szTypeName As String * 80
End Type

Private Declare Function SHGetFileInfo Lib "shell32.dll" Alias "SHGetFileInfoA" _
   (ByVal pszPath As String, _
    ByVal dwFileAttributes As Long, _
    psfi As SHFILEINFO, _
    ByVal cbSizeFileInfo As Long, _
    ByVal uFlags As Long) As Long

Private Declare Function ImageList_Draw Lib "comctl32.dll" _
   (ByVal himl&, ByVal i&, ByVal hDCDest&, _
    ByVal x&, ByVal y&, ByVal Flags&) As Long

Private shinfo As SHFILEINFO

Private Sub cmd_Click(Index As Integer)
  fl = ShowFolder(Me, "Choose folder " & Index & " to compare.", GetSetting(App.CompanyName, App.ProductName, "folder", App.Path))
  If fso.FolderExists(fl) = True Then
    Set fldr = fso.GetFolder(fl):
    If fldr.IsRootFolder Then fol(Index) = fldr.Path Else fol(Index) = fldr.Path & "\"
    txt(Index) = fol(Index)
    SaveSetting App.CompanyName, App.ProductName, "folder", fol(Index)
  End If
End Sub

Private Sub Form_DblClick()
On Error Resume Next
tSiz(1) = 0: tSiz(2) = 0
tFil(1) = 0: tFil(2) = 0
tFol(1) = 0: tFol(2) = 0
lvw.ListItems.Clear

If fso.FolderExists(txt(1)) = True Then
  indIn = 1: indTo = 2: iStart(1) = Len(fol(1)) + 1
    MatchFiles fso.GetFolder(fol(1))
  stbr.Panels(1).Text = tFil(1) & " file(s) in " & tFol(1) & " folder(s). Tot:" & StrSiz(tSiz(1)) & " Avg:" & StrSiz(tSiz(1) / tFil(1))
End If

If fso.FolderExists(txt(2)) = True Then
  indIn = 2: indTo = 1: iStart(2) = Len(fol(2)) + 1
    MatchFiles fso.GetFolder(fol(2))
  stbr.Panels(2).Text = tFil(2) & " file(s) in " & tFol(2) & " folders. Tot:" & StrSiz(tSiz(1)) & " Avg:" & StrSiz(tSiz(2) / tFil(2))
End If
End Sub

Private Sub Form_Resize()
lvw.Width = Me.ScaleWidth - 2 * lvw.Left

lvw.Height = Me.ScaleHeight - lvw.Top - lvw.Left - stbr.Height
txt(1).Width = lvw.Width / 2 - 0.5 * lvw.Left - 1.5 * cmd(1).Width: txt(2).Width = txt(1).Width
txt(2).Left = (Me.ScaleWidth + lvw.Left) * 0.5

lft = (Me.ScaleWidth - 1.5 * lvw.Left) / 2 - cmd(1).Width
cmd(1).Left = lft
cmd(2).Left = Me.ScaleWidth / 2 + lft
End Sub



Public Sub MatchFiles(fldr As Folder)
On Error Resume Next
tFol(indIn) = tFol(indIn) + 1
  For Each fil In fldr.Files
'if we need to compare sizes etc, it would be good idea to use itm(2)
  tFil(indIn) = tFil(indIn) + 1
  tSiz(indIn) = tSiz(indIn) + fil.Size
  
  'our cheap way to see if item already exists
  If lvwIn.ListItems(LCase(RelPath(fil.Path, indIn))).Key <> "" Then GoTo gDo
  GoTo Nxt
      
gDo:
      extnn = LCase(fso.GetExtensionName(fil.Path))
      If extnn <> "" Then
        GetFilIcon fil, extnn
        Set itm = lvw.ListItems.Add(, LCase(RelPath(fil.Path, indIn)), fil.Name, icoLarge.ListImages(extnn).Index, icoSmall.ListImages(extnn).Index)
        itm.SubItems(1) = RelPath(fil.Path, indIn)
        
        If fso.FileExists(fol(1) & itm.Key) Then
          Set nFil = fso.GetFile(fol(indIn) & itm.Key)
            itm.SubItems(2) = StrSiz(nFil.Size)
              itm.SubItems(8) = nFil.Size
            itm.SubItems(3) = doDate(nFil.DateCreated)
            itm.SubItems(4) = doDate(nFil.DateLastModified)
        Else
          itm.SubItems(8) = "0"
        End If
        
        If fso.FileExists(fol(2) & itm.Key) Then
          Set nFil = fso.GetFile(fol(indTo) & itm.Key)
            itm.SubItems(5) = StrSiz(nFil.Size)
              itm.SubItems(9) = nFil.Size
            itm.SubItems(6) = doDate(nFil.DateCreated)
            itm.SubItems(7) = doDate(nFil.DateLastModified)
        Else
          itm.SubItems(9) = "0"
        End If
      End If
Nxt:
  Next

Dim foldr As Folder
For Each foldr In fldr.SubFolders
  MatchFiles foldr
Next
End Sub



Function RelPath(fl As String, Index As Integer) As String
  RelPath = Mid(fl, iStart(Index)) ', Len(fl) - iStart(Index) - Len(fso.GetFileName(fl)) + 1)
End Function


Private Sub GetFilIcon(IFile As File, extn As String)
  extn = LCase(extn)
  If extn = "ico" Or extn = "exe" Or extn = "lnk" Then extn = IFile.Path
  If IsNumeric(extn) Then extn = "Numeric" & extn
  'If IsMissing(icoSmall.ListImages(extn)) = False Then Exit Sub
  For i = 1 To icoSmall.ListImages.Count
  If icoSmall.ListImages(i).Key = extn Then Exit Sub
  Next
  
  Dim hImgSmall As Long, hImgLarge As Long     ' The handle to the system image list

  ' Get the system icons associated with the file
  hImgSmall& = SHGetFileInfo(IFile, 0&, shinfo, Len(shinfo), BASIC_SHGFI_FLAGS Or &H1)
  hImgLarge& = SHGetFileInfo(IFile, 0&, shinfo, Len(shinfo), BASIC_SHGFI_FLAGS Or &H0)

  ' clear the pictureboxes before receiving the icons.
  picSmall.Picture = LoadPicture():    picLarge.Picture = LoadPicture()

  ' Draw the associated icons into the picture boxes
  ImageList_Draw hImgSmall&, shinfo.iIcon, picSmall.hdc, 0, 0, &H1
  ImageList_Draw hImgLarge&, shinfo.iIcon, picLarge.hdc, 0, 0, &H1

  icoSmall.ListImages.Add icoSmall.ListImages.Count + 1, extn, picSmall.Image
  icoLarge.ListImages.Add icoLarge.ListImages.Count + 1, extn, picLarge.Image
End Sub

Private Function StrSiz(Siz As Long)
If Siz >= 1048576 Then StrSiz = Int(Siz / 10485.76) / 100 & "MB": Exit Function
If Siz >= 1024 Then StrSiz = Int(Siz / 10.24) / 100 & "KB": Exit Function
StrSiz = Siz & "b"
End Function

Function doDate(MDat As Date) As String
doDate = Format(MDat, "d mmm yy") & " " & Format(MDat, "H:mm")
End Function

Private Sub lvw_ColumnClick(ByVal ColumnHeader As MSComctlLib.ColumnHeader)
Dim Order As Integer, sType As Integer
Static lastSorted As Integer, lastAsc As Boolean
If lastSorted = ColumnHeader.Index And lastAsc = False Then Order = 4: lastAsc = True Else Order = 3: lastAsc = False

If ColumnHeader.Index = 1 Or ColumnHeader.Index = 2 Then
  sType = 0 'Name
ElseIf ColumnHeader.Index = 3 Or ColumnHeader.Index = 6 Then
  sType = 1 'Size
Else
  sType = 2 'Dates
End If

If ColumnHeader.Index = 3 Then
  SortColumn lvw, 9, sType, Order
ElseIf ColumnHeader.Index = 6 Then
  SortColumn lvw, 10, sType, Order
Else
  SortColumn lvw, ColumnHeader.Index, sType, Order
End If

lastSorted = ColumnHeader.Index

End Sub
