VERSION 5.00
Begin VB.UserControl pBar 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00808080&
   ClientHeight    =   405
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   7155
   ScaleHeight     =   405
   ScaleWidth      =   7155
   Begin VB.PictureBox picVal 
      BackColor       =   &H008080FF&
      BorderStyle     =   0  'None
      Height          =   375
      Left            =   0
      ScaleHeight     =   375
      ScaleWidth      =   1335
      TabIndex        =   0
      Top             =   0
      Width           =   1335
      Begin VB.Label lbl 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "100"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   930
         TabIndex        =   1
         Top             =   120
         Width           =   270
      End
   End
End
Attribute VB_Name = "pBar"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
'Default Property Values:
Const m_def_Resolution = 1
Const m_def_Max = 100
Const m_def_Val = 50
'Property Variables:
Dim m_Resolution As Byte
Dim m_Max As Double
Dim m_Val As Double

Private Sub picVal_Resize()
If lbl.Height > picVal.Height Then lbl.Top = 0 Else lbl.Top = (picVal.Height - lbl.Height) / 2
lbl.Left = picVal.Width - lbl.Width
End Sub

'Initialize Properties for User Control
Private Sub UserControl_InitProperties()
  m_Max = m_def_Max
  m_Val = m_def_Val
  m_Resolution = m_def_Resolution
End Sub

'Load property values from storage
Private Sub UserControl_ReadProperties(PropBag As PropertyBag)
  Set lbl.Font = PropBag.ReadProperty("Font", Ambient.Font)
  m_Max = PropBag.ReadProperty("Max", m_def_Max)
  m_Val = PropBag.ReadProperty("Val", m_def_Val)
  m_Resolution = PropBag.ReadProperty("Resolution", m_def_Resolution)
  Refresh
End Sub

Private Sub UserControl_Resize()
picVal.Visible = False
picVal.Width = UserControl.Width
picVal.Height = UserControl.Height
Refresh
picVal.Visible = True
End Sub

'Write property values to storage
Private Sub UserControl_WriteProperties(PropBag As PropertyBag)

  Call PropBag.WriteProperty("Font", lbl.Font, Ambient.Font)
  Call PropBag.WriteProperty("Max", m_Max, m_def_Max)
  Call PropBag.WriteProperty("Val", m_Val, m_def_Val)
  Call PropBag.WriteProperty("Resolution", m_Resolution, m_def_Resolution)
End Sub

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=lbl,lbl,-1,Font
Public Property Get Font() As Font
Attribute Font.VB_Description = "Returns a Font object."
Attribute Font.VB_UserMemId = -512
  Set Font = lbl.Font
End Property

Public Property Set Font(ByVal New_Font As Font)
  Set lbl.Font = New_Font
  PropertyChanged "Font"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=5
Public Sub Refresh()
Attribute Refresh.VB_Description = "Forces a complete repaint of a object."
If m_Max <= 0 Then m_Max = 1
frac = m_Val / m_Max
If frac >= 1 Then frac = 1
picVal.Width = frac * UserControl.Width
lbl.Caption = Round(frac * 100 * 10 ^ m_Resolution) / (10 ^ m_Resolution) & "%"
picVal_Resize
Edn:
End Sub

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=7,0,0,100
Public Property Get Max() As Double
Attribute Max.VB_Description = "Maximum Value"
  Max = m_Max
End Property

Public Property Let Max(ByVal New_Max As Double)
  If New_Max <= 0 Then New_Max = 1
  m_Max = New_Max
  PropertyChanged "Max"
  Refresh
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=7,0,0,50
Public Property Get val() As Double
  val = m_Val
End Property

Public Property Let val(ByVal New_Val As Double)
  m_Val = New_Val
  PropertyChanged "Val"
  Refresh
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=lbl,lbl,-1,ForeColor
Public Property Get ColText() As OLE_COLOR
Attribute ColText.VB_Description = "Returns/sets the foreground color used to display text and graphics in an object."
  ColText = lbl.ForeColor
End Property

Public Property Let ColText(ByVal New_ColText As OLE_COLOR)
  lbl.ForeColor() = New_ColText
  PropertyChanged "ColText"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=UserControl,UserControl,-1,BackColor
Public Property Get ColMax() As OLE_COLOR
Attribute ColMax.VB_Description = "Returns/sets the background color used to display text and graphics in an object."
  ColMax = UserControl.BackColor
End Property

Public Property Let ColMax(ByVal New_ColMax As OLE_COLOR)
  UserControl.BackColor() = New_ColMax
  PropertyChanged "ColMax"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MappingInfo=picVal,picVal,-1,BackColor
Public Property Get ColVal() As OLE_COLOR
Attribute ColVal.VB_Description = "Returns/sets the background color used to display text and graphics in an object."
  ColVal = picVal.BackColor
End Property

Public Property Let ColVal(ByVal New_ColVal As OLE_COLOR)
  picVal.BackColor() = New_ColVal
  PropertyChanged "ColVal"
End Property

'WARNING! DO NOT REMOVE OR MODIFY THE FOLLOWING COMMENTED LINES!
'MemberInfo=1,0,0,1
Public Property Get Resolution() As Byte
Attribute Resolution.VB_Description = "Number of zeroes after the ."
  Resolution = m_Resolution
End Property

Public Property Let Resolution(ByVal New_Resolution As Byte)
  m_Resolution = New_Resolution
  PropertyChanged "Resolution"
  Refresh
End Property

