Attribute VB_Name = "modZXP"
'This code is copyrighted and has' limited warranties.Please see http://w
'     ww.Planet-Source-Code.com/xq/ASP/txtCode
'     Id.29483/lngWId.1/qx/vb/scripts/ShowCode
'     .htm'for details.'**************************************

Public Const sortAlphanumeric = 0
Public Const sortNumeric = 1
Public Const sortDate = 2
Public Const sortAscending = 3
Public Const sortDescending = 4


'icon loading declares
Public Const BASIC_SHGFI_FLAGS = &H400 _
   Or &H4 Or &H4000 _
   Or &H200 Or &H2000

Public Type SHFILEINFO
    hIcon As Long
    iIcon As Long
    dwAttributes As Long
    szDisplayName As String * 260
    szTypeName As String * 80
End Type

Public Declare Function SHGetFileInfo Lib "shell32.dll" Alias "SHGetFileInfoA" _
   (ByVal pszPath As String, _
    ByVal dwFileAttributes As Long, _
    psfi As SHFILEINFO, _
    ByVal cbSizeFileInfo As Long, _
    ByVal uFlags As Long) As Long

Public Declare Function ImageList_Draw Lib "comctl32.dll" _
   (ByVal himl&, ByVal i&, ByVal hDCDest&, _
    ByVal x&, ByVal y&, ByVal Flags&) As Long

Public shinfo As SHFILEINFO

'Regular Program Variables
Public apComp As String, apProd As String, fso As New FileSystemObject
Public fil As File, ts As TextStream, DBFol As Folder

Public Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Public tFils As Double, tFols As Double

Public Function StrSiz(Siz As Long)
If Siz > 1073741824 Then StrSiz = Int(Siz / 10737418.24) / 100 & "GB": Exit Function
If Siz >= 1048576 Then StrSiz = Int(Siz / 10485.76) / 100 & "MB": Exit Function
If Siz >= 1024 Then StrSiz = Int(Siz / 10.24) / 100 & "KB": Exit Function
StrSiz = Siz & "b"
End Function


Public Sub doTotals(fol As Folder)
tFils = tFils + fol.Files.Count

Dim fld As Folder
For Each fld In fol.SubFolders
  tFols = tFols + 1
  doTotals fld
Next
End Sub














Private Sub DoSort(ByVal lvw As MSComctlLib.ListView, SortOrder As Integer, SortKey As Integer)
    If SortOrder = sortAscending Then
        lvw.SortOrder = lvwAscending
    ElseIf SortOrder = sortDescending Then
        lvw.SortOrder = lvwDescending
    End If
    lvw.SortKey = SortKey
    lvw.Sorted = True
End Sub




Public Sub SortColumn(ByVal lvw As MSComctlLib.ListView, ColumnIndex As Integer, SortType As Integer, SortOrder As Integer)
    Dim x As Integer, y As Integer
    
Select Case SortType
        
'*** Alphanumeric sort
Case sortAlphanumeric
  DoSort lvw, SortOrder, ColumnIndex - 1
            
'*** Numeric Sort
Case sortNumeric
  Dim strMax As String, strNew As String
            
    'Find the longest (whole) number string length in the column

    If ColumnIndex > 1 Then
        For x = 1 To lvw.ListItems.Count
            If Len(lvw.ListItems(x).SubItems(ColumnIndex - 1)) <> 0 Then 'ignores 0 length strings
                If Len(CStr(Int(lvw.ListItems(x).SubItems(ColumnIndex - 1)))) > Len(strMax) Then
                    strMax = CStr(Int(lvw.ListItems(x).SubItems(ColumnIndex - 1)))
                End If
            End If
        Next
    Else
        For x = 1 To lvw.ListItems.Count
            If Len(lvw.ListItems(x)) <> 0 Then
                If Len(CStr(Int(lvw.ListItems(x)))) > Len(strMax) Then
                    strMax = CStr(Int(lvw.ListItems(x)))
                End If
            End If
        Next
    End If
            
      'hide the control - speeds up the sort
      lvw.Visible = False
            
    If ColumnIndex > 1 Then
        For x = 1 To lvw.ListItems.Count
            If Len(lvw.ListItems(x).SubItems(ColumnIndex - 1)) = 0 Then
                lvw.ListItems(x).SubItems(ColumnIndex - 1) = "0" 'make 0 length strings = To "0"
            ElseIf Len(CStr(Int(lvw.ListItems(x).SubItems(ColumnIndex - 1)))) < Len(strMax) Then
                'prefix all numbers with 0's as required
                strNew = lvw.ListItems(x).ListSubItems(ColumnIndex - 1)

                For y = 1 To Len(strMax) - Len(CStr(Int(lvw.ListItems(x).SubItems(ColumnIndex - 1))))
                    strNew = "0" & strNew
                Next
                lvw.ListItems(x).ListSubItems(ColumnIndex - 1) = strNew
            End If
        Next
    Else
        For x = 1 To lvw.ListItems.Count


            If Len(lvw.ListItems(x).Text) = 0 Then
                lvw.ListItems(x).Text = "0" 'make 0 length strings = To "0"
            ElseIf Len(CStr(Int(lvw.ListItems(x)))) < Len(strMax) Then
                'prefix all numbers with 0's as required
                
                strNew = lvw.ListItems(x).Text


                For y = 1 To Len(strMax) - Len(CStr(Int(lvw.ListItems(x))))
                    strNew = "0" & strNew
                Next
                lvw.ListItems(x).Text = strNew
            End If
        Next
    End If
            
                DoSort lvw, SortOrder, ColumnIndex - 1
                
    If ColumnIndex > 1 Then
        'Remove preceding 0's
        For x = 1 To lvw.ListItems.Count
            lvw.ListItems(x).ListSubItems(ColumnIndex - 1) = CDbl(lvw.ListItems(x).ListSubItems(ColumnIndex - 1))
            If lvw.ListItems(x).ListSubItems(ColumnIndex - 1) = 0 Then lvw.ListItems(x).ListSubItems(ColumnIndex - 1) = ""
        Next
    Else
        'Remove preceding 0's
        For x = 1 To lvw.ListItems.Count
            lvw.ListItems(x).Text = CDbl(lvw.ListItems(x).Text)
            If lvw.ListItems(x).Text = 0 Then lvw.ListItems(x).Text = ""
        Next
    End If
    lvw.Visible = True
                
'*** Date Sort
Case sortDate
    lvw.Visible = False

    If ColumnIndex > 1 Then
        'Convert dates to format that can be sorted alphanumerically
        For x = 1 To lvw.ListItems.Count
            lvw.ListItems(x).ListSubItems(ColumnIndex - 1) = Format(lvw.ListItems(x).ListSubItems(ColumnIndex - 1), "YYYY MM DD hh:mm:ss")
        Next

        DoSort lvw, SortOrder, ColumnIndex - 1

        'Convert dates back to General Date format
        For x = 1 To lvw.ListItems.Count
            lvw.ListItems(x).ListSubItems(ColumnIndex - 1) = Format(lvw.ListItems(x).ListSubItems(ColumnIndex - 1), "General Date")
        Next
    Else
        'Convert dates to format that can be sorted alphanumerically
        For x = 1 To lvw.ListItems.Count
            lvw.ListItems(x).Text = Format(lvw.ListItems(x).Text, "YYYY MM DD hh:mm:ss")
        Next
            
        DoSort lvw, SortOrder, ColumnIndex - 1
                
        'Convert dates back to General Date format
        For x = 1 To lvw.ListItems.Count
            lvw.ListItems(x).Text = Format(lvw.ListItems(x).Text, "General Date")
        Next
                
    End If
            
    lvw.Visible = True

End Select

End Sub
