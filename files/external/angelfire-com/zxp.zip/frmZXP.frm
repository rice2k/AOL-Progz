VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmZXP 
   Caption         =   "ZXP"
   ClientHeight    =   7935
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   10470
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   9.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmZXP.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   7935
   ScaleWidth      =   10470
   WindowState     =   2  'Maximized
   Begin MSComctlLib.StatusBar stbr 
      Align           =   2  'Align Bottom
      Height          =   270
      Left            =   0
      TabIndex        =   7
      Top             =   7665
      Width           =   10470
      _ExtentX        =   18468
      _ExtentY        =   476
      _Version        =   393216
      BeginProperty Panels {8E3867A5-8586-11D1-B16A-00C0F0283628} 
         NumPanels       =   2
         BeginProperty Panel1 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            Alignment       =   1
            AutoSize        =   1
            Object.Width           =   8969
         EndProperty
         BeginProperty Panel2 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            Alignment       =   1
            AutoSize        =   1
            Object.Width           =   8969
         EndProperty
      EndProperty
   End
   Begin VB.ListBox lstFols 
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   780
      Left            =   6960
      Sorted          =   -1  'True
      TabIndex        =   5
      Top             =   3360
      Visible         =   0   'False
      Width           =   2535
   End
   Begin VB.PictureBox vlin 
      AutoRedraw      =   -1  'True
      BorderStyle     =   0  'None
      DrawStyle       =   5  'Transparent
      FillColor       =   &H00008000&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   6105
      Left            =   3840
      MousePointer    =   9  'Size W E
      ScaleHeight     =   6105
      ScaleWidth      =   60
      TabIndex        =   1
      TabStop         =   0   'False
      Top             =   0
      Width           =   60
   End
   Begin VB.PictureBox picSmall 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   240
      Left            =   7800
      ScaleHeight     =   240
      ScaleWidth      =   240
      TabIndex        =   3
      TabStop         =   0   'False
      Top             =   2160
      Visible         =   0   'False
      Width           =   240
   End
   Begin VB.PictureBox picLarge 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00C0C0C0&
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   704
      Left            =   7800
      ScaleHeight     =   705
      ScaleWidth      =   705
      TabIndex        =   2
      TabStop         =   0   'False
      Top             =   1080
      Visible         =   0   'False
      Width           =   704
   End
   Begin MSComctlLib.ListView lvw 
      Height          =   1485
      Left            =   4920
      TabIndex        =   0
      Top             =   400
      Width           =   1815
      _ExtentX        =   3201
      _ExtentY        =   2619
      View            =   3
      Arrange         =   1
      LabelEdit       =   1
      MultiSelect     =   -1  'True
      LabelWrap       =   -1  'True
      HideSelection   =   0   'False
      AllowReorder    =   -1  'True
      PictureAlignment=   5
      _Version        =   393217
      Icons           =   "icoLarge"
      SmallIcons      =   "icoSmall"
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      Appearance      =   1
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      NumItems        =   8
      BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         Key             =   "name"
         Text            =   "File Name"
         Object.Width           =   5292
      EndProperty
      BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   1
         Key             =   "size"
         Object.Tag             =   "bytes"
         Text            =   "Size"
         Object.Width           =   1764
      EndProperty
      BeginProperty ColumnHeader(3) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   2
         Key             =   "type"
         Text            =   "Type"
         Object.Width           =   2117
      EndProperty
      BeginProperty ColumnHeader(4) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   3
         Text            =   "Created"
         Object.Width           =   3704
      EndProperty
      BeginProperty ColumnHeader(5) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   4
         Text            =   "Modified"
         Object.Width           =   3704
      EndProperty
      BeginProperty ColumnHeader(6) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   5
         Text            =   "Fldrs"
         Object.Width           =   1411
      EndProperty
      BeginProperty ColumnHeader(7) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   6
         Text            =   "Files"
         Object.Width           =   1411
      EndProperty
      BeginProperty ColumnHeader(8) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   7
         Text            =   "Bytes"
         Object.Width           =   0
      EndProperty
   End
   Begin MSComctlLib.ImageCombo ICmb 
      Height          =   375
      Left            =   4920
      TabIndex        =   4
      Top             =   0
      Width           =   3615
      _ExtentX        =   6376
      _ExtentY        =   661
      _Version        =   393216
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Locked          =   -1  'True
      Text            =   "ImageCombo1"
      ImageList       =   "imTvw"
   End
   Begin MSComctlLib.TreeView tvw 
      Height          =   1695
      Left            =   0
      TabIndex        =   6
      Top             =   0
      Width           =   3375
      _ExtentX        =   5953
      _ExtentY        =   2990
      _Version        =   393217
      HideSelection   =   0   'False
      Indentation     =   450
      LabelEdit       =   1
      LineStyle       =   1
      Sorted          =   -1  'True
      Style           =   7
      FullRowSelect   =   -1  'True
      HotTracking     =   -1  'True
      ImageList       =   "imTvw"
      BorderStyle     =   1
      Appearance      =   1
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      OLEDragMode     =   1
      OLEDropMode     =   1
   End
   Begin MSComctlLib.ImageList imTvw 
      Left            =   4200
      Top             =   0
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   20
      ImageHeight     =   20
      MaskColor       =   16777215
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   10
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmZXP.frx":08CA
            Key             =   ""
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmZXP.frx":0D1E
            Key             =   ""
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmZXP.frx":1172
            Key             =   ""
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmZXP.frx":15C6
            Key             =   ""
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmZXP.frx":1A1A
            Key             =   "current"
         EndProperty
         BeginProperty ListImage6 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmZXP.frx":1DCA
            Key             =   "folder"
         EndProperty
         BeginProperty ListImage7 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmZXP.frx":217A
            Key             =   "mycomp"
         EndProperty
         BeginProperty ListImage8 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmZXP.frx":25CE
            Key             =   "miss"
         EndProperty
         BeginProperty ListImage9 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmZXP.frx":2996
            Key             =   ""
         EndProperty
         BeginProperty ListImage10 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmZXP.frx":3272
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin MSComctlLib.ImageList icoSmall 
      Left            =   4200
      Top             =   1560
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   12632256
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   3
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmZXP.frx":3F4E
            Key             =   "IVYnotfile"
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmZXP.frx":4302
            Key             =   "folder"
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmZXP.frx":46B2
            Key             =   "IVYnofile"
         EndProperty
      EndProperty
   End
   Begin MSComctlLib.ImageList icoLarge 
      Left            =   4200
      Top             =   960
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   32
      ImageHeight     =   32
      MaskColor       =   12632256
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   3
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmZXP.frx":4A5A
            Key             =   "IVYnotfile"
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmZXP.frx":4EDE
            Key             =   "folder"
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmZXP.frx":528E
            Key             =   "IVYnofile"
         EndProperty
      EndProperty
   End
   Begin VB.Menu menuOptions 
      Caption         =   "&Options"
      Begin VB.Menu mnuCompare 
         Caption         =   "Compare &Folders"
         Shortcut        =   ^F
      End
      Begin VB.Menu mnuMoveCopy 
         Caption         =   "Move/Copy &Dialog"
         Shortcut        =   ^D
      End
      Begin VB.Menu mnuRenameAdd 
         Caption         =   "Rename Files"
         Shortcut        =   ^{F2}
      End
      Begin VB.Menu sf 
         Caption         =   "-"
      End
      Begin VB.Menu mnuExit 
         Caption         =   "E&xit"
         Shortcut        =   ^Q
      End
   End
   Begin VB.Menu menuFileList 
      Caption         =   "File &List"
      NegotiatePosition=   2  'Middle
      Begin VB.Menu lvwVW 
         Caption         =   "&View"
         Begin VB.Menu lvwView 
            Caption         =   "Large &Icons"
            Index           =   0
            Shortcut        =   +{F1}
         End
         Begin VB.Menu lvwView 
            Caption         =   "S&mall Icons"
            Index           =   1
            Shortcut        =   +{F2}
         End
         Begin VB.Menu lvwView 
            Caption         =   "&List"
            Index           =   2
            Shortcut        =   +{F3}
         End
         Begin VB.Menu lvwView 
            Caption         =   "&Details"
            Checked         =   -1  'True
            Index           =   3
            Shortcut        =   +{F4}
         End
      End
      Begin VB.Menu mnuArrangeIcons 
         Caption         =   "Arrange &Icons"
         Begin VB.Menu mnuArrange 
            Caption         =   "by Name"
            Index           =   0
         End
         Begin VB.Menu mnuArrange 
            Caption         =   "by Size"
            Index           =   1
         End
         Begin VB.Menu mnuArrange 
            Caption         =   "by Type"
            Index           =   2
         End
         Begin VB.Menu mnuArrange 
            Caption         =   "by Folder"
            Index           =   3
         End
         Begin VB.Menu mnuArrange 
            Caption         =   "by Time"
            Index           =   4
         End
      End
      Begin VB.Menu mnuViewFolderTotals 
         Caption         =   "Show Folder Totals"
      End
   End
End
Attribute VB_Name = "frmZXP"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim fso As New FileSystemObject
Dim itm As ListItem, fldr As Folder  'are to avoid declaring many times used only with local scope
Dim vMoving As Boolean, hhmoving As Boolean, bDrag As Boolean 'hMoving As Boolean,
Dim drgDrop As Boolean, clk1 As Boolean

Private Sub Form_Load()

ICmb.ComboItems.Clear

Dim drv As Drive
For Each Drive In fso.Drives
  If Drive.IsReady Then nam = Drive.VolumeName Else nam = ""
  ICmb.ComboItems.Add , Drive.DriveLetter & ":\", nam & " (" & Drive.DriveLetter & ":" & ")", imTvw.ListImages(Drive.DriveType).Index, imTvw.ListImages(Drive.DriveType).Index, 1
Next

Tvw_Refresh

End Sub

Private Sub Form_Resize()
On Error Resume Next
If Me.WindowState = vbMinimized Then Exit Sub
If Me.ScaleWidth < vlin.Left + 1000 Then Me.ScaleWidth = vlin.Left + 1000
  ICmb.Width = lvw.Width
tvw.Height = Me.ScaleHeight - stbr.Height
  vlin.Height = tvw.Height
lvw.Height = tvw.Height - lvw.Top
Vsiz
End Sub

Private Sub Form_Unload(Cancel As Integer)
  End
End Sub

Private Sub ICmb_Click()
If ICmb.SelectedItem.Tag <> "Expanded" Then _
  SubFol_load fso.GetFolder(ICmb.SelectedItem.Key), ICmb.SelectedItem.Indentation + 1, ICmb.SelectedItem.Index + 1: _
  ICmb.SelectedItem.Tag = "Expanded"

tvw_OpenPath ICmb.SelectedItem.Key
'lvwLoad tvw.SelectedFolder
End Sub

Sub SubFol_load(fldr As Folder, inden As Integer, indx As Integer)
i = indx

lstFols.Clear
For Each Folder In fldr.SubFolders
  lstFols.AddItem Folder.Path
Next

For j = 0 To lstFols.ListCount - 1
  ICmb.ComboItems.Add i, lstFols.List(j), StrReverse(Mid(StrReverse(lstFols.List(j)), 1, 1 + InStr(StrReverse(lstFols.List(j)), "\") - 2)), 6, 5, inden
  i = i + 1
Next
End Sub

Private Sub lvw_ColumnClick(ByVal ColumnHeader As MSComctlLib.ColumnHeader)
Dim Order As Integer, sType As Integer
Static lastSorted As Integer, lastAsc As Boolean
If lastSorted = ColumnHeader.Index And lastAsc = False Then Order = 4: lastAsc = True Else Order = 3: lastAsc = False

If ColumnHeader.Index = 1 Then
  sType = 0 'Name
ElseIf ColumnHeader.Index = 2 Or ColumnHeader.Index = 6 Or ColumnHeader.Index = 7 Or ColumnHeader.Index > 8 Then
  sType = 1 'Numeric
Else
  sType = 2 'Dates
End If

If ColumnHeader.Index = 2 Then
  SortColumn lvw, 8, sType, Order
Else
  SortColumn lvw, ColumnHeader.Index, sType, Order
End If

lastSorted = ColumnHeader.Index
lvw.Sorted = False
End Sub

Private Sub lvw_DblClick()
If lvw.SelectedItem.SubItems(2) = "File Folder" Then
'open folder
  Set fldr = fso.GetFolder(lvw.SelectedItem.Key)
  lvw.ListItems.Clear
  For Each File In fldr.Files
    Set itm = lvw.ListItems.Add(, File.Name, File.Name)
    itm.SubItems(1) = StrSiz(File.Size)
    'itm.Tag = File.Size
  Next
  
  tvw_OpenPath fldr.Path
End If
End Sub

Private Sub lvw_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
If Button = 2 Then PopupMenu menuFileList 'menuVault
End Sub

Private Sub mnuCompare_Click()
frmCompare.Show
End Sub

Private Sub mnuExit_Click()
End
End Sub

Private Sub mnuMoveCopy_Click()
'LoadFil "d:\imufol\vb\iviewer", True
frmDialog.Show
frmDialog.lbl = "Preparing To Copy"

Dim itm As ListItem, tm As Single
'tm = Timer()
For Each itm In lvw.ListItems
  If itm.Selected Then frmDialog.LoadFil itm.Key, True
Next
frmDialog.lbl = "Prepared in " & Timer() - tm
'Unload frmDialog
frmDialog.DoOperation
End Sub

Private Sub mnuRenameAdd_Click()
'On Error GoTo Exitt
Load frmRename

Dim itm As ListItem, lItm As ListItem

For Each lItm In lvw.ListItems
  If lItm.Selected = False Or lItm.SubItems(2) = "File Folder" Then GoTo Lop
  
  Set itm = frmRename.lvw.ListItems.Add(, lItm.Key, lItm.Text, , lItm.SmallIcon)
  itm.SubItems(1) = lItm.SubItems(1)
  itm.SubItems(2) = lItm.SubItems(2)
Lop:
Next
Exitt:

If frmRename.lvw.ListItems.Count > 0 Then
  frmRename.Show
  frmRename.txtFN.SetFocus
Else
  Unload frmRename
End If

End Sub


Private Sub mnuViewFolderTotals_Click()
mnuViewFolderTotals.Checked = Not mnuViewFolderTotals.Checked

If mnuViewFolderTotals.Checked Then 'Add Columns
  lvw.ColumnHeaders.Add lvw.ColumnHeaders.Count + 1, "T Fols", "T Fols", 400
  lvw.ColumnHeaders.Add lvw.ColumnHeaders.Count + 1, "T Fils", "T Fils", 400
  lvwLoad tvw.SelectedItem.Key
Else 'Remove columns
  lvw.ColumnHeaders.Remove lvw.ColumnHeaders("T Fols").Index
  lvw.ColumnHeaders.Remove lvw.ColumnHeaders("T Fils").Index
End If

End Sub

Private Sub tvw_Expand(ByVal Node As MSComctlLib.Node)
If Node.Key = "mycomp" Or Mid(Node.Key, 1, 1) = "#" Then Exit Sub
tvw_Load fso.GetFolder(Node.Key), Node
End Sub
Private Sub tvw_Load(fldr As Folder, Node As MSComctlLib.Node)
If Node.Tag = "expanded" Then Exit Sub
If Node.Children > 0 Then tvw.Nodes.Remove (fldr.Path & " ")
Node.Sorted = True
  For Each Folder In fldr.SubFolders
  If LCase(Folder.Name) = "recycled" Then GoTo Lop
  tvw.Nodes.Add Node, tvwChild, Folder.Path, Folder.Name, "folder", "current"
  tvw.Nodes(Folder.Path).Sorted = True
  If Folder.SubFolders.Count > 0 Then tvw.Nodes.Add tvw.Nodes(Folder.Path), tvwChild, Folder.Path & " "
Lop:
  Next
Node.Tag = "expanded"
End Sub
Private Sub Tvw_Refresh()
tvw.Nodes.Clear: 'cmbHistory.ComboItems.Clear

tvw.Nodes.Add , 4, "mycomp", "My Computer", 7


For Each Drive In fso.Drives
  tvw.Nodes.Add "mycomp", tvwChild, Drive.DriveLetter & ":\", Drive.DriveLetter & ":", imTvw.ListImages(Drive.DriveType).Index
  
  If Drive.DriveType = Fixed Then
    If Drive.IsReady Then
      Set fldr = fso.GetFolder(CStr(Drive.Path) & "\")
      If fldr.SubFolders.Count > 1 Then tvw.Nodes.Add fldr.Path, tvwChild, fldr.Path & " "
    End If
  End If
Next

tvw_OpenPath "D:\"
lvwLoad "D:\"

tvw.Nodes.Add , , "#Session1", "Session1", 9
'If fso.FolderExists(cmbHistory.Text) Then lstfols.Path = cmbHistory.Text Else SetHistoryFolder FileList.Path
End Sub

Private Sub tvw_KeyUp(KeyCode As Integer, Shift As Integer)

'If tvw.SelectedItem.FullPath = lstFols.Path Then Exit Sub
If fso.DriveExists(tvw.SelectedItem.Key) = True Then
  'If fso.Drives(tvw.SelectedItem.FullPath).IsReady = True Then _
    lstFols.Path = tvw.SelectedItem.FullPath & "\"
Else
  'lstFols.Path = tvw.SelectedItem.FullPath
End If
lvwLoad tvw.SelectedItem.Key
End Sub

Private Sub tvw_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
bDrag = True
End Sub

Private Sub tvw_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
bDrag = False
End Sub

Private Sub tvw_NodeClick(ByVal Node As MSComctlLib.Node)
'NOT WORKING TOO PROEPRLY CHECK BEFORE FINALISING
If Node.Key = "mycomp" Or Mid(Node.Key, 1, 1) = "#" Then Exit Sub

Me.MousePointer = vbHourglass
If fso.DriveExists(Node.Key) Then
  Do
  If fso.Drives(Node.Key).IsReady = True Then Exit Do
    m = MsgBox("The Drive is not ready", vbRetryCancel + vbCritical)
    If m = vbCancel Then Exit Sub
  Loop
ElseIf fso.FolderExists(Node.Key) = False Then
  tvw.Nodes.Remove (Node.Index)
  Exit Sub
End If
Set fldr = fso.GetFolder(Node.Key)
If Node.Tag <> "expanded" Then
  tvw_Load fldr, Node
  'tvw.Nodes(Node.Index).Expanded = True
Else
Dim nod As Node

'first clear a sub folder if it doesnt exist
  If Node.Children <> 0 Then
  Set nod = tvw.Nodes(Node.Child.Key)
    Do
      On Local Error GoTo Lop
      If fso.FolderExists(Node.Key) = False Then
        If nod.LastSibling = nod Then tvw.Nodes.Remove (nod.Index): GoTo Lop Else tvw.Nodes.Remove (nod.Index)
      End If
      If nod.LastSibling = nod Then Exit Do Else Set nod = tvw.Nodes(nod.Next.Key)
    Loop
Lop:
  End If
  
  On Local Error GoTo Serr:
  'now go folder by folder & see if u get an error then add new node coz itll error
  'only if there aint no subnode which is only if the folder hasnt already been added
  If fldr.SubFolders.Count > 0 Then
    For Each Folder In fldr.SubFolders
      If fldr.IsRootFolder And Folder.Name = "Recycled" Then
      Else: If tvw.Nodes(Folder.Path).Text = "" Then GoTo Serr
      End If
SerrRet:
    Next
  End If
End If

If fso.DriveExists(tvw.SelectedItem.Key) = True Then
  If fso.Drives(tvw.SelectedItem.Key).IsReady = True Then lvwLoad tvw.SelectedItem.Key
Else
  lvwLoad tvw.SelectedItem.Key
End If

Me.MousePointer = vbDefault
Exit Sub

Serr:
  tvw.Nodes.Add Node, tvwChild, Folder.Path, Folder.Name, "folder", "current"
  If Folder.SubFolders.Count > 1 Then tvw.Nodes.Add Folder.Path, tvwChild, Folder.Path & " "
  GoTo SerrRet:
End Sub

Private Sub tvw_OpenPath(nodPath As String)
On Error Resume Next
If fso.FolderExists(nodPath) Then Set fldr = fso.GetFolder(nodPath) Else Exit Sub
If fldr.IsRootFolder Then tvw.Nodes(fldr.Path).Selected = True: Exit Sub

If tvw.Nodes(fldr.Drive & "\").Expanded = False Then tvw_Load fso.GetFolder(UCase(fldr.Drive) & "\"), tvw.Nodes(UCase(fldr.Drive) & "\")

tvw.Nodes(UCase(fldr.Drive) & "\").Expanded = True

For i = 4 To Len(nodPath)
  If Mid(nodPath, i, 1) = "\" Then
    If tvw.Nodes(Mid(nodPath, 1, i - 1)).Expanded = False Then
      tvw_Load fso.GetFolder(Mid(nodPath, 1, i)), tvw.Nodes(Mid(nodPath, 1, i - 1))
SrtRet:
      tvw.Nodes(Mid(nodPath, 1, i - 1)).Expanded = True
    End If
  End If
Next

tvw_Load fso.GetFolder(nodPath), tvw.Nodes(nodPath)
'tvw.Nodes(nodPath).Expanded = True
tvw.Nodes(nodPath).Selected = True

Exit Sub
SorTrr:
  MsgBox Err.Number & " " & Err.Description, vbCritical
  GoTo SrtRet:
End Sub

Private Sub tvw_OLEDragDrop(Data As MSComctlLib.DataObject, Effect As Long, Button As Integer, Shift As Integer, x As Single, y As Single)
If fso.FolderExists(tvw.SelectedItem.Key) Then
  Dim fl As Folder, str As String
  Set fl = fso.GetFolder(tvw.SelectedItem.Key)
  If fl.IsRootFolder Then str = fl.Drive.DriveLetter Else str = fl.Name
  On Error Resume Next
  tvw.Nodes.Add "#Session1", 4, "#" & str, str & ".flc", 10
End If
End Sub

'Private Sub tvw_SelectionChange(Folder As ccrpfoldertv6.Folder, PreChange As Boolean, Cancel As Boolean)
'If Me.Tag <> Folder Then lvwLoad Folder
'Me.Tag = Folder
'Me.Caption = "ZXP " & Folder.FullPath
'End Sub

Private Sub vlin_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
vlin.BackColor = &H80000010: vMoving = True
End Sub
Private Sub vlin_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
Dim vpos As Single
If vMoving Then
  vpos = x + vlin.Left
  If vpos > Me.Width / 2 Then vpos = Me.Width / 2
  If vpos < 1000 Then vpos = 1000
  vlin.Left = vpos
End If
End Sub
Private Sub vlin_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
vlin.BackColor = &H8000000F: vMoving = False
Vsiz
End Sub

Sub Vsiz()
tvw.Width = vlin.Left
lvw.Left = vlin.Left + vlin.Width
  lvw.Width = Me.ScaleWidth - lvw.Left
ICmb.Left = lvw.Left
  ICmb.Width = lvw.Width
End Sub

Public Sub lvwLoad(spFol As String)
On Error Resume Next

lvw.ListItems.Clear
If fso.FolderExists(spFol) = False Then Exit Sub 'True Then GoTo Nxt

Dim fol As Folder, fil As File, foldr As Folder, drv As Drive
Set foldr = fso.GetFolder(spFol)
If fso.DriveExists(foldr) Then
  Set drv = fso.GetDrive(foldr)
  stbr.Panels(1) = "Used: " & StrSiz(drv.TotalSize - drv.AvailableSpace) & " Free: " & StrSiz(drv.FreeSpace) & " (Usage: " & Format((drv.TotalSize - drv.FreeSpace) / drv.TotalSize * 100, "###.##") & "% Total: " & StrSiz(drv.TotalSize) & ") Files: " & foldr.Files.Count & "  Fols: " & foldr.SubFolders.Count
Else
  If foldr.IsRootFolder Then lvw.Tag = foldr Else lvw.Tag = foldr & "\"
  stbr.Panels(1) = "Size: " & StrSiz(foldr.Size) & "  Files: " & foldr.Files.Count & "  Fols: " & foldr.SubFolders.Count
End If

If mnuViewFolderTotals.Checked Then
  tFils = 0: tFols = 0
  doTotals foldr
  stbr.Panels(1) = stbr.Panels(1) & "  T Fils: " & tFils & "  T Fols: " & tFols
End If

For Each fol In foldr.SubFolders

Set itm = lvw.ListItems.Add(, fol.Path, fol.Name, 2, 2)
itm.SubItems(1) = StrSiz(fol.Size)
itm.SubItems(2) = "File Folder"
'If fol.Attributes = Directory Then
  itm.SubItems(3) = fol.DateCreated
  itm.SubItems(4) = fol.DateLastModified
'End If
itm.SubItems(5) = fol.SubFolders.Count
itm.SubItems(6) = fol.Files.Count
itm.SubItems(7) = fol.Size
If mnuViewFolderTotals.Checked Then
  tFils = 0: tFols = 0
  doTotals fol
  itm.SubItems(8) = tFols
  itm.SubItems(9) = tFils
End If

Next

'getting the names in listview

  Dim extn As String

For Each fil In foldr.Files  ' i = 0 To File.ListCount - 1
  
  
  'If extn = "ico" Or extn = "exe" Or extn = "lnk" Then extn = fol & ListItem.SubItems(3)
  extn = GetFilIcon(fil.Path)
  Set itm = lvw.ListItems.Add(, fil, fil.Name, icoLarge.ListImages(extn).Index, icoSmall.ListImages(extn).Index)
  itm.SubItems(1) = StrSiz(fil.Size)
  itm.SubItems(2) = fil.Type
  itm.SubItems(3) = fil.DateCreated
  itm.SubItems(4) = fil.DateLastModified
  itm.SubItems(7) = fil.Size
Next

'MsgBox lvw.ListItems.Count
If lvw.ListItems.Count > 0 Then lvw.ListItems(1).Selected = False
lvw.Refresh
End Sub

Public Function GetFilIcon(strFile As String) As String
  Dim extn As String
  'get valid icon key
  If fso.FileExists(strFile) = False Then GetFilIcon = "IVYnotfile": Exit Function
  extn = LCase(fso.GetExtensionName(strFile))
    'if no extn, return default
    If extn = "" Then GetFilIcon = "IVYnofile": Exit Function
  If extn = "ico" Or extn = "exe" Or extn = "lnk" Then extn = LCase(strFile)
  If IsNumeric(extn) Then extn = "Numeric" & extn
  'check if already exists
  Dim i As Integer
  For i = 1 To icoSmall.ListImages.Count
  If icoSmall.ListImages(i).Key = extn Then GetFilIcon = extn: Exit Function
  Next
  
  Dim hImgSmall As Long, hImgLarge As Long     ' The handle to the system image list

  ' Get the system icons associated with the file
  hImgSmall& = SHGetFileInfo(strFile, 0&, shinfo, Len(shinfo), BASIC_SHGFI_FLAGS Or &H1)
  hImgLarge& = SHGetFileInfo(strFile, 0&, shinfo, Len(shinfo), BASIC_SHGFI_FLAGS Or &H0)

  ' clear the pictureboxes before receiving the icons.
  picSmall.Picture = LoadPicture():    picLarge.Picture = LoadPicture()

  ' Draw the associated icons into the picture boxes
  ImageList_Draw hImgSmall&, shinfo.iIcon, picSmall.hdc, 0, 0, &H1
  ImageList_Draw hImgLarge&, shinfo.iIcon, picLarge.hdc, 0, 0, &H1

  icoSmall.ListImages.Add icoSmall.ListImages.Count + 1, extn, picSmall.Image
  icoLarge.ListImages.Add icoLarge.ListImages.Count + 1, extn, picLarge.Image
  
  GetFilIcon = extn
End Function

Public Function lvwSiz()
On Error Resume Next
If lvw.MultiSelect Then
  Dim sz As Long: Dim it As Integer: sz = 0: it = 0
  For i = 1 To lvw.ListItems.Count
  If lvw.ListItems(i).Selected Then
    If lvw.ListItems(i).SubItems(2) = "File Folder" Then
      Set fldr = fso.GetFolder(lvw.Tag & lvw.ListItems(i)): sz = sz + fldr.Size: it = it + 1
    Else
      Set fil = fso.GetFile(lvw.Tag & lvw.ListItems(i)): sz = sz + fil.Size: it = it + 1
    End If
  End If
  Next i
  'frmMDI.stbr.Panels(3) = it & " items " & StrSiz(sz)
Else
  'frmMDI.stbr.Panels(3) = lvw.SelectedItem.SubItems(1)
End If
End Function

