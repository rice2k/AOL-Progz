VERSION 5.00
Begin VB.Form frmGrp 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "Address Book Groups"
   ClientHeight    =   2265
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   3150
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   9.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2265
   ScaleWidth      =   3150
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.ListBox lst 
      Height          =   1980
      Left            =   128
      TabIndex        =   0
      Top             =   142
      Width           =   2895
   End
End
Attribute VB_Name = "frmGrp"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Form_Load()
lst.Clear
For i = 1 To GetSetting(apComp, apProd, "Number of Groups", 1)
lst.AddItem GetSetting(apComp, apProd, "Group" & i, "Default")
Next
End Sub
