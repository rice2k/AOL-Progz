Run 'TrivQuiz.exe'

'Cash run' format means you must get every question in the volume to win

'Pyrimid' format means you start with 5 chances untill you get one right, followed by 4 and so on

See right hand column of program



CREATED BY BEN LEED