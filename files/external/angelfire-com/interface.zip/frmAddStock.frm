VERSION 5.00
Object = "{FE0065C0-1B7B-11CF-9D53-00AA003C9CB6}#2.0#0"; "MSCOMCT2.OCX"
Begin VB.Form frmAddStock 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Add Stock Item"
   ClientHeight    =   4200
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4710
   BeginProperty Font 
      Name            =   "Verdana"
      Size            =   9.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4200
   ScaleWidth      =   4710
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CheckBox chkLoad 
      Caption         =   "Load last entered values as default"
      Height          =   255
      Left            =   428
      TabIndex        =   10
      Top             =   3840
      Width           =   3855
   End
   Begin VB.CommandButton cmdCancel 
      Cancel          =   -1  'True
      Caption         =   "&Cancel"
      Height          =   375
      Left            =   2888
      TabIndex        =   9
      Top             =   3300
      Width           =   1095
   End
   Begin VB.CommandButton cmdAddStock 
      Caption         =   "&Add Stock Item"
      Default         =   -1  'True
      Height          =   375
      Left            =   720
      TabIndex        =   8
      Top             =   3300
      Width           =   1815
   End
   Begin VB.TextBox txtRate 
      Height          =   375
      Left            =   3840
      TabIndex        =   7
      Top             =   2760
      Width           =   615
   End
   Begin VB.TextBox txtQtyInit 
      Height          =   360
      Left            =   3840
      TabIndex        =   6
      Top             =   2280
      Width           =   615
   End
   Begin VB.TextBox txtQtyMin 
      Height          =   375
      Left            =   1800
      TabIndex        =   4
      Top             =   2280
      Width           =   615
   End
   Begin VB.TextBox txtQtyMax 
      Height          =   360
      Left            =   1800
      TabIndex        =   5
      Top             =   2760
      Width           =   615
   End
   Begin VB.ComboBox cmbUnit 
      Height          =   360
      Left            =   3000
      Sorted          =   -1  'True
      TabIndex        =   3
      Text            =   "Unit"
      Top             =   1680
      Width           =   1455
   End
   Begin VB.ComboBox cmbClass 
      Height          =   360
      Left            =   960
      Sorted          =   -1  'True
      Style           =   2  'Dropdown List
      TabIndex        =   2
      Top             =   1680
      Width           =   1215
   End
   Begin VB.ComboBox cmbCategory 
      Height          =   360
      Left            =   1680
      Sorted          =   -1  'True
      Style           =   2  'Dropdown List
      TabIndex        =   1
      Top             =   1200
      Width           =   1695
   End
   Begin VB.TextBox txtItem 
      Height          =   360
      Left            =   1680
      TabIndex        =   0
      Top             =   720
      Width           =   2775
   End
   Begin ComCtl2.DTPicker DTItemAdd 
      Height          =   375
      Left            =   1680
      TabIndex        =   11
      Top             =   240
      Width           =   2775
      _ExtentX        =   4895
      _ExtentY        =   661
      _Version        =   393216
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      CustomFormat    =   "dd, MMMM, yyyy"
      Format          =   24379393
      CurrentDate     =   37800
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Maximum Qty"
      Height          =   240
      Index           =   6
      Left            =   360
      TabIndex        =   20
      Top             =   2820
      Width           =   1320
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Rate"
      Height          =   240
      Index           =   8
      Left            =   3240
      TabIndex        =   19
      Top             =   2820
      Width           =   450
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Initial Qty"
      Height          =   240
      Index           =   7
      Left            =   2715
      TabIndex        =   18
      Top             =   2340
      Width           =   975
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Minimum Qty"
      Height          =   240
      Index           =   5
      Left            =   420
      TabIndex        =   17
      Top             =   2340
      Width           =   1260
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Unit"
      Height          =   240
      Index           =   4
      Left            =   2520
      TabIndex        =   16
      Top             =   1740
      Width           =   390
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Class"
      Height          =   240
      Index           =   3
      Left            =   360
      TabIndex        =   15
      Top             =   1740
      Width           =   510
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Category"
      Height          =   240
      Index           =   2
      Left            =   360
      TabIndex        =   14
      Top             =   1260
      Width           =   900
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Item Name"
      Height          =   240
      Index           =   1
      Left            =   360
      TabIndex        =   13
      Top             =   780
      Width           =   1065
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Date Added"
      Height          =   240
      Index           =   0
      Left            =   360
      TabIndex        =   12
      Top             =   300
      Width           =   1155
   End
End
Attribute VB_Name = "frmAddStock"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public NewStockName As String 'to know what new stock waas added

Private Sub chkLoad_Click()
Dim bol As Boolean
If chkLoad.Value = 1 Then bol = True Else bol = False
SaveSetting apComp, apProd, "StockAdd: Load Last as default", bol
End Sub

Private Sub cmdAddStock_Click()
'first validate
If IsNumeric(txtQtyMin) = False And Len(txtQtyMin) > 0 Then MsgBox "Invalid Minimum Quantity", vbCritical: setSel txtQtyMin: Exit Sub
If IsNumeric(txtQtyMax) = False And Len(txtQtyMax) > 0 Then MsgBox "Invalid Maximum Quantity", vbCritical: setSel txtQtyMax: Exit Sub
If IsNumeric(txtQtyInit) = False And Len(txtQtyInit) > 0 Then MsgBox "Invalid Initial Quantity", vbCritical: setSel txtQtyInit: Exit Sub

If IsNumeric(txtRate) = False And Len(txtRate) > 0 Then MsgBox "Invalid Rate", vbCritical: setSel txtRate: Exit Sub

If Len(txtItem) = 0 Then MsgBox "Cannot Proceed without entering an item name.", vbInformation: Exit Sub

  
Dim strVals As String

'if we are updating not adding must chk & do it here
If txtItem.Enabled = False Then
  
  adoConn.Execute "update StockItems " & _
    "SET Category ='" & cmbCategory.Text & "', Class ='" & cmbClass.Text & "', Unit ='" & cmbUnit.Text & "', Min = " & _
    txtQtyMin & ", Max =" & txtQtyMax & ", Rate=" & txtRate & " where item = '" & txtItem & "'"
  'remove from old category and add again in frmmain.tvw? or do we just assume cat aint gonna change?

Else
  'see if item name exists
  Set adoRecSet = adoConn.Execute("Select * from StockItems where Item = '" & txtItem & "'")
  If adoRecSet.EOF = False Then
    MsgBox "Item already exists. Cannot add. Change item name and try again.", vbInformation
    Exit Sub
  End If

  'finally add item
  strVals = "'" & txtItem & "','" & cmbCategory.Text & "','" & _
        cmbClass.Text & "','" & cmbUnit & "'," & txtQtyMin & "," & txtQtyMax & ",'" & _
        DTItemAdd.Value & "'," & txtQtyInit & "," & txtQtyInit & "," & txtRate & "," & txtRate * txtQtyInit

  adoConn.Execute "insert into StockItems values (" & strVals & ")"

  'add item in frmmain
    frmMain.tvw.Nodes.Add "All Items", tvwChild, , txtItem, 2
    Select Case cmbCategory.Text
      Case "Components"
        frmMain.tvw.Nodes.Add "Components", tvwChild, "Components\" & txtItem, txtItem, 4
      Case "Consumables"
        frmMain.tvw.Nodes.Add "Consumables", tvwChild, "Consumables\" & txtItem, txtItem, 5
      Case "Raw Materials"
        frmMain.tvw.Nodes.Add "Raw Materials", tvwChild, "Raw Materials\" & txtItem, txtItem, 6
    End Select
End If


'set defaults
SaveSetting apComp, apProd, "Last Item Category", cmbCategory.ListIndex 'we dont know what the categories are &_
SaveSetting apComp, apProd, "Last Item Classification", cmbClass.ListIndex 'so cant use text but only index
SaveSetting apComp, apProd, "Last Item Unit", cmbUnit.Text
SaveSetting apComp, apProd, "Last Item Minimum", txtQtyMin
SaveSetting apComp, apProd, "Last Item Maximum", txtQtyMax
SaveSetting apComp, apProd, "Last Item Initial", txtQtyInit
SaveSetting apComp, apProd, "Last Item Rate", txtRate

'exit sub
Me.NewStockName = txtItem
Me.Hide
End Sub

Sub setSel(txt As TextBox)
txt.SelStart = 0
txt.SelLength = Len(txt)
txt.SetFocus
End Sub

Private Sub cmdCancel_Click()
'exit sub
Me.NewStockName = ""
Me.Hide
End Sub

Private Sub Form_Load()

'load categories
Set adoRecSet = adoConn.Execute("select * from Category")
Do Until adoRecSet.EOF
  cmbCategory.AddItem adoRecSet!Category
  adoRecSet.MoveNext
Loop
cmbCategory.ListIndex = GetSetting(apComp, apProd, "Last Item Category", 0)

'load classifications
Set adoRecSet = adoConn.Execute("select * from Class")
Do Until adoRecSet.EOF
  cmbClass.AddItem adoRecSet!Class
  adoRecSet.MoveNext
Loop
cmbClass.ListIndex = GetSetting(apComp, apProd, "Last Item Classification", 0)

'all units
Set adoRecSet = adoConn.Execute("select distinct Unit from StockItems")
Do Until adoRecSet.EOF
  cmbUnit.AddItem adoRecSet!Unit
  adoRecSet.MoveNext
Loop
cmbUnit.Text = GetSetting(apComp, apProd, "Last Item Unit", "Nos")


If "True" = GetSetting(apComp, apProd, "StockAdd: Load Last as default", "True") Then chkLoad.Value = 1
If chkLoad.Value = 1 Then
  'if we must load last used,
  txtQtyMin = GetSetting(apComp, apProd, "Last Item Minimum", 50)
  txtQtyMax = GetSetting(apComp, apProd, "Last Item Maximum", 200)
  txtQtyInit = GetSetting(apComp, apProd, "Last Item Initial", 100)
  
  txtRate = GetSetting(apComp, apProd, "Last Item Rate", 100)
End If

'load proper date
DTItemAdd.Value = Date
End Sub

