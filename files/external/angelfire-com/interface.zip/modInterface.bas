Attribute VB_Name = "modInterface"
Public apComp As String, apProd As String

Public adoConn As New ADODB.Connection
Public adoRecSet As New ADODB.Recordset

Public itm As ListItem

Sub Main()
apComp = App.CompanyName: apProd = App.ProductName

adoConn.Open "Interface"

'Set adoRecSet = adoConn.Execute("select * from stockitems")
'Do Until adoRecSet.EOF
  'adoConn.Execute "update stockitems set balance = " & adoRecSet!Init & " where item = '" & adoRecSet!Item & "'"
  'adoConn.Execute "update stockitems set stockvalue = (balance * rate) where item = '" & adoRecSet!Item & "'"
  'adoRecSet.MoveNext
'Loop
'adoRecSet.Close

frmMain.Show
End Sub
