VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Object = "{FE0065C0-1B7B-11CF-9D53-00AA003C9CB6}#2.0#0"; "MSCOMCT2.OCX"
Begin VB.Form frmAddProject 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Add Project"
   ClientHeight    =   5160
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6510
   BeginProperty Font 
      Name            =   "Verdana"
      Size            =   9.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5160
   ScaleWidth      =   6510
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin MSComctlLib.ListView lvw 
      Height          =   1215
      Left            =   240
      TabIndex        =   13
      Top             =   3120
      Width           =   6015
      _ExtentX        =   10610
      _ExtentY        =   2143
      View            =   3
      LabelEdit       =   1
      LabelWrap       =   -1  'True
      HideSelection   =   0   'False
      FullRowSelect   =   -1  'True
      _Version        =   393217
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      NumItems        =   1
      BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         Text            =   "Product"
         Object.Width           =   2540
      EndProperty
   End
   Begin VB.CommandButton cmdCancel 
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   375
      Left            =   3548
      TabIndex        =   15
      Top             =   4560
      Width           =   1575
   End
   Begin VB.CommandButton cmdAddProject 
      Caption         =   "Add Project"
      Default         =   -1  'True
      Height          =   375
      Left            =   1388
      TabIndex        =   14
      Top             =   4560
      Width           =   1575
   End
   Begin VB.CommandButton cmdAddProduct 
      Caption         =   "&Add"
      Height          =   375
      Left            =   5640
      TabIndex        =   12
      Top             =   2640
      Width           =   615
   End
   Begin VB.ComboBox cmbProduct 
      Height          =   360
      Left            =   240
      Sorted          =   -1  'True
      Style           =   2  'Dropdown List
      TabIndex        =   11
      Top             =   2640
      Width           =   5295
   End
   Begin VB.TextBox txtAddress 
      Height          =   975
      Left            =   1320
      TabIndex        =   8
      Top             =   1440
      Width           =   3015
   End
   Begin VB.ComboBox cmbPriority 
      Height          =   360
      Left            =   5280
      Style           =   2  'Dropdown List
      TabIndex        =   6
      Top             =   840
      Width           =   975
   End
   Begin VB.ComboBox cmbCustomer 
      Height          =   360
      Left            =   1320
      TabIndex        =   4
      Top             =   840
      Width           =   3015
   End
   Begin ComCtl2.DTPicker dtJob 
      Height          =   375
      Left            =   840
      TabIndex        =   16
      Top             =   240
      Width           =   1695
      _ExtentX        =   2990
      _ExtentY        =   661
      _Version        =   393216
      Format          =   24444929
      CurrentDate     =   37800
   End
   Begin VB.TextBox txtWONo 
      Height          =   360
      Left            =   4200
      TabIndex        =   2
      Top             =   240
      Width           =   2055
   End
   Begin ComCtl2.DTPicker dtDue 
      Height          =   375
      Left            =   4560
      TabIndex        =   10
      Top             =   1920
      Width           =   1695
      _ExtentX        =   2990
      _ExtentY        =   661
      _Version        =   393216
      Format          =   24444929
      CurrentDate     =   37800
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Due Date"
      Height          =   240
      Index           =   5
      Left            =   4950
      TabIndex        =   9
      Top             =   1560
      Width           =   915
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Address"
      Height          =   240
      Index           =   4
      Left            =   240
      TabIndex        =   7
      Top             =   1440
      Width           =   780
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Priority"
      Height          =   240
      Index           =   3
      Left            =   4440
      TabIndex        =   5
      Top             =   900
      Width           =   690
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Customer"
      Height          =   240
      Index           =   2
      Left            =   240
      TabIndex        =   3
      Top             =   900
      Width           =   930
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Date"
      Height          =   240
      Index           =   1
      Left            =   240
      TabIndex        =   1
      Top             =   300
      Width           =   465
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Work Order No"
      Height          =   240
      Index           =   0
      Left            =   2640
      TabIndex        =   0
      Top             =   300
      Width           =   1440
   End
End
Attribute VB_Name = "frmAddProject"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmbCustomer_Click()
Set adoRecSet = adoConn.Execute("select * from jobs where customer = '" & cmbCustomer.Text & "'")
If adoRecSet.EOF = False Then txtAddress = adoRecSet!Address
adoRecSet.Close
End Sub

Private Sub cmbCustomer_LostFocus()
Set adoRecSet = adoConn.Execute("select * from jobs where customer = '" & cmbCustomer.Text & "'")
If adoRecSet.EOF = True Then txtAddress = ""
adoRecSet.Close
End Sub

Private Sub cmdAddProduct_Click()
'first see if product already added
For Each itm In lvw.ListItems
  If itm.Text = cmbProduct.Text Then MsgBox "Product already added": Exit Sub
Next

lvw.ListItems.Add , , cmbProduct.Text
End Sub

Private Sub cmdAddProject_Click()
If InStr(txtWONo, "'") > 0 Or InStr(txtAddress, "'") > 0 Then MsgBox "Name & Address cannot have an ' (apostrophe) in it.Click Ok to continue.", vbExclamation: Exit Sub


'finally add data
Dim strVals As String, strOrder As String

For Each itm In lvw.ListItems
  Set adoRecSet = adoConn.Execute("Select * from products where product ='" & itm.Text & "'")
  If adoRecSet.EOF Then
    MsgBox "Product " & itm.Text & " seems to have been deleted since this dialog loaded. It cannot be added", vbExclamation
  Else
    strOrder = strOrder & adoRecSet!productid '& "</name><qty>" & itm.SubItems(1) & "</qty></item>"
    If itm.Index < lvw.ListItems.Count Then strOrder = strOrder & ","
  End If
Next
adoRecSet.Close

strVals = "'" & dtJob.Value & "','" & txtWONo & "','" & cmbPriority.Text & "','" & _
        cmbCustomer.Text & "','" & txtAddress & "','" & strOrder & "','" & dtDue.Value & "'" & _
        ",No"

adoConn.Execute "insert into Jobs values(" & strVals & ")"

'now add in frmmain
frmMain.tvw.Nodes.Add "Jobs", tvwChild, "Jobs\" & txtWONo, txtWONo, 8 'is 8 active/finished

Unload Me
End Sub

Private Sub cmdCancel_Click()
Unload Me
End Sub

Private Sub Form_Load()

'load existing customers
Set adoRecSet = adoConn.Execute("select distinct customer from jobs")
  Do Until adoRecSet.EOF
    cmbCustomer.AddItem adoRecSet!Customer
    adoRecSet.MoveNext
  Loop
adoRecSet.Close

'load products
Set adoRecSet = adoConn.Execute("select * from Products")
  Do Until adoRecSet.EOF
    cmbProduct.AddItem adoRecSet!Product
    adoRecSet.MoveNext
  Loop
adoRecSet.Close

'load priority
cmbPriority.AddItem "Low"
cmbPriority.AddItem "Medium"
cmbPriority.AddItem "High"
cmbPriority.ListIndex = 1

'set date
dtJob.Value = Date
dtDue.Value = Date
End Sub

Private Sub Form_Resize()
  lvw.ColumnHeaders(1).Width = lvw.Width - 450 'lvw.ColumnHeaders(2).Width -
End Sub

Private Sub lvw_KeyDown(KeyCode As Integer, Shift As Integer)
If KeyCode = vbKeyDelete Then
  For Each itm In lvw.ListItems
    If itm.Selected = True Then GoTo Nxt
  Next
  Exit Sub
Nxt:
  Dim m As VbMsgBoxResult
  m = MsgBox("Sure you are cancelling" & vbCrLf & lvw.SelectedItem.Text & vbCrLf & "from this order?", vbQuestion + vbYesNo, "Confirm Product Cancellation")
  If m = vbYes Then lvw.ListItems.Remove (lvw.SelectedItem.Index)
End If
End Sub

Private Sub txtAddress_GotFocus()
txtAddress.SelStart = 0
txtAddress.SelLength = Len(txtAddress)
End Sub

Private Sub txtWONo_LostFocus()
Set adoRecSet = adoConn.Execute("select * from jobs where WO_No = '" & txtWONo & "'")
If adoRecSet.EOF = False Then
  Dim m As VbMsgBoxResult
  m = MsgBox("A Job with the given Work Order Number already exists. Do you want to enter another one or close this dialog?", vbQuestion + vbYesNo, "Duplicate WO NUmber found")
  If m = vbYes Then txtWONo.SelStart = 0: txtWONo.SelLength = Len(txtWONo) - 1: txtWONo.SetFocus Else Unload Me
End If
adoRecSet.Close
End Sub
