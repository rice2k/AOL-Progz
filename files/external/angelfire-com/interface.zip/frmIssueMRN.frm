VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Object = "{FE0065C0-1B7B-11CF-9D53-00AA003C9CB6}#2.0#0"; "MSCOMCT2.OCX"
Begin VB.Form frmIssueMRN 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Issue MRN & Receive Stock"
   ClientHeight    =   6285
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5100
   BeginProperty Font 
      Name            =   "Verdana"
      Size            =   9.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6285
   ScaleWidth      =   5100
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.ComboBox cmbItems 
      Height          =   360
      Left            =   960
      Sorted          =   -1  'True
      Style           =   2  'Dropdown List
      TabIndex        =   3
      Top             =   2167
      Width           =   3735
   End
   Begin VB.CommandButton cmdCancel 
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   375
      Left            =   2723
      TabIndex        =   11
      Top             =   5760
      Width           =   1455
   End
   Begin VB.CommandButton cmdAddMRN 
      Caption         =   "Add MRN"
      Default         =   -1  'True
      Height          =   375
      Left            =   923
      TabIndex        =   10
      Top             =   5760
      Width           =   1455
   End
   Begin VB.TextBox txtDCTot 
      Height          =   360
      Left            =   3600
      Locked          =   -1  'True
      TabIndex        =   23
      TabStop         =   0   'False
      Top             =   5160
      Width           =   1095
   End
   Begin VB.TextBox txtRecdBy 
      Height          =   360
      Left            =   1320
      TabIndex        =   9
      Top             =   5160
      Width           =   735
   End
   Begin VB.TextBox txtAmount 
      Height          =   360
      Left            =   3360
      Locked          =   -1  'True
      TabIndex        =   6
      TabStop         =   0   'False
      Top             =   2640
      Width           =   615
   End
   Begin VB.CommandButton cmdAddItem 
      Caption         =   "&Add"
      Height          =   375
      Left            =   4080
      TabIndex        =   7
      Top             =   2640
      Width           =   615
   End
   Begin VB.TextBox txtQty 
      Height          =   360
      Left            =   2160
      TabIndex        =   5
      Top             =   2640
      Width           =   615
   End
   Begin VB.TextBox txtRate 
      Height          =   360
      Left            =   960
      TabIndex        =   4
      Top             =   2640
      Width           =   615
   End
   Begin MSComctlLib.ListView lvw 
      Height          =   1815
      Left            =   240
      TabIndex        =   8
      Top             =   3120
      Width           =   4575
      _ExtentX        =   8070
      _ExtentY        =   3201
      View            =   3
      LabelEdit       =   1
      LabelWrap       =   -1  'True
      HideSelection   =   0   'False
      FullRowSelect   =   -1  'True
      _Version        =   393217
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      NumItems        =   4
      BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         Text            =   "Item"
         Object.Width           =   2540
      EndProperty
      BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   1
         Text            =   "Rate"
         Object.Width           =   1411
      EndProperty
      BeginProperty ColumnHeader(3) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   2
         Text            =   "Qty"
         Object.Width           =   1411
      EndProperty
      BeginProperty ColumnHeader(4) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   3
         Text            =   "Amt"
         Object.Width           =   1411
      EndProperty
   End
   Begin VB.TextBox txtDCNo 
      Height          =   375
      Left            =   840
      TabIndex        =   1
      Top             =   1440
      Width           =   975
   End
   Begin VB.TextBox txtMRN 
      Height          =   375
      Left            =   3600
      Locked          =   -1  'True
      TabIndex        =   16
      TabStop         =   0   'False
      Top             =   240
      Width           =   1215
   End
   Begin VB.ComboBox cmbSupplier 
      Height          =   360
      Left            =   1800
      Sorted          =   -1  'True
      TabIndex        =   0
      Top             =   840
      Width           =   3015
   End
   Begin ComCtl2.DTPicker dtMRN 
      Height          =   375
      Left            =   840
      TabIndex        =   12
      Top             =   240
      Width           =   1815
      _ExtentX        =   3201
      _ExtentY        =   661
      _Version        =   393216
      Format          =   24510465
      CurrentDate     =   37800
   End
   Begin ComCtl2.DTPicker dtDC 
      Height          =   375
      Left            =   3000
      TabIndex        =   2
      Top             =   1440
      Width           =   1815
      _ExtentX        =   3201
      _ExtentY        =   661
      _Version        =   393216
      Format          =   24510465
      CurrentDate     =   37800
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Item"
      Height          =   240
      Index           =   5
      Left            =   360
      TabIndex        =   25
      Top             =   2227
      Width           =   450
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Recd By"
      Height          =   240
      Index           =   10
      Left            =   360
      TabIndex        =   24
      Top             =   5220
      Width           =   795
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "DC Total"
      Height          =   240
      Index           =   9
      Left            =   2640
      TabIndex        =   22
      Top             =   5220
      Width           =   855
   End
   Begin VB.Line Line2 
      BorderWidth     =   2
      X1              =   240
      X2              =   4800
      Y1              =   5040
      Y2              =   5040
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Amt"
      Height          =   240
      Index           =   8
      Left            =   2880
      TabIndex        =   21
      Top             =   2700
      Width           =   390
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Qty"
      Height          =   240
      Index           =   7
      Left            =   1680
      TabIndex        =   20
      Top             =   2700
      Width           =   360
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Rate"
      Height          =   240
      Index           =   6
      Left            =   360
      TabIndex        =   19
      Top             =   2700
      Width           =   450
   End
   Begin VB.Line Line1 
      BorderWidth     =   2
      X1              =   240
      X2              =   4800
      Y1              =   2040
      Y2              =   2040
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "DC Date"
      Height          =   240
      Index           =   4
      Left            =   2040
      TabIndex        =   18
      Top             =   1500
      Width           =   810
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "DC #"
      Height          =   240
      Index           =   3
      Left            =   240
      TabIndex        =   17
      Top             =   1507
      Width           =   495
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "MRN #"
      Height          =   240
      Index           =   1
      Left            =   2880
      TabIndex        =   15
      Top             =   300
      Width           =   645
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Date"
      Height          =   240
      Index           =   0
      Left            =   240
      TabIndex        =   14
      Top             =   307
      Width           =   465
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Supplier Name"
      Height          =   240
      Index           =   2
      Left            =   240
      TabIndex        =   13
      Top             =   900
      Width           =   1395
   End
End
Attribute VB_Name = "frmIssueMRN"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit


Private Sub cmbItems_Click()
If cmbItems.Text = "... Add New Stock Item ..." Then
  frmAddStock.Show vbModal
  If frmAddStock.NewStockName <> "" Then
    cmbItems.AddItem frmAddStock.NewStockName
    cmbItems.Text = frmAddStock.NewStockName
  End If
  Unload frmAddStock
End If
End Sub

Private Sub cmdAddItem_Click()
'first see if product already added
For Each itm In lvw.ListItems
  If itm.Text = cmbItems.Text Then MsgBox "Item already added": Exit Sub
Next

If cmbItems.ListIndex < 1 Then MsgBox "Must select a Stock Item first.", vbInformation: cmbItems.SetFocus: Exit Sub
If Val(txtAmount) = 0 Then MsgBox "Improper Amount": Exit Sub

Set itm = lvw.ListItems.Add(, , cmbItems.Text)
itm.SubItems(1) = txtRate
itm.SubItems(2) = txtQty
itm.SubItems(3) = txtAmount

Dim tot As Long
tot = 0
For Each itm In lvw.ListItems
  tot = tot + Val(itm.SubItems(3))
Next
txtDCTot = "Rs " & tot
End Sub

Private Sub cmdAddMRN_Click()
Dim m As VbMsgBoxResult
m = MsgBox("Are you sure you have entered everything" & vbCrLf & "accurately and wish to proceed?", vbQuestion + vbYesNo)
If m = vbNo Then Exit Sub

'verify
If cmbSupplier.Text = "" Then MsgBox "Must enter a Supplier name before you can proceed.", vbInformation: Exit Sub
If Len(txtRecdBy) = 0 Then
  m = MsgBox("There is no mention of person receiving delivery. Do you wish to proceed?", vbQuestion + vbYesNo)
  If m = vbNo Then Exit Sub
End If

If lvw.ListItems.Count = 0 Then
  MsgBox "MRN Cannot be accepted without any items.", vbInformation
  Exit Sub
ElseIf lvw.ListItems.Count = 1 Then
  m = MsgBox("Are you certain there is only one item being reeceived?", vbQuestion + vbYesNo)
  If m = vbNo Then Exit Sub
End If
  
If txtDCNo = "" Then MsgBox "There is no DC Number. Enter one to proceed.", vbInformation: Exit Sub

'add to MRN table
Dim strVals As String
strVals = txtMRN & ",'" & dtMRN.Value & "','" & cmbSupplier.Text
strVals = strVals & "','" & txtDCNo & "','" & dtDC.Value & "',"
strVals = strVals & Val(Mid(txtDCTot, 4)) & ",'" & txtRecdBy & "'"

'MsgBox "Insert into mrn values (" & strVals & ")"
adoConn.Execute "Insert into mrn values (" & strVals & ")"

'add to stock in table
For Each itm In lvw.ListItems
  strVals = ""
  strVals = "'" & dtMRN.Value & "'," & txtMRN & ",'" & itm.Text & "'," & _
          itm.SubItems(2) & "," & itm.SubItems(1) & "," & itm.SubItems(3)
  adoConn.Execute "insert into stockin values (" & strVals & ")"
  adoConn.Execute "update stockitems set Balance = Balance + " & itm.SubItems(2) & ", stockvalue = (balance + " & itm.SubItems(2) & ")* rate where item = '" & itm.Text & "'"
Next

frmMain.tvw.Nodes.Add "MRN", tvwChild, , txtMRN, 13

'ian to add this section later
m = MsgBox("Would you like a printout of the MRN now? I dont think u can print it later.")

Unload Me
End Sub

Private Sub cmdCancel_Click()
Unload Me
End Sub

Private Sub Form_Load()

'get mrn number
Set adoRecSet = adoConn.Execute("Select * from mrn order by mrn_no desc")
  If adoRecSet.EOF = True Then txtMRN = "1" Else txtMRN = adoRecSet!Mrn_no + 1
adoRecSet.Close

'get supplier names
Set adoRecSet = adoConn.Execute("Select distinct SupplierName from mrn")
  Do Until adoRecSet.EOF
    cmbSupplier.AddItem adoRecSet!SupplierName
    adoRecSet.MoveNext
  Loop
adoRecSet.Close

'add stock items
cmbItems.AddItem "... Add New Stock Item ..."
Set adoRecSet = adoConn.Execute("Select * from stockitems")
  Do Until adoRecSet.EOF
    cmbItems.AddItem adoRecSet!Item
    adoRecSet.MoveNext
  Loop
adoRecSet.Close

'update dates
dtDC.Value = Date
dtMRN.Value = Date
End Sub

Private Sub Form_Resize()
lvw.ColumnHeaders(1).Width = lvw.Width - 3 * lvw.ColumnHeaders(2).Width - 100
End Sub

Private Sub lvw_KeyDown(KeyCode As Integer, Shift As Integer)
If KeyCode = vbKeyDelete Then
  For Each itm In lvw.ListItems
    If itm.Selected = True Then GoTo Nxt
  Next
  Exit Sub
Nxt:
  Dim m As VbMsgBoxResult
  m = MsgBox("Sure you want to remove" & vbCrLf & lvw.SelectedItem.Text & vbCrLf & "from this delivery?", vbQuestion + vbYesNo, "Confirm Product Cancellation")
  If m = vbYes Then lvw.ListItems.Remove (lvw.SelectedItem.Index)
  
  'recalculate total
  Dim tot As Long
  tot = 0
  For Each itm In lvw.ListItems
    tot = tot + Val(itm.SubItems(3))
  Next
  txtDCTot = "Rs " & tot
End If
End Sub

Private Sub txtQty_Change()
If IsNumeric(txtQty) = False And Len(txtQty) > 0 Then MsgBox "Invalid Quantity.", vbCritical: txtAmount = "": Exit Sub
txtAmount = Val(txtRate) * Val(txtQty)
End Sub

Private Sub txtRate_Change()
If IsNumeric(txtRate) = False And Len(txtRate) > 0 Then MsgBox "Invalid Rate.", vbCritical: txtAmount = "": Exit Sub
txtAmount = Val(txtRate) * Val(txtQty)
End Sub
