VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Object = "{FE0065C0-1B7B-11CF-9D53-00AA003C9CB6}#2.0#0"; "MSCOMCT2.OCX"
Begin VB.Form frmMain 
   Caption         =   "Interface Electronics' Inventory Organiser"
   ClientHeight    =   8370
   ClientLeft      =   60
   ClientTop       =   600
   ClientWidth     =   9645
   BeginProperty Font 
      Name            =   "Verdana"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   8370
   ScaleWidth      =   9645
   WindowState     =   2  'Maximized
   Begin VB.PictureBox Picture1 
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   4200
      ScaleHeight     =   495
      ScaleWidth      =   9495
      TabIndex        =   4
      Top             =   0
      Width           =   9495
      Begin VB.ComboBox cmbMonths 
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   360
         Left            =   1320
         Style           =   2  'Dropdown List
         TabIndex        =   5
         Top             =   0
         Width           =   2895
      End
      Begin ComCtl2.DTPicker dtTo 
         Height          =   375
         Left            =   7200
         TabIndex        =   6
         Top             =   0
         Width           =   1695
         _ExtentX        =   2990
         _ExtentY        =   661
         _Version        =   393216
         Format          =   24444929
         CurrentDate     =   37940
      End
      Begin ComCtl2.DTPicker dtFrom 
         Height          =   375
         Left            =   5040
         TabIndex        =   8
         Top             =   0
         Width           =   1695
         _ExtentX        =   2990
         _ExtentY        =   661
         _Version        =   393216
         Format          =   24444929
         CurrentDate     =   37940
      End
      Begin VB.Label lbl 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "To"
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   2
         Left            =   6840
         TabIndex        =   10
         Top             =   60
         Width           =   255
      End
      Begin VB.Label lbl 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "From"
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   0
         Left            =   4455
         TabIndex        =   9
         Top             =   60
         Width           =   480
      End
      Begin VB.Label lbl 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "Date Filter"
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   240
         Index           =   1
         Left            =   180
         TabIndex        =   7
         Top             =   60
         Width           =   1035
      End
   End
   Begin MSComctlLib.StatusBar stbr 
      Align           =   2  'Align Bottom
      Height          =   375
      Left            =   0
      TabIndex        =   3
      Top             =   7995
      Width           =   9645
      _ExtentX        =   17013
      _ExtentY        =   661
      _Version        =   393216
      BeginProperty Panels {8E3867A5-8586-11D1-B16A-00C0F0283628} 
         NumPanels       =   3
         BeginProperty Panel1 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   2
            Object.Width           =   4498
            Picture         =   "frmMain.frx":0CCA
            Text            =   "Show tvw Item totals"
            TextSave        =   "Show tvw Item totals"
         EndProperty
         BeginProperty Panel2 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   1
            Object.Width           =   6668
            Picture         =   "frmMain.frx":0DE2
            Text            =   "Total job expenditure"
            TextSave        =   "Total job expenditure"
         EndProperty
         BeginProperty Panel3 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   2
            Bevel           =   0
            Object.Width           =   5292
            Picture         =   "frmMain.frx":10FE
            Text            =   "  Interface Electronics  "
            TextSave        =   "  Interface Electronics  "
         EndProperty
      EndProperty
   End
   Begin VB.PictureBox vlin 
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   11115
      Left            =   3720
      MousePointer    =   9  'Size W E
      ScaleHeight     =   11115
      ScaleWidth      =   60
      TabIndex        =   1
      Top             =   0
      Width           =   60
   End
   Begin MSComctlLib.ImageList imTvw 
      Left            =   5640
      Top             =   120
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   20
      ImageHeight     =   20
      MaskColor       =   12632256
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   15
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":1552
            Key             =   ""
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":222E
            Key             =   ""
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":2F0A
            Key             =   ""
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":3BE6
            Key             =   ""
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":48C2
            Key             =   ""
         EndProperty
         BeginProperty ListImage6 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":559E
            Key             =   ""
         EndProperty
         BeginProperty ListImage7 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":627A
            Key             =   ""
         EndProperty
         BeginProperty ListImage8 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":6F56
            Key             =   ""
         EndProperty
         BeginProperty ListImage9 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":7C32
            Key             =   ""
         EndProperty
         BeginProperty ListImage10 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":890E
            Key             =   ""
         EndProperty
         BeginProperty ListImage11 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":95EA
            Key             =   ""
         EndProperty
         BeginProperty ListImage12 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":A2C6
            Key             =   ""
         EndProperty
         BeginProperty ListImage13 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":A5E2
            Key             =   ""
         EndProperty
         BeginProperty ListImage14 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":AA36
            Key             =   ""
         EndProperty
         BeginProperty ListImage15 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":AD52
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin MSComctlLib.ListView lvw 
      Height          =   4095
      Left            =   4200
      TabIndex        =   2
      Top             =   480
      Width           =   4695
      _ExtentX        =   8281
      _ExtentY        =   7223
      View            =   3
      LabelEdit       =   1
      LabelWrap       =   -1  'True
      HideSelection   =   -1  'True
      _Version        =   393217
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      NumItems        =   0
   End
   Begin MSComctlLib.TreeView tvw 
      Height          =   7215
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   4095
      _ExtentX        =   7223
      _ExtentY        =   12726
      _Version        =   393217
      HideSelection   =   0   'False
      Indentation     =   441
      LabelEdit       =   1
      Sorted          =   -1  'True
      Style           =   7
      HotTracking     =   -1  'True
      ImageList       =   "imTvw"
      Appearance      =   1
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
   Begin VB.Menu menuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuExport 
         Caption         =   "&Export Table"
      End
      Begin VB.Menu sf2 
         Caption         =   "-"
      End
      Begin VB.Menu mnuExit 
         Caption         =   "E&xit"
      End
   End
   Begin VB.Menu menuActions 
      Caption         =   "&Actions"
      Begin VB.Menu mnuStockAdd 
         Caption         =   "Add Stock Item"
      End
      Begin VB.Menu mnuStockEdit 
         Caption         =   "&Edit Stock Item"
         Enabled         =   0   'False
      End
      Begin VB.Menu mnuIssueStock 
         Caption         =   "Issue &Stock"
      End
      Begin VB.Menu mnuIssueMRN 
         Caption         =   "Receive Stock"
      End
      Begin VB.Menu sa0 
         Caption         =   "-"
      End
      Begin VB.Menu mnuProjectAdd 
         Caption         =   "Add &Project"
      End
      Begin VB.Menu mnuProjectComplete 
         Caption         =   "Complete Project(s)"
      End
   End
   Begin VB.Menu menuOptions 
      Caption         =   "&Options"
      Begin VB.Menu mnuOptGridlines 
         Caption         =   "View Gridlines"
      End
      Begin VB.Menu mnuOptFullRow 
         Caption         =   "Full Row Select"
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Dim vMoving As Boolean

Dim strTable As String, strSql As String 'order by is added in column_click
Dim iColSort As Integer

'to lock lvw while reloading
Private Declare Function LockWindowUpdate Lib "user32" (ByVal hwndLock As Long) As Long

Private Sub Form_Load()
'SavePicture imTvw.ListImages(1).ExtractIcon, "Inter2.ico"

vlin.Left = GetSetting(apComp, apProd, "vlin.left", vlin.Left)
If True = GetSetting(apComp, apProd, "Opt: FullRow", "True") Then mnuOptFullRow_Click
If True = GetSetting(apComp, apProd, "Opt: Gridlines", "True") Then mnuOptGridlines_Click

  tvw_Load
  
cmbMonths.AddItem "All"
cmbMonths.AddItem "This Month (" & Format(Date, "MMM yy") & ")"
cmbMonths.AddItem "Last Month (" & Format(DateAdd("m", -1, Date), "MMM yy") & ")"
End Sub


Private Sub tvw_Load()

tvw.Nodes.Add , , "IE", "Interface", 1
tvw.Nodes("IE").Expanded = True

tvw.Nodes.Add "IE", tvwChild, "All Items", "All Items", 2
  tvw.Nodes("All Items").Sorted = True
tvw.Nodes.Add "IE", tvwChild, "Category", "Category", 3
tvw.Nodes("Category").Expanded = True
tvw.Nodes.Add "Category", tvwChild, "Components", "Components", 4
  tvw.Nodes("Components").Sorted = True
tvw.Nodes.Add "Category", tvwChild, "Consumables", "Consumables", 5
  tvw.Nodes("Consumables").Sorted = True
tvw.Nodes.Add "Category", tvwChild, "Raw Materials", "Raw Materials", 6
  tvw.Nodes("Raw Materials").Sorted = True

tvw.Nodes.Add "IE", tvwChild, "Damages", "Damages", 7

tvw.Nodes.Add "IE", tvwChild, "Jobs", "Jobs", 8

tvw.Nodes.Add "IE", tvwChild, "Stock In", "Stock In", 10  'MRNs
tvw.Nodes.Add "IE", tvwChild, "Stock Out", "Stock Out", 11

tvw.Nodes.Add "IE", tvwChild, "Monthly Reports", "Monthly Reports", 12
tvw.Nodes.Add "IE", tvwChild, "MRN", "MRN", 13

'tvw.Nodes.Add "IE", tvwChild, "Trays", "Trays", 11
  'tvw.Nodes("Trays").Expanded = True
  'tvw.Nodes.Add "Trays", tvwChild, "Pending Jobs", "Pending Jobs", 8
    'tvw.Nodes("Pending Jobs").Sorted = True
  'tvw.Nodes.Add "Trays", tvwChild, "Pending Replacements", "Pending Replacements", 12
    'tvw.Nodes("Pending Replacements").Sorted = True
  'tvw.Nodes.Add "Trays", tvwChild, "Pending Orders", "Pending Orders", 13
    'tvw.Nodes("Pending Orders").Sorted = True

'load all items in 'Category' & 'All Items'
Set adoRecSet = adoConn.Execute("select * from StockItems")
Dim strItm As String
  Do Until adoRecSet.EOF
    strItm = adoRecSet!Item
    tvw.Nodes.Add "All Items", tvwChild, "All Items\" & strItm, strItm, 2
    
    Select Case adoRecSet!Category
  
    Case "Components"
      tvw.Nodes.Add "Components", tvwChild, "Components\" & strItm, strItm, 4
    Case "Consumables"
      tvw.Nodes.Add "Consumables", tvwChild, "Consumables\" & strItm, strItm, 5
    Case "Raw Materials"
      tvw.Nodes.Add "Raw Materials", tvwChild, "Raw Materials\" & strItm, strItm, 6
    Case Else
    
    End Select
    
    adoRecSet.MoveNext
  Loop
adoRecSet.Close

'Load damaged
Set adoRecSet = adoConn.Execute("select distinct Item from StockOut where Damaged = true ")
  Do Until adoRecSet.EOF
    tvw.Nodes.Add "Damages", tvwChild, "Damages\" & adoRecSet!Item, adoRecSet!Item, 7
    adoRecSet.MoveNext
  Loop
adoRecSet.Close

'load MRNs
Set adoRecSet = adoConn.Execute("select * from MRN order by MRN_No desc")
  Do Until adoRecSet.EOF
    tvw.Nodes.Add "MRN", tvwChild, "MRN\" & adoRecSet!Mrn_no, adoRecSet!Mrn_no, 13
    adoRecSet.MoveNext
  Loop
adoRecSet.Close

'load Jobs
Set adoRecSet = adoConn.Execute("select * from Jobs order by delivered desc") ', order by wo_no desc")
Dim icn As Byte
  Do Until adoRecSet.EOF
    If adoRecSet!Delivered = False Then icn = 8 Else icn = 9 'tvw.Nodes.Add "Pending Jobs", tvwChild, "Pending Jobs\" & adoRecSet!WO_No, adoRecSet!WO_No, 8
    tvw.Nodes.Add "Jobs", tvwChild, "Jobs\" & adoRecSet!WO_No, adoRecSet!WO_No, icn
    adoRecSet.MoveNext
  Loop
adoRecSet.Close

tvw.Nodes.Add "Monthly Reports", tvwChild, "Monthly Reports\" & Format(Date, "mmm yyyy"), Format(Date, "mmm yyyy"), 12
'must ensure Monthly reports arent done in current month/only on last day of month.
'i.e add monthly report to table cannot be done until 1st day of next month
Set adoRecSet = adoConn.Execute("select * from MonthlyReports")
  Do Until adoRecSet.EOF
    tvw.Nodes.Add "Monthly Reports", tvwChild, "Monthly Reports\" & Format(adoRecSet!Month, "mmm yyyy"), Format(adoRecSet!Month, "mmm yyyy"), 12
    adoRecSet.MoveNext
  Loop
adoRecSet.Close

End Sub

Private Sub Form_Resize()
If Me.WindowState = vbMinimized Then Exit Sub
vlin.Height = Me.ScaleHeight - stbr.Height
tvw.Height = Me.ScaleHeight - stbr.Height - tvw.Top
lvw.Height = Me.ScaleHeight - stbr.Height - lvw.Top
If Me.WindowState <> vbMinimized Then vSiz
End Sub


Private Sub loadLvwCols()
Dim cHead As ColumnHeader, i As Integer
  Set adoRecSet = adoConn.Execute(strSql)

For Each cHead In lvw.ColumnHeaders
  SaveSetting apComp, apProd & "\Columns", cHead.Text, cHead.Width
Next

  lvw.ColumnHeaders.Clear
  lvw.ListItems.Clear
  Dim wd As Long
  For i = 1 To adoRecSet.Fields.Count
    wd = GetSetting(apComp, apProd & "\Columns", adoRecSet.Fields(i - 1).Name, 1440)
    lvw.ColumnHeaders.Add , , adoRecSet.Fields(i - 1).Name, wd
  Next

  adoRecSet.Close
End Sub

Private Sub loadLvwFields(Optional OrderBy As String, Optional sAsc As String)  'if desc then pass "Desc" as sAsc
Dim Tots(12) As Double, Titls(12) As String 'never the first field needs totalling
  Set adoRecSet = adoConn.Execute(strSql & OrderBy)
  
  lvw.ListItems.Clear
  
  Dim i As Integer
  
  For i = 0 To adoRecSet.Fields.Count - 1: Titls(i) = adoRecSet.Fields(i).Name: Next
  
  Do Until adoRecSet.EOF
    Set itm = lvw.ListItems.Add(, , adoRecSet.Fields(0).Value)
    For i = 1 To adoRecSet.Fields.Count - 1
      If IsNull(adoRecSet.Fields(i).Value) = False Then
        itm.SubItems(i) = adoRecSet.Fields(i).Value
        If IsNumeric(adoRecSet.Fields(i).Value) Then Tots(i) = Tots(i) + adoRecSet.Fields(i).Value
      End If
    Next
    
    adoRecSet.MoveNext
  Loop
  
  stbr.Panels(1).Text = "  " & lvw.ListItems.Count & " item(s)  "
  'stbr.Panels(1).AutoSize = sbrContents
  Dim strTots As String
  For i = 0 To adoRecSet.Fields.Count - 1
    If InStr("Balance,StockValue,Qty,Amount,PurchVal,IssueVal,DC_Amt", Titls(i)) > 0 Then
      strTots = strTots & Titls(i) & ": " & Tots(i) & "; " 'If Tots(i) > 0 Then
    End If
  Next
  If Len(strTots) > 2 Then strTots = Mid(strTots, 1, Len(strTots) - 2)
  stbr.Panels(2).Text = "Column Totals (" & strTots & ")"
  
  adoRecSet.Close
End Sub


Private Sub Form_Unload(Cancel As Integer)
mnuExit_Click
End Sub

Private Sub lvw_ColumnClick(ByVal ColumnHeader As MSComctlLib.ColumnHeader)

If ColumnHeader.Index = iColSort Then
  iColSort = 0
  loadLvwFields " order by [" & ColumnHeader.Text & "]Desc"
Else
  iColSort = ColumnHeader.Index
  loadLvwFields " order by [" & ColumnHeader.Text & "]Asc"
End If

End Sub

Private Sub lvw_DblClick()
On Error Resume Next
Dim tTxt As String
tTxt = tvw.SelectedItem.Text: GoTo Nxt
Exit Sub
Nxt:
If tTxt = "Raw Materials" Or tTxt = "Consumables" Or tTxt = "Components" Or tTxt = "All Items" Or tTxt = "Jobs" Or tTxt = "MRN" Then
  tvw.Nodes(tTxt & "\" & lvw.SelectedItem.Text).Selected = True
  tvw_NodeClick tvw.Nodes(tTxt & "\" & lvw.SelectedItem.Text)
End If
End Sub

Private Sub mnuExit_Click()
SaveSetting apComp, apProd, "vlin.left", vlin.Left

SaveSetting apComp, apProd, "Opt: FullRow", mnuOptFullRow.Checked
SaveSetting apComp, apProd, "Opt: Gridlines", mnuOptGridlines.Checked


End
End Sub

Private Sub mnuExportExcel_Click()
Dim m As VbMsgBoxResult
m = MsgBox("Would you like to export the Column Headers as well?", vbYesNo + vbQuestion, "Export to Excel")

End Sub

Private Sub mnuExport_Click()
    On Error Resume Next
    Dim fNAME As String, obj As CDLG
    Set obj = New CDLG
    fNAME = ""
    obj.VBGetSaveFileName fNAME, , , "Excel Workbook (*.xls)|*.xls", , CurDir, "Export to:", "*.xls"
    If fNAME <> "" Then
        Screen.MousePointer = vbHourglass
        ExportIt fNAME
        Screen.MousePointer = vbDefault
        'MsgBox "Export to:" & fNAME & " complete.", vbInformation, "Done"
    End If
End Sub

Private Sub mnuIssueMRN_Click()
frmIssueMRN.Show vbModal
End Sub

Private Sub mnuIssueStock_Click()
frmIssueStock.Show vbModal
End Sub

Private Sub mnuOptFullRow_Click()
  mnuOptFullRow.Checked = Not mnuOptFullRow.Checked
  lvw.FullRowSelect = mnuOptFullRow.Checked
End Sub

Private Sub mnuOptGridlines_Click()
  mnuOptGridlines.Checked = Not mnuOptGridlines.Checked
  lvw.GridLines = mnuOptGridlines.Checked
End Sub

Private Sub mnuProjectAdd_Click()
frmAddProject.Show vbModal
End Sub

Private Sub mnuProjectComplete_Click()
Set adoRecSet = adoConn.Execute("select * from jobs where Delivered=no")
If adoRecSet.EOF Then MsgBox "There are no incomplete Jobs. All jobs have been delivered." & vbCrLf & "You cannot complete a job unless there are incomplete ones", vbInformation: Exit Sub

frmProjectComplete.Show vbModal
End Sub

Private Sub mnuStockAdd_Click()
frmAddStock.Show vbModal
Unload frmAddStock
End Sub

Private Sub mnuStockEdit_Click()
'lock desired controld & load vals from stockitems
Set adoRecSet = adoConn.Execute("select * from stockitems where item = '" & tvw.SelectedItem.Text & "'")
If adoRecSet.EOF Then MsgBox "Item '" & tvw.SelectedItem.Text & "' not found": Exit Sub

Load frmAddStock
With frmAddStock
.Caption = "Edit Stock Item '" & tvw.SelectedItem.Text & "'"
.cmdAddStock.Caption = "Update Item"

.DTItemAdd.Enabled = False
.txtItem = tvw.SelectedItem.Text: .txtItem.Enabled = False
If IsNull(adoRecSet!Init) = False Then .txtQtyInit = adoRecSet!Init: .txtQtyInit.Enabled = False
.cmbCategory.Text = adoRecSet!Category
.cmbClass.Text = adoRecSet!Class
If IsNull(adoRecSet!Unit) = False Then .cmbUnit.Text = adoRecSet!Unit
If IsNull(adoRecSet!Max) = False Then .txtQtyMax = adoRecSet!Max
If IsNull(adoRecSet!Min) = False Then .txtQtyMin = adoRecSet!Min
If IsNull(adoRecSet!Rate) = False Then .txtRate = adoRecSet!Rate
End With
adoRecSet.Close

frmAddStock.Show vbModal
Unload frmAddStock
End Sub

Private Sub tvw_NodeClick(ByVal Node As MSComctlLib.Node)
Dim Ky As String, pKy As String 'faster to read vars than properties
Dim oldstrTable As String
Ky = Node.Key
If Node.Key <> "IE" Then pKy = Node.Parent.Key

oldstrTable = strTable

If Ky = "Interface" Then Exit Sub 'cant think of any use for it
mnuStockEdit.Enabled = False  'will enable only if tvw stockitem is selected

Dim strOrder As String

'on table change, clear iColSort so have static strTable and strFilter = strSql
If pKy = "All Items" Or pKy = "Raw Materials" Or pKy = "Components" Or pKy = "Consumables" Then
  'give option to show stock in opr stock out in top pane and load accordingly
  strTable = "StockIn"
  strSql = "select * from StockIn  where item = '" & Node.Text & "'"

  'strTable = "StockOut"
  'strSql = "select * from StockOut  where item = '" & Node.Text & "'"
  mnuStockEdit.Enabled = True
ElseIf pKy = "Jobs" Then
  strTable = "StockOut"
  strSql = "select * from StockOut  where WO_No = '" & Node.Text & "'"
ElseIf pKy = "MRN" Then
  strTable = "StockIn"
  strSql = "select * from StockIn  where MRN_No = " & Node.Text

ElseIf Ky = "Raw Materials" Or Ky = "Components" Or Ky = "Consumables" Then
'maybe ask for what the user wants to see each time either 'all raw matls' or 'all raw matls in' or 'all raw matls out'
  strTable = "StockItems"
  strSql = "select * from StockItems where Category = '" & Ky & "'"
ElseIf Ky = "All Items" Then
  strTable = "StockItems"
  strSql = "select * from stockItems": strOrder = " order by Item asc"
ElseIf Ky = "Category" Then
  strTable = "StockItems"
  strSql = "select * from StockItems": strOrder = " order by [Category] asc"
ElseIf Ky = "Damages" Then
  strTable = "StockOut"
  strSql = "select * from StockOut where damaged = true"
ElseIf Ky = "Jobs" Then
  strTable = "Jobs"
  strSql = "select * from Jobs": strOrder = " order by [WO_Date] desc"
ElseIf Ky = "Stock In" Then
  strTable = "StockIn"
  strSql = "select * from stockin": strOrder = " order by [Date] desc"
ElseIf Ky = "Stock Out" Then
  strTable = "StockOut"
  strSql = "select * from stockout": strOrder = " order by [Date] desc"
ElseIf Ky = "MRN" Then
  strTable = "MRN"
  strSql = "select * from MRN": strOrder = " order by [Date] desc"
ElseIf Ky = "Monthly Reports" Then
  strTable = "Monthly Reports"
  strSql = "select * from MonthlyReports"
ElseIf pKy = "Monthly Reports" Then
  strSql = "": strTable = ""
Else
  Exit Sub

End If

If strSql = "" Then Exit Sub
'now that sql has been (after askin user what he wanted to see) set
LockWindowUpdate lvw.hwnd
  If oldstrTable <> strTable Then loadLvwCols
  loadLvwFields strOrder
LockWindowUpdate 0

End Sub

Private Sub vlin_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
vMoving = True: vlin.BackColor = &H808080
End Sub

Private Sub vlin_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
Dim vpos As Single
If vMoving Then
  vpos = x + vlin.Left
  If vpos < 2000 Then vpos = 2000
  If vpos > Me.Width / 2 Then vpos = Me.Width / 2
  vlin.Left = vpos
End If
End Sub

Private Sub vlin_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
vMoving = False: vlin.BackColor = Me.BackColor
vSiz
End Sub

Private Sub vSiz()
tvw.Width = vlin.Left
lvw.Left = vlin.Left + vlin.Width
lvw.Width = Me.ScaleWidth - lvw.Left
End Sub


'------------------------------------------------------------
' Author:  Clint LaFever [lafeverc@saic.com]
' Purpose:  Exports the ListView to the selected file using
'                the CEXCEL class.
' Date: November,27 2001 @ 11:38:15
'------------------------------------------------------------
Private Sub ExportIt(fNAME As String)
    On Error GoTo ErrorExportIt
    Dim obj As CEXCEL, itm As ListItem, x As Long, y As Long
    '------------------------------------------------------------
    ' Extract that template workbook file from the
    ' resource file to the selected file name
    '------------------------------------------------------------
    GenFileFromRes 101, "XLS", "XLS", , , fNAME
    Set obj = New CEXCEL
    With obj
        '------------------------------------------------------------
        ' Opens the workbook hidden.
        '------------------------------------------------------------
        .OpenExcel fNAME
        '------------------------------------------------------------
        ' Set the name of Sheet 1
        '------------------------------------------------------------
        .XL.Sheets(1).Name = tvw.SelectedItem.Text
        '------------------------------------------------------------
        ' Loop the column headers and write them to row 1 on sheet 1
        '------------------------------------------------------------
        For x = 1 To lvw.ColumnHeaders.Count
            .WriteToCell lvw.ColumnHeaders(x).Text, 1, Chr(64 + x), 1
        Next x
        '------------------------------------------------------------
        ' Loop each listitem and write out the data
        '------------------------------------------------------------
        For x = 1 To lvw.ListItems.Count
            Set itm = lvw.ListItems(x)
            .WriteToCell itm.Text, 1, "A", x + 2
            For y = 1 To lvw.ColumnHeaders.Count - 1
              .WriteToCell itm.SubItems(y), 1, Chr(65 + y), x + 2
            Next
        Next x
        '------------------------------------------------------------
        ' I wanted to show the XL property of the class.
        '  It is a direct link back to the Excel Object
        ' pointing to the workbook.  If you know Excel
        ' VBA you can type in any code that Excel will
        ' understand using it.  I resized the first five
        ' columns to 11 with this code then set the selected
        ' cell back to A1
        '------------------------------------------------------------
        '.XL.Sheets(1).Columns("A:E").ColumnWidth = 11
        '.XL.Sheets(1).Range("A1").Select
        
        '------------------------------------------------------------
        ' Here I am adjusting the Page Setup [you can see
        ' it when you hit print preview on the file in Excel.
        '------------------------------------------------------------
          '.XL.Sheets(1).PageSetUp.CenterHeader = "DEMO EXPORT"
          '.XL.Sheets(1).PageSetUp.LeftFooter = "http://vbasic.iscool.net"
          '.XL.Sheets(1).PageSetUp.RightFooter = "Clint LaFever"
        '------------------------------------------------------------
        ' Create a pivot table from the data
        '------------------------------------------------------------
          '.XL.Sheets(1).PivotTableWizard SourceType:=1, SourceData:="'" & .XL.Sheets(1).Name _
              & "'!R1C1:R" & lvw.ListItems.Count + 2 & "C5", TableDestination:="", TableName:="PivotTable1"
          '.XL.Sheets(1).PivotTables("PivotTable1").AddFields RowFields:=Array("ITEM", "Data"), _
              ColumnFields:="STORE"
          'With .XL.Sheets(1).PivotTables("PivotTable1").PivotFields(DateAdd("d", -1, Date))
              '.Orientation = 4
              '.Position = 1
          'End With
          'With .XL.Sheets(1).PivotTables("PivotTable1").PivotFields(DateAdd("d", -2, Date))
              '.Orientation = 4
              '.Position = 2
          'End With
          '.XL.Sheets(1).PivotTables("PivotTable1").PivotFields(DateAdd("d", -3, Date)).Orientation = 4
        '------------------------------------------------------------
        ' Here I am adjusting the Page Setup [you can see
        ' it when you hit print preview on the file in
        ' Excel.
        ' Note: When I created the Pivot Table, it created a new sheet 1 and moved
        ' the other to sheet 2
        '------------------------------------------------------------
          '.XL.Sheets(1).PageSetUp.CenterHeader = "DEMO EXPORT"
          '.XL.Sheets(1).PageSetUp.LeftFooter = "http://vbasic.iscool.net"
          '.XL.Sheets(1).PageSetUp.RightFooter = "Clint LaFever"
          '.XL.Sheets(1).Name = "Pivot"
        .CloseExcel True
    End With
    Set obj = Nothing
    Exit Sub
ErrorExportIt:
    If Not obj Is Nothing Then
        obj.CloseExcel True
        Set obj = Nothing
    End If
    MsgBox Err & ":Error in ExportIt.  Error Message: " & Err.Description, vbCritical, "Warning"
    Exit Sub
End Sub
