VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Object = "{FE0065C0-1B7B-11CF-9D53-00AA003C9CB6}#2.0#0"; "MSCOMCT2.OCX"
Begin VB.Form frmIssueStock 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Issue Stock"
   ClientHeight    =   6090
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5940
   BeginProperty Font 
      Name            =   "Verdana"
      Size            =   9.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6090
   ScaleWidth      =   5940
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdAdd 
      Caption         =   "Add Item"
      Height          =   375
      Left            =   3840
      TabIndex        =   16
      Top             =   2400
      Width           =   1455
   End
   Begin VB.CheckBox chkDamaged 
      Caption         =   "Damaged"
      Height          =   375
      Left            =   2520
      TabIndex        =   15
      Top             =   2400
      Width           =   1215
   End
   Begin VB.ComboBox cmbProduct 
      Height          =   360
      Left            =   1200
      Sorted          =   -1  'True
      Style           =   2  'Dropdown List
      TabIndex        =   14
      Top             =   720
      Width           =   4335
   End
   Begin VB.TextBox txtQty 
      Height          =   375
      Left            =   1680
      TabIndex        =   11
      Top             =   2400
      Width           =   615
   End
   Begin VB.ComboBox cmbItems 
      Height          =   360
      Left            =   960
      Sorted          =   -1  'True
      Style           =   2  'Dropdown List
      TabIndex        =   10
      Top             =   1920
      Width           =   4575
   End
   Begin VB.TextBox txtTaken 
      Height          =   360
      Left            =   4560
      TabIndex        =   8
      Top             =   1200
      Width           =   975
   End
   Begin VB.ComboBox cmbWO 
      Height          =   360
      Left            =   3720
      Sorted          =   -1  'True
      Style           =   2  'Dropdown List
      TabIndex        =   3
      Top             =   240
      Width           =   1815
   End
   Begin VB.CommandButton cmdCancel 
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   375
      Left            =   3383
      TabIndex        =   2
      Top             =   5520
      Width           =   1575
   End
   Begin VB.CommandButton cmdIssueStock 
      Caption         =   "Issue Items"
      Default         =   -1  'True
      Height          =   375
      Left            =   1223
      TabIndex        =   1
      Top             =   5520
      Width           =   1695
   End
   Begin MSComctlLib.ListView lvw 
      Height          =   2415
      Left            =   240
      TabIndex        =   0
      Top             =   2880
      Width           =   5415
      _ExtentX        =   9551
      _ExtentY        =   4260
      View            =   3
      LabelWrap       =   -1  'True
      HideSelection   =   0   'False
      FullRowSelect   =   -1  'True
      _Version        =   393217
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      NumItems        =   3
      BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         Text            =   "Item"
         Object.Width           =   2540
      EndProperty
      BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   1
         Text            =   "Qty"
         Object.Width           =   1499
      EndProperty
      BeginProperty ColumnHeader(3) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   2
         Text            =   "D"
         Object.Width           =   1058
      EndProperty
   End
   Begin ComCtl2.DTPicker dtIssue 
      Height          =   375
      Left            =   960
      TabIndex        =   9
      Top             =   240
      Width           =   1935
      _ExtentX        =   3413
      _ExtentY        =   661
      _Version        =   393216
      Format          =   24510465
      CurrentDate     =   37800
   End
   Begin VB.Line Line1 
      BorderWidth     =   2
      X1              =   360
      X2              =   5520
      Y1              =   1800
      Y2              =   1800
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Qty"
      Height          =   240
      Index           =   3
      Left            =   1200
      TabIndex        =   13
      Top             =   2460
      Width           =   360
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Item"
      Height          =   240
      Index           =   1
      Left            =   360
      TabIndex        =   12
      Top             =   1980
      Width           =   450
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "TakenBy"
      Height          =   240
      Index           =   5
      Left            =   3480
      TabIndex        =   7
      Top             =   1320
      Width           =   840
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Product"
      Height          =   240
      Index           =   4
      Left            =   360
      TabIndex        =   6
      Top             =   780
      Width           =   765
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "Date"
      Height          =   240
      Index           =   2
      Left            =   360
      TabIndex        =   5
      Top             =   307
      Width           =   465
   End
   Begin VB.Label lbl 
      AutoSize        =   -1  'True
      Caption         =   "WO #"
      Height          =   240
      Index           =   0
      Left            =   3120
      TabIndex        =   4
      Top             =   300
      Width           =   570
   End
End
Attribute VB_Name = "frmIssueStock"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmbItems_Click()
If cmbItems.Text = "... Add New Stock Item ..." Then
  frmAddStock.Show vbModal
  If frmAddStock.NewStockName <> "" Then
    cmbItems.AddItem frmAddStock.NewStockName
    cmbItems.Text = frmAddStock.NewStockName
  End If
  Unload frmAddStock
End If
End Sub

Private Sub cmbWO_Click()
cmbProduct.Clear

Dim var, i As Integer

Set adoRecSet = adoConn.Execute("select * from jobs where WO_No = '" & cmbWO.Text & "'")
  If adoRecSet.EOF = False Then
    var = Split(adoRecSet!OrderFor, ",")
    adoRecSet.Close
    For i = LBound(var) To UBound(var)
      Set adoRecSet = adoConn.Execute("select * from Products where ProductID = " & var(i))
        If adoRecSet.EOF = False Then cmbProduct.AddItem adoRecSet!Product
      adoRecSet.Close
    Next
  End If
If cmbProduct.ListCount > 0 Then cmbProduct.ListIndex = 0
End Sub

Private Sub cmdAdd_Click()
'first see if product already added
For Each itm In lvw.ListItems
  If itm.Text = cmbItems.Text Then MsgBox "Item already added": Exit Sub
Next

If cmbItems.ListIndex < 1 Then MsgBox "Must select a Stock Item first.", vbInformation: cmbItems.SetFocus: Exit Sub

'lvw.ListItems.Clear
Set itm = lvw.ListItems.Add(, , cmbItems.Text)
itm.SubItems(1) = txtQty
If chkDamaged.Value = 1 Then itm.SubItems(2) = "True" Else itm.SubItems(2) = "False"

End Sub

Private Sub cmdCancel_Click()
Unload Me
End Sub

Private Sub cmdIssueStock_Click()
Dim m As VbMsgBoxResult
m = MsgBox("Are you sure you have entered everything" & vbCrLf & "accurately and wish to proceed?", vbQuestion + vbYesNo)
If m = vbNo Then Exit Sub

'verify if stock issue detls are proper
If cmbWO.ListIndex < 0 Then MsgBox "Must enter 'Work Order Number' before you can proceed.", vbInformation: Exit Sub
If Len(txtTaken) = 0 Then
  m = MsgBox("There is no mention of who is collecting the parts. Do you wish to proceed?", vbQuestion + vbYesNo)
  If m = vbNo Then Exit Sub
End If

If lvw.ListItems.Count = 0 Then _
  MsgBox "You cannot proceed without entering the stock items that are being issued.", vbInformation: Exit Sub
  

'add to stock out table
Dim strVals As String
For Each itm In lvw.ListItems
  strVals = ""
  strVals = "'" & dtIssue.Value & "','" & cmbWO.Text & "','" & cmbProduct.Text & "','" & _
          itm.Text & "'," & itm.SubItems(1) & ",'" & txtTaken & "'," & itm.SubItems(2)
  
  adoConn.Execute "insert into stockout values (" & strVals & ")"
  adoConn.Execute "update stockitems set Balance = Balance - " & itm.SubItems(1) & ", stockvalue = (balance - " & itm.SubItems(2) & ")* rate where item = '" & itm.Text & "'"
Next

Unload Me

End Sub

Private Sub Form_Load()

'add undelivered WO Nos
Set adoRecSet = adoConn.Execute("select * from jobs") ' where deliverydate = vbnull")
  Do Until adoRecSet.EOF
    If adoRecSet!delivered = False Then cmbWO.AddItem adoRecSet!WO_No
    adoRecSet.MoveNext
  Loop
adoRecSet.Close
  

'add stock items
cmbItems.AddItem "... Add New Stock Item ..."
Set adoRecSet = adoConn.Execute("Select * from stockitems")
  Do Until adoRecSet.EOF
    cmbItems.AddItem adoRecSet!Item
    adoRecSet.MoveNext
  Loop
adoRecSet.Close

'sync date
dtIssue.Value = Date
End Sub

Private Sub Form_Resize()
lvw.ColumnHeaders(1).Width = lvw.Width - 1900
End Sub

Private Sub lvw_KeyDown(KeyCode As Integer, Shift As Integer)
If KeyCode = vbKeyDelete Then
  For Each itm In lvw.ListItems
    If itm.Selected = True Then GoTo Nxt
  Next
  Exit Sub
Nxt:
  Dim m As VbMsgBoxResult
  m = MsgBox("Sure you are cancelling" & vbCrLf & lvw.SelectedItem.Text & vbCrLf & "from this order?", vbQuestion + vbYesNo, "Confirm Product Cancellation")
  If m = vbYes Then lvw.ListItems.Remove (lvw.SelectedItem.Index)
End If
End Sub

