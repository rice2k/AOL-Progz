VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmProjectComplete 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Select kobs that have been completed"
   ClientHeight    =   4065
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5490
   BeginProperty Font 
      Name            =   "Verdana"
      Size            =   9.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4065
   ScaleWidth      =   5490
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdCancel 
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   375
      Left            =   2918
      TabIndex        =   2
      Top             =   3600
      Width           =   1695
   End
   Begin VB.CommandButton cmdComplete 
      Caption         =   "Complete Jobs"
      Default         =   -1  'True
      Height          =   375
      Left            =   878
      TabIndex        =   1
      Top             =   3600
      Width           =   1815
   End
   Begin MSComctlLib.ListView lvw 
      Height          =   3255
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   5175
      _ExtentX        =   9128
      _ExtentY        =   5741
      View            =   3
      LabelEdit       =   1
      LabelWrap       =   -1  'True
      HideSelection   =   0   'False
      Checkboxes      =   -1  'True
      _Version        =   393217
      ForeColor       =   -2147483640
      BackColor       =   -2147483643
      BorderStyle     =   1
      Appearance      =   1
      NumItems        =   2
      BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         Text            =   "WO_No"
         Object.Width           =   2646
      EndProperty
      BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
         SubItemIndex    =   1
         Text            =   "Company Name"
         Object.Width           =   2540
      EndProperty
   End
End
Attribute VB_Name = "frmProjectComplete"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdCancel_Click()
Unload Me
End Sub

Private Sub cmdComplete_Click()
Dim tot As Integer, m As VbMsgBoxResult
For Each itm In lvw.ListItems
  If itm.Checked Then tot = tot + 1
Next

m = MsgBox("Are you sure we have Delivered " & tot & " jobs?", vbYesNo + vbQuestion, "Job Completion Confirmation")
If m = vbNo Then Exit Sub

For Each itm In lvw.ListItems
  adoConn.Execute "update jobs set Delivered = yes where WO_No = '" & itm.Text & "'"
  frmMain.tvw.Nodes("Jobs\" & itm.Text).Image = 9
Next

Unload Me
End Sub

Private Sub Form_Load()

Set adoRecSet = adoConn.Execute("select * from jobs where Delivered = no")
Do Until adoRecSet.EOF
  Set itm = lvw.ListItems.Add(, , adoRecSet!WO_No)
  itm.SubItems(1) = adoRecSet!Customer
  If adoRecSet!Delivered = True Then itm.Checked = True
  adoRecSet.MoveNext
Loop
End Sub

Private Sub Form_Resize()
lvw.ColumnHeaders(2).Width = lvw.Width - 2500
End Sub
