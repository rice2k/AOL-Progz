(c)2005 Screen saver by mclodo
freeware
INSTALLATION:
run install.bat and go to windows screensaver screen
lancez install.bat et allez sur l'ecran des screensavers
