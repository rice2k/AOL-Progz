copy FeuD'artifice-MCLD.scr c:\windows\system32\
copy back.jpg c:\windows\system32\
copy SDL_image.dll c:\windows\system32\
copy SDL.dll c:\windows\system32\
