Run '8 Ball.exe'

Type in question and press the 'Ask button'

Message box will appear with question you asked and answer

Question and answer will save in 'Questions.log' file situated in the same folder that the program is in.


CREATED BY BEN LEED