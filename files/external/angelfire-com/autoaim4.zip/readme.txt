autoaim.d2h

version 4

Changed it so you can use leftclick with autoaiming.(Check function list)


EMAIL = ViperOfHell@attbi.com

IF U FIND BUGS!

1) .load autoaim

2) .autoaim on MyPKChar      (This makes it so you do not target yourself! This basically puts you on the ignore list so make sure its your Chracter's Name!)

3) run around and log the characters(Easiest way is to run away so nobody is on your map then run back to them OR use .autoaim on while nobody is on your map!), the screen will say CHARACTERNAME Logged into Slot #.

4) Use next, current, previous to switch targets(good idea to BIND keys with these 3 commands with bind.d2h!)

5) Hold down rightclick or leftclick when u have target selected (You will not see where the guided arrow is really going, way to tell you have hit them is if your leaching life)

GUIDED ARROWS AND FoH HAVE A LIMIT ON HOW FAR THEY CAN GO!


__________________________________________________________
.autoaim on <My Character Name>		

Turns Auto Aiming on and starts logging characters in the game.  Ignores your 
character's name from being a target of the autoaim.

__________________________________________________________
.autoaim next

Switches to the next target.

__________________________________________________________
.autoaim previous

Goes backwards through targets.

__________________________________________________________
.autoaim current

Shows current target.

__________________________________________________________
.autoaim targetlist

Shows list of targets.

__________________________________________________________
.autoaim ignore	<Character Name>

Ignores character.

__________________________________________________________
.autoaim unignore <Character Name>

Unignores character.

__________________________________________________________
.autoaim ignorelist

Shows a list of players ignored.

__________________________________________________________
.autoaim rightclick <on> or <off>

Turns on or off Autoaiming for Rightclick (default is ON!)

__________________________________________________________
.autoaim leftclick <on> or <off>

Turns on or off Autoaiming for LeftClick (default is OFF!)

__________________________________________________________
.autoaim off

Turns autoaim off.
