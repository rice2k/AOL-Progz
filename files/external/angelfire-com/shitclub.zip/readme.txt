Shoot S Club 7!!!	7th November 1999

Hi there, Colm here.
Master Mayhem and I have worked together to modify an old game of his into 'Shoot S Club 7'.

Hope you enjoy it, it's all pretty self explanitory.

Send any particularly high scores you get to me at colmwhitehouse@hotmail.com and I'll put them on the page. Oh, and I may ask for proof that you got that score. Sorry.

Seeya

Colm