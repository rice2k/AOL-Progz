Dear "Million Dollar Emails" Owner,

Thank you for your purchase of Million Dollar Emails.

Remember, you get the full resell rights to MDE, so you can
actually make some serious money just by selling MDE. We talk
about the 2 different ways to do this at:

http://www.profitjump.com/milliondollaremails/affiliates.html

If you've selected "Solution #2" and have already signed up
as a reseller at:

http://www.profitjump.com/rbot/

you would have received your ROIbot affiliate ID by now. Your
affiliate link to promote MDE is:

http://www.roibot.com/mde.cgi?ROIbotID_campaign

Make sure you replace "ROIbotID" with your own affiliate ID.

You'll notice that the word "campaign" appears at the end of
the URL. A campaign is anything you are doing to sell
products -- such as sending an article to your newsletter
subscribers or putting an ad up on your site. Replace
"campaign" with your own campaign names and we'll keep track
of the results of each of your affiliate campaigns.

To view your sales and campaign stats, log into your
affiliate area at:

http://www.profitjump.com/rbot/

I've included some sample classified ads and headlines, as
well as a solo ad that has consistently brought me double-
digit response rates. Use this solo ad and watch your sales
soar!

All the best,

Alan Yap
http://www.profitjump.com


---------------


Sample Solo Ad:


Hi,

Believe it or not we've made special arrangements for
you to pull in thousands of dollars each week on the
Internet with a simple 3-Step-System called...

"Million Dollar Emails" -- for a one-time price of
only $1...

http://www.roibot.com/mde.cgi?ROIbotID_campaign

But ONLY if you hurry over now and don't miss the
deadline today.

Just when you thought how ridiculous this is, you'll be
totally amazed at the value of the Surprise Bonus Gift
that we've prepared for you here:

http://www.roibot.com/mde.cgi?ROIbotID_campaign
<a href="http://www.roibot.com/mde.cgi?ROIbotID_campaign">
AOL HotLink </a>

Hmmm... I wonder how quickly you're going to act
this time.


To your success,

Your Name

P.S. Please profit with us on the Net and don't miss
the deadline to get your risk-free "Million Dollar
Emails" for the special price of ONLY $1...
http://www.roibot.com/mde.cgi?ROIbotID_campaign


---------------


Sample Ezine Classified Ads:

============================================================
SPECIAL NOTICE: To Our Readers - We want to let you know
about a new resource filled with winning email campaigns to
model, copy and swipe. It's called "Million Dollar Emails"
and you can find out more here:
===>  http://www.roibot.com/mde.cgi?ROIbotID_campaign
REVEALED! Insider secrets to profitable email marketing
============================================================

============================================================
===> New Resource Reveals The Amazing Secrets Behind
The Net's Most Successful Email Campaigns
How to make a fortune with permission email marketing!
Check out  =====>
http://www.roibot.com/mde.cgi?ROIbotID_campaign
============================================================

************************************************************
If you know how to send out simple emails - I'll show you
exactly how these Internet Pros are making a fortune...and
you can too! Click...Send...Make Money!
=======>  http://www.roibot.com/mde.cgi?ROIbotID_campaign
************************************************************


---------------


Sample Headlines For Text Links:

Now, you can get an entire collection of winning emails for
you to model, copy and swipe. (Plus you can turn around and
sell this incredible resource and keep all the money!)

How to Create Powerful, Money-Making Emails to sell any
product or service...100% Guaranteed

At Last! You can get your hands on the ultimate collection of
winning Emails from the top Internet pros!

Introducing the Greatest Collection of Winning Emails for you
to copy, swipe and model

REVEALED! Insider secrets to profitable email marketing

How to make a fortune with permission email marketing

How to create instant profits with virtually zero cost...
simply using the secrets of *legal* opt-in email marketing

If you know how to send out simple emails - I'll show you
exactly how these Internet Pros are making a fortune...and
you can too!

Now! You can discover the insider secrets these top Internet
pros are using to create a fortune online with email
marketing

New resource reveals the insider secrets these top Internet
pros are using to create a fortune online with email
marketing

Released at last - the greatest collection of moneymaking
emails ever!

The amazing secrets behind the most successful email
campaigns of all time

Today...earn thousands with a simple email campaign for less
than a Tuna sandwich

What everybody ought to know about "opt-in" and "permission"
email marketing

Finally! Discover The Secrets of the Net's Best-Selling
Emails

Discover the jealously guarded secrets to creating powerful
emails that sell like crazy!

One powerful email campaign can make your business a fortune

How much is one good email campaign worth to your business?

If you need help writing compelling and powerful emails -
this new ebook is for you

Announcing...A new resource that can help you create your
own million dollar email

Now available at your fingertips - an entire arsenal of
powerful, money-making emails to model, study and learn from
- guaranteed to help sell more of your product or service!

Winning emails that sell like crazy! Don't spend another
minute struggling to write your own series without this
powerful resource


