=============================
=============================
===  WaRPeD SeRVeR v2.0l  ===
=============================
=============================


Build Time: 11:00PM - 21 APR 04
===============================


Important notes before use:
===========================

1. Install Notes

a. Install VB 6 Runtimes: (link on warped server website also)

   http://download.microsoft.com/download/vb60pro/Redist/sp5/WIN98Me/EN-US/vbrun60sp5.exe

b. Install winsock version 2 if you dont have it. Windows 98 SE and up will have it.

c. read this whole readme.txt file for help and if that dont work message me.

d. "DO" let the clicker run provided. Its there for a reason.

e. Also it does a have speed control for slower machines =[.

f. Put the font provided in your c:/windows/fonts folder and the server will look better.

g. if you get on refresh subscript 9 out of range. either aol died or you got a mail the
   server can not read. so watch to see where it stops. most likely itll be the same spot
   everytime and its a bad mail. Like one without a subject.


2. If updating to a newer version and have pending move the pending.txt from the older 
   verison to the new verison's folder. along with the rest of the text files.
 


------------------------------------------------------------------------------------------

Index:
======

I. Version changes
II. File check
III. Support
IV. Credits


------------------------------------------------------------------------------------------


I.   Version changes:
=====================

note: (please read notes form pervious version for most questions you have. then ask for help.)

any bugs please report immediately!


v2.0l
-----

notes: 

- when you update always replace the warpedclicker.exe too
- aim colors can be either #000000 or blue. works with both

a. fixed the fwd: bug that left it in the mail subject of the mail being sent
b. added support to serve on both aim and irc at the same time. however you dont have to
   connect either one of your liking. if you just want to finish your pending disconnect both.
c. added to user setting tab aim motd. so aim and irc have their own. so you dont have to see
   the color thing on aim that mirc uses.
d. reconnect on disconnection supported finally 100%. if aim or irc dies itll auto reconnect in
   20 seconds as long as you didn't manually disconnected it by pressing the button. it
   also will go server by server in the combo boxes over and over until it gets on aim or irc.
e. regular bnc now supported. not just psybnc. look for this to be improved further.
f. warpedserver.exe is alot smaller now as the code has been more optimized
g. modified interface a little to allow room for the aim chat textbox and connect button
h. removed the step and moved deadmail count to its place. this was to make room for the aim
   connection status


v2.0k
-----

notes: 

- should get some great sessions out this mod.
- when you update always replace the warpedclicker.exe too
- if you run the aol restart like ever 2000 youll get alot less to 0 waols


a. new interface that can be rolled up and is bit smaller
b. fixed the delete sent bugs. should work pretty good now. any issues report please
c. patched the mail fwd: caption bug for the mail thats being forwarded that hung the server
   when the mail in incoming/saved was forwarded and the fwd: wasnt removed before it was 
   flashed to incoming saved mail. since the sub looking for the window after you click
   forward looks for fwd: you can see two windows with fwd: in the title is a problem. so
   i made a check for that and if it exist it removes it changes the title by removing the
   fwd: from it.
d. rebuilt the mail write sub to help rpevent waols from clicking the fuck out the send now
e. updated clicker to close aol when waol comes up "america online error" which hangs aol and 
   the server until you close aol
f. updated aol restart to work faster
g. added tool tips to each setting to help explain what each is for



v2.0j
-----

a. patched the mail resize form and unresize . can see it works alot smoother now when you
   start and stop.
b. patched winsock bug that could kill servers if certain msgs are typed
c. removed the notice server stopped since its not needed. 
d. ims off removed as aol no longer supported the feature of $im_on and $im_off
e. fixed aim reconnect if logged out and still serving itll now auto reconnect like its 
   suppose too
f. added a status scroll to be shown for aim when you break the rate limit.


v2.0i
-----

notes: first version with aim built in please read all notes below

- you can only serve on aim or irc not both
- if you dont want to serve in three rooms on aim then type in none for the others
- when you logon to aim wait until it says joined the rooms or itll go greet crazy
  if you start it after your on the rooms it doesnt greet whose there
- if you cant reconnect change aim servers
- all notices are ims to the aoler so if they got you on block its not your fault
- if the greeting is getting you rate limited turn it off and let me know. this is the first
  version
- recommend 60 second scrolls to prevent rate limiting


a. aim serving built into server. has a tab in settings to put in username and pass and one 
   to three rooms youwish to join to serve in.
b. patched clicker so it dont hang aol
c. patched send later sub to press escape to bail if it hangs after 15 seconds
d. added a secondary check for left over windows to close them


v2.0h
-----

a. patched a bug in the aol restart that made it hang occassionally after it signed on and 
   stayed there
b. modified mail sending code into one master sub to control errors easier. should never
   get stuck with new code layout being reduntant
c. made a patch for pausing to reset scrolltimer so you dont get a flood on irc when you
   unpaused the server.
d. patched bnc password bug where it didnt update the password for winsock


note: possible aim serving addon coming, cant promise. will use winsock also if i decide to   
      add it into the server


v2.0g
-----

a. blocked the bad sn bug that runtimed the server. i wont list that sn out of courtesy to
   those that are on older mods
b. patched html list background color bug
c. patched clicker bug that left it open after the server was closed
d. patched step 3 occassional infinite loop bug. should not get stuck in the loop no more 
   on step 3



v2.0f
-----

a. patched case bug for requests where users typed /handle Send sn 1-10 and it confirmed but
   didnt really add the request
b. improved the greet flood control (especially helps on netsplits)
c. modified the status replies to be more uniform
d. added ircusername field to fix the username outcast problem for psybnc
e. modified the stuck control to work properly (wasnt doing nothing for some reason before)



v2.0e
-----

a. fixed a major bug in the multisend that only sent to the first person that requested it
b. added a delete sent option to help older pcs. if you have a newer pc id suggest dont 
   use it.
c. converted status box from textbox to listbox
d. updated warped clicker to catch the new waol
e. converted the status lines to be uniform


v2.0d
-----

a. added a stuck control to restart aol if server gets stuck for more than 60 secs
b. improved irc connection check
c. little more delay on aol restart to make it more reliable

forgot the rest but it was little things =]


v2.0c
-----

a. patched greeting dupe greeting problem
b. patched fwd loops causing server to get stuck occassionally
c. modified the list making buttons to make sense to the user
d. added a 30 minute disconnection check for irc to reconnect it irc died
e. modified the html to upload ot the default folder instead of the private folder on
   aol because or a quota on the folder
f. patched status notice bug
g. patched the occassional left over mail that confused the server. now it will close
   after the send.



v2.0b
-----

a. patched the internal mail error that it didnt close and made it get stuck
b. patched send o and send later loops that sometimes made it get stuck
c. fixed some typos which im good for on the labeling
d. modified the main scroll visualization a bit
e. flood control for netsplits and the greeting


v2.0
----

a. new interface, new sending subs, new error controls, lots of beta testing for stability,
   instant logging, stil lthe same name and still a great server.




II.  File check:
================

1. The following files should be in this release rar file.

a. warpedserver.exe

b. find.db

c. SSTAB.dll

d. Bank Gothic MD (font)

e. Warped Clicker.exe (temp fix for waol error)

f. readme.txt (your reading it now)

g. servers.txt

h. MSWNSOCK.dll

i. TOCSOCK.ocx



III. Support:
=============

1. contact outcast one of the following methods

a. aim: jiggaoutcast
b. email: outcast@imperial2k.com


IV. Credits:
============

a. Fates: fates got me going and ive been picking up since. He did do alot of the initial
   coding on the server.

b. martyr: guys is one of the few like Fates & Latino that are approachable for programming.
   much thanks to martyr for the bas file and some of the sub routines he shared.

c. Latino: for the help in understanding vb and many other things. the help hes given martyr 
   for the chatscan that will soon be replace on inept and warpeded server by marty's 
   chatscan.ocx. also for the finds on the server list. 

d. Beta Testers: jc, diva, jr, xy2, LadyA, pnt, martyr, med, more to come

