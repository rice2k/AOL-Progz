Run 'Spokes.exe'

This was my first ever program! :D

A good number for 'Number of spokes' is about 50-150
Any more than 1000 could crash the program, but experiment!

The increment is best between 1-5, depending on the amount of spokes
Recommended increment of 1 to get best results

Spokes (mod) has a button placed down the bottom of the screen allowing you to save the picture

Source code added into zip folder

CREATED BY BEN LEED