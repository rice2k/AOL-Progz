Run 'Movement.exe'

Try and click the target!

Making the dificulty harder will allow for much smaller times and therefore better results

Making the difficulty easier will make things harder to get a good time.


CREATED BY BEN LEED