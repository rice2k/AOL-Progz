Dominicks StarCraft Gateway has had many requests to use it's menu
graphics.  So I made this zip file of generic menus that you can use
on your website.  Feel free to use THESE menus as your own.  If there
is one you need that is not here, email the site and you can request
a new menu.

dominickbernal@yahoo.com

Thank you.