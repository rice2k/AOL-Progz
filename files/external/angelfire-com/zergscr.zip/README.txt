<~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~>
 > 							     <
<    	        Zergs ScreenSaver for Win95/98 		      >
 >							     <
<     	          by DaxTar RedOx, Dec 1998	              >
 > 							     <
<	  Web   : www.geocities.com/Area51/Orion/1343/	      >
 >	  EMail : DaxTar.RedOx@gmx.net			     <
<							      >
 ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 


Installation
~~~~~~~~~~~~~
  Copy the File "Zerg Saver.scr" into your windows directory
  Choose the ScreenSaver "Zerg Saver" in the list of available
  Savers.

  Run "Settings" to
    - switch of sound (blobb if Zerg is disappearing)
    - adjust Zerg's movement speed
    - adjust the number of moving Zergs


Thanx to
~~~~~~~~~
  my brother Daniel
  Blizzard for their fantastic fantasy and strategy games