_________________________________________________________
Map: Evil_Empire
bsp: Evil_Empire.bsp
*********************************************************
Authors:
NoodleHammer
Mr. Yuk
*********************************************************
Description:
This map is a large castle with a dungeon area.
It is quite large and all weapons are included.
 It will support 12-32 players. 
custom textures by David Guerra and noodle.
*********************************************************
Installation: Just unzip to your halflife\valve\maps directory.
*********************************************************
Tools used:
Hammer 3.4
wally
Merl's build of Zoners tools
*********************************************************
Hint: The egon is behind the horned skull. Just shoot it in its third
          eye to gain access.
           The guass is behind a wooden door, but be careful!
*********************************************************
Thanks to mimicmaster and 2ez2kill for beta testing.
*********************************************************
Contact: jonnyevilseed@hotmail.com
                 thecrippler65@yahoo.com 
_________________________________________________________



