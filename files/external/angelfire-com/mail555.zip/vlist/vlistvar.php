<?php
if (ok == 'ok') {
} else {
header( 'Location: index.php');
exit;
}
?>
<?
$listname='���� �������';
$listaddress='albakr@albakr.net';
$adminaddress='saleh1267@hotmail.com';
$siteaddress='http://www.albakr.net';
$vlisturl='http://www.albakr.net/vlist/vlist.php';
$pw='albakr';
$un='albakr';
$bgcolor='#999966';
$border='#000000';
$linkbar='#fff000';
$header='#003399';
$textbg='#ffffff';
$linkcolour='#222222';
$vlinkcolour='#444444';
$bartext='{font-family:VERDANA,arial;font-size:9pt;font-weight:bold;color:#ffffff}';
$main='{font-family:VERDANA,arial,helvetica;font-size:8pt;font-weight:normal;color:#000000}';
$linkclass='{font-family:VERDANA,arial,helvetica;font-size:8pt;font-weight:normal;color:#000000}';
$emp='{font-family:VERDANA,arial,helvetica;font-size:8pt;font-style:italic;color:#ffffff}';
$linkblaa='';
?>