VLIST 1.0 : The Sly Fox
==================
This is a mailing list manager, some little sections of code have been 
nabbed from books and examples - but for the most part Vince Hide
wrote it.

Please read the Legal-ramble file.

If you want support mail vlist@namesweb.co.uk or visit :
http://www.namesweb.ltd.uk/vlh

INSTALL NOTES:
==============

1. Obviously you have unzipped this package
2. Upload the files and folders in the same structure as they are (in ASCII format)
3. CHMOD the following files to 666 :

vlist/vlistvar.php 
vlist/data/vlist.db
vlist/data/vlist.log

4. Visit http://www.your-site.co.uk/vlist and login :

Username : test
Password : test

5. Click the link to administrate, Click the 'vlist settings' link
6. Customise your list
7. Click 'subscribe box' link , copy the auto-generated code and paste within your pages
8. You are up and running.

9. If you are stuck mail vlist@namesweb.co.uk

10. The data folder is vunerable, we advise that you use the sample .htaccess file supplied.