Run 'Text Cricket.exe'

This was my biggest ever program to date! :D

Start menu allows for Team Select

'View Scorecard' views all scorecards saved in current directory.

'View team stats' views all the averages and records for players in team
Be sure to have played atleast one game for this feature to work!

Game formats:
************
*'50 overs'*
************
This is traditional 50 over rules
10 overs a bowler
50 overs a team

************
*'20 overs'*
************
This is traditional 50 over rules
40 overs a bowler
20 overs a team

*************
*'1 innings'*
*************
New feature
3 days
1 innings

*************
*'2 innings'*
*************
Similer to test match
5 Days
2 innings
No follow on

'Bowler select'
This feature allows you to select what bowler bowls each over
If not selected this will be done at random providing the bowlers total ability is above 11
To select bowler in game, click on them (must be done at end of each over)
Start the match:

'Speed'
Change speed of match

'RR Chart'
View the runrate of innings. If game format is NOT '2 innnings' then both teams graphs will appear

'Status'
Shows the other teams score/runs to win/runs behind/runs infront

'Declare'
Stop current innings

'This over'
Shows what happend on each delivery of over

Right click player names to see abilitys



CREATED BY BEN LEED