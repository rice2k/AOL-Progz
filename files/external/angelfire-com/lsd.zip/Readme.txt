ELetr�nica IV Home Page - by Tiba 2000	
www.angelfire.com/de2/eletronica4

Olhe fixamente no centro da imagem em movimento
 por uns 20 ou 30 segundos e depois desvie os 
olhos da tela ou feche a janela.
S� tenha for�a de vontade para nao viciar.