README
-------

Most people think that you need to download the ActiveX internet pack to get WINSCK.OCX installed on your system.  That's not true.  Just follow the steps below to install and register some commonly required DLLs and OCXs, including WINSCK.OCX.  I like this better because ActiveX is over 6MB to download and it gives you a bunch of unnecessary crap.  Just use this ZIP and you get exactly what you need.  Feel free to distribute this anywhere as long as this ZIP is not changed and a link is provided to http://www.deathsdoor.com/paragon. 

Hav phun but dun git kaught :P -- Paragon

----------------------------

Please do the following steps:

1. Unzip this archive to a temporary folder.

2. Copy all the .dll and winsck.ocx to your
   Windows System Directory (c:\windows\system).

2. Double-click Ocx.reg.

3. Restart your computer.

4. That's it!