Run 'Color.exe'

Move the scroll bars to change the color

The 'Red Green Blue' code will appear in the bottom text box

Simply copy that code into whatever you may need it for

Example: You want to change the background of your webpage (or any program etc...) to Orange. 
Use the 'Color.exe' to get desired color. In this case we will use 'rgb(255, 145, 5)'.
And then copy into whatever your needing...like: <body style="background-color:rgb(255, 145, 5);">

Its that simple!

CREATED BY BEN LEED