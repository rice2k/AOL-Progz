This Font was recreated by !DarkArchon! who found the old
set to be of bad quality.  This font was recreated from the
best quality title I could find.  Use it as you wish.
Great for headers and other starcraft related things.
Distibute it freely and have fun.  

Only restrictions are...

1)This file may not be sold.

(That's All!:)