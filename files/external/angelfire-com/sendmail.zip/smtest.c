///////////////////////////////////////////////////////////////////
// SMTEST.C - Test program for Sendmail DLL.
// Author - Arnab Bhaduri.
///////////////////////////////////////////////////////////////////

// includes ///////////////////////////////////////////////////////

#include <windows.h>
#include <stdio.h>
#include <io.h>
#include "sendmail.h"

// defines ////////////////////////////////////////////////////////

// SendMail() function ptr type
typedef BOOL (*BRET)( SENDMAIL *, int *);


///////////////////////////////////////////////////////////////////
int main( int argc, char *argv[] )
{
SENDMAIL  sm;                 // SendMail info structure
HINSTANCE hDLL = NULL;        // Handle to SendMail DLL
BRET      pfn  = NULL;        // Pointer to SendMail() function
FILE     *fp   = NULL;        // Pointer to message text file
long      nLen = -1L;
int       nRet = 0;
char     *buff = NULL;

// check args
if( argc < 4 )
    {
    printf( "\nUsage: %s <recipient> <server> <filename>\n\
    recipient: The mail recipient's name.\n\
    server:    The mail server name, in the form server.domain.com.\n\
    filename:  File containing message in ASCII text format.\n", argv[0] );
    return -1;
    }

// read message text
fp = fopen( argv[3], "rt" );
if( fp == NULL )
    {
    printf( "\nCould not open message file %s\n", argv[3] );
    return -1;
    }

nLen = filelength( fileno(fp) );
if( nLen == -1L )
    {
    printf( "\nCould not read from message file %s\n", argv[3] );
    fclose( fp );
    return -1;
    }
else
    {
    buff = (char *) malloc( nLen );
    if( buff == NULL )
        {
        printf( "\nFailed to allocate memory\n" );
        fclose( fp );
        return -1;
        }
    }

fread( buff, nLen, 1, fp );
fclose( fp );

// send mail message
printf( "\nSending mail message, please wait...\n" );

sm.lpszHost          = argv[2];
sm.lpszSender        = "SM DLL";
sm.lpszSenderName    = "SendMail DLL Test App";
sm.lpszRecipient     = argv[1];
sm.lpszRecipientName = NULL;
sm.lpszReplyTo       = NULL;
sm.lpszReplyToName   = NULL;
sm.lpszMessageID     = NULL;
sm.lpszSubject       = "Test Mail";
sm.lpszMessage       = buff;
sm.bLog              = TRUE;

hDLL = LoadLibrary( "SM.DLL" );
if( hDLL == NULL )
    {
    printf( "\nFailed to load SendMail DLL\n" );
    free( buff );
    return -1;
    }

pfn = (BRET) GetProcAddress( hDLL, "SendMail" );
if( pfn == NULL )
    {
    printf( "\nSendMail DLL is invalid\n" );
    free( buff );
    return -1;
    }

(*pfn)( &sm, &nRet );
FreeLibrary( hDLL );
free( buff );

if( nRet == 0 )
    printf( "\nMail Sent successfully\n" );
else
    printf( "\nFailed to send mail. Please see SENDMAIL.LOG.\n", nRet );

return 0;
}
