/////////////////////////////////////////////////////////////////
// SendMail.h - declares functions and data structures for the
// SendMail DLL.
// Author - Arnab Bhaduri.
/////////////////////////////////////////////////////////////////

#ifndef __SENDMAIL_H__
#define __SENDMAIL_H__


// SendMail defines /////////////////////////////////////////////

#define SMTP_PORT       25
#define MAX_LINE_SIZE   1024
#define MAX_NAME_SIZE   64


// SendMail exported functions //////////////////////////////////
__declspec ( dllexport )
    BOOL SendMail( struct SENDMAIL *pMail, int *pResult );


// SendMail data structures /////////////////////////////////////

typedef struct SENDMAIL {
    LPCTSTR lpszHost;          // host name or dotted IP address
    LPCTSTR lpszSender;        // sender userID (optional)
    LPCTSTR lpszSenderName;    // sender display name (optional)
    LPCTSTR lpszRecipient;     // recipient userID
    LPCTSTR lpszRecipientName; // recipient display name (optional)
    LPCTSTR lpszReplyTo;       // reply to userID (optional)
    LPCTSTR lpszReplyToName;   // reply to display name (optional)
    LPCTSTR lpszMessageID;     // message ID (optional)
    LPCTSTR lpszSubject;       // subject of message
    LPCTSTR lpszMessage;       // message text
    BOOL    bLog;              // if TRUE, log messages to file
} SENDMAIL;

#endif  //  __SENDMAIL_H__

// End //
