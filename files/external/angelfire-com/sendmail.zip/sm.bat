@rem Batch file to build SM.DLL
@rem
@echo Building the SendMail DLL...
@rem
cl.exe /MT /TC /W3 /GD /O1 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /c SendMail.c
link.exe kernel32.lib user32.lib advapi32.lib wsock32.lib /subsystem:windows /dll /machine:I386 /out:"SM.dll" /implib:"SM.lib" SendMail.obj
@rem
@echo Build completed.