@rem Batch file to build SMTEST.EXE
@rem
@echo Building the SendMail Test Application...
@rem
cl.exe /MT /TC /W3 /GD /O1 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /c smtest.c
link.exe kernel32.lib user32.lib /subsystem:console /machine:I386 /out:"smtest.exe" smtest.obj
@rem
@echo Build completed.
