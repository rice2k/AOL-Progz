  LIST      P=16F84, F=INHX8M
            include "P16F84.inc"
            
	    ORG     0x0000
            GOTO    start
            NOP
            NOP
            NOP
            NOP
	    
start    
	    MOVLW   0x55
            MOVWF   0x2a
Label_0002  DECFSZ  0x2a      , f
            GOTO    Label_0002

start2  
Label_0013  CALL    Label_0006
            MOVF    0x12      , W
            XORLW   0x3B
            BTFSS   STATUS    , Z
            GOTO    Label_0013
            MOVLW   0x0F
            MOVWF   0x28
Label_0014  CALL    Label_0006
            DECFSZ  0x28      , f
            GOTO    Label_0014				
	    BCF     TMR0,00

main  	    NOP
	    CALL    receive
            MOVWF   0x16
            XORLW   0xC1
            BTFSS   STATUS    , Z
            GOTO    main
            CALL    receive
            MOVWF   0x0c
            CALL    receive
            MOVWF   0x0d
            CALL    receive
            MOVWF   0x0e
            CALL    receive
            MOVWF   0x0f
            MOVWF   0x10
            MOVF    0x0c      , W
            XORLW   0x34
            BTFSS   STATUS    , Z
            GOTO    ins0e

ins34      
            MOVLW   0x34
            CALL    send				;send ack
	    CALL    receive
	    MOVWF   0x17
	    CALL    receive
	    MOVWF   0x18 
	    CALL    receive				;ricevi i 3 bytes dell'ins 34
	    MOVWF   0x19
	    
	    MOVLW   0x03
	    XORWF   0x17,W				;� record ppv?
	    BTFSS   STATUS,Z
            GOTO    txins34				;no : trasmetti alla mosc
	    BTFSC   TMR0,00
	    GOTO    buy_ev
delete_bx	    
	    BSF     TMR0,00
	    MOVLW   0x40
	    MOVWF   0x17
	    CLRF    0X18
	    CLRF    0x19
	    MOVLW   0xFF
	    MOVWF   0x1A
	    MOVWF   0x1B
	    CALL    txc140

buy_ev	    MOVLW   0x32				;si : prepara c1 40
	    MOVWF   0x17
	    MOVLW   0xFF
	    MOVWF   0x1A
	    CLRF    0x1B
	    CALL    txc140

	    MOVLW   0x34
	    MOVWF   0x0c
	    CLRF    0x0d
	    CLRF    0x0e
	    MOVLW   0x03
	    MOVWF   0x0f
	    MOVWF   0x17
txins34	    CALL    send5bytes
	    CALL    receive
	    CALL    send_sw_corpo
            GOTO    txstatus

ins0e	    MOVF    0x0c      , W
            XORLW   0x0E
            BTFSS   STATUS    , Z
            GOTO    all_ins

	    MOVLW   0x10
	    MOVWF   0x2B
	    MOVLW   0x17
	    MOVWF   FSR	   
loop_0e	    MOVF    0x2B,W
	    CALL    Rd_eeprom
	    MOVWF   INDF
	    INCF    0X2B,F
	    INCF    FSR,F
	    MOVLW   0x1A
	    XORWF   0x2B,W
	    BTFSS   STATUS,Z
	    GOTO    loop_0e	    

	    MOVLW   0x0E
	    CALL    send
	    
            MOVLW   0x17
            MOVWF   FSR
	    MOVLW   0x0A
	    MOVWF   0x0F
	    
Label_0052  MOVF    INDF      , W
            CALL    send
            INCF    FSR       , f
            DECFSZ  0x0f      , f
            GOTO    Label_0052
	    GOTO    main

;ins0e
all_ins     CALL    send5bytes
	    CALL    Label_0006				;TX ACK
Label_001E  CALL    Label_0006
            DECFSZ  0x0f      , f
            GOTO    Label_001E
;	    MOVF    0x12,W
;	    XORLW   0x10
;	    XORWF   0x0C,W
;	    BTFSS   STATUS,Z
;	    GOTO    txstatus

;            CALL    Label_0006
;            CALL    Label_0006
;	    MOVLW   0x40
;	    MOVWF   0x17
;	    CLRF    0X18
;	    CLRF    0x19
;	    MOVLW   0xFF
;	    MOVWF   0x1A
;	    MOVWF   0x1B
;	    CALL    txc140
;	    GOTO    main
	    
txstatus    CALL    Label_0006
            CALL    Label_0006				;status byte
            GOTO    main

txc140	    CLRF    0x1C
	    CLRF    0x1D
	    MOVLW   0x82
	    MOVWF   0x1E
	    CALL    copy17_1f
	    CALL    Encrypt				;calcola signa
	    MOVLW   0x40
	    MOVWF   0x0c
	    MOVLW   0x01
	    MOVWF   0x0d
	    MOVLW   0x08
	    CALL    Rd_eeprom
	    MOVWF   0x0e
	    MOVLW   0x10
	    MOVWF   0x0f
	    CALL    send5bytes				;manda c1 40 01 0x 10
	    CALL    receive
	    CALL    send_sw_corpo
	    CALL    receive
	    GOTO    receive


Label_0006  BTFSS   PORTB     , 07
            GOTO    Label_0004
            BTFSS   PORTB     , 00
            GOTO    Label_0005
            GOTO    Label_0006

card2cam
Label_0005  CALL    Label_0007         
	    MOVLW   0x7F           ;\ Define PORT B I/O RB7=output, all others=input
            TRIS    PORTB          ;/
	    CLRF    0x12
	    BCF     PORTB,07       ; Send start bit
	    CALL    Label_0009
            MOVLW   0x08
            MOVWF   0x14
            BCF     STATUS    , C
Label_000C  RRF     0x12      , f
            BTFSS   PORTB     , 00
            GOTO    Label_000A
            BSF     PORTB     , 07
            BSF     0x12      , 07
            GOTO    Label_000B
Label_000A  BCF     PORTB     , 07
Label_000B  CALL    Label_0009
            DECFSZ  0x14      , f
            GOTO    Label_000C

            BTFSS   PORTB     , 00		;bit di parit�
            BCF     PORTB     , 07
            BTFSC   PORTB     , 00
            BSF     PORTB     , 07
            CALL    Label_0009

Label_0008  BSF     PORTB     , 07		;fine trasmissione byte
            MOVLW   0xFF          		;\ Define PORT B I/O = all input
            TRIS    PORTB          		;/        
            GOTO    Label_0009          	;/
   


Label_0004  CALL    Label_0007         
	    MOVLW   0xFE           ;\ Define PORT B I/O RB0=output, all others=input
            TRIS    PORTB          ;/
	    CLRF    0x12
	    BCF     PORTB,00       ; Send start bit
	    CALL    Label_0009
            MOVLW   0x08
            MOVWF   0x14
            BCF     STATUS    , C
Label_005C  RRF     0x12      , f
            BTFSS   PORTB     , 07
            GOTO    Label_005A
            BSF     PORTB     , 00
            BSF     0x12      , 07
            GOTO    Label_005B
Label_005A  BCF     PORTB     , 00
Label_005B  CALL    Label_0009
            DECFSZ  0x14      , f
            GOTO    Label_005C

            BTFSS   PORTB     , 07		;bit di parit�
            BCF     PORTB     , 00
            BTFSC   PORTB     , 07
            BSF     PORTB     , 00
            CALL    Label_0009

	    BSF     PORTB     , 00		;fine trasmissione byte
            MOVLW   0xFF          		;\ Define PORT B I/O = all input
            TRIS    PORTB          		;/        
            GOTO    Label_0009          	;/

          

Label_0007  MOVLW   0x0E
            GOTO    Label_0011

Std_pause
Label_0009  MOVLW   0x1A
Pause
Label_0011  MOVWF   0x2a
Label_0012  DECFSZ  0x2a      , f
            GOTO    Label_0012
            RETURN


Label_0015  BTFSS   PORTB     , 07
            GOTO    Label_001F
            BTFSS   PORTB     , 00
            GOTO    Label_0020
            GOTO    Label_0015


Label_0020  MOVLW   0x2A           ;\ 0 (start bit) has been seen on RB0: pause
            CALL    Pause          ;/
            MOVLW   0x09           ; Length = 9 (1 byte data + 1 bit parity)
            MOVWF   0x2D           ; Counter

Receivem_loop  
            BCF     STATUS,C       ; Clear carry flag
            BTFSC   PORTB,00       ; Read PORT B
            BSF     STATUS,C       ; 1 on RB0, set carry flag
            RRF     0x29,f         ; 0 on RB0, rotate right 
            CALL    Std_pause
            DECFSZ  0x2D,f         ; Decrement counter
            GOTO    Receivem_loop  ; Repeat

            RLF     0x29,f         ; Done, rotate left to skip parity bit
            MOVLW   0x29           ;\ Pause
            GOTO    Pause          ;/

Label_001F  MOVLW   0x2A           ;\ 0 (start bit) has been seen on RB7: pause
            CALL    Pause          ;/
            MOVLW   0x09           ; Length = 9 (1 byte data + 1 bit parity)
            MOVWF   0x2D           ; Counter

Receive_loop  
            BCF     STATUS,C       ; Clear carry flag
            BTFSC   PORTB,07       ; Read PORT B
            BSF     STATUS,C       ; 1 on RB7, set carry flag
            RRF     0x29,f         ; 0 on RB7, rotate right 
            CALL    Std_pause
            DECFSZ  0x2D,f         ; Decrement counter
            GOTO    Receive_loop  ; Repeat

            RLF     0x29,f         ; Done, rotate left to skip parity bit
            MOVLW   0x29           ;\ Pause
            GOTO    Pause          ;/


Label_002B  CLRF    0x13
            BCF     STATUS    , C
            MOVLW   0x08
            MOVWF   0x14
Label_002A  RLF     0x29      , f
            BTFSS   STATUS    , C
            GOTO    Label_0029
            INCF    0x13      , f
Label_0029  DECFSZ  0x14      , f
            GOTO    Label_002A
            RLF     0x29      , f
            RETURN

send2mosc
	    MOVWF   0x29           ; Store the data byte into 0x16
            MOVLW   0x32           ;\ Pause (0x32)
            CALL    Pause          ;/
            MOVLW   0xFE           ;\ Define PORT B I/O RB0=output, all others=input
            TRIS    PORTB          ;/
            CLRF    0x2c           ; Clear 0x17, used for parity
            BCF     PORTB,00       ; Send start bit
            MOVLW   0x08           ;\ Length = 8, load counter
            MOVWF   0x2d           ;/

send2m_loop
	    CALL    Std_pause      ; Wait
            RRF     0x29,f         ;\ Load bit to be transmitted in bit 0 of W
            RLF     0x29,W         ;/
            ANDLW   0x01           ; Clear bits 7:1 of W
            XORWF   0x2c,f         ; Update parity
            XORWF   PORTB,W        ; Read PORT B data into W xoring bit 0 (RB0) \ merge bit 0 of W
            XORWF   PORTB,f        ; Write W to PORT B xoring bit 0 again       / into PORT B
            DECFSZ  0x2d,f         ;\ Cycle
            GOTO    send2m_loop    ;/

            CALL    Std_pause      ; Wait
            MOVF    0x2c,W         ;\    
            XORWF   PORTB,W        ; Send parity
            XORWF   PORTB,f        ;/
            CALL    Std_pause      ; Wait
            MOVLW   0xFF           ;\ Define PORT B I/O = all input
            TRIS    PORTB          ;/

        
            MOVLW   0x4f           ;\ Pause
            GOTO    Pause          ;/

send
	    MOVWF   0x29           ; Store the data byte into 0x16
            MOVLW   0x32           ;\ Pause (0x32)
            CALL    Pause          ;/
            MOVLW   0x7F           ;\ Define PORT B I/O RB7=output, all others=input
            TRIS    PORTB          ;/
            CLRF    0x2c           ; Clear 0x17, used for parity
            BCF     PORTB,07       ; Send start bit
            MOVLW   0x08           ;\ Length = 8, load counter
            MOVWF   0x2d           ;/

send_loop   CALL    Std_pause      ; Wait
            RRF     0x29,f         ;\ Load bit to be transmitted in bit 7 of W
            RRF     0x29,W         ;/
            ANDLW   0x80           ; Clear bits 6:0 of W
            XORWF   0x2c,f         ; Update parity
            XORWF   PORTB,W        ; Read PORT B data into W xoring bit 7 (RB7) \ merge bit 7 of W
            XORWF   PORTB,f        ; Write W to PORT B xoring bit 7 again       / into PORT B
            DECFSZ  0x2d,f         ;\ Cycle
            GOTO    send_loop      ;/

            CALL    Std_pause      ; Wait
            MOVF    0x2c,W         ;\    
            XORWF   PORTB,W        ; Send parity
            XORWF   PORTB,f        ;/
            CALL    Std_pause      ; Wait
            MOVLW   0xFF           ;\ Define PORT B I/O = all input
            TRIS    PORTB          ;/

        
            MOVLW   0x4f     ;\ Pause
            GOTO    Pause          ;/


send5bytes
            MOVF    0x16      , W
            CALL    send2mosc
            MOVF    0x0c      , W
            CALL    send2mosc
            MOVF    0x0d      , W
            CALL    send2mosc
            MOVF    0x0e      , W
            CALL    send2mosc
            MOVF    0x0f      , W
            GOTO    send2mosc
        
copy17_1f
	MOVLW   0X17
	MOVWF   FSR
copy2	MOVF    INDF,W
	MOVWF   0X34
	MOVLW   0X08
	ADDWF   FSR,F
	MOVF    0X34,W
	MOVWF   INDF
	MOVLW   0X07
	SUBWF   FSR,F
	MOVLW   0X1F
	XORWF   FSR,W
	BTFSS   STATUS,Z
	GOTO    copy2
	RETURN   


receive
	    CALL    Label_0015
            MOVF    0x29      , W
	    RETURN

send_sw_corpo
            MOVLW   0x17
            MOVWF   FSR
Label_0042  MOVF    INDF      , W
            CALL    send2mosc
            INCF    FSR       , f
            DECFSZ  0x0f      , f
            GOTO    Label_0042
            RETURN

Rd_eeprom   MOVWF   EEADR          ; Load address
            BSF     STATUS,RP0     ; Select page 1 (80H - FFH)
            BSF     EECON1,0x00
            BCF     STATUS,RP0     ; Select page 0 (00H - 7FH)
            MOVF    EEDATA,W       ; Return value
            RETURN

;--------------------------------------------------------------------------------------


load_key
	MOVWF   FSR
	MOVLW   0x08
	MOVWF   0x2B
enc_loop1
	DECF    0x2B,W
	CALL    Rd_eeprom
	DECF    FSR,F
	MOVWF   INDF
	DECFSZ  0x2B,F
	GOTO    enc_loop1
	RETURN

Encrypt
;	MOVLW   0x40
;	MOVWF   FSR
;	MOVLW   0x08
;	MOVWF   0x0D
;	MOVLW   0x11
;enc_loop1			;key : 11 x 16
;	MOVWF   INDF
;	INCF    FSR,F
;	DECFSZ  0x0D,F
;	GOTO    enc_loop1

	MOVLW   0x48
	CALL    load_key
	MOVLW   0x50
	CALL    load_key
	
	CLRF    0x34             ;C = 0
	MOVLW   0FFH
	MOVWF   0x36             ;i = FF
Encrypt_2   
	MOVF    0x23,W            ;d5 -> 0x38
	MOVWF   0x38             
	MOVF    0x24,W            ;d6 -> 0x33
	MOVWF   0x33             
	MOVF    0x25,W            ;d7 -> 0x31
	MOVWF   0x31             
	MOVF    0x26,W            ;d8 -> 0x310
	MOVWF   0x30            
	CALL    Encphase2       ;K(i)=K(i) XOR T1[K(i+1)XOR K(i-1) XOR C]
	CALL    Pointer         ;k(i)
	XORWF   0x38,f           ;xor con d5
	CALL    Encphase2       ;K(i+1)=K(i+1) XOR T1[K(i+2)XOR K(i) XOR C]
	CALL    Pointer         ;k(i+1)
	XORWF   0x33,f           ;xor con d6
	CALL    Encphase2       ;K(i+2)=K(i+2) XOR T1[K(i+3)XOR K(i+1) XOR C]
	CALL    Pointer         ;k(i+2)
	XORWF   0x31,f           ;xor con d7
	CALL    Encphase2       ;K(i+3)=K(i+3) XOR T1[K(i+4)XOR K(i+2) XOR C]
	CALL    Pointer         ;k(i+3)
	XORWF   0x30,f          ;xor con d8
	MOVLW   0x0F            ;4 bit meno significativi
	ANDWF   0x36,f           ;Corregge puntatore
	CALL    decenc_nucleo
	INCF    0x34,f           ;incrementa contatore C
	BTFSC   0x34,4           ;finiti i 16 cicli?
	RETURN                  ;si ritorna
	CALL    decenc_swapbyte
	GOTO    Encrypt_2       ;altro ciclo

;---------------------------------------------------------------------------
; Loop phase of Encrypt Algorithm                                                     
;---------------------------------------------------------------------------
Encphase2      
	INCF    0x36,f
	DECF    0x36,W           ;puntatore - 1
	CALL    PointerAdd      ;Punta a k-1
	XORWF   0x34,W           ;xor con C
	MOVWF   0x32             ;salva in 0x32
	INCF    0x36,W           ;puntatore + 1
	CALL    PointerAdd      ;Punta a k+1
	XORWF   0x32,W           ;xor con 0x32
	CALL    ReadT1          ;prende valore da tabella 1
	MOVWF   0x37             ;salva in 0x37
	CALL    Pointer         ;Punta a k
	XORWF   0x37,W           ;xor con 0x37
	MOVWF   INDF           ;salva k
	RETURN                  ;Return from subroutine

;---------------------------------------------------------------------------
; Update Key Pointer and load k(i)                               
;---------------------------------------------------------------------------
Pointer     
	MOVF    0x36,W           ;Legge puntatore a Kx
PointerAdd  
	ANDLW   0x0F            ;4 bit meno significativi
	ADDLW   0x40              ;offset
	MOVWF   FSR             ;punta a Kx
	MOVF    INDF,W         ;legge valore in Kx -> W
	RETURN                  ;ritorna


;---------------------------------------------------------------------------
; Decrypt / Encrypt  Nucleo                                             
;---------------------------------------------------------------------------
decenc_nucleo
	MOVF    0x38,W           ;d5=T1(d5)
	CALL    ReadT1          
	MOVWF   0x38             
	MOVF    0x33,W           ;d6=T1(d6)
	CALL    ReadT1          
	MOVWF   0x33             
	MOVF    0x31,W           ;d7=T1(d7)
	CALL    ReadT1          
	MOVWF   0x31             
	MOVF    0x30,W          ;d8=T1(d8)
	CALL    ReadT1          
	MOVWF   0x30            
	XORWF   0x38,f           ;d5=d8 XOR d5
	SWAPF   0x30,W          ;d7=T2[(^d8)+d7]
	ADDWF   0x31,W           
	CALL    ReadT2          
	MOVWF   0x31             
	XORWF   0x30,f          ;d8=d7 XOR d8
	SWAPF   0x31,W           ;d6=T2[(^d8)+d6]
	ADDWF   0x33,W           
	CALL    ReadT2          
	MOVWF   0x33             
	XORWF   0x31,f           ;d7=d6 XOR d7
	SWAPF   0x33,W           ;d5=T2[(^d6)+d5]
	ADDWF   0x38,W           
	CALL    ReadT2          
	MOVWF   0x38             
	XORWF   0x33,f           ;d6=d5 XOR d6
	SWAPF   0x38,W           ;d8=T1[(^d5)+d8]
	ADDWF   0x30,W          
	CALL    ReadT1          
	MOVWF   0x30            
	XORWF   0x38,f           ;d5=d8 XOR d5
	SWAPF   0x30,W          ;d7=T1[(^d8)+d7]
	ADDWF   0x31,W           
	CALL    ReadT1          
	MOVWF   0x31             
	XORWF   0x30,f          ;d8=d7 XOR d8
	SWAPF   0x31,W           ;d6=T1[(^d7)+d6]
	ADDWF   0x33,W           
	CALL    ReadT1          
	MOVWF   0x33             
	XORWF   0x31,f           ;d7=d6 XOR d7
	MOVF    0x38,W           ;d6=d5 XOR d6
	XORWF   0x33,f           
	MOVF    0x38,W           ;d3=T2(d5) XOR d3
	CALL    ReadT2          
	XORWF   0x21,f            
	MOVF    0x33,W           ;d1=T2(d6) XOR d1
	CALL    ReadT2          
	XORWF   0x1f,f            
	MOVF    0x31,W           ;d4=T2(d7) XOR d4
	CALL    ReadT2          
	XORWF   0x22,f            
	MOVF    0x30,W          ;d2=T2(d8) XOR d2
	CALL    ReadT2          
	XORWF   0x20,f
	RETURN            

;---------------------------------------------------------------------------
; Decrypt / Encrypt  swap byte                                            
;---------------------------------------------------------------------------
decenc_swapbyte
	MOVF    0x23,W            ;d1 <-> d5
	MOVWF   0x35             
	MOVF    0x1f,W            
	MOVWF   0x23              
	MOVF    0x35,W           
	MOVWF   0x1f              
	MOVF    0x20,W            ;d2 <-> d6
	MOVWF   0x35             
	MOVF    0x24,W            
	MOVWF   0x20              
	MOVF    0x35,W           
	MOVWF   0x24              
	MOVF    0x21,W            ;d3 <-> d7
	MOVWF   0x35             
	MOVF    0x25,W            
	MOVWF   0x21              
	MOVF    0x35,W           
	MOVWF   0x25              
	MOVF    0x22,W            ;d4 <-> d8
	MOVWF   0x35             
	MOVF    0x26,W            
	MOVWF   0x22              
	MOVF    0x35,W           
	MOVWF   0x26              
	RETURN

;---------------------------------------------------------------------------
; Read Decrypt Table 1 and 2                                             
;---------------------------------------------------------------------------
ReadT1      
	CLRF    PCLATH          ;setta pagina 2         
	BSF     PCLATH,1
	MOVWF   PCL             ;prende byte da tabella1 e ritorna
ReadT2      
	CLRF    PCLATH          ;setta pagina 3         
	BSF     PCLATH,0
	BSF     PCLATH,1
	MOVWF   PCL             ;prende byte da tabella2 e ritorna






;---------------------------------------------------------------------------
; Decrypt Table 1                                                           
;---------------------------------------------------------------------------
	ORG     0x200
	DT      0x2A,0xE1,0x0B,0x13,0x3E,0x6E,0x32,0x48,0xD3,0x31,0x08,0x8C,0x8F
	DT      0x95,0xBD,0xD0,0xE4,0x6D,0x50,0x81,0x20,0x30,0xBB,0x75,0xF5,0xD4
	DT      0x7C,0x87,0x2C,0x4E,0xE8,0xF4,0xBE,0x24,0x9E,0x4D,0x80,0x37,0xD2
	DT      0x5F,0xDB,0x04,0x7A,0x3F,0x14,0x72,0x67,0x2D,0xCD,0x15,0xA6,0x4C
	DT      0x2E,0x3B,0x0C,0x41,0x62,0xFA,0xEE,0x83,0x1E,0xA2,0x01,0x0E,0x7F
	DT      0x59,0xC9,0xB9,0xC4,0x9D,0x9B,0x1B,0x9C,0xCA,0xAF,0x3C,0x73,0x1A
	DT      0x65,0xB1,0x76,0x84,0x39,0x98,0xE9,0x53,0x94,0xBA,0x1D,0x29,0xCF
	DT      0xB4,0x0D,0x05,0x7D,0xD1,0xD7,0x0A,0xA0,0x5C,0x91,0x71,0x92,0x88
	DT      0xAB,0x93,0x11,0x8A,0xD6,0x5A,0x77,0xB5,0xC3,0x19,0xC1,0xC7,0x8E
	DT      0xF9,0xEC,0x35,0x4B,0xCC,0xD9,0x4A,0x18,0x23,0x9F,0x52,0xDD,0xE3
	DT      0xAD,0x7B,0x47,0x97,0x60,0x10,0x43,0xEF,0x07,0xA5,0x49,0xC6,0xB3
	DT      0x55,0x28,0x51,0x5D,0x64,0x66,0xFC,0x44,0x42,0xBC,0x26,0x09,0x74
	DT      0x6F,0xF7,0x6B,0x4F,0x2F,0xF0,0xEA,0xB8,0xAE,0xF3,0x63,0x6A,0x56
	DT      0xB2,0x02,0xD8,0x34,0xA4,0x00,0xE6,0x58,0xEB,0xA3,0x82,0x85,0x45
	DT      0xE0,0x89,0x7E,0xFD,0xF2,0x3A,0x36,0x57,0xFF,0x06,0x69,0x54,0x79
	DT      0x9A,0xB6,0x6C,0xDC,0x8B,0xA7,0x1F,0x90,0x03,0x17,0x1C,0xED,0xD5
	DT      0xAA,0x5E,0xFE,0xDA,0x78,0xB0,0xBF,0x12,0xA8,0x22,0x21,0x3D,0xC2
	DT      0xC0,0xB7,0xA9,0xE7,0x33,0xFB,0xF1,0x70,0xE5,0x17,0x96,0xF8,0x8D
	DT      0x46,0xA1,0x86,0xE2,0x40,0x38,0xF6,0x68,0x25,0x16,0xAC,0x61,0x27
	DT      0xCB,0x5B,0xC8,0x2B,0x0F,0x99,0xDE,0xCE,0xC5

;---------------------------------------------------------------------------
; Decrypt Table 2                                                          
;---------------------------------------------------------------------------
	ORG     0x300
	DT      0xBF,0x11,0x6D,0xFA,0x26,0x7F,0xF3,0xC8,0x9E,0xDD,0x3F,0x16,0x97
	DT      0xBD,0x08,0x80,0x51,0x42,0x93,0x49,0x5B,0x64,0x9B,0x25,0xF5,0x0F
	DT      0x24,0x34,0x44,0xB8,0xEE,0x2E,0xDA,0x8F,0x31,0xCC,0xC0,0x5E,0x8A
	DT      0x61,0xA1,0x63,0xC7,0xB2,0x58,0x09,0x4D,0x46,0x81,0x82,0x68,0x4B
	DT      0xF6,0xBC,0x9D,0x03,0xAC,0x91,0xE8,0x3D,0x94,0x37,0xA0,0xBB,0xCE
	DT      0xEB,0x98,0xD8,0x38,0x56,0xE9,0x6B,0x28,0xFD,0x84,0xC6,0xCD,0x5F
	DT      0x6E,0xB6,0x32,0xF7,0x0E,0xF1,0xF8,0x54,0xC1,0x53,0xF0,0xA7,0x95
	DT      0x7B,0x19,0x21,0x23,0x7D,0xE1,0xA9,0x75,0x3E,0xD6,0xED,0x8E,0x6F
	DT      0xDB,0xB7,0x07,0x41,0x05,0x77,0xB4,0x2D,0x45,0xDF,0x29,0x22,0x43
	DT      0x89,0x83,0xFC,0xD5,0xA4,0x88,0xD1,0xF4,0x55,0x4F,0x78,0x62,0x1E
	DT      0x1D,0xB9,0xE0,0x2F,0x01,0x13,0x15,0xE6,0x17,0x6A,0x8D,0x0C,0x96
	DT      0x7E,0x86,0x27,0xA6,0x0D,0xB5,0x73,0x71,0xAA,0x36,0xD0,0x06,0x66
	DT      0xDC,0xB1,0x2A,0x5A,0x72,0xBE,0x3A,0xC5,0x40,0x65,0x1B,0x02,0x10
	DT      0x9F,0x3B,0xF9,0x2B,0x18,0x5C,0xD7,0x12,0x47,0xEF,0x1A,0x87,0xD2
	DT      0xC2,0x8B,0x99,0x9C,0xD3,0x57,0xE4,0x76,0x67,0xCA,0x3C,0xFB,0x90
	DT      0x20,0x14,0x48,0xC9,0x60,0xB0,0x70,0x4E,0xA2,0xAD,0x35,0xEA,0xC4
	DT      0x74,0xCB,0x39,0xDE,0xE7,0xD4,0xA3,0xA5,0x04,0x92,0x8C,0xD9,0x7C
	DT      0x1C,0x7A,0xA8,0x52,0x79,0xF2,0x33,0xBA,0x1F,0x30,0x9A,0x00,0x50
	DT      0x4C,0xFF,0xE5,0xCF,0x59,0xC3,0xE3,0x0A,0x85,0xB3,0xAE,0xEC,0x0B
	DT      0xFE,0xE2,0xAB,0x4A,0xAF,0x69,0x6C,0x2C,0x5D
		
;---------------------------------------------------------------------------
 
 
            ORG     0x2000
            DATA    0x0C
            DATA    0x09
            DATA    0x00
            DATA    0x01
 
            ORG     0x2007
            DATA    0x1B

 
            ORG     0x2100
            DATA    0x11
            DATA    0x11
            DATA    0x11
            DATA    0x11
            DATA    0x11
            DATA    0x11
            DATA    0x11
            DATA    0x11
            DATA    0x02
            DATA    0x00
            DATA    0x00
            DATA    0x00
            DATA    0x00
            DATA    0x00
            DATA    0x00
            DATA    0x00

 	    DATA    0x00
            DATA    0x25
            DATA    0x00
            DATA    0x00
            DATA    0x00
            DATA    0xAA
            DATA    0xBB
            DATA    0xCC
            DATA    0x90
            DATA    0x00

            DATA    0xFF
            DATA    0xFF
            DATA    0xFF
            DATA    0xFF
            DATA    0xFF
            DATA    0xFF
            DATA    0xFF
            DATA    0xFF
            DATA    0xFF
            DATA    0xFF
            DATA    0xFF
            DATA    0xFF
            DATA    0xFF
            DATA    0xFF
            DATA    0x20
            DATA    0x20
            DATA    0x63
            DATA    0x6F
            DATA    0x64
            DATA    0x65
            DATA    0x64
            DATA    0x20
            DATA    0x62
            DATA    0x79
            DATA    0x20
            DATA    0x41
            DATA    0x6E
            DATA    0x67
            DATA    0x68
            DATA    0x79
            DATA    0x00
            DATA    0x00
            DATA    0x00
            DATA    0x00
            DATA    0x00
            DATA    0x00
            DATA    0x00
            DATA    0x00

            END
