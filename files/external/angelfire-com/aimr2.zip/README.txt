AIM Password Recover V. 2.10
----------------------------

Description:
-----------
	This decrypts AIM passwords that are saved on the computer. That means the save
password option must be checked. This is our full working version as of 9/25/99. It can decrypt the whole password and get the complete buddylist for each account on your computer. And NO this does not get them remotely.  

Future versions:
---------------
	Only future versions will be bugfixes *if* they are needed.

Support & Contact info:
----------------------
WebPage: Http://www.dark-e.com
Email:   support@dark-e.com
ICQ:     5760044