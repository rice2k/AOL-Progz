#include <iostream>
#include <iomanip>
using namespace std;

int main() {
	int x;
	x=1;
	do {
		cout << "000000000000000000011111111111111111111100000000001111111!";
	} while (x!=0);
	return 0;
}