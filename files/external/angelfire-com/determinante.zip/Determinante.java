class Determinante
{
	public static void main(String[] args)
	{
		int a11= 1,a12 = 1,a21 =2 ,a22 =2;
		int det;
		det = (a11*a22)- (a21 *a12);
		System.out.println("El resultado del determinente es:" + det);
	}
}