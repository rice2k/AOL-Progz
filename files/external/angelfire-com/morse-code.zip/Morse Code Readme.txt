Run 'Morse Code.exe'

Type in what you want to be converted to Morse code in the top text box.

Press 'Save' and the morse code will be saved into a text file with the name the user has given.

Also this will save the text you typed into the top text box in a '.mse' file which can be re-opened later.


CREATED BY BEN LEED