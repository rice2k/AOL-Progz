(c)2005 Screen saver by mclodo
freeware

INSTALLATION:
right mouse button on "plasmascreensaver..." and select install
boutton droit de la souris sur "plasmascreensaver" et selectionnez installer

NOTE:
OpenGL version is faster but loss of quality
La version OpenGL est plus rapide mais de moins bonne qualit�