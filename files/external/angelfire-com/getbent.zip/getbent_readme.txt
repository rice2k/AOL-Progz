_________________________________________________________
Map: Get Bent
bsp: getbent.bsp
*********************************************************
Author:
NoodleHammer
*********************************************************
Description:
Just a old map I fixed alittle.
You can be a cannonball.
*********************************************************
Installation: Just unzip to your halflife\valve\maps directory.
*********************************************************
Tools used:
Hammer 3.4
Merl's build of Zoners tools
*********************************************************
*********************************************************
Thanks to mimicmaster and 2ez2kill for beta testing.
*********************************************************
Contact: jonnyevilseed@hotmail.com
                 thecrippler65@yahoo.com 
_________________________________________________________



