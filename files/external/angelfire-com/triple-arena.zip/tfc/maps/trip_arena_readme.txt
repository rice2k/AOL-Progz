**********************************************************
Map: Triple_Arena
Bsp name: triple_arena.bsp
Map Author: Noodlehammer
e-mail: thecrippler65@yahoo.com :e-mail me if you would like foxbot
 watpoints
**********************************************************
Installation: Extract to your Halflife directory.
**********************************************************
Description: This is a 4 team map  with three areas. One area all 4 teams
can fight it out as snipers. There are flags to carry for frags. Flag carrying 
can be harmful to your health. The middle(cap area) is lowgravity, jump
on the grate to be blown into the goal.
The second  and third arenas are for red and blue deathmatch only. All
but a couple classes are available for red and blue in these 2 arenas.
Arena 2 is low gravity.
**********************************************************
Tools used: Wc 3.3
                       Merls build of Zoners tools
                       Wally
                       Gensurf
**********************************************************
Thanks to 2ezekill,mimicmaster and Mr.Yuk for testing. Also to
 Mr. Yuk for help. Big thanks to the DoE for beta testing an earlier
version that was wisely trashed
**********************************************************
More maps for tfc and HLDM at: http://www.angelfire.com/realm/noodlehammer