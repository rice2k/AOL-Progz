<HTML DIR="RTL" LANG="AR-SA">    <HTML>
<?php

///////////////////////////////////////////////
//                                           //
// Email Form v.1                           //
// ----------------------------------------- //
// by Graeme (webmaster@phpscriptcenter.com) //
// http://www.phpscriptcenter.com            //
//                                           //////////////////////////////
// PHP Script CENTER offers no warranties on this script.                //
// The owner/licensee of the script is solely responsible for any        //
// problems caused by installation of the script or use of the script    //
//                                                                       //
// All copyright notices regarding Email Form, must remain               //
// intact on the scripts and in the HTML for the scripts.                //
//                                                                       //
// (c) Copyright 2001 PHP Script CENTER                                  //
//                                                                       //
// For more info on Email Form,                                          //
// see http://www.phpscriptcenter.com/emailform.php3                     //
//                                                                       //
///////////////////////////////////////////////////////////////////////////

// your name
$yourname = "���� �������";

// your email
$youremail = "albake@albakr.net";



////////////////////////////////////////////////////////////////////////////
//                      DO NOT EDIT BELOW THIS LINE                       //
////////////////////////////////////////////////////////////////////////////



if($submitform) {

$dcheck = explode(",",$require);
while(list($check) = each($dcheck)) {
if(!$$dcheck[$check]) {
$error .= "��� ����� $dcheck[$check]<BR>";
}
}

if($error) {
echo("<P><CENTER><FONT FACE=\"Verdana\">���� ���</FONT></CENTER></P>
<P><CENTER>&nbsp;</CENTER></P><P><CENTER><TABLE BORDER=\"0\" CELLSPACING=\"0\" 
CELLPADDING=\"0\">
  <TR>
    <TD WIDTH=\"100%\" BGCOLOR=\"#004080\">
    <TABLE WIDTH=\"394\" BORDER=\"0\" CELLSPACING=\"4\" CELLPADDING=\"2\">
      <TR>
        <TD WIDTH=\"26%\" BGCOLOR=\"#004080\">
        <P><CENTER><B><FONT COLOR=\"#ffffff\" SIZE=\"-1\" FACE=\"Verdana\">��� (��� �� ����� �������)</FONT></B></CENTER></TD>
      </TR>
      <TR>
        <TD WIDTH=\"26%\" BGCOLOR=\"#000000\">
        <FONT COLOR=\"#cccccc\" SIZE=\"-1\" FACE=\"Verdana\">$error</FONT></TD> 
      </TR>
    </TABLE></TD>
  </TR>
</TABLE></CENTER><P><CENTER>&nbsp;</CENTER></P><P><CENTER>&nbsp;</CENTER></P><P><CENTER><FONT SIZE=\"-2\" FACE=\"Verdana\"><A HREF=\"http://www.phpscriptcenter.com/emailform.php3\">Email Form</A> Version 1.0 <BR>
Copyright � 2000-2001 <A HREF=\"http://www.phpscriptcenter.com/\">PHPScriptCENTER.com</A></FONT></CENTER></P>");
exit();
}

if ($fromname) {
$yeshow = "\nFrom, $fromname\n";
}

mail($toemail,"$subject","

$message

$yeshow

---------------------
Powerd by Email Form v1.0
From http://www.phpscriptcenter.com
","From: $fromname <$fromemail>");

header("Location: $sendpage");

} else {

echo("<P><CENTER><B><FONT FACE=\"Verdana\">���� ���</FONT></B></CENTER></P>
<FORM ACTION=\"emailform.php3\" METHOD=\"POST\">
<P><CENTER><TABLE BORDER=\"0\" CELLSPACING=\"0\" CELLPADDING=\"0\">
  <TR>
    <TD WIDTH=\"100%\" BGCOLOR=\"#004080\">
    <TABLE WIDTH=\"394\" BORDER=\"0\" CELLSPACING=\"3\" CELLPADDING=\"2\">
      <TR>
        <TD WIDTH=\"48%\" BGCOLOR=\"#000000\">
        <B><FONT COLOR=\"#ffffff\" SIZE=\"-1\" FACE=\"Verdana\">����:</FONT></B></TD>
        <TD WIDTH=\"52%\" BGCOLOR=\"#000000\">
        <INPUT NAME=\"fromname\" TYPE=\"text\" SIZE=\"25\">
</TD>
      </TR>
      <TR>
        <TD WIDTH=\"48%\" BGCOLOR=\"#000000\">
        <B><FONT COLOR=\"#ffffff\" SIZE=\"-1\" FACE=\"Verdana\">����� ����������:</FONT></B></TD>
        <TD WIDTH=\"52%\" BGCOLOR=\"#000000\">
        <INPUT NAME=\"fromemail\" TYPE=\"text\" SIZE=\"25\">
</TD>
      </TR>
      <TR>
        <TD COLSPAN=\"2\" BGCOLOR=\"#000000\">
        <B><FONT COLOR=\"#ffffff\" SIZE=\"-1\" FACE=\"Verdana\">�������:<BR><INPUT
        TYPE=\"hidden\" NAME=\"subject\" VALUE=\"Contact Form\"><INPUT TYPE=\"hidden\"
        NAME=\"toemail\" VALUE=\"$youremail\"><INPUT TYPE=\"hidden\" NAME=\"toname\"
        VALUE=\"$yourname\"><INPUT TYPE=\"hidden\" NAME=\"require\" VALUE=\"����,����� ����������,�������\"><INPUT TYPE=\"hidden\" NAME=\"sendpage\" VALUE=\"http://www.phpscriptcenter.com/sent.php3\"><TEXTAREA
        NAME=\"message\" ROWS=\"5\" COLS=\"45\"
></TEXTAREA></FONT></B></TD>
      </TR>
    </TABLE></TD>
  </TR>
</TABLE></CENTER></P>

<P><CENTER><INPUT NAME=\"submitform\" TYPE=\"submit\" VALUE=\"����\"></CENTER></FORM><P><CENTER>&nbsp;</CENTER></P><P><CENTER>&nbsp;</CENTER></P><P><CENTER><FONT SIZE=\"-2\" FACE=\"Verdana\"><A HREF=\"http://www.phpscriptcenter.com/emailform.php3\">Email Form</A> Version 1.0 <BR>
Copyright � 2000-2001 <A HREF=\"http://www.phpscriptcenter.com/\">PHPScriptCENTER.com</A></FONT></CENTER></P>");

}



php?>