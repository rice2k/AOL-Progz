Run 'Ben's Megasound.exe'

Press options to change skin colours, this will save for the next time you open the program

To reset default skin Delete the 'Ben's Data' file situated in the same directory


NOTE: This program may not run on some newer models of 'Windows' as Microsoft disabled the use of 'Custom Media'

CREATED BY BEN LEED