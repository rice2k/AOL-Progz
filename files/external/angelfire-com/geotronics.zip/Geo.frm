VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmGeo 
   Caption         =   "Geotronics"
   ClientHeight    =   7335
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   10485
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "Geo.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   ScaleHeight     =   7335
   ScaleWidth      =   10485
   StartUpPosition =   3  'Windows Default
   WindowState     =   2  'Maximized
   Begin VB.Timer tmr 
      Enabled         =   0   'False
      Interval        =   2000
      Left            =   9840
      Top             =   6720
   End
   Begin VB.Timer tmrXaxis 
      Enabled         =   0   'False
      Interval        =   50
      Left            =   10200
      Top             =   2760
   End
   Begin VB.PictureBox picSmall 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  'None
      DrawWidth       =   2
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   240
      Left            =   10320
      ScaleHeight     =   240
      ScaleWidth      =   240
      TabIndex        =   16
      TabStop         =   0   'False
      Top             =   1560
      Visible         =   0   'False
      Width           =   240
   End
   Begin VB.PictureBox cont 
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   1095
      Left            =   120
      ScaleHeight     =   1095
      ScaleWidth      =   10215
      TabIndex        =   15
      Top             =   120
      Width           =   10215
      Begin VB.CheckBox chkAutomate 
         Caption         =   "Automate"
         Height          =   195
         Left            =   720
         TabIndex        =   24
         Top             =   420
         Visible         =   0   'False
         Width           =   1095
      End
      Begin VB.TextBox txtData 
         Height          =   285
         Index           =   1
         Left            =   3705
         TabIndex        =   4
         Top             =   135
         Width           =   855
      End
      Begin VB.CommandButton cmdShow 
         Caption         =   "&Show Options"
         Height          =   285
         Left            =   7560
         TabIndex        =   7
         Tag             =   "2285"
         Top             =   135
         Visible         =   0   'False
         Width           =   1695
      End
      Begin VB.TextBox txtData 
         Height          =   285
         Index           =   3
         Left            =   8400
         TabIndex        =   6
         Top             =   135
         Width           =   855
      End
      Begin VB.ComboBox cmbOptions 
         Height          =   315
         Left            =   6000
         Style           =   2  'Dropdown List
         TabIndex        =   3
         ToolTipText     =   "Click on an option to change it"
         Top             =   600
         Width           =   2055
      End
      Begin VB.CheckBox chkAxes 
         Caption         =   "&Axes"
         Height          =   255
         Left            =   9450
         TabIndex        =   11
         ToolTipText     =   "Show Axes"
         Top             =   660
         Value           =   1  'Checked
         Width           =   675
      End
      Begin VB.CheckBox chkHorz 
         Caption         =   "&Horz"
         Height          =   255
         Left            =   9450
         TabIndex        =   9
         ToolTipText     =   "Draw Horizontal Lines"
         Top             =   150
         Width           =   640
      End
      Begin VB.CheckBox chkVert 
         Caption         =   "&Vert"
         Height          =   255
         Left            =   9450
         TabIndex        =   10
         ToolTipText     =   "Draw Vertical Lines"
         Top             =   405
         Width           =   600
      End
      Begin VB.CommandButton cmdDraw 
         Caption         =   "&Draw"
         Default         =   -1  'True
         Height          =   285
         Left            =   8400
         TabIndex        =   8
         Tag             =   "2285"
         Top             =   615
         Width           =   855
      End
      Begin VB.ComboBox cmbSpan 
         Height          =   315
         Left            =   720
         Style           =   2  'Dropdown List
         TabIndex        =   1
         ToolTipText     =   "Specify Span of Graph"
         Top             =   600
         Width           =   1215
      End
      Begin VB.TextBox txtData 
         Height          =   285
         Index           =   2
         Left            =   5985
         TabIndex        =   5
         Top             =   135
         Width           =   855
      End
      Begin VB.ComboBox cmb 
         Height          =   315
         Left            =   720
         Style           =   2  'Dropdown List
         TabIndex        =   0
         Top             =   120
         Width           =   1215
      End
      Begin MSComctlLib.ImageCombo cmbColours 
         Height          =   330
         Left            =   2760
         TabIndex        =   2
         ToolTipText     =   "Click on a colour to change it"
         Top             =   585
         Width           =   2175
         _ExtentX        =   3836
         _ExtentY        =   582
         _Version        =   393216
         ForeColor       =   -2147483640
         BackColor       =   -2147483643
         BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
            Name            =   "Verdana"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Locked          =   -1  'True
         ImageList       =   "imColours"
      End
      Begin VB.Label lblData 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "Colours"
         Height          =   195
         Index           =   1
         Left            =   3105
         TabIndex        =   23
         Top             =   180
         Width           =   540
      End
      Begin VB.Label lblData 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "Colours"
         Height          =   195
         Index           =   3
         Left            =   7810
         TabIndex        =   22
         Top             =   180
         Width           =   540
      End
      Begin VB.Label lblCap 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "Settings"
         Height          =   195
         Index           =   3
         Left            =   5235
         TabIndex        =   21
         Top             =   660
         Width           =   585
      End
      Begin VB.Label lblCap 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "Span"
         Height          =   195
         Index           =   1
         Left            =   255
         TabIndex        =   20
         Top             =   660
         Width           =   360
      End
      Begin VB.Label lblData 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "Colours"
         Height          =   195
         Index           =   2
         Left            =   5395
         TabIndex        =   19
         Top             =   180
         Width           =   540
      End
      Begin VB.Label lblCap 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "Colours"
         Height          =   195
         Index           =   2
         Left            =   2145
         TabIndex        =   18
         Top             =   660
         Width           =   540
      End
      Begin VB.Label lblCap 
         Alignment       =   1  'Right Justify
         AutoSize        =   -1  'True
         Caption         =   "Make"
         Height          =   195
         Index           =   0
         Left            =   255
         TabIndex        =   17
         Top             =   180
         Width           =   375
      End
      Begin VB.Shape Shape1 
         Height          =   1095
         Left            =   0
         Shape           =   4  'Rounded Rectangle
         Top             =   0
         Width           =   10215
      End
   End
   Begin VB.PictureBox picXaxis 
      AutoRedraw      =   -1  'True
      BackColor       =   &H00808080&
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   295
      Left            =   120
      ScaleHeight     =   368.75
      ScaleMode       =   0  'User
      ScaleWidth      =   9855
      TabIndex        =   13
      TabStop         =   0   'False
      Top             =   1320
      Width           =   9855
      Begin VB.Label lbl 
         Alignment       =   2  'Center
         AutoSize        =   -1  'True
         BackColor       =   &H00C0C0FF&
         Height          =   195
         Index           =   0
         Left            =   3030
         TabIndex        =   14
         Top             =   41
         Width           =   60
      End
   End
   Begin VB.PictureBox pic 
      AutoRedraw      =   -1  'True
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      FillColor       =   &H00C0C0C0&
      FillStyle       =   0  'Solid
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   4455
      Left            =   120
      ScaleHeight     =   4455
      ScaleWidth      =   9855
      TabIndex        =   12
      TabStop         =   0   'False
      Top             =   1725
      Width           =   9855
   End
   Begin MSComctlLib.ImageList imColours 
      Left            =   10200
      Top             =   1920
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   16777215
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   2
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Geo.frx":0442
            Key             =   "HAdd"
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Geo.frx":07A6
            Key             =   "HDel"
         EndProperty
      EndProperty
   End
End
Attribute VB_Name = "frmGeo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private twoPi As Double
Dim iXaxis As Integer, iYCount As Integer, iThick As Integer, iDensity As Integer
Dim rX As Integer, ry As Integer, Xy As Boolean
Dim maxDegrees As Integer
Dim HCcount As Integer 'Harmnic Colours count
Dim strExclude As String 'States to exclude

'Winding Declares
Public wdMachine As Integer 'Machine Type: 1-DC;2-1ph AC;3-3ph AC
Public wdWinding As Integer 'Winding Type: 1-Lap;2-Wave
Public wdMSides As Single 'Margin @ Sides
Public wdMTop As Single 'Margin @ Top

Public wdDouble As Boolean  'Double Layer?
Public wdEqRing As Boolean 'Equivalent Ring Diagram?
Public wdRetro As Boolean 'Retrogressive?

Private Declare Function LockWindowUpdate Lib "user32" (ByVal hwndLock As Long) As Long
Private Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hwnd As Long, ByVal wMsg As Long, ByVal wParam As Long, lParam As Any) As Long
Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)

Private Sub chkAutomate_Click()
chkAutomate.Visible = False
If chkAutomate.Value = 1 Then tmr.Enabled = True Else tmr.Enabled = False
End Sub

Private Sub tmr_Timer()
cmb.SetFocus
n = cmb.ListIndex
Do
  If n = cmb.ListCount - 1 Then n = 0 Else n = n + 1
  If InStr(strExclude, n) = 0 Then Exit Do
Loop
cmb.ListIndex = n
DoEvents
cmdDraw.SetFocus
cmdDraw_Click
DoEvents
End Sub


Private Sub cmb_Click()

pic.Cls

cmdShow.Visible = False
If cmb.text = "Winding" Then
  picXaxis.Visible = False
  pic.Top = picXaxis.Top ': pic.DrawWidth = 2
  pic.Height = Me.ScaleHeight - pic.Top - pic.Left
  cmbSpan.Enabled = False: cmbOptions.Enabled = False
Else
  picXaxis.Visible = True
  pic.Top = 1725 ': pic.DrawWidth = 1
  pic.Height = Me.ScaleHeight - pic.Top - pic.Left
  cmbSpan.Enabled = True: cmbOptions.Enabled = True
End If

Select Case cmb.text

Case "Sine Wave"
  lblData(1) = "": lblData(2) = "": lblData(3) = ""
Case "AM Wave"
  lblData(1) = "AM Carrier Freq": lblData(2) = "AM Mod Freq": lblData(3) = "AM Mod Depth"
Case "FM Wave"
  lblData(1) = "FM Carrier Freq": lblData(2) = "FM Mod Freq": lblData(3) = "Modulation Index"
Case "Harmonics"
  lblData(1) = "Harmonics": lblData(2) = "Amplitude": lblData(3) = ""
Case "Winding"
  lblData(1) = "No of Slots": lblData(2) = "No of Poles": lblData(3) = ""
  cmdShow.Visible = True
Case Else
  lblData(1) = "": lblData(2) = "": lblData(3) = ""
End Select

Dim i As Integer
For i = 1 To 3
If lblData(i) = "" Then
  lblData(i).Visible = False
  txtData(i).Visible = False
Else
  lblData(i).Visible = True
  txtData(i).Visible = True
  txtData(i) = GetSetting(apComp, apProd, lblData(i), getDefault(lblData(i)))
  txtData(i).ToolTipText = getToolTip(i)
End If
Next i

iThick = GetSetting(apComp, apProd, cmb.text & "\Thickness", iThick)
iDensity = GetSetting(apComp, apProd, cmb.text & "\Density", iDensity)

cmbOptions.Clear
cmbOptions.AddItem "X Axis (" & iXaxis & "�)"
cmbOptions.AddItem "Vertical Lines (" & iYCount & ")"
cmbOptions.AddItem "Plot Thickness (" & iThick & ")"
cmbOptions.AddItem "Plot Density (" & iDensity & ")"

cmbSpan.text = GetSetting(apComp, apProd, cmb.text & "\Span", cmbSpan.text)

SaveSetting apComp, apProd, "Last Drawing Mode", cmb.ListIndex

End Sub

Private Function getDefault(str As String) As String
Select Case str
Case "AM Carrier Freq"
  getDefault = 3000
Case "AM Mod Freq"
  getDefault = 300
Case "AM Mod Depth"
  getDefault = 0.6
Case "FM Carrier Freq"
  getDefault = 2000
Case "FM Mod Freq"
  getDefault = 150
Case "Modulation Index"
  getDefault = 50
Case "Harmonics"
  getDefault = "3,5,7"
Case "Amplitude"
  getDefault = "5,3,1"
Case "No of Slots"
  getDefault = 24
Case "No of Poles"
  getDefault = 4
'Case ""
  'getDefault = ""
End Select
End Function

Private Function getToolTip(Index As Integer) As String
Select Case lblData(Index)
Case "Harmonics"
  getToolTip = "Enter the Harmonic(s) you wish to see, separated by a comma (,)"
Case "Amplitude"
  getToolTip = "Enter Amplitude on a scale of 1 to 10 - eg '3,2'"
Case "AM Carrier Frequency", "FM Carrier Frequency"
  getToolTip = "Enter Carrier Frequency (in MHz)"
Case "AM Mod Frequency", "FM Mod Frequency"
  getToolTip = "Enter Modulating Frequency (in kHz)"
Case "Modulation Index"
  getToolTip = "Modulation Index = Max Freq Deviation/Mod Freq"
End Select
End Function

Private Sub cmbColours_Click()
Dim newColor As Long

If cmbColours.SelectedItem.text = "----------------" Then Exit Sub

If cmbColours.SelectedItem.text = "Add Harmonic" Then
  Dim def As Long
  HCcount = HCcount + 1
  If HCcount = 1 Then def = cmbColours.ComboItems("Draw Lines").Tag Else def = cmbColours.ComboItems("Harmonic " & HCcount - 1).Tag
  AddItem "Harmonic " & HCcount, GetSetting(apComp, apProd, "Harmonic " & HCcount, def)
  cmbColours.ComboItems(cmbColours.ComboItems.Count).Selected = True
  SaveSetting apComp, apProd, "Harmonic Count", HCcount
  SaveSetting apComp, apProd, "Harmonic " & HCcount, cmbColours.ComboItems("Graph Lines").Tag
ElseIf cmbColours.SelectedItem.text = "Clear Harmonics" Then
  Dim m As VbMsgBoxResult
  m = MsgBox("Sure you want to remove Harmonic Colours?" & vbCrLf & vbCrLf & _
    "Further Harmonics will be the colour of Graph Lines.", _
      vbYesNo + vbQuestion, "Clear Harmonic Colours")
  If m = vbNo Then Exit Sub
  Do Until cmbColours.ComboItems.Count = cmbColours.ComboItems("HDel").Index
    cmbColours.ComboItems.Remove (cmbColours.ComboItems.Count)
  Loop
  HCcount = 0
  SaveSetting apComp, apProd, "Harmonic Count", 0
  Exit Sub
End If

If cmbColours.SelectedItem.Tag = "" Then Exit Sub
newColor = ShowColor(Me, cmbColours.SelectedItem.Tag, 1)
If newColor <> -1 Then

cmbColours.SelectedItem.Image = AddImage(cmbColours.SelectedItem.key, newColor)
SaveSetting apComp, apProd, cmbColours.SelectedItem.key, newColor
cmbColours.SelectedItem.Tag = newColor

'Resync Images
Dim CI As ComboItem
For Each CI In cmbColours.ComboItems
  If CI.text <> "Add Harmonic" And CI.text <> "Clear Harmonics" And CI.text <> "----------------" Then _
  CI.Image = imColours.ListImages(CI.key).Index
Next

End If
End Sub


Private Sub cmbOptions_Click()
Dim i As String, ip As String

If cmbOptions.ListIndex = 0 Then 'X Axis
  ip = InputBox("Every how many degrees should there be" & vbCrLf & "Vertical Lines (X Axis Markings)" & _
    vbCrLf & vbCrLf & "Must be a multiple of 30", "X Axis", iXaxis)
  If ip = "" Or IsNumeric(ip) = False Then Exit Sub
  iXaxis = Int(Val(ip) / 30) * 30
  tmrXaxis.Enabled = True
ElseIf cmbOptions.ListIndex = 1 Then ' Vertical lines Count
  ip = InputBox("How many horizontal lines origin and side?", "Horizontal Lines", iYCount)
  If ip = "" Or IsNumeric(ip) = False Then Exit Sub
  iYCount = Val(ip)
ElseIf cmbOptions.ListIndex = 2 Then ' Plot Thickness
  ip = InputBox("Define Thickness of Plot", "Plot Thickness", iThick)
  If ip = "" Or IsNumeric(ip) = False Then Exit Sub
  iThick = Val(ip)
ElseIf cmbOptions.ListIndex = 3 Then ' Vertical lines Count
  ip = InputBox("Define Density of Plot", "Plot Density", iDensity)
  If ip = "" Or IsNumeric(ip) = False Then Exit Sub
  iDensity = Val(ip)
End If

SaveSetting apComp, apProd, "X Axis Resolution", iXaxis
SaveSetting apComp, apProd, "Horizontal Lines", iYCount
SaveSetting apComp, apProd, cmb.text & "\Thickness", iThick
SaveSetting apComp, apProd, cmb.text & "\Density", iDensity

cmbOptions.Clear
cmbOptions.AddItem "X Axis (" & iXaxis & "�)"
cmbOptions.AddItem "Vertical Lines (" & iYCount & ")"
cmbOptions.AddItem "Plot Thickness (" & iThick & ")"
cmbOptions.AddItem "Plot Density (" & iDensity & ")"


End Sub

Private Sub cmbSpan_Click()
'�
tmrXaxis.Enabled = True
pic.Cls
SaveSetting apComp, apProd, "Span Index", cmbSpan.ListIndex
End Sub

Private Sub cmdDraw_Click()

Dim ht As Single
pic.BackColor = cmbColours.ComboItems("Graph Background").Tag

'Dim tm As Single: tm = Timer()
Me.MousePointer = vbHourglass
'LockWindowUpdate pic.hWnd
pic.Cls

'draw grid
pic.ForeColor = cmbColours.ComboItems("Graph Lines").Tag 'grid color

    'vertical gridlines
  Dim cnt As Integer, i As Integer, Y As Single
  cnt = lbl.Count - 1
  If chkVert.Value = 1 Then
    For i = 0 To cnt '0.05 * pic.ScaleHeight To pic.ScaleHeight - 0.05 * pic.ScaleHeight Step 0.9 * pic.ScaleHeight / 18
      pic.Line (i * pic.ScaleWidth / cnt, 0)-(i * pic.ScaleWidth / cnt, pic.ScaleHeight)
    Next
  End If
  
  ht = pic.ScaleHeight / 2
    'horizontal gridlines
  If chkHorz.Value = 1 Then
    For i = 1 To iYCount
      Y = i / iYCount * 0.9 * ht
      pic.Line (0, ht + Y)-(pic.Width, ht + Y)
      pic.Line (0, ht - Y)-(pic.Width, ht - Y)
    Next
  End If
  
'to draw axes
If chkAxes.Value = 1 Then
  pic.ForeColor = cmbColours.ComboItems("Axes Lines").Tag 'axes color
  pic.Line (0, ht)-(pic.ScaleWidth, ht)
  pic.Line (pic.ScaleWidth / 2, 0)-(pic.ScaleWidth / 2, pic.ScaleHeight)
End If

pic.ForeColor = cmbColours.ComboItems("Draw Lines").Tag 'grid color
pic.FillColor = pic.ForeColor

Dim mult As Single

Select Case cmb.text

Case "Sine Wave"
  mult = twoPi * maxDegrees / 360 / pic.ScaleWidth
  For X = 0 To pic.ScaleWidth Step iDensity
    pic.Circle (X, ht - 0.9 * ht * Sin(X * mult)), iThick
  Next

Case "3 Phase AC"
  Dim offs As Single
  mult = twoPi * maxDegrees / 360 / pic.ScaleWidth
  'BLUE PHASE
  offs = pic.ScaleWidth / maxDegrees * 240
  pic.ForeColor = cmbColours.ComboItems("Blue Phase").Tag: pic.FillColor = pic.ForeColor
  For X = 0 To pic.ScaleWidth Step iDensity
    pic.Circle (X, ht - 0.9 * ht * Sin((X - offs) * mult)), iThick
  Next
  'YELLOW PHASE
  offs = pic.ScaleWidth / maxDegrees * 120
  pic.ForeColor = cmbColours.ComboItems("Yellow Phase").Tag: pic.FillColor = pic.ForeColor
  For X = 0 To pic.ScaleWidth Step iDensity
    pic.Circle (X, ht - 0.9 * ht * Sin((X - offs) * mult)), iThick
  Next
  'RED PHASE
  pic.ForeColor = cmbColours.ComboItems("Red Phase").Tag: pic.FillColor = pic.ForeColor
  For X = 0 To pic.ScaleWidth Step iDensity
    pic.Circle (X, ht - 0.9 * ht * Sin(X * mult)), iThick
  Next

Case "Harmonics"
  If txtData(1) = "" Then MsgBox "Must mention Harmonics to include": txtData(1).SetFocus: Exit Sub
  If txtData(2) = "" Then MsgBox "Must mention amplitude(s) of Harmonic(s)": txtData(2).SetFocus: Exit Sub
  
  mult = twoPi * maxDegrees / 360 / pic.ScaleWidth
  For X = 0 To pic.ScaleWidth Step iDensity
    pic.Circle (X, ht - 0.9 * ht * Sin(X * mult)), iThick
  Next
  
  Dim strHarm As String, ampHarm As String, Harm As Integer, Amp As Single, cHarm As Integer
  strHarm = txtData(1): ampHarm = txtData(2)
 
  Do
    If InStr(strHarm, ",") = 0 Then
      Harm = strHarm: Amp = 0.1 * ampHarm
      strHarm = ""
    Else
      Harm = Mid(strHarm, 1, InStr(strHarm, ",") - 1)
      Amp = 0.1 * Mid(ampHarm, 1, InStr(ampHarm, ",") - 1)
        strHarm = Mid(strHarm, InStr(strHarm, ",") + 1)
        ampHarm = Mid(ampHarm, InStr(ampHarm, ",") + 1)
    End If
    
    'load harmonic colour
    cHarm = cHarm + 1
    If cHarm < HCcount + 1 Then
      pic.ForeColor = cmbColours.ComboItems("Harmonic " & cHarm).Tag 'grid color
      pic.FillColor = pic.ForeColor
    End If
    
    'draw harmonic
    mult = Harm * (twoPi * maxDegrees / 360 / pic.ScaleWidth)
    For X = 0 To pic.ScaleWidth Step iDensity
      pic.Circle (X, ht - 0.9 * Amp * ht * Sin(X * mult)), iThick
    Next
    
  Loop Until strHarm = ""
Case "AM Wave", "FM Wave"
  Dim Am As Single, Ac As Single, Wm As Single, Wc As Single
  Dim t As Single, m As Single
  Ac = 0.9 * ht
  Wm = txtData(2)
  Wc = txtData(1)
  If cmb.text = "AM Wave" Then
    Am = Val(txtData(3)) * Ac / 2
    mult = twoPi * maxDegrees / 360 / pic.ScaleWidth / 100
    m = 1 / (1 + Val(txtData(3)))
    For X = 0 To pic.ScaleWidth Step iDensity
      t = X * mult
      Y = Ac * Cos(Wc * t) + Am * (Cos((Wm + Wc) * t) + Cos((Wm - Wc) * t))
      pic.Circle (X, ht - Y * m), iThick
    Next
  Else
    m = Val(txtData(3))
    mult = twoPi * maxDegrees / 360 / pic.ScaleWidth / 500
    For X = 0 To pic.ScaleWidth Step iDensity
      t = X * mult
      Y = (Wc * t) + m * Sin(Wm * t)
      pic.Circle (X, ht - 0.9 * ht * Sin(Y)), iThick
    Next
  End If
Case "Winding"
  Dim j As Single, k As Single
  Dim S As Integer, P As Integer, sp As Integer
  Dim y1 As Integer, y2 As Integer
  Dim stp As Integer, stpn As Integer
  
  pic.Cls: pic.DrawStyle = 0
  'First Draw Slots
  y1 = wdMTop * pic.ScaleHeight: y2 = (1 - wdMTop) * pic.ScaleHeight
    j = wdMSides * pic.Width: k = (1 - wdMSides) * pic.Width
  S = Val(txtData(1).text)
  If wdDouble Then S = 2 * S:
  P = Val(txtData(2).text): sp = S / P
  stp = (k - j) / (S - 1): stpn = stp
  If wdMachine <> 3 Then 'Non 3 phase
    For i = j To k Step 2 * stp
      pic.DrawStyle = 0
      pic.Line (i, y1)-(i, y2)
      If wdDouble Then pic.DrawStyle = 2
      pic.Line (i + stp, y1)-(i + stp, y2)
    Next
  Else '3 phase
  
  End If
  
  pic.DrawStyle = 0
  'Then draw Poles
  mult = sp * stp
  col = cmbColours.ComboItems("North Pole").Tag
  For i = j To k Step mult
    pic.Line (i - stpn / 8, ht - 100)-(i + mult - stpn / 4, ht + 100), col, BF
    If col = cmbColours.ComboItems("North Pole").Tag Then col = cmbColours.ComboItems("South Pole").Tag Else col = cmbColours.ComboItems("North Pole").Tag
  Next
  
  ht = 0.5 * (y2 - y1) 'Overhang Portion
  'Draw Windings (Overhang)
  Dim Yb As Integer, Yf As Integer
  If wdWinding = 1 Then 'Lap
    If wdRetro Then Yb = sp + 1: Yf = sp - 1 Else Yf = sp + 1: Yb = sp - 1
    j = j - stpn
    For i = 1 To S
      pic.DrawStyle = 0
      If i Mod 2 <> 0 Then
        pic.Line (j + i * stpn, y1)-(j + (i + Yf / 2) * stpn, y1 - ht) 'Top Going Up Overhang
        pic.Line (j + i * stpn, y2)-(j + (i + Yb / 2) * stpn, y2 + ht) 'Bot Coming Up Overhang
      End If
      
      If wdDouble Then pic.DrawStyle = 2 'draw bottom layer
      
      If i Mod 2 = 0 Then
        pic.Line (j + i * stpn, y1)-(j + (i - Yf / 2) * stpn, y1 - ht)  'Top Coming Down Overhang
        pic.Line (j + i * stpn, y2)-(j + (i - Yb / 2) * stpn, y2 + ht) 'Bot Going Down Overhang
      End If
    Next
  Else 'Wave
  
  End If
  pic.DrawStyle = 0
  If wdEqRing Then frmEqRing.Show Else Unload frmEqRing
End Select

'MsgBox Timer - tm:LockWindowUpdate 0
Me.MousePointer = vbDefault

'save default values
For i = 1 To 3
  If lblData(i) <> "" Then SaveSetting apComp, apProd, lblData(i), txtData(i)
Next
SaveSetting apComp, apProd, cmb.text & "\Span", cmbSpan.text
End Sub

Private Sub cmdShow_Click()
  frmWinding.Show vbModal

cmdDraw.Default = True
cmdDraw.SetFocus

End Sub

Private Sub cont_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
If X > cmb.Left And X < cmb.Left + cmb.Width And Y > cmb.Top And Y < cmbSpan.Top Then
  If Button = 1 Then
    chkAutomate.Visible = True
  ElseIf Button = 2 Then
    ip = InputBox("Enter Time for Changing (in Seconds)", "Automate Timer", tmr.Interval / 1000)
    If IsNumeric(ip) Then tmr.Interval = 1000 * Val(ip): SaveSetting apComp, apProd, "Automate Interval", tmr.Interval
  ElseIf Button = 4 Or Button = 3 Then 'MouseWheel / Middle
    ip = InputBox("Enter States to Exclude (eg 0,3,5 excludes Sine, FM and Windings)", "Exclude States", strExclude)
    If ip = "" Then
      m = MsgBox("Would You like to clear Exclusions?" & vbCrLf & "No will cancel Update", vbYesNo, "Clear Exclusions")
      If m = vbYes Then strExclude = ""
    Else
      strExclude = ip
    End If
    SaveSetting apComp, apProd, "Automate's Exclusions", strExclude
  End If
End If
End Sub

Private Sub Form_Load()
twoPi = 44 / 7
rX = -1: rX = -1

'MsgBox "use lockwindow update to speed rendering & auto re-render?"

apComp = App.CompanyName
apProd = App.ProductName

AddItem "Graph Background", GetSetting(apComp, apProd, "Graph Background", &HF0E0E0)
  pic.BackColor = cmbColours.ComboItems("Graph Background").Tag
AddItem "Graph Lines", GetSetting(apComp, apProd, "Graph Lines", &HA07070)
AddItem "Axes Lines", GetSetting(apComp, apProd, "Axes Lines", &HFF8080)
AddItem "Draw Lines", GetSetting(apComp, apProd, "Draw Lines", vbBlack)
  cmbColours.ComboItems.Add cmbColours.ComboItems.Count + 1, , "----------------"

AddItem "North Pole", GetSetting(apComp, apProd, "North Pole", &HC0C0C0)
AddItem "South Pole", GetSetting(apComp, apProd, "South Pole", &H606060)
  cmbColours.ComboItems.Add cmbColours.ComboItems.Count + 1, , "----------------"

AddItem "Red Phase", GetSetting(apComp, apProd, "Red Phase", vbRed)
AddItem "Yellow Phase", GetSetting(apComp, apProd, "Yellow Phase", vbYellow)
AddItem "Blue Phase", GetSetting(apComp, apProd, "Blue Phase", vbBlue)
  cmbColours.ComboItems.Add cmbColours.ComboItems.Count + 1, , "----------------"

cmbColours.ComboItems.Add cmbColours.ComboItems.Count + 1, "HAdd", "Add Harmonic", 1
cmbColours.ComboItems.Add cmbColours.ComboItems.Count + 1, "HDel", "Clear Harmonics", 2

HCcount = GetSetting(apComp, apProd, "Harmonic Count", 0)
If HCcount = 0 Then
  HCcount = 3: SaveSetting apComp, apProd, "Harmonic Count", 3
  SaveSetting apComp, apProd, "Harmonic 1", &H808080
  SaveSetting apComp, apProd, "Harmonic 2", &HA0A0A0
  SaveSetting apComp, apProd, "Harmonic 3", &HC0C0C0
End If
For i = 1 To HCcount
  AddItem "Harmonic " & i, GetSetting(apComp, apProd, "Harmonic " & i, cmbColours.ComboItems("Graph Lines").Tag)
Next

cmb.AddItem "Sine Wave"
cmb.AddItem "3 Phase AC"
cmb.AddItem "AM Wave"
cmb.AddItem "FM Wave"
cmb.AddItem "Harmonics"
cmb.AddItem "Winding"

For i = 1 To 16 '(eight cycles)
  cmbSpan.AddItem Format(i / 2, "0.0") & " Cycles"
Next

iXaxis = GetSetting(apComp, apProd, "X Axis Resolution", 90)
iYCount = GetSetting(apComp, apProd, "Vertical Lines", 5)
iThick = GetSetting(apComp, apProd, cmb.text & "\Thickness", 25)
iDensity = GetSetting(apComp, apProd, cmb.text & "\Density", 10)

cmbOptions.AddItem "X Axis (" & iXaxis & "�)"
cmbOptions.AddItem "Vertical Lines (" & iYCount & ")"
cmbOptions.AddItem "Plot Thickness (" & iThick & ")"
cmbOptions.AddItem "Plot Density (" & iDensity & ")"

cmbSpan.ListIndex = GetSetting(apComp, apProd, "Span Index", 3)
tmrXaxis.Enabled = True

cmb.ListIndex = GetSetting(apComp, apProd, "Last Drawing Mode", 0)
tmr.Interval = GetSetting(apComp, apProd, "Automate Interval", 2000)
strExclude = GetSetting(apComp, apProd, "Automate's Exclusions", "")
'cmbOptions.text = "..Options.."

'Load Winding Variables
wdMachine = GetSetting(apComp, apProd & "\Winding", "Machine", 1)
wdWinding = GetSetting(apComp, apProd & "\Winding", "Winding", 1)
wdMSides = GetSetting(apComp, apProd & "\Winding", "Margin Sides", 0.2)
wdMTop = GetSetting(apComp, apProd & "\Winding", "Margin Top", 0.4)
wdDouble = GetSetting(apComp, apProd & "\Winding", "Double Layer", False)
wdEqRing = GetSetting(apComp, apProd & "\Winding", "Eq Ring", False)

End Sub

Sub AddItem(text As String, color As Long)
cmbColours.ComboItems.Add cmbColours.ComboItems.Count + 1, text, text, AddImage(text, color)
cmbColours.ComboItems(cmbColours.ComboItems.Count).Tag = color
End Sub

Private Function AddImage(key As String, color As Long) As Integer
On Error Resume Next
If imColours.ListImages(key).Picture <> 0 Then imColours.ListImages.Remove (imColours.ListImages(key).Index)

picSmall.BackColor = color
'add border for image combo
picSmall.Line (0, 0)-(0, 240): picSmall.Line (0, 0)-(240, 0)
picSmall.Line (0, 240)-(240, 240): picSmall.Line (240, 0)-(240, 240)

imColours.ListImages.Add imColours.ListImages.Count + 1, key, picSmall.Image
AddImage = imColours.ListImages(key).Index
End Function

Private Sub Form_Resize()
If Me.WindowState = 1 Then Exit Sub

pic.Visible = False

If Me.Width < cont.Width + 800 Then Me.Width = cont.Width + 800
cont.Left = (Me.Width - cont.Width) / 2
pic.Width = Me.ScaleWidth - 2 * pic.Left
picXaxis.Width = pic.Width
pic.Height = Me.ScaleHeight - pic.Top - pic.Left

pic.Visible = True
End Sub

Private Sub Form_Unload(Cancel As Integer)
End
End Sub

Private Sub picXaxis_Resize()
Dim c As Long
If lbl.Count = 1 Then Exit Sub
c = iXaxis / maxDegrees * pic.ScaleWidth ' picXaxis.Width / (lbl.Count - 1)
For i = 0 To lbl.Count - 1
  lbl(i) = iXaxis * i & "�"
  lbl(i).Left = i * c - lbl(i).Width / 2
Next
End Sub


Private Sub tmrXaxis_Timer()
  Dim cnt As Integer
  cnt = (cmbSpan.ListIndex + 1) * 180 / iXaxis
  maxDegrees = (cmbSpan.ListIndex + 1) * 180
  
  Do Until lbl.Count = cnt + 1
    If lbl.Count < cnt + 1 Then
      Load lbl(lbl.Count)
      lbl(lbl.Count - 1).Visible = True
    Else
      Unload lbl(lbl.Count - 1)
    End If
  Loop
  picXaxis_Resize

  tmrXaxis.Enabled = False
End Sub

Private Sub txtData_GotFocus(Index As Integer)
With txtData(Index)
  .SelStart = 0
  .SelLength = Len(.text)
End With
End Sub
