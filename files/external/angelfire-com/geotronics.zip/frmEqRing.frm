VERSION 5.00
Begin VB.Form frmEqRing 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Equivalent Ring Diagram"
   ClientHeight    =   1455
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   8640
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1455
   ScaleWidth      =   8640
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox pic 
      AutoRedraw      =   -1  'True
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      FillColor       =   &H00C0C0C0&
      FillStyle       =   0  'Solid
      Height          =   1215
      Left            =   120
      ScaleHeight     =   1215
      ScaleWidth      =   8415
      TabIndex        =   0
      TabStop         =   0   'False
      Top             =   120
      Width           =   8415
   End
End
Attribute VB_Name = "frmEqRing"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Form_Load()
pic.BackColor = frmGeo.pic.BackColor

Me.Top = GetSetting(apComp, apProd, "frmEqRing.Top", Me.Top)
Me.Left = GetSetting(apComp, apProd, "frmEqRing.Left", Me.Left)

End Sub
