VERSION 5.00
Begin VB.Form frmWinding 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "  Winding Details"
   ClientHeight    =   3090
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   3135
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmWinding.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3090
   ScaleWidth      =   3135
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.CheckBox chkEqRing 
      Caption         =   "Show &Equivalent Ring Diagram"
      Height          =   255
      Left            =   300
      TabIndex        =   13
      Top             =   2760
      Width           =   2535
   End
   Begin VB.Frame Frame3 
      Caption         =   "Margins"
      Height          =   615
      Left            =   120
      TabIndex        =   8
      Top             =   2040
      Width           =   2895
      Begin VB.TextBox txtMarginTop 
         Alignment       =   1  'Right Justify
         Height          =   285
         Left            =   2280
         TabIndex        =   10
         Text            =   ".4"
         Top             =   240
         Width           =   495
      End
      Begin VB.TextBox txtMarginSide 
         Alignment       =   1  'Right Justify
         Height          =   285
         Left            =   600
         TabIndex        =   9
         Text            =   ".2"
         Top             =   240
         Width           =   495
      End
      Begin VB.Label lbl 
         AutoSize        =   -1  'True
         Caption         =   "Up & Down"
         Height          =   195
         Index           =   1
         Left            =   1440
         TabIndex        =   12
         Top             =   285
         UseMnemonic     =   0   'False
         Width           =   795
      End
      Begin VB.Label lbl 
         AutoSize        =   -1  'True
         Caption         =   "Sides"
         Height          =   195
         Index           =   0
         Left            =   120
         TabIndex        =   11
         Top             =   285
         Width           =   375
      End
   End
   Begin VB.Frame Frame2 
      Caption         =   "Type of Winding"
      Height          =   1035
      Left            =   120
      TabIndex        =   4
      Top             =   900
      Width           =   2895
      Begin VB.CheckBox chkRetro 
         Caption         =   "Retrogressive"
         Height          =   195
         Left            =   1440
         TabIndex        =   14
         Top             =   640
         Width           =   1335
      End
      Begin VB.CheckBox chkDouble 
         Caption         =   "&Double Layer"
         Height          =   255
         Left            =   120
         TabIndex        =   7
         Top             =   610
         Width           =   1300
      End
      Begin VB.OptionButton optWind 
         Caption         =   "&Wave Winding"
         Height          =   195
         Index           =   2
         Left            =   1440
         TabIndex        =   6
         Top             =   300
         Width           =   1335
      End
      Begin VB.OptionButton optWind 
         Caption         =   "&Lap Winding"
         Height          =   195
         Index           =   1
         Left            =   120
         TabIndex        =   5
         Top             =   300
         Value           =   -1  'True
         Width           =   1335
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "Type of Machine"
      Height          =   665
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   2895
      Begin VB.OptionButton optMach 
         Caption         =   "&DC"
         Height          =   255
         Index           =   1
         Left            =   120
         TabIndex        =   3
         Top             =   300
         Value           =   -1  'True
         Width           =   615
      End
      Begin VB.OptionButton optMach 
         Caption         =   "&1ph AC"
         Height          =   255
         Index           =   2
         Left            =   735
         TabIndex        =   2
         Top             =   300
         Width           =   975
      End
      Begin VB.OptionButton optMach 
         Caption         =   "&3ph AC"
         Height          =   255
         Index           =   3
         Left            =   1710
         TabIndex        =   1
         Top             =   300
         Width           =   855
      End
   End
End
Attribute VB_Name = "frmWinding"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'general declarations
Dim Xx As Integer, Yy As Integer

Private Sub chkDouble_Click()
If chkDouble.Value = 1 Then frmGeo.wdDouble = True Else frmGeo.wdDouble = False
End Sub

Private Sub chkEqRing_Click()
If chkEqRing.Value = 1 Then frmGeo.wdEqRing = True Else frmGeo.wdEqRing = False
End Sub

Private Sub chkRetro_Click()
If chkRetro.Value = 1 Then frmGeo.wdRetro = True Else frmGeo.wdRetro = False
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
  If KeyCode = vbKeyEscape Or KeyCode = vbKeyReturn Then Unload Me
End Sub

Private Sub Form_Load()
Me.Top = GetSetting(apComp, apProd, "frmWinding.Top", Me.Top)
Me.Left = GetSetting(apComp, apProd, "frmWinding.Left", Me.Left)

optMach(frmGeo.wdMachine).Value = True
optWind(frmGeo.wdWinding).Value = True
If frmGeo.wdDouble Then chkDouble.Value = 1
If frmGeo.wdEqRing Then chkEqRing.Value = 1
If frmGeo.wdRetro Then chkRetro.Value = 1
txtMarginSide = frmGeo.wdMSides
txtMarginTop = frmGeo.wdMTop
End Sub

Private Sub Form_Unload(Cancel As Integer)
'Saveallsettings
SaveSetting apComp, apProd, "frmWinding.Top", Me.Top
SaveSetting apComp, apProd, "frmWinding.Left", Me.Left

SaveSetting apComp, apProd & "\Winding", "Machine", frmGeo.wdMachine
SaveSetting apComp, apProd & "\Winding", "Winding", frmGeo.wdWinding
SaveSetting apComp, apProd & "\Winding", "Double Layer", frmGeo.wdDouble
SaveSetting apComp, apProd & "\Winding", "Margin Sides", frmGeo.wdMSides
SaveSetting apComp, apProd & "\Winding", "Margin Top", frmGeo.wdMTop
SaveSetting apComp, apProd & "\Winding", "Eq Ring", frmGeo.wdEqRing
SaveSetting apComp, apProd & "\Winding", "Retrogressive", frmGeo.wdRetro
End Sub

Private Sub optMach_Click(Index As Integer)
frmGeo.wdMachine = Index
End Sub

Private Sub optWind_Click(Index As Integer)
frmGeo.wdWinding = Index
End Sub

Private Sub txtMarginSide_Change()
If Val(txtMarginSide) > 0 Then frmGeo.wdMSides = Val(txtMarginSide)
End Sub

Private Sub txtMarginTop_Change()
If Val(txtMarginTop) > 0 Then frmGeo.wdMTop = Val(txtMarginTop)
End Sub
