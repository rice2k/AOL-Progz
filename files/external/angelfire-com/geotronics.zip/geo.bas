Attribute VB_Name = "Module1"
Public apComp As String, apProd As String
