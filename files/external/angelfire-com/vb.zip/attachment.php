<?php
error_reporting(7);

$noheader=1;

require("./global.php");
if ($postid) {
  $postid=verifyid("post",$postid);
} else {
  $attachmentid=verifyid("attachment",$attachmentid);
}

$getforuminfo=$DB_site->query_first("SELECT forumid".
                                     iif($postid,',attachmentid ','')."
                                     FROM thread,post
                                     WHERE post.threadid=thread.threadid ".
                                      iif($postid,"AND post.postid='$postid'","AND post.attachmentid='$attachmentid'")."
                                      ");

$permissions=getpermissions($getforuminfo[forumid]);
if (!$permissions[canview]) {
  show_nopermission();
}

if ($postid) {
  $attachmentid=$getforuminfo[attachmentid];
}

if (!$attachmentinfo=$DB_site->query_first("SELECT filename,filedata,dateline FROM attachment WHERE attachmentid='$attachmentid'")){
  $idname='attachment';
  eval("standarderror(\"".gettemplate('error_invalidid')."\");");
  exit;
}

if ($noshutdownfunc) {
  $DB_site->query("UPDATE attachment SET counter=counter+1 WHERE attachmentid='$attachmentid'");
} else {
  $shutdownqueries[]="UPDATE LOW_PRIORITY attachment SET counter=counter+1 WHERE attachmentid='$attachmentid'";
}
header("Cache-control: max-age=31536000");
header("Expires: " . gmdate("D, d M Y H:i:s",time()+31536000) . "GMT");
header("Last-Modified: " . gmdate("D, d M Y H:i:s",$attachmentinfo[dateline]) . "GMT");
header("Content-disposition: filename=$attachmentinfo[filename]");
header("Content-Length: ".strlen($attachmentinfo[filedata]));
$extension=strtolower(substr(strrchr($attachmentinfo[filename],"."),1));
if ($extension=="gif") {
  header("Content-type: image/gif");
} elseif ($extension=="jpg" or $extension=="jpeg") {
  header("Content-type: image/pjpeg");
} elseif ($extension=="png") {
  header("Content-type: image/png");
} else {
  header("Content-type: unknown/unknown");
}
echo $attachmentinfo[filedata];

?>
