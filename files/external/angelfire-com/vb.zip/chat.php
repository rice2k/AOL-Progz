<?php 

include("./global.php"); 

if( $bbuserid ) { 

$user = $DB_site->query_first( "SELECT username 
FROM user 
WHERE userid = $bbuserid" ); 
$bbusername = $user[ username ]; 
eval("dooutput(\"".gettemplate('chat')."\");"); 
} else { 
eval("dooutput(\"".show_nopermission()."\");"); 

} // end if 

?> 


