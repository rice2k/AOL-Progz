<?php

//..........Top X Posters  v0.0.4..........\\
//......by Kevin (kevin@tubescan.com)......\\

// For vBulletin version 2, beta 3
// (c) 2001 Jelsoft Enterprises, Ltd.

// vBulletin.com thread: http://www.vbulletin.com/forum/showthread.php?threadid=12067

///////////// CHANGE LOG /////////////
//
// New in version 0.0.4
// -- Fixed alternating colors so they are horizontal, not vertical
// -- Changed $path to $url and $path2 to $path to make variables easier
// -- Added a seperate header row color
//
// New in version 0.0.3
// -- Added option to exclude admins from list of posters
//
// New in version 0.0.2
// -- Fixed a small bug with the path.
//
// New in version 0.0.1
// -- Released! :)
//
/////////// END CHANGE LOG ///////////

//////// CONFIG EXPLANATION //////////
//
// a] $maxposters > This is the number of posters you want to show.
// b] $hc > The head row color.
// c] $bc1 and $bc2 > These are the first and second alternating color.
// d] $text and $link > Set the colors of the main text and the color of the links. Make sure this color is visible on both alternating colors.
// e] $font > This is the font(s) to use for display. You can set specific fonts (e.g. Verdana, Arial, etc.) or general font-families (e.g. sans-serif, serif).
// f] $fontsize > Set a point size for your font. Size 8 is about equivelant to <font size=1>. Anything below about 6 will basically be undreadable, so be careful.
// g] $url > This is the URL to your board directory. This is not the path to config.php! Do not put a trailing slash, either.
// h] $path > This *is* the path to your config.php file. This should include the /admin part. NO TRAILING SLASH! (May need a leading slash)
// i] $admins > Set this to "1" to show admins on the list of top posters. Set this to "0" to NOT show admins on the list.
//
////// END CONFIG EXPLANATION ////////

/////////////// CONFIG ///////////////
//
$maxposters = "10"; // change this to the number of posters you want to show. for a top 10 listing, set it to 10, etc.
$hc = "#005C77"; // change to head row color.
$bc1 = "#AFDCEB"; // change to first alternating color.
$bc2 = "#CCE9F2"; // change to second alternating color.
$text = "#000007"; // change to text color.
$link = "#005C7"; // change to link color.
$font = "Verdana,Helvetica,sans-serif"; // change to fonts you want. use serif or sans-serif for general, or use specific fonts names.
$fontsize = "8pt"; // change to font size you want. 8 is about the minimum; go up from there. 1 will not even show up.
$admins = "0"; // change this to "0" to leave admins off the list of top posters.
//
///////////// END CONFIG /////////////

require("admin/config.php");
$db=mysql_connect($servername,$dbusername,$dbpassword) or die("Unable to connect to database");
mysql_select_db($dbname) or die("Unable to select database $dbname");

if ($admins == "1") {
	$exq = mysql_query("SELECT usergroupid FROM usergroup WHERE cancontrolpanel='1'");
	$exr = mysql_result($exq,0,0);
	$exn = "WHERE usergroupid<>$exr";
}

echo("<table width= 100% border=0 cellpadding=4 cellspacing=0><tr><td align=\"center\" bgcolor=\"$hc\"><b style=\"color: $text; font-family: $font; font-size: $fontsize\">�����</b></td><td align=\"center\" bgcolor=\"$hc\"><b style=\"color: $text; font-family: $font; font-size: $fontsize\">���������</b></td></tr>");

$postsresult = mysql_query("SELECT username,posts,userid FROM user $exn ORDER BY posts desc LIMIT 0,$maxposters") or die("Unable to complete query");
while ($topposters = mysql_fetch_array($postsresult)):
	if (($counter++ % 2) != 0) {
		$bc=$bc1;
	} else {
		$bc=$bc2;
	}
	echo("<tr><td align=\"center\" bgcolor=\"$bc\" style=\"color: $text; font-family: $font; font-size: $fontsize\"><a href=\"member.php?&action=getinfo&userid=$topposters[userid]\" style=\"color: $link\">$topposters[username]</a></td><td align=\"center\" bgcolor=\"$bc\" style=\"color: $text; font-family: $font; font-size: $fontsize\">$topposters[posts]</td></tr>");
endwhile;
echo("</table>");

?>