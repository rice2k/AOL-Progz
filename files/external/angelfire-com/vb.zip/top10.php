<html >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1256">
<title>top 10</title>
<base target="_blank">
</head>

<body background="images/bg.gif"><div dir=rtl>
  <center>
<? include("topposters.php"); ?>
  </center>


</body>

</html>
