<?php
error_reporting(7);

require ("./global.php");

echo "Importing new templates<br>";
$path="./vbulletin.style";

if(file_exists($path)==0) {
	$styletext="";
} else {
	$filesize=filesize($path);

	$filenum=fopen($path,"r");

	$styletext=fread($filenum,$filesize);

	fclose($filenum);
}

if ($styletext=="") {
  echo "<p>Please ensure that the vbulletin.style file exists in the current directory and then reload this current page.</p>";
  exit;
}

$DB_site->query("DELETE FROM template WHERE templatesetid=-1 AND title<>'options'");
$DB_site->query("DELETE FROM replacement WHERE replacementsetid=-1");

$stylebits=explode("|||",$styletext);

list($devnul,$styleversion)=each($stylebits);

list($devnul,$style[title])=each($stylebits);
list($devnul,$replacementset[title])=each($stylebits);
list($devnul,$templateset[title])=each($stylebits);

// check to see if we are installing a master template set or just a custom style set

// installing a master!!
$style[styleid]=-1;
$style[userselect]=0;
$style[replacementsetid]=-1;
$style[templatesetid]=-1;

// get number of replacements and templates
list($devnull,$numreplacements)=each($stylebits);
list($devnull,$numtemplates)=each($stylebits);

$counter=0;
while ($counter++<$numreplacements) {
	list($devnull,$findword)=each($stylebits);
	list($devnull,$replaceword)=each($stylebits);
	if (trim($findword)!="") {
		$DB_site->query("INSERT INTO replacement (replacementsetid,findword,replaceword) VALUES ($style[replacementsetid],'".addslashes($findword)."','".addslashes($replaceword)."')");
	}
}

$counter=0;
while ($counter++<$numtemplates) {
	list($devnull,$title)=each($stylebits);
	list($devnull,$template)=each($stylebits);
	if (trim($title)!="") {
		$DB_site->query("INSERT INTO template (templatesetid,title,template) VALUES ($style[templatesetid],'".addslashes($title)."','".addslashes($template)."')");
	}
}

echo "Templates imported correctly<br>";

// update version
$DB_site->query("UPDATE setting SET value='2.0.0 beta 3' WHERE varname='templateversion'");

$template="";
$settings=$DB_site->query("SELECT varname,value FROM setting");
while ($setting=$DB_site->fetch_array($settings)) {
	$template.="\$$setting[varname] = \"".addslashes(str_replace("\"","\\\"",$setting[value]))."\";\n";
}

$DB_site->query("UPDATE template SET template='$template' WHERE title='options'");

echo "<p>Upgrade to 2.0 beta 3 completed successfully";

?>