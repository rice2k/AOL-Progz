<?php
error_reporting(7);

if (function_exists("set_time_limit")==1 and get_cfg_var("safe_mode")==0) {
  @set_time_limit(1200);
}

require ("./global.php");

?>
<HTML><HEAD>
<META content="text/html; charset=windows-1252" http-equiv=Content-Type>
<META content="MSHTML 5.00.3018.900" name=GENERATOR></HEAD>
<STYLE>
A:visited   {TEXT-DECORATION: none}
A:hover   {BACKGROUND-COLOR: #40364d; COLOR: #f5d300}
A:link        {TEXT-DECORATION: none}
A:active      {TEXT-DECORATION: none}
BODY        {CURSOR: default; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 12px}
UL            {CURSOR: default; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 12px}
LI            {CURSOR: default; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 12px}
P           {CURSOR: default; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 12px}
TD          {FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 12px}
TR          {FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 12px}
SELECT    {COLOR: #51485F; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 10px}
INPUT     {COLOR: #51485F; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 10px}
TEXTAREA  {COLOR: #51485F; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 10px}
OPTION    {COLOR: #51485F; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 10px}
FORM      {FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 10px}
</STYLE>
<title>vBulletin 2.0.0 Beta 3 to Beta 4 Upgrade script</title>
</HEAD>
<BODY bgcolor="#CCCCCC" text="#3F3849" link="#3F3849" vlink="#3F3849" alink="#3F3849" leftmargin="10" topmargin="10" marginwidth="10" marginheight="10">
<p><font size=+3>vBulletin 2.0.0 Beta 3 to Beta 4 Upgrade Script</font></p>
<p><i>(Note: Please be patient as some parts of this may take some time.)</i></p>
<?php

if (!$step) {
  $step = 1;
}

// ******************* STEP 1 *******************
if ($step==1) {
  echo "This script will upgrade you from vBulletin 2.0 beta 3 to vBulletin 2.0 beta 4. If you are upgrading from a different version than beta 3, please run previous upgrade scripts first.

  <p><a href=\"upgrade4.php?step=2\">Continue with the upgrade --&gt;</a>";
}

// ******************* STEP 2 *******************
if ($step==2) {
  if ($thissetting=$DB_site->query_first("SELECT settingid FROM setting WHERE varname='ignoremods'")) {
    echo "It appears that you have already run this script or made the changes by hand. You will not be able to continue until you remove these additions";
    exit;
  }

  echo "Updating settings .... ";
  $DB_site->query("INSERT INTO setting VALUES (NULL,6,'Allow Ignore Moderators','ignoremods','0','Allow users to add Moderators and admins to their ignore list?','yesno',17)");
  $DB_site->query("INSERT INTO setting VALUES (NULL,4,'Clickable Smilies per Row','smcolumns','3','When a user has enabled the clickable vbcode/smilies how many smilies do you want to show per row?','',6)");
  $DB_site->query("INSERT INTO setting VALUES (NULL,4,'Clickable Smilies Total','smtotal','15','When a user has enabled the clickable vbcode/smilies how many smilies do you want to display on the screen before the user is prompted to click for more.','',7)");
  $DB_site->query("INSERT INTO setting VALUES (NULL,5,'Show today\'s birthdays on the homepage?','showbirthdays','1','','yesno',1)");
  $DB_site->query("INSERT INTO setting VALUES (NULL,10,'Allow Wild Cards?','allowwildcards','1','Allow users to use a star (*) in searches to match partial words?','yesno','6')");
  $DB_site->query("INSERT INTO setting VALUES (NULL,19,'Word to denote cancelled message','pmcancelledword','Cancelled:','This is the word that will prefix the title of \'cancelled\' messages in the read receipts section.','','15')");
  $DB_site->query("INSERT INTO setting VALUES (NULL,14,'Time limit on editing of thread title','editthreadtitlelimit','5','Specify the time-limit (in minutes) within which the thread-title may be edited by the thread starter.','','5')");
	$DB_site->query("INSERT INTO setting VALUES (NULL,'8','Stop \'Shouting\' in titles','stopshouting','1','Prevent your users \'shouting\' in their thread titles by changing all-uppercase titles to capitalization only on the first letters of some words. Disable this for some international boards with different character sets, as this may cause problems.','yesno','9')");
  $DB_site->query("DELETE FROM setting WHERE varname='timezone'"); //old, not used anymore
  echo "Done!<p>\n";

  echo "Altering and updating customavatar .... ";
  $DB_site->query("ALTER TABLE customavatar ADD dateline INT UNSIGNED not null");
  $DB_site->query("ALTER TABLE customavatar ADD filename VARCHAR(100)");
  $DB_site->query("UPDATE customavatar SET dateline='".time()."'");
  echo "Done!<p>\n";

  echo "Altering and Updating user .... ";
  $DB_site->query("UPDATE user SET showsignatures = showsignatures + 14");
  $DB_site->query("ALTER TABLE user CHANGE showsignatures options SMALLINT (6) DEFAULT '1' not null");
  echo "Done!<p>\n";

  echo "Inserting [font] vB code .... ";
  $DB_site->query("INSERT INTO bbcode VALUES (NULL, 'font', '<font face=\"\\\\5\">\\\\7</font>', '[font=courier]Test[/font]', 'You can change the font of your text.', '1')");
  echo "Done!<p>\n";

  echo "Inserting special templates .... ";
  $DB_site->query("INSERT INTO template (templatesetid, title) VALUES ('-2','maxloggedin')");
  $DB_site->query("INSERT INTO template (templatesetid, title) VALUES ('-2','birthdays')");
  echo "Done!<p>\n";

  echo "<p><a href=\"upgrade4.php?step=3\">Continue with the upgrade --&gt;</a> (the next step may take a <b>very</b> long time)\n";
  echo "<br><a href=\"upgrade4.php?step=3&emptyindex=1\">Continue with the upgrade, emptying the search index --&gt;</a> (the next step will be significantly faster, but you will have to reindex)\n<br><i>Note: You will need to reindex no matter what to take advantage of the new search features</i></p>";
}

// ******************* STEP 3 *******************
if ($step==3) {
  if ($emptyindex) {
    echo "Emptying search index and word tables .... ";
    $DB_site->query("DELETE FROM searchindex");
    $DB_site->query("DELETE FROM word");
    echo "Done!<p>\n";
  }

  echo "Altering tables (part 1).... ";
  $DB_site->query("ALTER TABLE subscribethread CHANGE threadid threadid INT UNSIGNED NOT NULL");
  $DB_site->query("ALTER TABLE searchindex ADD intitle smallint(5) unsigned DEFAULT '0' NOT NULL");
  echo "Done!<p>\n";

  echo "<p><a href=\"upgrade4.php?step=4\">Continue with the upgrade --&gt;</a>";
}

// ******************* STEP 4 *******************
if ($step==4) {
  echo "Altering tables (part 2).... ";
  $DB_site->query("ALTER TABLE privatemessage ADD readtime INT (10) UNSIGNED DEFAULT '0' not null");
  $DB_site->query("ALTER TABLE privatemessage ADD receipt SMALLINT (6) UNSIGNED DEFAULT '0' not null");
  $DB_site->query("ALTER TABLE privatemessage ADD deleteprompt SMALLINT (6) UNSIGNED DEFAULT '0' not null");
  $DB_site->query("ALTER TABLE privatemessage ADD multiplerecipients SMALLINT (6) UNSIGNED DEFAULT '0' not null");
  echo "Done!<p>\n";

  echo "<p><a href=\"upgrade4.php?step=5\">Continue with the upgrade --&gt;</a>";
}

// ******************* STEP 5 *******************
if ($step==5) {
  echo "Altering tables (part 3).... ";
  $DB_site->query("ALTER TABLE usergroup ADD maxbuddypm SMALLINT (6) UNSIGNED DEFAULT '5' not null");
  $DB_site->query("ALTER TABLE usergroup ADD maxforwardpm SMALLINT (6) UNSIGNED DEFAULT '5' not null");
  $DB_site->query("ALTER TABLE usergroup ADD cantrackpm SMALLINT (6) DEFAULT '1' not null");
  $DB_site->query("ALTER TABLE usergroup ADD candenypmreceipts SMALLINT (6) DEFAULT '1' not null");
  echo "Done!<p>\n";

  echo "<p><a href=\"upgrade4.php?step=6\">Continue with the upgrade --&gt;</a>";
}

// ******************* STEP 6 *******************
if ($step==6) {

  echo "Changing Session table type (affects 3.23 only) .... ";
  $DB_site->reporterror=0;
  $DB_site->query(" ALTER TABLE session /*!32306 TYPE=HEAP */");
  $DB_site->reporterror=1;
  echo "Done!<p>\n";

  echo "Adding indexes .... ";
  $DB_site->query("ALTER TABLE thread ADD INDEX stick (sticky)");
  $DB_site->query("ALTER TABLE forumpermission ADD INDEX ugid_fid (usergroupid, forumid)");
  $DB_site->query("ALTER TABLE announcement ADD INDEX (forumid)");
  $DB_site->query("ALTER TABLE search ADD INDEX (querystring), ADD INDEX (userid)");
  echo "Done!<p>\n";

  echo "<p><a href=\"upgrade4.php?step=7\">Continue with the upgrade --&gt;</a>";
}

// ******************* STEP 7 *******************
if ($step==7) {
  echo "Importing new templates ....";
  $path="./vbulletin.style";

  if(file_exists($path)==0) {
  	$styletext="";
  } else {
  	$filesize=filesize($path);

  	$filenum=fopen($path,"r");

  	$styletext=fread($filenum,$filesize);

  	fclose($filenum);
  }

  if ($styletext=="") {
    echo "<p>Please ensure that the vbulletin.style file exists in the current directory and then reload this current page.</p>";
    exit;
  }

  $DB_site->query("DELETE FROM template WHERE templatesetid=-1 AND title<>'options'");
  $DB_site->query("DELETE FROM replacement WHERE replacementsetid=-1");

  $stylebits=explode("|||",$styletext);

  list($devnul,$styleversion)=each($stylebits);

  list($devnul,$style[title])=each($stylebits);
  list($devnul,$replacementset[title])=each($stylebits);
  list($devnul,$templateset[title])=each($stylebits);

  // check to see if we are installing a master template set or just a custom style set

  // installing a master!!
  $style[styleid]=-1;
  $style[userselect]=0;
  $style[replacementsetid]=-1;
  $style[templatesetid]=-1;

  // get number of replacements and templates
  list($devnull,$numreplacements)=each($stylebits);
  list($devnull,$numtemplates)=each($stylebits);

  $counter=0;
  while ($counter++<$numreplacements) {
  	list($devnull,$findword)=each($stylebits);
  	list($devnull,$replaceword)=each($stylebits);
  	if (trim($findword)!="") {
  		$DB_site->query("INSERT INTO replacement (replacementsetid,findword,replaceword) VALUES ($style[replacementsetid],'".addslashes($findword)."','".addslashes($replaceword)."')");
  	}
  }

  $counter=0;
  while ($counter++<$numtemplates) {
  	list($devnull,$title)=each($stylebits);
  	list($devnull,$template)=each($stylebits);
  	if (trim($title)!="") {
  		$DB_site->query("INSERT INTO template (templatesetid,title,template) VALUES ($style[templatesetid],'".addslashes($title)."','".addslashes($template)."')");
  	}
  }

  echo "Done!<p>\n";

  echo "<p><a href=\"upgrade4.php?step=8\">Continue with the upgrade --&gt;</a> (last step!)";
}

// ******************* STEP 8 *******************
if ($step==8) {
  // update version
  echo "Updating settings .... ";
  $DB_site->query("UPDATE setting SET value='2.0.0 beta 4' WHERE varname='templateversion'");

  $template="";
  $settings=$DB_site->query("SELECT varname,value FROM setting");
  while ($setting=$DB_site->fetch_array($settings)) {
  	$template.="\$$setting[varname] = \"".addslashes(str_replace("\"","\\\"",$setting[value]))."\";\n";
  }

  $DB_site->query("UPDATE template SET template='$template' WHERE title='options'");
  echo "Done!\n";

  echo "<p><a href=\"upgrade4.php?step=9\">Continue with the upgrade --&gt;</a> (last step!)";
}

//  ******************* STEP 9 *******************
if ($step==9) {
  // clean up html in replacements
  echo "<p>Cleaning-up HTML in your custom replacement variables .... </p>";

  $repls = $DB_site->query("SELECT replacement.*, replacementset.title FROM replacement LEFT JOIN replacementset USING(replacementsetid) WHERE replacement.replacementsetid<>-1");
	while ($repl = $DB_site->fetch_array($repls)) {
		if (ereg(". $", $repl[replaceword]) || ereg("id=all", $repl[replaceword])) {
			$newrepl = trim(ereg_replace("(.) $", "\\1", $repl[replaceword]));
			$newrepl = str_replace("id=all", "id=\"all\"", $newrepl);
			echo "<li>Cleaned-up custom replacement '<b>".htmlspecialchars($repl[findword])."</b>' from replacement set '<b>$repl[title]</b>'</li>\n";
			$DB_site->query("UPDATE replacement SET replaceword='$newrepl' WHERE replacementid='$repl[replacementid]'");
		}
	}
	echo "Done!\n";

	echo "<p>Upgrade to 2.0 beta 4 completed successfully! <br>Please delete the following files if you uploaded them: install.php, upgrade1.php, upgrade2.php, upgrade3.php, upgrade4.php";
}

?>
</body>
</html>