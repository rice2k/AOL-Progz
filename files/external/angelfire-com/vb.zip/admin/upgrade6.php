<?php
error_reporting(7);

$oldversion = "2.0.0 beta 5";
$newversion = "2.0.0 Release Candidate 1";
$thisscript = "upgrade6.php";

function gotonext($extra="") {
	global $step,$thisscript;
	$nextstep = $step+1;
	echo "<p><a href=\"$thisscript?step=$nextstep\">Continue with the upgrade --&gt;</a> $extra</p>\n";
}

if (function_exists("set_time_limit")==1 and get_cfg_var("safe_mode")==0) {
  @set_time_limit(1200);
}

require ("./global.php");

?>
<HTML><HEAD>
<META content="text/html; charset=windows-1252" http-equiv=Content-Type>
<META content="MSHTML 5.00.3018.900" name=GENERATOR></HEAD>
<link rel="stylesheet" href="../cp.css">
<title>vBulletin <?php echo $oldversion ?> to <?php echo $newversion ?> Upgrade script</title>
</HEAD>
<BODY>
<p><font size=+2>vBulletin <?php echo $oldversion ?> to <?php echo $newversion ?> Upgrade Script</font></p>
<p><i>(Note: Please be patient as some parts of this may take some time.)</i></p>
<?php

if (!$step) {
  $step = 1;
}

// ******************* STEP 1 *******************
if ($step==1) {
  ?>
  <p>This script will upgrade you from vBulletin <?php echo $oldversion ?> to vBulletin <?php echo $newversion ?>. If you are upgrading from a version other than <?php echo $oldversion ?>, please run previous upgrade scripts first.</p>

  <ul>
  <li>Installing a new version: run <i>install.php</i><br><br>
  <li>Upgrading from vBulletin 1.1x: run <i>upgrade1.php</i><br><br>
  <li>Upgrading from vBulletin 2.0 beta 1: run <i>upgrade2.php, upgrade3.php, upgrade4.php, upgrade5.php, upgrade6.php</i>
  <li>Upgrading from vBulletin 2.0 beta 2: run <i>upgrade3.php, upgrade4.php, upgrade5.php, upgrade6.php</i>
  <li>Upgrading from vBulletin 2.0 beta 3: run <i>upgrade4.php, upgrade5.php, upgrade6.php</i>
  <li>Upgrading from vBulletin 2.0 beta 4: run <i>upgrade5.php, upgrade6.php</i>
  <li>Upgrading from vBulletin 2.0 beta 5: run <i>upgrade6.php</i> (this file)
  </ul>

  <?php

  gotonext();

}

// ******************* STEP 2 *******************
if ($step==2) {
  $thissetting = $DB_site->query_first("SELECT value FROM setting WHERE varname='templateversion'");
  if ($thissetting[value]==$newversion) {
    echo "It appears that you have already run this script or made the changes by hand. You will not be able to continue until you remove these additions";
    exit;
  }

	echo "<b>Altering Table Structure (pollvotes) ....</b>";
    $DB_site->query("ALTER TABLE pollvote CHANGE userid userid INT UNSIGNED NOT NULL");
    $DB_site->query("ALTER TABLE pollvote CHANGE pollid pollid INT UNSIGNED NOT NULL");
	$DB_site->query("ALTER TABLE pollvote ADD INDEX (userid,pollid)");
	echo "<p>Index added to <i>pollvote</i> table</p>\n";

	echo "<p>All done!</p>\n";

	gotonext();

}

// ******************* STEP 3 *******************
if ($step==3) {

	echo "<b>Altering Table Structure (threads) ....</b>";

	// get keys list
	$sql="";
	$start=0;
	$keys = $DB_site->query("SHOW KEYS FROM thread");
	while ($key = $DB_site->fetch_array($keys)) {
		$kname=$key['Key_name'];
		if (!$isdone[$kname]) {
	     if ($kname!="PRIMARY") {
	       if ($start==0) {
	         $sql ="DROP INDEX $kname";
	         $list = $kname;
	         $start=1;
	       } else {
	         $sql.=",DROP INDEX $kname";
	         $list .= ", $kname";
	       }
	     }
		  $isdone[$kname]=1;
		}
	}
	if ($sql) {
	  $DB_site->query("ALTER TABLE thread $sql");
	  echo "<p>Thread indexes ($list) have been dropped";
	}

	echo "<p>Adding indexes to <i>thread</i> table:<br>\nThis may take some time. If this step fails due to a PHP timeout (verify via phpmyadmin that the indexes weren't successfully created), you should log in to mySQL via telnet and run the following query:</p>\n<pre>ALTER TABLE thread ADD INDEX (iconid), ADD INDEX (forumid,visible,sticky,lastpost);</pre>\n";
	$DB_site->query("ALTER TABLE thread ADD INDEX (forumid,visible,sticky,lastpost)");
	$DB_site->query("ALTER TABLE thread ADD INDEX (iconid)");
	echo "<p>Indexes added to <i>thread</i> table sucessfully</p>";

	echo "<p>All done!</p>\n";

	gotonext();


}

// ******************* STEP 4 *******************
if ($step==4) {
  echo "<b>Importing new templates ....</b>";
  $path="./vbulletin.style";

  if(file_exists($path)==0) {
  	$styletext="";
  } else {
  	$filesize=filesize($path);

  	$filenum=fopen($path,"r");

  	$styletext=fread($filenum,$filesize);

  	fclose($filenum);
  }

  if ($styletext=="") {
    echo "<p>Please ensure that the vbulletin.style file exists in the current directory and then reload this current page.</p>";
    exit;
  }

  $DB_site->query("DELETE FROM template WHERE templatesetid=-1 AND title<>'options'");
  $DB_site->query("DELETE FROM replacement WHERE replacementsetid=-1");

  $stylebits=explode("|||",$styletext);

  list($devnul,$styleversion)=each($stylebits);

  list($devnul,$style[title])=each($stylebits);
  list($devnul,$replacementset[title])=each($stylebits);
  list($devnul,$templateset[title])=each($stylebits);

  // check to see if we are installing a master template set or just a custom style set

  // installing a master!!
  $style[styleid]=-1;
  $style[userselect]=0;
  $style[replacementsetid]=-1;
  $style[templatesetid]=-1;

  // get number of replacements and templates
  list($devnull,$numreplacements)=each($stylebits);
  list($devnull,$numtemplates)=each($stylebits);

  $counter=0;
  while ($counter++<$numreplacements) {
  	list($devnull,$findword)=each($stylebits);
  	list($devnull,$replaceword)=each($stylebits);
  	if (trim($findword)!="") {
  		$DB_site->query("INSERT INTO replacement (replacementsetid,findword,replaceword) VALUES ($style[replacementsetid],'".addslashes($findword)."','".addslashes($replaceword)."')");
  	}
  }

  $counter=0;
  while ($counter++<$numtemplates) {
  	list($devnull,$title)=each($stylebits);
  	list($devnull,$template)=each($stylebits);
  	if (trim($title)!="") {
  		$DB_site->query("INSERT INTO template (templatesetid,title,template) VALUES ($style[templatesetid],'".addslashes($title)."','".addslashes($template)."')");
  	}
  }

  echo "Done!<p>\n";

  gotonext("(last step!)");
}

// ******************* STEP 5 *******************
if ($step==5) {
  // update version
  echo "Updating settings .... ";
  $DB_site->query("UPDATE setting SET value='$newversion' WHERE varname='templateversion'");

  $template="";
  $settings=$DB_site->query("SELECT varname,value FROM setting");
  while ($setting=$DB_site->fetch_array($settings)) {
  	$template.="\$$setting[varname] = \"".addslashes(str_replace("\"","\\\"",$setting[value]))."\";\n";
  }

  $DB_site->query("UPDATE template SET template='$template' WHERE title='options'");
  echo "Done!\n";

  echo "<p>Upgrade to $newversion completed successfully! <br>Please delete the following files if you uploaded them: install.php, upgrade1.php, upgrade2.php, upgrade3.php, upgrade4.php, upgrade5.php, upgrade6.php";

  echo "<p>Thank you for using vBulletin.";
}

?>
</body>
</html>