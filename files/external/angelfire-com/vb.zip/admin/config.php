<?php

/////////////////////////////////////////////////////////////
// Please note that if you get any errors when connecting, //
// that you will need to email your host as we cannot tell //
// you what your specific values are supposed to be        //
/////////////////////////////////////////////////////////////

// type of database running
// (only mysql is supported at the moment)
$dbservertype='mysql';

// hostname or ip of server
$servername='localhost';

// username and password to log onto db server
$dbusername='username';
$dbpassword='pw';

// name of database
$dbname='databasename';

// allow password viewing / editing in control panel
// 0 = not visible or editable
// 1 = not visible, but can be edited
// 2 = visible and can be edited
$pwdincp=0;

// technical email address - any error messages will be emailed here
$technicalemail='youremail@yourdomain.com';

$usepconnect=0;

?>
