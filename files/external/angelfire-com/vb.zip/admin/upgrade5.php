<?php
error_reporting(7);

if (function_exists("set_time_limit")==1 and get_cfg_var("safe_mode")==0) {
  @set_time_limit(1200);
}

require ("./global.php");

?>
<HTML><HEAD>
<META content="text/html; charset=windows-1252" http-equiv=Content-Type>
<META content="MSHTML 5.00.3018.900" name=GENERATOR></HEAD>
<STYLE>
A:visited   {TEXT-DECORATION: none}
A:hover   {BACKGROUND-COLOR: #40364d; COLOR: #f5d300}
A:link        {TEXT-DECORATION: none}
A:active      {TEXT-DECORATION: none}
BODY        {CURSOR: default; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 12px}
UL            {CURSOR: default; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 12px}
LI            {CURSOR: default; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 12px}
P           {CURSOR: default; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 12px}
TD          {FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 12px}
TR          {FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 12px}
SELECT    {COLOR: #51485F; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 10px}
INPUT     {COLOR: #51485F; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 10px}
TEXTAREA  {COLOR: #51485F; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 10px}
OPTION    {COLOR: #51485F; FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 10px}
FORM      {FONT-FAMILY: Verdana, Arial, Helvetica, sans-serif; FONT-SIZE: 10px}
</STYLE>
<title>vBulletin 2.0.0 Beta 4/4.1 to Beta 5 Upgrade script</title>
</HEAD>
<BODY bgcolor="#CCCCCC" text="#3F3849" link="#3F3849" vlink="#3F3849" alink="#3F3849" leftmargin="10" topmargin="10" marginwidth="10" marginheight="10">
<p><font size=+3>vBulletin 2.0.0 Beta 4/4.1 to Beta 5 Upgrade Script</font></p>
<p><i>(Note: Please be patient as some parts of this may take some time.)</i></p>
<?php

if (!$step) {
  $step = 1;
}

// ******************* STEP 1 *******************
if ($step==1) {
  echo "This script will upgrade you from vBulletin 2.0 beta 4/4.1 to vBulletin 2.0 beta 5. If you are upgrading from a version other than beta 4/4.1, please run previous upgrade scripts first.

  <p><a href=\"upgrade5.php?step=2\">Continue with the upgrade --&gt;</a>";
}

// ******************* STEP 2 *******************
if ($step==2) {
  if ($thissetting=$DB_site->query_first("SELECT settingid FROM setting WHERE varname='pmcancelkill'")) {
    echo "It appears that you have already run this script or made the changes by hand. You will not be able to continue until you remove these additions";
    exit;
  }

  echo "Updating settings .... ";
  $DB_site->query("INSERT INTO setting (settingid,settinggroupid,title,varname,value,description,optioncode,displayorder) VALUES ('',19,'Delete \'cancelled\' messages?','pmcancelkill',0,'When users \'cancel\' messages in the message tracking area, would you like to remove the message completely? WARNING: Selecting \'yes\' could confuse users who have been notified by email about the message.','yesno',17)");
  echo "Done!<p>\n";

  echo "Adding indexes .... ";
  $DB_site->query("ALTER TABLE replacement ADD INDEX (replacementsetid)");
  $DB_site->query("ALTER TABLE subscribethread ADD INDEX (threadid)");
  $DB_site->query("ALTER TABLE subscribeforum ADD INDEX (userid)");
  echo "Done!<p>\n";

  echo "<p><a href=\"upgrade5.php?step=3\">Continue with the upgrade --&gt;</a>\n";
}

// ******************* STEP 3 *******************
if ($step==3) {
  echo "Importing new templates ....";
  $path="./vbulletin.style";

  if(file_exists($path)==0) {
  	$styletext="";
  } else {
  	$filesize=filesize($path);

  	$filenum=fopen($path,"r");

  	$styletext=fread($filenum,$filesize);

  	fclose($filenum);
  }

  if ($styletext=="") {
    echo "<p>Please ensure that the vbulletin.style file exists in the current directory and then reload this current page.</p>";
    exit;
  }

  $DB_site->query("DELETE FROM template WHERE templatesetid=-1 AND title<>'options'");
  $DB_site->query("DELETE FROM replacement WHERE replacementsetid=-1");

  $stylebits=explode("|||",$styletext);

  list($devnul,$styleversion)=each($stylebits);

  list($devnul,$style[title])=each($stylebits);
  list($devnul,$replacementset[title])=each($stylebits);
  list($devnul,$templateset[title])=each($stylebits);

  // check to see if we are installing a master template set or just a custom style set

  // installing a master!!
  $style[styleid]=-1;
  $style[userselect]=0;
  $style[replacementsetid]=-1;
  $style[templatesetid]=-1;

  // get number of replacements and templates
  list($devnull,$numreplacements)=each($stylebits);
  list($devnull,$numtemplates)=each($stylebits);

  $counter=0;
  while ($counter++<$numreplacements) {
  	list($devnull,$findword)=each($stylebits);
  	list($devnull,$replaceword)=each($stylebits);
  	if (trim($findword)!="") {
  		$DB_site->query("INSERT INTO replacement (replacementsetid,findword,replaceword) VALUES ($style[replacementsetid],'".addslashes($findword)."','".addslashes($replaceword)."')");
  	}
  }

  $counter=0;
  while ($counter++<$numtemplates) {
  	list($devnull,$title)=each($stylebits);
  	list($devnull,$template)=each($stylebits);
  	if (trim($title)!="") {
  		$DB_site->query("INSERT INTO template (templatesetid,title,template) VALUES ($style[templatesetid],'".addslashes($title)."','".addslashes($template)."')");
  	}
  }

  echo "Done!<p>\n";

  echo "<p><a href=\"upgrade5.php?step=4\">Continue with the upgrade --&gt;</a> (last step!)";
}

// ******************* STEP 4 *******************
if ($step==4) {
  // update version
  echo "Updating settings .... ";
  $DB_site->query("UPDATE setting SET value='2.0.0 beta 5' WHERE varname='templateversion'");

  $template="";
  $settings=$DB_site->query("SELECT varname,value FROM setting");
  while ($setting=$DB_site->fetch_array($settings)) {
  	$template.="\$$setting[varname] = \"".addslashes(str_replace("\"","\\\"",$setting[value]))."\";\n";
  }

  $DB_site->query("UPDATE template SET template='$template' WHERE title='options'");
  echo "Done!\n";

  echo "<p>Upgrade to 2.0 beta 5 completed successfully! <br>Please delete the following files if you uploaded them: install.php, upgrade1.php, upgrade2.php, upgrade3.php, upgrade4.php";
}

?>
</body>
</html>