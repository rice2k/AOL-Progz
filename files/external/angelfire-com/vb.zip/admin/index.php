<?php
error_reporting(7);

require("./global.php");

if ($action=="") {
  adminlog();
}

if ($redirect!="") {

  $redirect=ereg_replace("sessionhash=[a-z0-9]{32}&","",$redirect);
  $redirect=ereg_replace("\\?sessionhash=[a-z0-9]{32}","",$redirect);
  $redirect=ereg_replace("s=[a-z0-9]{32}&","",$redirect);
  $redirect=ereg_replace("\\?s=[a-z0-9]{32}","",$redirect);

  if (strpos($redirect,"?")>0) {
    $redirect.="&s=$session[dbsessionhash]";
  } else {
    $redirect.="?s=$session[dbsessionhash]";
  }

  cpheader("<meta http-equiv=\"Refresh\" content=\"0; URL=$redirect\">");
  echo "<p>Hang on a sec</p>";
  cpfooter();
  exit;
}

if (isset($action)==0) {
  $action="frames";
}

if ($action=="phpinfo") {
  phpinfo();
}

if ($action=="frames") {
?>
<html>
<head>
<title><?php echo $bbtitle?> Control Panel</title>

<frameset cols="180,*"  framespacing="0" border="0" frameborder="0" frameborder="no" border="0">

<frame src="index.php?s=<?php echo $session[sessionhash]; ?>&action=nav" name="nav" scrolling="AUTO" NORESIZE frameborder="0" marginwidth="0" marginheight="0" border="no">

<frameset rows="20,*"  framespacing="0" border="0" frameborder="0" frameborder="no" border="0">
<frame src="index.php?s=<?php echo $session[sessionhash]; ?>&action=head" name="head" scrolling="NO" NORESIZE frameborder="0" marginwidth="10" marginheight="0" border="no" >

<frame src="<?php

if ($loc!="") {
  echo $loc;
} else {
  echo "index.php?s=$session[sessionhash]&action=home";
}

?>" name="main" scrolling="AUTO" NORESIZE frameborder="0" marginwidth="10" marginheight="10" border="no">

</frameset>
</frameset>
</head>
</html><?php
}

if ($action=="head") {
?>
<HTML><HEAD>
<link rel="stylesheet" href="../cp.css">
</HEAD>
<BODY leftmargin="10" topmargin="0" marginwidth="0" marginheight="0" id="navbody">
<TABLE border=0 width="100%" height="100%">
  <TBODY>
  <TR valign="middle">
    <TD width="100%" nowrap><a href="http://www.vbulletin.com/" target="_blank">Control Panel (Version <?php echo $versionnumber.doformiddle("1477aab7"); ?>)</a></TD>
    <TD nowrap><B><a href="../index.php?s=<?php echo $session[sessionhash]; ?>"
      target="_blank">Go to your Forums Home Page</A></B> </TD>
  </TR></TBODY></TABLE></BODY></HTML>
<?php
}

if ($action=="home") {
  cpheader();

?><p><b>Welcome to the vBulletin Administrators' Control Panel</b><br>
<font size='1'>Software Developed by <a href="http://www.jelsoft.com/">Jelsoft Enterprises Limited</a></font></p>

<p><font size='1'>From here, you can control all aspects of your vBulletin forums.
Please select what you need from the links down the left hand side of this page.</font><p>

<?php

if ($moderatenewmembers==1 or $usecoppa==1) {
  $waiting=$DB_site->query_first("SELECT COUNT(*) AS users FROM user WHERE usergroupid=4");
  if ($waiting[users]==0) {
    echo "<font size='1'>There are currently $waiting[users] user(s) awaiting <a href=\"user.php?s=$session[sessionhash]&action=moderate\">moderation</a>.</font>";
  } else {
    echo "<b><a href=\"user.php?s=$session[sessionhash]&action=moderate\">There are currently $waiting[users] user(s) awaiting moderation</a>.</b>";
  }
}

?>

<form action="user.php" method="get">
<input type="hidden" name="s" value="$session[dbsessionhash]">
<input type="hidden" name="action" value="find">
<table cellpadding="0" cellspacing="10" border="0" width="90%" align="center">
<tr valign="top" align="center">
	<td width="65%">
	
	<table cellpadding="1" cellspacing="0" border="0" width="100%" align="center" class="tblborder"><tr valign="top"><td>
	<table cellpadding="4" cellspacing="0" border="0" width="100%">
	<?php
	maketableheader("Quick User Finder");
	makeinputcode("Find user(s) whose name contains ...","ausername","",1,25);
	?>
	<tr id='submitrow' align='center'>
		<td colspan='2'>
		<input type="submit" value="Search Now">
		<input type="reset" value="Reset">
		</td>
	</tr>
	</table>
	</td></tr></table>
	
	</td><td width="35%">
	
	<table cellpadding="1" cellspacing="0" border="0" width="100%" align="center" class="tblborder"><tr valign="top"><td>
	<table cellpadding="4" cellspacing="0" border="0" width="100%">
	<?php
	maketableheader("Useful Links");
	makedescription("<nobr>
		<li><a href=\"http://www.vbulletin.com/\">vBulletin Home Page</a></li>
		<li><a href=\"http://www.vbulletin.com/forum/\">vBulletin Support Forums</a></li>
		<li><a href=\"http://www.vbulletin.com/manual/\">vBulletin Online Manual</a></li>
		<li><a href=\"http://www.php.net/\">PHP Home Page</a></li>
		<li><a href=\"http://www.mysql.com/\">MySQL Home Page</a></li>
	</nobr>");
	?>
	</table>
	</td></tr></table>
	
	</td>
</tr>
<tr align="center">
	<td colspan="2">
	
	<table cellpadding="1" cellspacing="0" border="0" width="100%" align="center" class="tblborder"><tr valign="top"><td>
	<table cellpadding="4" cellspacing="0" border="0" width="100%">
	<?php
	maketableheader("vBulletin Developers & Contributors");
	makelabelcode("<b>Product Manager:</b>","<a href=\"http://www.vbulletin.com/forum/member.php?s=&action=getinfo&userid=1\" target=\"_blank\">John Percival</a>");
	makelabelcode("<b>Business Development:</b>","<a href=\"http://www.vbulletin.com/forum/member.php?s=&action=getinfo&userid=2\" target=\"_blank\">James Limm</a>");
	makelabelcode("<b>Developers:</b>","
		<a href=\"http://www.vbulletin.com/forum/member.php?s=&action=getinfo&userid=37\" target=\"_blank\">Mike 'Ed' Sullivan</a>,
		<a href=\"http://www.vbulletin.com/forum/member.php?s=&action=getinfo&userid=224\" target=\"_blank\">Freddie Bingham</a>,
		<a href=\"http://www.vbulletin.com/forum/member.php?s=&action=getinfo&userid=1034\" target=\"_blank\">Kier Darby</a>,
		<a href=\"http://www.vbulletin.com/forum/member.php?s=&action=getinfo&userid=40\" target=\"_blank\">Chris 'Stallion' Lambert</a>,
		<a href=\"http://www.vbulletin.com/forum/member.php?s=&action=getinfo&userid=146\" target=\"_blank\">Jim Frasch</a>
	");
	makelabelcode("<b>Polls:</b>","
		<a href=\"http://www.vbulletin.com/forum/member.php?s=&action=getinfo&userid=65\" target=\"_blank\">Doron Rosenberg</a>");
	makelabelcode("<b>Graphics:</b>","
		<a href=\"http://www.vbulletin.com/forum/member.php?s=&action=getinfo&userid=1034\" target=\"_blank\">Kier</a>,
		<a href=\"http://www.vbulletin.com/forum/member.php?s=&action=getinfo&userid=19\" target=\"_blank\">Menno</a>,
		<a href=\"http://www.vbulletin.com/forum/member.php?s=&action=getinfo&userid=5137\" target=\"_blank\">Robin 'Isoeph' Morrison</a>
	");
	makelabelcode("<b>Graphics</b> (logo):","<a href=\"mailto:peter@nrg.be\">Peter Van den Wyngaert</a> ( <a href=\"http://www.nrg.be\" target=\"_blank\">NRG.BE</a> )");
	?>
	</table>
	</td></tr></table>
	
	</td>
</tr>
</table>
</form>

<p align="center"><font size='1'>&copy;2000,2001 Jelsoft Enterprises Ltd.</font></p>
</body>
</html>

<?php
}

if ($action=="nav") {
?>
<html><head>
<link rel="stylesheet" href="../cp.css">
<base target="main">
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="navbody">
<a href="http://www.vbulletin.com" target="_blank"><img src="./cp_logo.gif" width="160" height="49" border="0"></a><br><?php $ratval=doformiddle("1477aab7"); ?>


<center><a href="index.php?s=<?php echo $session[sessionhash]; ?>&action=home"> Control Panel Home </a></center>
<table width="100%" border="0" cellspacing="0" cellpadding="5" id="navtable">

<tr><td><hr></td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("Options"); ?>
</table>
<a href="options.php?s=<?php echo $session[sessionhash]; ?>&action=options"> Change options </a>
</td></tr>

<tr><td><hr></td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("Announcements"); ?>
</table>
<a href="announcement.php?s=<?php echo $session[sessionhash]; ?>&action=add" class="newa"> Add </a> |
<a href="announcement.php?s=<?php echo $session[sessionhash]; ?>&action=modify"> Modify </a>
</td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("Forums and Moderators"); ?>
</table>
<a href="forum.php?s=<?php echo $session[sessionhash]; ?>&action=add"> Add </a> |
<a href="forum.php?s=<?php echo $session[sessionhash]; ?>&action=modify"> Modify </a>
</td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("Threads"); ?>
</table>
<a href="thread.php?s=<?php echo $session[sessionhash]; ?>&action=prune"> Prune </a> |
<a href="thread.php?s=<?php echo $session[sessionhash]; ?>&action=move"> Move </a> |
<a href="thread.php?s=<?php echo $session[sessionhash]; ?>&action=killpoll"> Strip Poll </a><br>
<a href="thread.php?s=<?php echo $session[sessionhash]; ?>&action=unsubscribe"> Unsubscribe thread(s) </a>
</td></tr>

<tr><td><hr></td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("Users"); ?>
</table>
<a href="user.php?s=<?php echo $session[sessionhash]; ?>&action=add"> Add </a> |
<a href="user.php?s=<?php echo $session[sessionhash]; ?>&action=modify"> Find </a> |
<a href="user.php?s=<?php echo $session[sessionhash]; ?>&action=prune"> Move/Prune </a><br>
<a href="user.php?s=<?php echo $session[sessionhash]; ?>&action=pmstats"> Private Message Stats </a><br>
<a href="user.php?s=<?php echo $session[sessionhash]; ?>&action=doips"> IP Addresses </a><br>
<a href="user.php?s=<?php echo$session[sessionhash]; ?>&action=referrers"> Referrals </a><br>
<a href="email.php?s=<?php echo $session[sessionhash]; ?>"> Email users </a><br>
<a href="email.php?s=<?php echo $session[sessionhash]; ?>&action=genlist"> Generate mailing list </a>
</td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("User Titles"); ?>
</table>
<a href="usertitle.php?s=<?php echo $session[sessionhash]; ?>&action=add"> Add </a> |
<a href="usertitle.php?s=<?php echo $session[sessionhash]; ?>&action=modify"> Modify </a>
</td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("User profile fields"); ?>
</table>
<a href="profilefield.php?s=<?php echo $session[sessionhash]; ?>&action=add"> Add </a> |
<a href="profilefield.php?s=<?php echo $session[sessionhash]; ?>&action=modify"> Modify </a>
</td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("User Groups and Permissions"); ?>
</table>
<a href="usergroup.php?s=<?php echo $session[sessionhash]; ?>&action=add"> Add </a> |
<a href="usergroup.php?s=<?php echo $session[sessionhash]; ?>&action=modify"> Modify </a><br>
<a href="forumpermission.php?s=<?php echo $session[sessionhash]; ?>&action=modify">Modify forums</a>
</td></tr>

<tr><td><hr></td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("Avatars"); ?>
</table>
<a href="avatar.php?s=<?php echo $session[sessionhash]; ?>&action=upload"> Upload </a> |
<a href="avatar.php?s=<?php echo $session[sessionhash]; ?>&action=add"> Add </a> |
<a href="avatar.php?s=<?php echo $session[sessionhash]; ?>&action=modify"> Modify </a>
</td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("Icons"); ?>
</table>
<a href="icon.php?s=<?php echo $session[sessionhash]; ?>&action=upload"> Upload </a> |
<a href="icon.php?s=<?php echo $session[sessionhash]; ?>&action=add"> Add </a> |
<a href="icon.php?s=<?php echo $session[sessionhash]; ?>&action=modify"> Modify </a>
</td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("Smilies"); ?>
</table>
<a href="smilie.php?s=<?php echo $session[sessionhash]; ?>&action=upload"> Upload </a> |
<a href="smilie.php?s=<?php echo $session[sessionhash]; ?>&action=add"> Add </a> |
<a href="smilie.php?s=<?php echo $session[sessionhash]; ?>&action=modify"> Modify </a>
</td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("Custom BB codes"); ?>
</table>
<a href="bbcode.php?s=<?php echo $session[sessionhash]; ?>&action=add"> Add </a> |
<a href="bbcode.php?s=<?php echo $session[sessionhash]; ?>&action=modify"> Modify </a>
</td></tr>

<tr><td><hr></td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("Backup database"); ?>
</table>
<a href="backup.php?s=<?php echo $session[sessionhash]; ?>&action=choose"> Backup choices </a>
</td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("Import & Maintenance"); ?>
</table>
<a href="bbimport.php?s=<?php echo $session[sessionhash]; ?>"> BB Import Systems </a><br>
<a href="misc.php?s=<?php echo $session[sessionhash]; ?>"> Update counters... </a>
</td></tr>

<?php
if ($debug) {
?><tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("Settings</b> (Don't edit unless you are sure)<b>","",0); ?>
</table>
<a href="setting.php?s=<?php echo $session[sessionhash]; ?>&action=add"> Add setting </a> |
<a href="setting.php?s=<?php echo $session[sessionhash]; ?>&action=modify"> Modify </a><br>
<a href="setting.php?s=<?php echo $session[sessionhash]; ?>&action=addgroup"> Add group </a>
</td></tr>
<?php
}
?>
<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("Stats & Logs"); ?>
</table>
<a href="stats.php?s=<?php echo $session[sessionhash]; ?>"> View Statistics </a><br>
<a href="adminlog.php?s=<?php echo $session[sessionhash]; ?>"> View Admin Logs </a>
</td></tr>

<tr><td><hr></td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("Styles"); ?>
</table>
<a href="style.php?s=<?php echo $session[sessionhash]; ?>&action=add"> Add </a> |
<a href="style.php?s=<?php echo $session[sessionhash]; ?>&action=modify"> Modify </a><br>
<a href="style.php?s=<?php echo $session[sessionhash]; ?>&action=download"> Download / Upload </a>
</td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("Replacement variables"); ?>
</table>
<a href="replacement.php?s=<?php echo $session[sessionhash]; ?>&action=add"> Add </a> |
<a href="replacement.php?s=<?php echo $session[sessionhash]; ?>&action=modify"> Modify </a><br>
<a href="replacement.php?s=<?php echo $session[sessionhash]; ?>&action=addset"> Add replacement set </a><?php echo $ratval; ?>
</td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("Templates"); ?>
</table>
<a href="template.php?s=<?php echo $session[sessionhash]; ?>&action=add"> Add </a> |
<a href="template.php?s=<?php echo $session[sessionhash]; ?>&action=modify"> Edit </a> |
<a href="template.php?s=<?php echo $session[sessionhash]; ?>&action=search"> Search </a><br>
<a href="template.php?s=<?php echo $session[sessionhash]; ?>&action=addset"> Add template set </a>
<?php
if ($debug) {
?>
<br><a href="template.php?s=<?php echo $session[sessionhash]; ?>&action=downloadset"> Download template set </a><br>
<a href="template.php?s=<?php echo $session[sessionhash]; ?>&action=uploadset"> Upload template set </a><br>
<a href="template.php?s=<?php echo $session[sessionhash]; ?>&action=imgtags"> Do img tags </a><br>
<?php
}
?>
</td></tr>

<tr><td><hr></td></tr>

</table>
</BODY></HTML>
<?php
}

?>