<?php
error_reporting(7);

require ("./global.php");

echo "Importing new templates<br>";
$path="./vbulletin.style";

if(file_exists($path)==0) {
	$styletext="";
} else {
	$filesize=filesize($path);

	$filenum=fopen($path,"r");

	$styletext=fread($filenum,$filesize);

	fclose($filenum);
}

if ($styletext=="") {
  echo "<p>Please ensure that the vbulletin.style file exists in the current directory and then reload this current page.</p>";
  exit;
}

$DB_site->query("DELETE FROM template WHERE templatesetid=-1 AND title<>'options'");
$DB_site->query("DELETE FROM replacement WHERE replacementsetid=-1");

$stylebits=explode("|||",$styletext);

list($devnul,$styleversion)=each($stylebits);

list($devnul,$style[title])=each($stylebits);
list($devnul,$replacementset[title])=each($stylebits);
list($devnul,$templateset[title])=each($stylebits);

// check to see if we are installing a master template set or just a custom style set

// installing a master!!
$style[styleid]=-1;
$style[userselect]=0;
$style[replacementsetid]=-1;
$style[templatesetid]=-1;

// get number of replacements and templates
list($devnull,$numreplacements)=each($stylebits);
list($devnull,$numtemplates)=each($stylebits);

$counter=0;
while ($counter++<$numreplacements) {
	list($devnull,$findword)=each($stylebits);
	list($devnull,$replaceword)=each($stylebits);
	if (trim($findword)!="") {
		$DB_site->query("INSERT INTO replacement (replacementsetid,findword,replaceword) VALUES ($style[replacementsetid],'".addslashes($findword)."','".addslashes($replaceword)."')");
	}
}

$counter=0;
while ($counter++<$numtemplates) {
	list($devnull,$title)=each($stylebits);
	list($devnull,$template)=each($stylebits);
	if (trim($title)!="") {
		$DB_site->query("INSERT INTO template (templatesetid,title,template) VALUES ($style[templatesetid],'".addslashes($title)."','".addslashes($template)."')");
	}
}

echo "Templates imported correctly<br>";

if (!$thissetting=$DB_site->query_first("SELECT settingid FROM setting WHERE varname='minsearchlength'")) {

	echo "The following templates have changed: modifyavatar, modifyavatarbit, getinfo, forumdisplaybit, searchresultbit_threadonly<br>";
	echo "If you have edited any of the templates above, please compare your custom template to the default one stored in the database, and make any changes necessary.<br>";


	echo "Adding new settings<br>";

	// Added the minsearchlength and maxsearchlength options to the search section in the CP.
	$DB_site->query("INSERT INTO setting VALUES (NULL,10,'Minimum Word Length','minsearchlength','4','Enter the minimum word length that the search engine is to index.  The smaller this number is, the larger your search index, and conversely your database is going to be.','',4)");
	$DB_site->query("INSERT INTO setting VALUES (NULL,10,'Maximum Word Length','maxsearchlength','20','Enter the maximum word length that the search engine is to index.  The larger this number is, the larger your search index, and conversely your database is going to be.','',5)");

	// New options for avatars
	$DB_site->query("INSERT INTO setting VALUES (NULL,26,'Display Height','numavatarshigh','5','How many rows of avatars do you wish to display to the user when selecting an avatar?','',7)");
	$DB_site->query("INSERT INTO setting VALUES (NULL,26,'Display Width','numavatarswide','5','How many columns of avatars do you wish to display to the user when selecting an avatar?','',8)");

	// New Poll thread prefix setting
	$DB_site->query("INSERT INTO setting VALUES (NULL,9,'Prefix for Polls','pollthreadprefix','Poll: ','Prefix to append to the beginning of Poll thread titles.','',12)");

	//Minimum/Maximum Username settings
	$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Minimum Username Length','minuserlength','3','Enter the minimum length a user can register with.','',15)");
	$DB_site->query("INSERT INTO setting VALUES (NULL,6,'Maximum Username Length','maxuserlength','15','Enter the maximum length a user can register with.','',16)");

	// Duplicate Attachments Settings
	$DB_site->query("INSERT INTO setting VALUES (NULL,27,'Allow Duplicate Images','allowduplicates','1','Disable this option to prevent users from uploading duplicate images. Doing so checks the actual data so it can be resource intensive depending on your attachment sizes and number of attachments in your database.','yesno',6)");

	//- FRESH INSTALLS ONLY: missing setting for forum display depth
	if (!$DB_site->query_first("SELECT settingid FROM setting WHERE varname='forumdisplaydepth'")) {
		$DB_site->query("INSERT INTO setting VALUES (NULL,9,'Depth of Forums', 'forumdisplaydepth', '2', 'Depth of forums to show on forum display when displaying subforums. Do not go too large on this value for performance reasons.', '', '13')");
	}

	echo "Added new settings<br>";

	// - Support for ordering the custom profile fields
	$DB_site->query("ALTER TABLE profilefield ADD displayorder SMALLINT not null");

	//  - FRESH INSTALLS ONLY: missing userfield on installs
	$min=$DB_site->query_first("SELECT MIN(userid) AS min FROM user");
	$DB_site->query("INSERT IGNORE INTO userfield (userid) VALUES ('$min[min]')");

	if (!$DB_site->query_first("SELECT styleid FROM style WHERE styleid=1")) {
		//  - FRESH INSTALLS ONLY: missing default style:
		$DB_site->query("INSERT IGNORE INTO style VALUES (1, 1, 1, 'Default', 1)");
	}

	echo "DB structure updated correctly<br>";

	$DB_site->query("UPDATE setting SET value='2.0.0 beta 2' WHERE varname='templateversion'");

	$template="";
	$settings=$DB_site->query("SELECT varname,value FROM setting");
	while ($setting=$DB_site->fetch_array($settings)) {
		$template.="\$$setting[varname] = \"".addslashes(str_replace("\"","\\\"",$setting[value]))."\";\n";
	}

	$DB_site->query("UPDATE template SET template='$template' WHERE title='options'");

	echo "<p>Upgrade to 2.0 beta 2 completed successfully";
} else {
	echo "<p><b>We have detected that you have already attempted to run this upgrade. Please revert to an unmodified beta 1 database before proceeding.</b>";
}

?>