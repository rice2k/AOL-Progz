<?php
error_reporting(7);

$oldversion = "2.0.0 Release Candidate 1";
$newversion = "2.0.0 Release Candidate 2";
$thisscript = "upgrade7.php";

function gotonext($extra="") {
	global $step,$thisscript;
	$nextstep = $step+1;
	echo "<p><a href=\"$thisscript?step=$nextstep\">Continue with the upgrade --&gt;</a> $extra</p>\n";
}

if (function_exists("set_time_limit")==1 and get_cfg_var("safe_mode")==0) {
  @set_time_limit(1200);
}

require ("./global.php");

?>
<HTML><HEAD>
<META content="text/html; charset=windows-1252" http-equiv=Content-Type>
<META content="MSHTML 5.00.3018.900" name=GENERATOR></HEAD>
<link rel="stylesheet" href="../cp.css">
<title>vBulletin <?php echo $oldversion ?> to <?php echo $newversion ?> Upgrade script</title>
</HEAD>
<BODY>
<p><font size=+2>vBulletin <?php echo $oldversion ?> to <?php echo $newversion ?> Upgrade Script</font></p>
<p><i>(Note: Please be patient as some parts of this may take some time.)</i></p>
<?php

if (!$step) {
  $step = 1;
}

// ******************* STEP 1 *******************
if ($step==1) {
  ?>
  <p>This script will upgrade you from vBulletin <?php echo $oldversion ?> to vBulletin <?php echo $newversion ?>. If you are upgrading from a version other than <?php echo $oldversion ?>, please run previous upgrade scripts first.</p>

  <ul>
  <li>Installing a new version: run <i>install.php</i><br><br>
  <li>Upgrading from vBulletin 1.1x: run <i>upgrade1.php</i><br><br>
  <li>Upgrading from vBulletin 2.0 beta 1: run <i>upgrade2.php, upgrade3.php, upgrade4.php, upgrade5.php, upgrade6.php, upgrade7.php</i>
  <li>Upgrading from vBulletin 2.0 beta 2: run <i>upgrade3.php, upgrade4.php, upgrade5.php, upgrade6.php, upgrade7.php</i>
  <li>Upgrading from vBulletin 2.0 beta 3: run <i>upgrade4.php, upgrade5.php, upgrade6.php, upgrade7.php</i>
  <li>Upgrading from vBulletin 2.0 beta 4: run <i>upgrade5.php, upgrade6.php, upgrade7.php</i>
  <li>Upgrading from vBulletin 2.0 beta 5: run <i>upgrade6.php, upgrade7.php</i>
  <li>Upgrading from vBulletin 2.0 RC1: run <i>upgrade7.php</i> (this file)
  </ul>

  <?php

  gotonext();

}

// ******************* STEP 2 *******************
if ($step==2) {
  echo "<b>Updating settings ....</b>";

	// alter descriptions
	$DB_site->query("UPDATE setting SET description='The default option is to require unique email addresses for each registered user. This means that no two users can have the same email address. You can disable this requirement by choosing NO for this option.' WHERE varname='requireuniqueemail'");
	$DB_site->query("UPDATE setting SET description='The password is emailed to the new member after they submit their registration to confirm their identity and email address. If account is not activated, they will remain in the \"users awaiting activation\" usergroup.' WHERE varname='verifyemail'");
	$DB_site->query("UPDATE setting SET description='The text with which to prefix a thread that has been moved to another forum. (You may use HTML)' WHERE varname='movedthreadprefix'");
	$DB_site->query("UPDATE setting SET description='Prefix to append to the beginning of thread titles that have been set to \"Sticky\". These threads always appear at the top of the thread list. (You may use HTML)' WHERE varname='stickythreadprefix'");
	$DB_site->query("UPDATE setting SET description='Prefix to append to the beginning of Poll thread titles. (You may use HTML)' WHERE varname='pollthreadprefix'");
	$DB_site->query("UPDATE setting SET description='Do you want to use the Forumjump drop-down menu on your pages?  If your mysql server is optimized and you still are having problems you can try disabling this option to save queries.' WHERE varname='useforumjump'");
	$DB_site->query("UPDATE setting SET description='Enable email sending features: send to friend and email notification for posters and moderators. Don\'t forget to remove those links from the <i>forumdisplay, newreply, newtopic</i>, &amp; <i>editpost</i> templates<br><br>You can turn off the \'Send to Friend\' feature for invidual user groups in the <a href=\"usergroup.php?s=$session[sessionhash]&action=modify\" target=\"_blank\">User Permissions area</a>.' WHERE varname='enableemail'");
	$DB_site->query("UPDATE setting SET description='Type all words you want censored in the field below. Do not use commas to separate words, just use spaces. For example, type \"dog cat boy\", rather than \"dog, cat, boy.\" If you type \"dog\", all words containing the string \"dog\" would be censored (dogma, for instance, would appear as \"***ma\"). To censor more accurately, you can require that censors occur only for exact words. You can do this by placing a censor word in curly braces, as in {dog}. Signifying \"dog\" in the curly braces would mean that dogma would appear as dogma, but dog would appear as \"***\". Thus your censor list may appear as: cat {dog} {barn} barn<br>Do not use quotation marks and make sure you use curly braces, not parentheses, when specifying exact words.<br>This field can contain a maximum 250 characters.' WHERE varname='censorwords'");
	$DB_site->query("UPDATE setting SET description='This is the word that will prefix the title of \"cancelled\" messages in the <i>message tracking</i> section. (You may use HTML)' WHERE varname='pmcancelledword'");
	$DB_site->query("UPDATE setting SET description='Use this option to enable/disable the overall use of avatars.<br><br>Avatars are small images displayed under usernames in thread display and user info pages.' WHERE varname='avatarenabled'");
	$DB_site->query("UPDATE setting SET description='Setting this to NO will cause the post to refer to the previous existence of the attachment instead of adding another copy of it to the database. It only checks for attachments posted by the user that is making the post.' WHERE varname='allowduplicates'");

  echo "Done!<p>\n";

  gotonext();
}

// ******************* STEP 3 *******************
if ($step==3) {

  echo "<b>Importing new templates ....</b>";
  $path="./vbulletin.style";

  if(file_exists($path)==0) {
  	$styletext="";
  } else {
  	$filesize=filesize($path);

  	$filenum=fopen($path,"r");

  	$styletext=fread($filenum,$filesize);

  	fclose($filenum);
  }

  if ($styletext=="") {
    echo "<p>Please ensure that the vbulletin.style file exists in the current directory and then reload this current page.</p>";
    exit;
  }

  $DB_site->query("DELETE FROM template WHERE templatesetid=-1 AND title<>'options'");
  $DB_site->query("DELETE FROM replacement WHERE replacementsetid=-1");

  $stylebits=explode("|||",$styletext);

  list($devnul,$styleversion)=each($stylebits);

  list($devnul,$style[title])=each($stylebits);
  list($devnul,$replacementset[title])=each($stylebits);
  list($devnul,$templateset[title])=each($stylebits);

  // check to see if we are installing a master template set or just a custom style set

  // installing a master!!
  $style[styleid]=-1;
  $style[userselect]=0;
  $style[replacementsetid]=-1;
  $style[templatesetid]=-1;

  // get number of replacements and templates
  list($devnull,$numreplacements)=each($stylebits);
  list($devnull,$numtemplates)=each($stylebits);

  $counter=0;
  while ($counter++<$numreplacements) {
  	list($devnull,$findword)=each($stylebits);
  	list($devnull,$replaceword)=each($stylebits);
  	if (trim($findword)!="") {
  		$DB_site->query("INSERT INTO replacement (replacementsetid,findword,replaceword) VALUES ($style[replacementsetid],'".addslashes($findword)."','".addslashes($replaceword)."')");
  	}
  }

  $counter=0;
  while ($counter++<$numtemplates) {
  	list($devnull,$title)=each($stylebits);
  	list($devnull,$template)=each($stylebits);
  	if (trim($title)!="") {
  		$DB_site->query("INSERT INTO template (templatesetid,title,template) VALUES ($style[templatesetid],'".addslashes($title)."','".addslashes($template)."')");
  	}
  }

  echo "Done!<p>\n";

  gotonext();
}

// ******************* STEP 4 *******************
if ($step==4) {
  // update template.title index

  echo "Updating an index on template table...";
  $DB_site->reporterror=0;
  $DB_site->query("ALTER TABLE template DROP INDEX title, ADD INDEX (title(30),templatesetid)");
  $DB_site->reporterror=1;

  echo "done!";

  gotonext("(last step!)");
}

// ******************* STEP 5 *******************
if ($step==5) {
  // update version
  echo "Updating version number .... ";
  $DB_site->query("UPDATE setting SET value='$newversion' WHERE varname='templateversion'");

  $template="";
  $settings=$DB_site->query("SELECT varname,value FROM setting");
  while ($setting=$DB_site->fetch_array($settings)) {
  	$template.="\$$setting[varname] = \"".addslashes(str_replace("\"","\\\"",$setting[value]))."\";\n";
  }

  $DB_site->query("UPDATE template SET template='$template' WHERE title='options'");
  echo "Done!\n";

  echo "<p>Upgrade to $newversion completed successfully! <br>Please delete the following files if you uploaded them: install.php, upgrade1.php, upgrade2.php, upgrade3.php, upgrade4.php, upgrade5.php, upgrade6.php, upgrade7.php";

  echo "<p>Thank you for using vBulletin.";
}

?>
</body>
</html>
