<?php
error_reporting(7);

$templatesused = "postbit_useremail,icq,aim,yahoo,postbit_homepage,postbit_sendpm,postbit_profile,memberlistbit,memberlist,memberlistsearch";

require("./global.php");

if (!$enablememberlist) {
  eval("standarderror(\"".gettemplate("error_nomemberlist")."\");");
  exit;
}

if (!isset($action) or $action=="") {
  $action="getall";
}

if (intval($perpage)==0) {
  // NUMBER OF RECORDS PER PAGE
  $perpage = $memberlistperpage;
}

if (intval($pagenumber)==0) {
  $pagenumber=1;
}

$permissions=getpermissions();
if (!$permissions[canview] or !$permissions[canviewmembers]) {
  show_nopermission();
}

if ($action=="getall") {

  // get conditions
  $condition="1=1";
  if ($usememberlistadvsearch) {
    if ($ausername!="") {
      $condition.=" AND username LIKE '%".addslashes($ausername)."%' ";
    }
    if ($email!="") {
      $condition.=" AND email LIKE '%".addslashes($email)."%' ";
    }
    if ($homepage!="") {
      $condition.=" AND homepage LIKE '%".addslashes($homepage)."%' ";
    }
    if ($icq!="") {
      $condition.=" AND icq LIKE '%".addslashes($icq)."%' ";
    }
    if ($aim!="") {
      $condition.=" AND aim LIKE '%".addslashes($aim)."%' ";
    }
    if ($yahoo!="") {
      $condition.=" AND yahoo LIKE '%".addslashes($yahoo)."%' ";
    }
    if ($joindateafter!="") {
      $condition.=" AND joindate>UNIX_TIMESTAMP('".addslashes(strtolower($joindateafter))."')";
    }
    if ($joindatebefore!="") {
      $condition.=" AND joindate<UNIX_TIMESTAMP('".addslashes(strtolower($joindatebefore))."')";
    }
    if ($lastpostafter!="") {
      $condition.=" AND lastpost>UNIX_TIMESTAMP('".addslashes(strtolower($lastpostafter))."')";
    }
    if ($lastpostbefore!="") {
      $condition.=" AND lastpost<UNIX_TIMESTAMP('".addslashes(strtolower($lastpostbefore))."')";
    }
    $postslower=intval($postslower);
    if ($postslower!="") {
      $condition.=" AND posts>'$postslower'";
    }
    $postsupper=intval($postsupper);
    if ($postsupper!="") {
      $condition.=" AND posts<'$postsupper'";
    }
  } else {
    $orderby="";
    $direction="";
  }

  if ($what=="topposters") {
    $orderby="posts";
    $direction="DESC";
  }
  if ($what=="datejoined") {
    $orderby="joindate";
    $direction="DESC";
  }

  if ($orderby=="" or ($orderby!="username" and $orderby!="posts" and $orderby!="joindate" and $orderby!="lastpost")) {
    $orderby="username";
  }

  $memberlistbit = "";
  $perpage = intval($perpage);
  $limitlower=($pagenumber-1)*$perpage+1;
  $limitupper=($pagenumber)*$perpage;
  $counter=0;

  $userscount=$DB_site->query_first("SELECT COUNT(*) AS users
                                     FROM user,userfield
                                     WHERE $condition AND
                                           user.userid = userfield.userid
                                           ".iif($memberAllGood, " AND usergroupid NOT IN (1,3,4) ", "")."
                                           ");
  $totalusers=$userscount[users];
  if ($limitupper>$totalusers) {
    $limitupper=$totalusers;
    if ($limitlower>$totalusers) {
      $limitlower=$totalusers-$perpage;
    }
  }
  if ($limitlower<=0) {
    $limitlower=1;
  }

  $users=$DB_site->query("SELECT *
                          FROM user,userfield
                          WHERE $condition AND
                                user.userid = userfield.userid
                                ".iif($memberAllGood, " AND usergroupid NOT IN (1,3,4) ", "")."
                          ORDER BY $orderby $direction
                          LIMIT ".($limitlower-1).",$perpage");

  $counter=0;
  while ($userinfo=$DB_site->fetch_array($users) and $counter++<$perpage) {

    $post=$userinfo;

    $userinfo[datejoined]=vbdate($dateformat,$userinfo[joindate]);

    if ($userinfo[showemail] and $displayemails) {
      eval("\$userinfo[useremail] = \"".gettemplate("postbit_useremail")."\";");
    } else {
      $userinfo[useremail]="&nbsp;";
    }
    if ($userinfo[icq]!="") {
      eval("\$userinfo[icqicon] = \"".gettemplate("icq")."\";");
    } else {
      $userinfo[icq]="&nbsp;";
    }
    if ($userinfo[aim]!="") {
      eval("\$userinfo[aimicon] = \"".gettemplate("aim")."\";");
    } else {
      $userinfo[aim]="&nbsp;";
    }
    if ($userinfo[yahoo]!="") {
      eval("\$userinfo[yahooicon] = \"".gettemplate("yahoo")."\";");
    } else {
      $userinfo[yahoo]="&nbsp;";
    }

    if ($userinfo[homepage]!="" and $userinfo[homepage]!="http://") {
      eval("\$userinfo[homepage] = \"".gettemplate("postbit_homepage")."\";");
    } else {
      $userinfo[homepage]="&nbsp;";
    }

    if ($userinfo[receivepm]) {
      eval("\$userinfo[pmlink] = \"".gettemplate("postbit_sendpm")."\";");
    } else {
      $userinfo[pmlink] = "&nbsp;";
    }

    eval("\$userinfo[profile] = \"".gettemplate("postbit_profile")."\";");

    eval("\$memberlistbits .= \"".gettemplate("memberlistbit")."\";");

  }  // end while

  $pagenav = getpagenav($totalusers,"memberlist.php?s=$session[sessionhash]&action=$action&what=$what&perpage=$perpage&orderby=$orderby&ausername=$ausername&ahomepage=$ahomepage&aicq=$aicq&aaim=$aaim&ayahoo=$ayahoo&joindateafter=$joindateafter&joindatebefore=$joindatebefore&lastpostafter=$lastpostafter&lastpostbefore=$lastpostbefore&postslower=$postslower&postsupper=$postsupper&direction=$direction");

  eval("dooutput(\"".gettemplate("memberlist")."\");");
} #end if ($action=="getall")

if ($action=="search") {
  if (!$usememberlistadvsearch) {
    eval("standarderror(\"".gettemplate("error_nomemberlistsearch")."\");");
    exit;
  }

  eval("dooutput(\"".gettemplate("memberlistsearch")."\");");

} #end if ($action=="search")

?>