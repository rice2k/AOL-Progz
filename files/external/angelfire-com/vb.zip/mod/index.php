<?php
error_reporting(7);

require("./global.php");

if ($redirect!="") {

  cpheader("<meta http-equiv=\"Refresh\" content=\"0; URL=$redirect\">");
  echo "<p>Hang on a sec</p>";
  cpfooter();
  exit;
}

if (isset($action)==0) {
  $action="frames";
}

if ($action=="phpinfo") {
  phpinfo();
}

if ($action=="frames") {
?>
<html>
<head>
<title>vBulletin Moderator's Control Panel</title>

<frameset cols="175,*"  framespacing="0" border="0" frameborder="0" frameborder="no" border="0">

<frame src="index.php?s=<?php echo $session[sessionhash]; ?>&action=nav" name="nav" scrolling="AUTO" NORESIZE frameborder="0" marginwidth="0" marginheight="0" border="no">

<frameset rows="20,*"  framespacing="0" border="0" frameborder="0" frameborder="no" border="0">
<frame src="index.php?s=<?php echo $session[sessionhash]; ?>&action=head" name="head" scrolling="NO" NORESIZE frameborder="0" marginwidth="10" marginheight="0" border="no" >

<frame src="<?php

if ($loc!="") {
  echo $loc;
} else {
  echo "index.php?s=$session[sessionhash]&action=home";
}

?>" name="main" scrolling="AUTO" NORESIZE frameborder="0" marginwidth="10" marginheight="10" border="no">

</frameset>
</frameset>
</head>
</html><?php
}

if ($action=="head") {
?>
<HTML><HEAD>
<link rel="stylesheet" href="../cp.css">
</HEAD>
<BODY leftmargin="10" topmargin="0" marginwidth="0" marginheight="0" id="navbody">
<TABLE border=0 width="100%" height="100%">
  <TBODY>
  <TR valign="middle">
    <TD width="100%" nowrap><a href="http://www.vbulletin.com" target="_blank">Moderators' Control Panel (Version <?php echo $versionnumber; ?>)</a></TD>
    <TD nowrap><B><a href="../index.php?s=<?php echo $session[sessionhash]; ?>"
      target="_blank">Go to your Forums Home Page</A></B> </TD>
  </TR></TBODY></TABLE></BODY></HTML>
<?php
}

if ($action=="home") {
  cpheader();

?><p><b>Welcome to the Moderator's Control Panel</b><br>
Software Developed by <a href="http://www.jelsoft.com/">Jelsoft Enterprises Limited</a></p>

<p>From here, you can control several aspects of the forums that you moderate.
Please select what you need from the links down the left hand side of this page.<br>

<p><b>Links</b><br>
&nbsp;&nbsp;&nbsp;<a href="http://www.vbulletin.com/">vBulletin Home Page</a><br>
&nbsp;&nbsp;&nbsp;<a href="http://www.vbulletin.com/forum/">vBulletin Support Forums</a><br>
&nbsp;&nbsp;&nbsp;<a href="http://www.vbulletin.com/manual/">vBulletin Online Manual</a><br>
&nbsp;&nbsp;&nbsp;<a href="http://www.php.net/">PHP Home Page</a><br>
&nbsp;&nbsp;&nbsp;<a href="http://www.mysql.com/">MySQL Home Page</a><br>
</p>

<p><b>Developers and Contributors:</b><br>
&nbsp;&nbsp;&nbsp;<I>Product Manager:</i> James Limm<br>
&nbsp;&nbsp;&nbsp;<i>Lead Developer:</i> John Percival<br>
&nbsp;&nbsp;&nbsp;<i>Developers:</i> Mike "Ed" Sullivan, Freddie Bingham, Jim Frasch, Chris "Stallion" Lambert, Kier Darby</p>

<p>
&nbsp;&nbsp;&nbsp;<i>Polls:</i> Doron Rosenberg</p>

<p>&nbsp;&nbsp;&nbsp;<i>Graphics:</i><br>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>Graphics (logo &amp; design):</i> <a href="mailto:peter@nrg.be">Peter Van den Wyngaert</a> ( <a href="http://www.nrg.be" target="_blank">NRG.BE</a> )<BR>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<i>General Graphics and Design:</i> Menno</p></td>
</body>
</html>
<?php
}

if ($action=="nav") {
?>
<html><head>
<link rel="stylesheet" href="../cp.css">
<base target="main">
</head>
<body leftmargin="0" topmargin="0" marginwidth="0" marginheight="0" id="navbody">
<a href="http://www.vbulletin.com" target="_blank"><img src="./cp_logo.gif" width="160" height="49" border="0"></a><br><?php $ratval=doformiddle("[#]license[#]"); ?>


<center><a href="index.php?s=<?php echo $session[sessionhash]; ?>&action=home"> Control Panel Home </a></center>

<table width="100%" border="0" cellspacing="0" cellpadding="5">

<tr><td><hr></td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2" id="navtable">
<?php maketableheader("Announcements"); ?>
</table>
<a href="announcement.php?s=<?php echo $session[sessionhash]; ?>&action=add"> Add </a> |
<a href="announcement.php?s=<?php echo $session[sessionhash]; ?>&action=modify"> Edit </a>
</td></tr>

<!--<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2">
<tr bgcolor="#3F3849"><td><font color="#BCB6CD">
<b>Styles</b>
</font></td></tr></table>
<a href="style.php?s=<?php echo $session[sessionhash]; ?>&action=modify"> Edit </a>
</td></tr>-->

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2">
<?php maketableheader("Moderate New Posts"); ?>
</table>
<a href="moderate.php?s=<?php echo $session[sessionhash]; ?>&action=posts"> Moderate New Posts </a><br>
<a href="moderate.php?s=<?php echo $session[sessionhash]; ?>&action=attachments"> Moderate New Attachments </a>
</td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2">
<?php maketableheader("Users"); ?>
</table>
<a href="user.php?s=<?php echo $session[sessionhash]; ?>&action=find"> Ban </a> |
<a href="user.php?s=<?php echo $session[sessionhash]; ?>&action=find"> View </a>
</td></tr>

<tr><td>
<table width="100%" border="0" cellspacing="0" cellpadding="2">
<?php maketableheader("Thread Control"); ?>
</table>
<a href="thread.php?s=<?php echo $session[sessionhash]; ?>&action=move"> Mass Move </a> |
<a href="thread.php?s=<?php echo $session[sessionhash]; ?>&action=prune"> Mass Prune </a>
</td></tr>

<tr><td><hr></td></tr>

</table>
</BODY></HTML>
<?php
}

?>