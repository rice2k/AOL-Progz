<?php

eval("\$messagecenter .= \"".gettemplate('messagecenter')."\";");

?>