<HTML DIR="RTL" LANG="AR-SA">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1256">
<title>��� ��� ������</title>

<style><!--
A. {color=#AFDCEB};text-decoration:none;}
A.:hover {color=#CC3233;}
A.:visited {color=#2F96BA;}
A.:visited:hover {color=#CC3233;}
//-->
</style></head>
<body bgcolor="#004F67" >

<?php 
echo"<marquee direction=\"right\" dir=rtl scrolldelay=\"200\">";
$maxthreads =10; 
require("./admin/config.php") ; 
$db=mysql_connect($servername,$dbusername,$dbpassword); 
mysql_select_db($dbname); 
$query = "SELECT * FROM thread  ORDER BY threadid DESC LIMIT $maxthreads"; 
$resultlatest = mysql_query($query,$db); 
while ($latest_array = mysql_fetch_array($resultlatest)) { 
echo "<font size=4><a target=\"_blank\" href=\"./showthread.php?threadid=$latest_array[threadid]\" >$latest_array[title]
</A></font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"; 

} 
echo "</marquee>";
?> 

</body>
</html>