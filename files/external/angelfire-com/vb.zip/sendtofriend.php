<?php
error_reporting(7);

$templatesused = "sendtofriend,email_sendtofriend,redirect_sentemail";

require("./global.php");

if (!isset($action) or $action=="") {
  $action="showsend";
}

if (!$enableemail) {
  eval("standarderror(\"".gettemplate("error_emaildisabled")."\");");
  exit;
}

$threadid = verifyid("thread",$threadid);
$threadinfo=getthreadinfo($threadid);
$permissions=getpermissions($threadinfo[forumid]);
if (!$permissions[canview] or !$permissions[canemail]) {
  show_nopermission();
}

if ($action=="showsend") {

  if ($wordwrap!=0) {
    $threadinfo[title]=dowordwrap($threadinfo[title]);
  }

  eval("dooutput(\"".gettemplate("sendtofriend")."\");");

}

if ($HTTP_POST_VARS['action']=="sendfriend") {

  if ($sendtoname=="" or $sendtoemail=="" or $emailsubject=="" or $emailmessage=="") {
    eval("standarderror(\"".gettemplate("error_requiredfields")."\");");
    exit;
  }

  eval("\$message = \"".gettemplate("email_sendtofriend",1,0)."\";");

  mail($sendtoemail,$emailsubject,$message,"From: \"$bbtitle Mailer\" <$webmasteremail>");

  eval("standardredirect(\"".gettemplate("redirect_sentemail")."\",\"showthread.php?s=$session[sessionhash]&threadid=".intval($threadid)."\");");
}

?>