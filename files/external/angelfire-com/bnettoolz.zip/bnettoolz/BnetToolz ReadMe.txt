+======================================+
|Downloaded from http://66.197.205.195/|
|  (Soon to be brimstonedragons.com)   |
+======================================+

Bnet Toolz �
By: Faze
Bahufas@hotmail.com

Copyright � 2001
World OutRage Production

Get the latest news and updates for Bnet Toolz at
www.worldoutrage.com

Bnet Toolz is designed for chat manipulation using the 
Battle.net game client. It is NOT a $%&$ing bot!! If you 
thought I was trying to make a bot, then you were 
wrong, and you can stop making fun of me now...
Bnet Toolz has been tested on WarCraft II BNE, 
StarCraft, and StarCraft Brood War.

Bnet Toolz is freeware, meaning that you use this 
program AT YOUR OWN RISK!! Don't come crying to me 
if you get flooded from Bnet cuz you scrolled something 
too fast, it aint my fault. Bnet Toolz was made with as 
much anti-flood protection I could think of, but it can still 
happen. If you'd like to see something added to Bnet 
Toolz, email me what it is you'd like to see, and I'll try to 
do it. If you don't wanna email me a comment, question, 
or suggestion... then post it up on the forum at 
www.worldoutrage.com

As you have read, Bnet Toolz is protected under 
Copyright law, so don't be lame and make a reproduction 
(hexed) program and call it your own. If you do 
reproduce Bnet Toolz, this includes adding a virus, this 
is what's known as a felony and I am under legal rights 
to sue your lamer ass.

Thanks goes out to:
VisualParadox.com - for all of the graphics
nobody - for helping me

Thank you for downloading/stealing Bnet Toolz!

==============================================
Also: I will not teach anyone how to make a Bnet proggie, 
so don't bother asking... it's just too hard to explain. All I 
can say is, pick up a Visual Basic book and start readin. 
A good place to look for help is www.vbforums.com 
If someone would like to help me make the next version of 
Bnet Toolz, email me and attatch a small sample program 
that you've made.
