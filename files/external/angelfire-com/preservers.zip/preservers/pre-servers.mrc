;Name: Previous Servers List.
;Written By: JAMARO
;jamaro@37.com
;http://come.to/jamaro
;Feb 2001
;==================================

;===Previous Servers List===>>
on *:connect:/pre-server
alias pre-server {
  if ($server $port == %pre-server1) || ($server $port == %pre-server2) || ($server $port == %pre-server3) || ($server $port == %pre-server4) || ($server $port == %pre-server5) || ($server $port == %pre-server6) || ($server $port == %pre-server7) || ($server $port == %pre-server8) || ($server $port == %pre-server9) || ($server $port == %pre-server10) { halt }
  inc %con.no
  if (%con.no == 1) { set %pre-server1 $server $port }
  if (%con.no == 2) { set %pre-server2 $server $port }
  if (%con.no == 3) { set %pre-server3 $server $port }
  if (%con.no == 4) { set %pre-server4 $server $port }
  if (%con.no == 5) { set %pre-server5 $server $port }
  if (%con.no == 6) { set %pre-server6 $server $port }
  if (%con.no == 7) { set %pre-server7 $server $port }
  if (%con.no == 8) { set %pre-server8 $server $port }
  if (%con.no == 9) { set %pre-server9 $server $port }
  if (%con.no == 10) { set %pre-server10 $server $port }
  if (%con.no >= 10) { set %con.no 0 }
}
menu status,menubar,channel {
  Previous Servers
  .%pre-server1 :/server %pre-server1
  .%pre-server2 :/server %pre-server2
  .%pre-server3 :/server %pre-server3
  .%pre-server4 :/server %pre-server4
  .%pre-server5 :/server %pre-server5
  .%pre-server6 :/server %pre-server6
  .%pre-server7 :/server %pre-server7
  .%pre-server8 :/server %pre-server8
  .%pre-server9 :/server %pre-server9
  .%pre-server10 :/server %pre-server10
  .-
  .Clear List:/unset %pre-server* %con.no
}
alias thank dialog -mo thank thank
dialog thank {
  title "Add-ons By Jamaro 2001"
  size -1 -1 200 180
  box "",1,5 0 190 70
  text "Thank you for loading this Add-on written by jamaro. Please visit my website for more add-ons and other IRC tools. Have fun.",2,10 12 180 50,left
  box "",3,5 68 190 86
  text "jamaro@37.com",4,10 80 180 15,center
  edit "http://come.to/jamaro",5,33 100 130 22,center,read
  button "Visit",6,70 127 50 20
  button "Close",7,5 158 190 20,ok
}
on *:dialog:thank:init:0:/did -f thank 6
on *:dialog:thank:sclick:6:/run http://come.to/jamaro
on *:load:if ($version > 5.41) { thank }
