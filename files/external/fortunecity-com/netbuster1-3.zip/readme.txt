NetBuster 1.30

NetBuster is Win 95/98/NT  tool to fool with the people trying to fool you 
with NetBus.  It also removes any NetBus server from your system if found.
Earlier versions didn't discovered renamed NetBus files, but this has been
improved in this version.  It should now remove all NetBus servers.

How it works:

NetBuster emulates the NetBus server so that the intruder THINKS 
he's fooling around with you. But instead all his actions will be logged, 
and you will be able to fool him instead.    This is a typical NetBuster log:

127.0.0.1  [localhost.swipnet.se]
Connected at 1998-11-16 [01:15:46]
01:16:05: Open CD-ROM
01:16:07: Get Allowed IP numbers
01:16:24: Close server
01:16:25: Set Allowed IP's [130.244.100.23|]
01:16:33: Screen Dump
01:16:50: Start Application : crash.exe
01:16:54: Get Info  [Infomessage(s) sent back]
01:17:06: Get Applications Running
01:17:11: Kill Application [Program Manager]
01:17:20: Download [Retrieve Directory Listing]
01:18:28: Delete file [c:\WINDOWS\EXPLORER.EXE]
01:19:28: Download File [d:\Internet\Nuke.exe]
127.0.0.1 disconnected at 1998-11-16 [01:19:43]

Note that NOTHING will happen to you, his actions will just be logged.

How you can fool them:

You can set an info message to be sent when he requests info about you.
You can send multiple messages which can be very annoying to the intruder. 
You can select a picture to be sent as a screen dump, a wavfile to be sent 
as a recording, a fake directory tree to be sent when he tries to examine your 
harddrive and a file to be sent as the file he tries to download from you.
You can make the balance controls fool around for a while before they stop.

This is some of the functions, check it out to realise how fun it can be
to fool people back!

The latest version of netbuster can be found at http://surf.to/netbuster

H�kan Bergstr�m




